---
name: chinese-celestial-palace-video
description: Create Chinese celestial-palace films, game trailers or concept boards from themes and references, with continuity and quality reports. Not for ads, fast action or modern science fiction.
trigger-words:
- celestial palace video
- Chinese immortal palace
- 暗宫明境
- 中式仙宫视频
- 仙宫场景视频
- 角色资产图
- 道具资产图
- 角色连续性
---

# Chinese Celestial Palace Video

Use this Skill for three related but distinct production directions: (1) a cinematic film sequence with atmosphere and narrative beats, (2) a game PV with character/world hooks and readable escalation, or (3) a concept-design package with scene keyframes, worldbuilding variants, and optional motion proof. All directions share the “dark palace, bright wonder” identity: shaded architectural thresholds open onto luminous immortal landscapes, while tiny figures, controlled reflections, stable structures, and ancient-cosmic traces establish scale. The process is staged and reviewable; never run the whole production through without confirmation.

The visual reference set in `references/xiaohongshu-xian-gong-style-reference.md` contains two user-provided Xiaohongshu videos: “世人皆赴凡尘，我独往云上仙宫” and “苍松嵌古殿，明月浮云海”. Use the extracted videos and their evidence as a combined visual-language library when no higher-priority reference is supplied: Chinese celestial architecture, framed reveals, three-layer depth, cinematic CG material detail, slow parallax, architecture-nature integration, mirror reflections, floating islands, and optional gravity-inverted celestial structures. This is a style and camera-language reference, not a source for copying characters, exact shots, music, text, or frame-by-frame composition. User-provided references override it; an explicit request for a different style disables it.

## STEP 0: Lock Global Specifications

Create a concise production specification document and confirm the following values:

- 16:9 landscape format.
- Five shots unless the user explicitly changes the count.
- Character and prop anchor assets default to GPT Image 2.
- Scene/environment anchor images default to Midjourney 8.2 (MJ V8).
- Approved character, prop, and scene anchors are passed directly to each video shot as multimodal references. Do not generate an intermediate final-keyframe image.
- Storyboard planning images, when needed, default to GPT Image 2 and remain planning documents only; they are not opening frames or mandatory video inputs.
- Visual direction: immense, elegant, minimalist Chinese celestial palace; sacred scale; restrained ancient-cosmic science-fiction undertone.
- Prompt language and audience-facing language follow the user’s confirmed requirements.
- Before any image-generation stage, ask the user to choose the visual medium: **真人画面风格** or **写实CG动画风格**. Do not infer this choice from the subject or references; carry the confirmed choice through character, prop, scene, storyboard, and video prompts.
- Production direction: choose one mode before planning. **Film** prioritizes atmosphere, spatial revelation, and restrained narrative continuity; **Game PV** prioritizes a readable character hook, world premise, escalation, and a memorable reveal without turning into combat by default; **Concept Design** prioritizes breadth, world-system exploration, architecture, props, activity studies, and labeled scene variants, with video optional. The skill is not an advertising workflow and must not invent product claims, CTA copy, sales messaging, or commercial beats.
- Interaction level: choose quiet, lively, or dramatic-but-controlled. Lively interaction is the default for Film and Game PV unless the user requests contemplative stillness; Concept Design may include multiple interaction studies.

Pause for confirmation before designing the five-shot variation plan. The visual-medium choice must be confirmed before any image generation begins.

## STEP 1: Build and Review the Variation Card

Design one Variation Card for all five shots. Select one route family per shot from:

1. Giant Pine Cloud-Viewing Temple
2. Moon Gate Astral Terrace Palace
3. Cloudfall Cliff Palace
4. Jade Pool Mirror-Sky Palace
5. Infinite Column-Corridor Celestial Palace
6. Cloud-Sea Flower Garden Palace
7. Floating-Island Bridge Corridor Palace
8. Solitary Peak Observatory Palace

Additive worldbuilding scene families (available in the same candidate pool; do not stack two families as simultaneous primary routes):

9. Frost Bridge Celestial Workshop / Cold-Jade Star-Forging Palace
10. Tidal Listening Palace / Cloud-Sea Moon-Tide Water Court
11. Silent Hundred-Bird Garden / Seasonal Flower-Calendar Palace
12. Sunken Bell Corridor / Silent Ritual Memory Palace
13. Cloud-Below Waystation / Immortal Ferry Transit Order

These five families expand the world beyond observation terraces. They may introduce a celestial workshop, tide-observation water court, seasonal ecology palace, sound-and-ritual archive, or quiet transit waystation, while preserving the core dark-threshold-to-bright-wonder identity.

Scene-family anchors:

- Frost Bridge Celestial Workshop: cold-jade platforms, a suspended star-forging well, and one giant jade star disk; activities may include incense making, star-ledger checking, or inkstone washing.
- Tidal Listening Palace: shallow tidal steps, a single white-jade ferry, and moon-tide reflections; activities may include recording the tide, releasing one water lamp, or washing an inkstone.
- Silent Hundred-Bird Garden: seasonal flower-calendar terraces and one quiet butterfly or crane; activities may include flower arranging, making blank flower paper, planting a seed, or observing a cloud sign.
- Sunken Bell Corridor: a long dark acoustic corridor, one monumental plain bronze bell, and a distant ritual road; activities may include bell-rubbing, checking a bell rope, preparing a zither, or greeting with folded hands.
- Cloud-Below Waystation: a silent transit pavilion, one stationary white-jade ferry, a suspended cable, and a cloud gorge; activities may include packing a travel case, drying herbs, checking a ferry knot, sending a blank jade tablet, or a quiet farewell.

For each expanded family, introduce only one main wonder and keep tools small and visibly present in the shot. Do not turn workshops into machinery, gardens into crowded markets, ritual spaces into performances, or waystations into action scenes.

Assign five different composition grammars. Choose from deep dark hall framing outward, giant circular moon-gate framing, diagonal cliff corridor, open cliff terrace, mirror-pool foreground/background, one-point column corridor, horizontal old-pine division, low-horizon interior reveal, stepped vertical depth, or palace-wall/cloudfall widescreen.

For every shot assign:

- A distinct space type and foreground frame.
- Exactly one main wonder: ancient pine, moon or planet, cloud waterfall, solitary peak and suspended palace, white-stone sky road or infinite corridor, flower garden, jade-pool reflection, or layered cliff palace corridor.
- At most one ancient-cosmic trace, with conspicuous large rings used in no more than two shots.
- One quiet elegant activity and its required props. Existing activities include tea, chess, music, excursion, horse riding, listening to rain, sea viewing, reading, and calligraphy. Expanded activities include star-ledger checking, tide recording, bell-rubbing, cloud-sign observation, incense making, inkstone washing, flower arranging, paper-making, knot tying, lamp repair, jade polishing, preparing a zither, packing a travel case, drying herbs, checking a ferry, sending a blank jade tablet, a quiet farewell, greeting with folded hands, receiving a scroll, waiting at a ritual terrace, standing before a star altar, tending a lamp, feeding koi, releasing a crane, touching an old pine, collecting dew, or catching a wisp of cloud. Every activity requires its tools or props to be visibly present in the shot contract and generated video. Horse riding is outdoor-only and may appear in no more than one shot; music uses one principal instrument.
- Camera position, wind direction, brightness structure, and figure arrangement.
- Optional living element, no more than one type in a shot: three to five koi, one to three white cranes, or a very distant Kunpeng silhouette. Use living elements in no more than three shots.

### Variation Deduplication Gate

Before video-contract authoring, compare every pair. If two shots share two of these three fields—space type, foreground frame, main wonder—redesign one shot. Also verify five different composition grammars, five different main wonders, at least four activities, no consecutive activity repetition, and, when the expanded pool is used, at least two activity categories among observation, craft, travel, ritual, and nature. Do not use more than two strict centered-symmetry shots, one exterior palace-city view, or one long bridge axis. When a workshop, transit, or ritual scene appears, keep at least two shots as pure observation spaces so the film remains tranquil.

Present the completed Variation Card and pause for user approval. For Film, include a beginning state, a spatial or emotional turn, and an end state. For Game PV, include a character/world hook, a controlled escalation, and a final reveal. For Concept Design, present five independent but compatible design studies and label which studies are intended as environment concepts, interaction studies, or prop studies.

## STEP 1.5: Build Character, Prop, and Scene Anchor Assets

Before generating video shots, establish the complete asset anchor set. Character and prop anchors use GPT Image 2; scene/environment anchors use Midjourney 8.2 (MJ V8). Approved anchors are passed directly into video generation as multimodal references. Do not create an intermediate final-keyframe image.

- Before generation begins, ask the user to choose one visual medium: **真人画面风格** or **写实CG动画风格**. Record the answer as a global production lock and apply it to every anchor, storyboard, and video prompt.
- Generate separate character anchor images for each recurring primary character or recognizable role with GPT Image 2. Make silhouette, face when allowed, hairstyle, costume layers, sleeves, accessories, body proportions, and signature markings easy to inspect.
- Generate separate prop anchor images for every continuity-critical object with GPT Image 2. Show the complete object, functional parts, material, scale cues, and distinctive symbols without unrelated scene composition.
- Generate a scene/environment anchor image for each major location or reusable world space with Midjourney 8.2. Scene anchors establish architecture, depth, threshold-to-wonder composition, materials, atmosphere, and the main environmental wonder; they must not be treated as character identity sources.
- When a character and prop must interact, generate their character and prop anchors separately first, then optionally create one interaction reference. Do not use a crowded group sheet as the only identity source.
- Record an anchor contribution map for every asset: identity, costume/design, role, prop geometry/material, interaction relationship, scene/world structure, composition, and environmental wonder. The map is internal production state and must travel with every later video task that uses the anchor.
- After every anchor is generated, run a quality check and report results to the user. Do not automatically regenerate or modify any asset when issues are found. Wait for an explicit user decision before changing any character, prop, or scene anchor.
- After all required anchors pass, present the complete character/prop/scene anchor set and pause for user confirmation before generating video shots.

## STEP 2: Prepare Direct-to-Video Shot Contracts

Do not generate final keyframe images. Convert the approved Variation Card and anchor contribution maps directly into one video contract per shot.

For every shot:

- Use the approved character, prop, and scene anchors as multimodal references in stable order: character anchors first, prop anchors second, scene anchor last.
- State the contribution of every reference: identity, costume/design, prop geometry/material, interaction relationship, scene/world structure, composition, or environmental wonder.
- Preserve the confirmed visual medium, 16:9 ratio, shot order, character identity, continuity-critical prop state, and established location.
- Define the opening state in text from the approved shot contract; no generated still is required as an opening frame.
- Describe one readable primary action, up to two secondary environmental responses, one restrained camera move, intended sound, and a stable end state.
- Make continuity-critical details visible through framing. If a missing shoe, hand-held prop, rope, bell striker, or exchange drives the story, use a shot scale and staging that keeps it readable.
- Do not add subtitles, text overlays, new characters, new props, combat, modern technology, or an unapproved story beat.

Inspect the five video contracts for reference completeness, action visibility, identity continuity, prop-state continuity, scene continuity, and sound fit. Report any missing or weak elements to the user. Do not silently rewrite or reauthor contracts without an explicit user request. Then pause for user confirmation before the high-cost video generation stage.

## Interaction Design: Make the Palace Feel Alive

Before animation, assign an interaction pattern to every shot. Keep the main wonder readable, but allow people and environment to respond to one another rather than merely pose. Use one primary interpersonal or human-environment exchange and up to two secondary reactions.

### Human-to-human patterns

- Passing an object: a cup, scroll, lamp, jade tablet, flower, rope, or travel bundle moves once from one person to another; both hands and the object remain anatomically stable.
- Coordinated attention: two or more figures turn, lean, or shift their gaze toward the same cloud, sound, bird, moon, or distant structure, with slight timing offsets rather than synchronized mannequin motion.
- Guided movement: one person leads another around a pool, along a railing, across a threshold, or toward a ferry; preserve spacing and avoid marching.
- Shared task: one holds a tray, lamp, scroll, instrument, or tool while another performs one small operation.
- Social acknowledgment: a glance, half-turn, folded-hands greeting, sleeve gesture, or brief pause communicates relation without dialogue or exaggerated acting.
- Protective or playful response: a person steadies a companion near a step, shields a lamp from wind, or reacts to a koi, crane, falling leaf, or drifting mist; keep the movement gentle and non-comedic unless explicitly requested.

### Human-to-environment patterns

- Fabric and architecture respond together: sleeves and sashes lift as a figure passes a column, doorway, bridge, or open terrace; mist parts slightly and settles behind them.
- Water responds to presence: one footstep, dropped petal, water lamp, sleeve edge, or hand creates a small local ripple that does not distort the whole reflection.
- Light responds subtly: a cloud gap reveals a person, a lamp brightens a nearby face or prop, or a moon reflection shifts with a small water movement; never change the global lighting direction.
- Living elements acknowledge people: koi approach a hand, one crane turns its head, a butterfly follows a flower, or a pine branch brushes a passing sash; never use swarms or sudden attacks.
- Sound has spatial consequence: a bell causes a tiny dust or mist response, a plucked string disturbs a hanging tassel, or a footstep causes a faint echo gesture in water; do not visualize energy beams.
- Objects have weight and friction: a jade door slides a short distance, a rope tightens, a lamp rocks once, a scroll unfurls slightly, or a ferry settles against its mooring.

Interaction guardrails: one primary exchange per shot, one or two secondary environmental responses, no teleporting props, no duplicated hands or bodies, no sudden weather, no architecture morphing, no combat choreography unless the user explicitly requests a controlled action variant. Keep each action readable with a clear start, contact/response, and rest state.

## STEP 3: Generate Each Shot Directly from Approved Anchors

Process shots in order, passing only that shot’s approved character, prop, and scene anchors as multimodal references. Use low motion and high structure preservation. The video prompt must bind every reference role, then describe the opening state, motion, interaction, sound, and stable end state without reinventing identity, architecture, props, lighting, wonder, or activity.

Use one very slow move per shot: slow lateral slide, slow push-in, slow pull-back, slight rise, or locked camera. Add one to three subtle environmental motions: drifting clouds, mist between columns, steady waterfall, pine needles, pool ripples, incense smoke, or slow fabric movement. If people are present, always include low-amplitude robe and sash motion in the same wind direction.

Choose one primary activity or interaction micro-action per shot:

- Tea: one person slowly raises the cup slightly; tea smoke rises.
- Chess: one hand slowly places one piece; board and seats remain fixed.
- Music: fingertips barely pluck or a flute player subtly adjusts breath; instrument remains fixed.
- Excursion: figures take one or two slow steps; spacing remains fixed.
- Horse: horse walks one or two quiet steps; mane and tail move gently.
- Rain: fine rain and eaves drips continue; figures remain listening.
- Sea viewing: a tiny head turn or weight shift; railing relation remains fixed.
- Reading: fingers support the scroll; page edge moves once.
- Calligraphy: brush completes one small stroke; paper contains no readable writing.

If the expanded worldbuilding pool is selected, apply these additional rules:

- A new scene family may change the middle observation/life system, but must retain the three-layer space, one main wonder, stable architecture, controlled reflections, unified wind, and restrained ancient-cosmic trace.
- Treat activity props as narrative anchors, not oversized hero objects; figures remain small and quiet.
- New scene families and existing families participate in the same deduplication check.
- Keep modern technology out of all expansions: no spacecraft, robots, armor, HUDs, data streams, LED strips, industrial hatches, or cyberpunk forms.
- Use no more than one living-element type per shot and no more than three living-element shots in the five-shot set.

If the generated clip does not clearly preserve a required pose, prop state, or interaction, do not silently repair the contract or regenerate the shot. Report the failure, list the affected shot and the specific issue, and stop. The user decides whether to accept the result, request a reauthored contract, or order a regeneration.

The final second of every clip must hold still. Avoid cuts, morphing, rapid camera movement, exaggerated acting, weather changes, global lighting changes, new people, unplanned props, or activity changes. A planned interaction may move an existing prop or trigger a local environmental response, but it must settle before the hold.

## Direction-Specific Deliverables

- **Film mode:** deliver five continuity-conscious video shots and an ordered sequence; emphasize mood, spatial discovery, character relation, and an emotionally legible end state.
- **Game PV mode:** deliver five promotional narrative shots without advertising copy; emphasize a character hook, world rule, controlled interaction or confrontation, escalation, and a final playable-world reveal. Combat is optional, not assumed.
- **Concept Design mode:** deliver a curated set of independent environment/prop/interaction studies or boards for environment, architecture, props, character placement, and interaction studies. Keep variants distinct and annotate the design purpose; assemble video only when the user requests motion proof or a concept teaser.

## STEP 5: Assemble and Deliver

After all five clips are complete, assemble them strictly as Shot 1 → Shot 5. Use direct cuts or restrained 0.3–0.5 second fades. Preserve a slow, airy, ceremonial rhythm; do not use beat cutting or flashy transitions. Keep audio silent or extremely restrained ambient sound unless the user supplied or approved music. Hold the composition during the last second of each shot.

Before delivery verify 16:9 output, no black bars, no text overlays, no watermark, correct shot order, stable structures, and no duplicate or newly invented content. Report the final video and the editable production documents.

## Quality Check and Failure Reporting Rules

- The Skill is single-pass: every asset, contract, and shot is generated once, then inspected and reported.
- Quality checks produce a written report listing pass or issue for every asset, every video contract, and every generated shot. Do not silently rewrite, modify, or regenerate any output.
- The user decides whether to accept the result, request a reauthored contract, or order a regeneration. Only regenerate when the user explicitly asks, and keep successful outputs intact while doing so.
- Never silently change the locked image model, ratio, shot order, visual medium, or approved visual identity.
- If a required model, input, or assembly capability is unavailable, stop at the relevant stage and explain the exact decision needed from the user.
