---
name: wool-felt-story-short
description: |
  Create flexible wool-felt story shorts from narration or scripts with staged review, resolution choices, timed voices, reusable assets, shot generation, and assembly. Not for stills or miniatures.
trigger-words: [wool felt animation, felt story short, narrated felt video, wool-felt short, handmade felt story, realistic-scale felt world]
---

# Wool Felt Story Short

Use this Skill when the user wants a complete format-flexible story video in which real-world characters, scenes, and props are rebuilt with visible wool-felt material. The workflow is deliberately gated: do not advance to the next production node until the user confirms the current node.

## Core production contract

- The default final aspect ratio is `9:16`; supported alternatives are `16:9`, `1:1`, `4:3`, `3:4`, and `21:9`.
- Choose and lock one supported aspect ratio in the Final Video Spec before storyboard approval. Never silently change the user-approved ratio.
- Before asset generation, present and lock an image-resolution choice card: `1K` or `2K`. If the user already stated one of these options explicitly, record it as locked and do not ask again. This choice applies to generated character, scene, and prop images; user-supplied images are bound directly and are not regenerated solely to change resolution.
- Before video-shot generation, present and lock a video-resolution choice card: `768P` or `2K`. If the user already stated one of these options explicitly, record it as locked and do not ask again. Use the locked choice for every generated shot and final video derivative unless the user explicitly revises it. If the active generation capability cannot produce the selected resolution, explain the incompatibility and obtain a new user choice; never silently change resolution or generation capability.
- The visual baseline is a full-size realistic-scale felt world, not a miniature, diorama, puppet stage, doll, or toy display.
- Default motion is smooth, soft, fluid, and naturally readable rather than stiff or stop-motion-like.
- SFX are baked into each generated video shot; do not create a separate SFX layer unless the user explicitly asks for replacement or enhancement.
- MiniMax-H3 is the default video model. If the user explicitly selects another model, check its capabilities first and follow that choice when compatible; after a failure, retry once for the diagnosed cause, then switch to another compatible available model instead of repeatedly forcing the same model.
- Select one audio mode before storyboard approval: `narration` for a narrator-led story, or `dialogue` for characters speaking on screen. Do not mix modes implicitly.
- Voice-over timing is authoritative in `narration` mode: each narration paragraph and its corresponding shot must have the same duration, and the complete narration must be audible without truncation or rushed omission.
- Dialogue timing is authoritative in `dialogue` mode: every line must have a speaker, exact text, start/end time, and paired shot; dialogue must be complete and must not be rushed. The default dialogue source is the original character audio generated inside each approved video shot; do not generate separate TTS clips after shot approval unless the user explicitly requests replacement dubbing, an independent dialogue track, or repair.
- In mixed `narration` + `dialogue` mode, build and approve a per-shot audio timeline before video generation: measure or generate each narration paragraph at natural speed, place dialogue lines in non-overlapping windows, reserve explicit gaps where needed, and set shot duration from the complete audio plan. Never generate a fixed-duration shot first and then lay a longer narration track over dialogue. Narration and dialogue must not overlap unless the user explicitly requests intentional simultaneous speech.
- The audio timeline is the source of truth for shot timing. Each shot's `audio_timeline` must record `narration_start`, `narration_end`, `dialogue_start`, `dialogue_end`, any `audio_gap`, and `shot_duration`. If a narration paragraph does not fit naturally, extend the shot, split it at a semantic boundary, or revise the timing before video generation; do not compress speech unnaturally. During mix, place tracks by their approved timecodes and use ducking only for ambience or SFX, never as a substitute for separating two speaking voices.
- Optional BGM is recommended only after the voice-over version of the final video has been assembled and reviewed.
- When BGM is approved, target the final cut duration but do not require native exact length. If the generated BGM is longer than the final cut, trim it directly to the final cut duration with a clean ending. If it is shorter, loop it as needed to cover the final cut, then trim the looped result to the exact final-cut duration; do not stretch it unnaturally.
- The no-BGM voice-over final cut is a preserved deliverable. The BGM version must be exported as a separate new asset and must never overwrite, replace, or hide the original no-BGM version.
- Default BGM mix level must be clearly audible beneath the narration and ambience, while ducking or lowering it whenever it competes with speech; do not use an inaudibly low background level.
- Preserve the user's exact narration copy when it becomes voice-over text; do not rewrite it for style. In `dialogue` mode, preserve every approved character line verbatim and bind it to the correct speaker.
- For any character with a transformation, disguise, costume change, or other persistent state change, define and generate each required state separately. A transformed character must have a dedicated post-transformation reference image and must be bound explicitly to the shots after the change; do not rely on the pre-transformation reference alone.
- Keep every planner document and generated asset in the active project workspace, using returned asset references for downstream work.

## Step 1: Receive and validate the copy

Accept plain text narration, a script, or a story copy as the primary input. Do not require a reference video. Optional character, scene, prop, or style images may be accepted, but the built-in wool-felt baseline is sufficient when none are supplied.

Extract only what the copy supports: title or working title, estimated duration, topic, emotional arc, named characters, locations, props, narration language, and possible audio cues. Do not invent factual claims or character details that are not needed for visual continuity.

If the copy is missing or too fragmentary to identify a primary story, ask for the copy before planning. Otherwise continue to Step 2.

Choose the audio mode from the user's intent: use `narration` when a narrator tells the story; use `dialogue` when characters speak to one another or deliver on-screen lines. If both are explicitly requested, use mixed `narration` + `dialogue` mode, record separate tracks, and keep their roles distinct. Before fixing shot lengths, estimate or generate the natural duration of every narration paragraph and dialogue line, then reserve non-overlapping time windows for all speaking content.

## Step 2: Write and review `Final_Video_Spec.md`

Create a concise production specification containing:

- title or working title;
- locked aspect ratio selected from `9:16`, `16:9`, `1:1`, `4:3`, `3:4`, or `21:9`;
- estimated total duration derived from normal narration speed, approximately 5–6 Chinese characters per second or the equivalent natural reading pace;
- aspect-ratio-specific framing, safe-area, and composition requirements;
- unresolved image-resolution choice (`1K` or `2K`) and video-resolution choice (`768P` or `2K`);
- subject and story premise;
- theme, emotional direction, and ending intent;
- narration language and whether narration is expected to be generated later;
- the built-in wool-felt visual baseline;
- confirmed and unresolved choices.

Pause here. Ask the user to confirm or revise the estimated duration, current theme, narration language, and aspect ratio. Do not ask the asset-resolution cards here unless image or video generation is about to begin; present each resolution card at the corresponding generation gate. Treat the user's reply as the authoritative lock for this stage.

## Step 3: Design the storyboard

Using the locked specification and the original copy, create a storyboard with three top-level components: `key_elements`, `shot_list`, and `audio_layers`.

### `key_elements`

Define every reusable character, scene, and prop. Each item must include a written description and a field reserved for the later bound reference-image asset.

For characters, specify body type, readable facial features, clothing colors, distinctive silhouette traits, and the appropriate felt proportion tier:

- **Realistic-cute** by default for primary characters: approximately 1:3–1:4 head-to-body ratio, rounded warm face, normal body and limb proportions. Do not use chibi, super-deformed, doll-like, puppet, or toy-figurine language.
- **Moderately chibi** for secondary or one-shot passerby characters: approximately 1:2 head-to-body ratio, rounded features, clear expression.
- **Highly chibi** only for crowds, symbolic groups, or emotional crowd cues: simplified but readable faces and large-head/small-body shorthand.

For scenes, buildings, food, and props, preserve true real-world shape and scale. They should look like ordinary full-size rooms, streets, restaurants, utensils, or food rebuilt entirely in felt, never like a miniature set.

Each scene or prop description must cover dominant color direction, component structure, and light type. Use muted warm color language unless the copy or a confirmed reference requires another palette.

For transformation stories, add a separate `character_states` entry for every visible state, such as `frog_prince_before` and `human_prince_after`. Each state must describe its silhouette, face, costume, accessories, and continuity anchors, and reserve its own reference-image asset.

### `shot_list`

Order shots as `Shot 1`, `Shot 2`, `Shot 3`, and so on. Every shot must include duration, visual subject and action, atmosphere, camera movement, reference bindings, and a narration reference.

Use narrative boundaries rather than mechanical equal division, but never assign a fixed duration before timing the narration. First divide the copy into narration paragraphs, estimate or synthesize each paragraph at a natural pace, and set the paired shot duration to exactly the same duration. The complete paragraph must fit inside that shot without truncation, omission, or unnatural speed-up. If a paragraph exceeds the selected video model's maximum duration, split it at a semantic sentence or action boundary into multiple narration/shot pairs; do not squeeze it into one clip. If a paragraph is shorter than the model's minimum, combine it with the adjacent compatible paragraph or pad the paired shot only with a deliberate silent visual beat while keeping the narration clip's full duration explicit. Each shot must contain 2–4 internal time segments, and the segment ranges must cover the exact shot duration. Every segment states a time range, the visible action or emotional beat, and the camera movement. The visual focus must directly answer the narration at that moment: if the narration says that food comes out of the pot, show the food coming out; if it describes an emotion, show that emotion through readable face and posture.

Do not let a shot continue showing the previous beat while narration describes a new turn. Keep spatial relations and character identity continuous across adjacent shots.

### `audio_layers`

In `narration` mode, contain the optional cross-shot BGM plan and shot-level narration references. In `dialogue` mode, contain a dialogue table with `speaker`, `line`, `start`, `end`, `shot_id`, `voice_id`, and `mouth_state`; keep dialogue, optional narration, BGM, and baked-in SFX as distinct roles. In mixed `narration` + `dialogue` mode, add an `audio_timeline` for every shot with `narration_start`, `narration_end`, `dialogue_start`, `dialogue_end`, `audio_gap`, and `shot_duration`. Speaking windows must not overlap, and any intentional overlap must be explicitly approved. Do not put baked-in SFX here.

### Narration voice lock

Before any video generation, video assembly, or narration generation, the Storyboard must include a locked `narration_voice` block whenever narration is used. Record: language and accent; perceived gender and age; timbre characteristics; speaking speed; emotional range; narration style; and one fixed `voice_id`. Use that same `voice_id` and voice settings for every narration clip. Do not select a new voice per shot. If the user has not supplied a voice, prepare catalog options and lock one before proceeding.

### Storyboard validation

Before presenting the storyboard, verify:

- every narration passage is assigned to one shot;
- every shot has 2–4 timed segments;
- each segment has action plus camera movement;
- every narration paragraph has an explicit duration and its paired shot has exactly the same duration;
- in `dialogue` mode, every line has one speaker, one voice binding, explicit timing, and a matching shot;
- whenever narration is used, the Storyboard contains a complete locked `narration_voice` block with language/accent, perceived gender/age, timbre, speed, emotion, style, and one fixed `voice_id`;
- in `dialogue` mode, each shot identifies the active speaker and keeps non-speaking visible characters silent or in a reaction state;
- the complete narration text is preserved and fits without truncation or rushed delivery;
- shot duration matches the amount of copy at a natural speaking pace;
- visual action and narration are semantically aligned;
- each recurring character and scene has a reusable element definition;
- there is no accidental miniature, puppet, doll, or toy-stage interpretation.
- every transformation, disguise, or persistent character-state change has a separate reference asset and an explicit shot binding before and after the change;

Pause and present the shot structure. Ask the user to confirm the storyboard and the narration-to-picture correspondence.

## Step 4: Generate reusable element images

Generate one image per required element, preferably as a batch by element type. Before generating element images, present an image-resolution choice card with exactly two options: `1K` and `2K`, unless the user has already explicitly selected one. Lock the user's selection for all generated element images in this project. If the active image capability cannot produce it, explain the incompatibility and ask the user to choose a compatible path before generation; never substitute a different resolution silently. Use the locked project aspect ratio and selected image resolution for the element sheet, with a white background and three views: front view, side view, and three-quarter back view from left to right. If the user supplied a suitable element image, bind it directly and do not regenerate it.

Every image prompt begins with this exact visual anchor:

`wool felt animation style, real-world scene and characters rendered entirely in wool felt material, visible fiber texture covering all surfaces, soft rounded forms with no sharp edges, smooth and fluid motion, natural movement, warm muted color palette — full-size felt world at realistic scale, NOT miniature, NOT diorama, NOT puppet, NOT toy figurine; characters have clearly defined facial features (eyes, nose, mouth fully visible and readable)`

Then add the concrete subject description, at least two material cues such as visible wool fibers, slightly uneven handmade surface, soft fabric sheen, or felted texture, muted colors, and the fixed three-view composition. Use soft diffused lighting and no harsh shadows. Do not ask the image model to render text.

Pause after all element images are available. Ask the user to confirm wool-felt consistency and character/scene identity before video generation. Keep the locked image resolution in the project record.

## Step 5: Generate video shots one at a time

Before generating the first video shot, present a video-resolution choice card with exactly two options: `768P` and `2K`, unless the user has already explicitly selected one. Lock the user's selection for every generated shot and final video derivative. Generate exactly one shot per production call, in storyboard order, using the locked project aspect ratio and locked video resolution. Combine the relevant character front-view reference and scene-wide reference whenever both exist. Use the storyboard duration and its exact internal time segments. Before each video call, verify that the shot duration equals the complete approved `audio_timeline` for that shot. In mixed mode, verify that every narration and dialogue window fits inside the shot, that speaking windows do not overlap, and that the paired narration duration is fully covered. If not, repair the audio timeline and shot duration before generating.

Each video prompt follows this order:

1. reference binding, using ordered image placeholders such as `<<<image_1>>>`;
2. the exact wool-felt visual anchor;
3. scene atmosphere and realistic scale;
4. timecoded action and camera direction for every storyboard segment;
5. natural SFX markers such as `<soft fabric rustling>` or `<quiet kitchen ambience>`;
6. the fixed ending constraints: `no subtitles, no text overlay, no sharp edges, no realistic human skin, no CG glossy material, no puppet, no doll figurine, no miniature diorama, no toy stage`.

Prefer smooth slow push-ins, gentle tracking, soft pans, and natural dolly movement. Avoid handheld shake, rapid zooms, jerky camera movement, frantic gestures, stiff motion, or random scene changes. If narration is a separate track, use `<no dialogue, narration on separate track>` and do not place the narration copy inside the video prompt. In `dialogue` mode, use the approved speaker binding and timecoded line; direct mouth movement only to the active speaker, keep other visible characters closed-mouth or reacting, and do not let narration or BGM trigger lip-sync. The shot's original generated dialogue audio is the default dialogue track and must be preserved through assembly.
For a transformation shot, bind both the pre-change and post-change character states when visible, describe the transition beat explicitly, and use the post-change reference for every subsequent shot.

After every generated shot, stop and ask the user to confirm felt texture, character continuity, SFX, and rhythm. Only a clear confirmation advances to the next shot. If a shot fails, repair only that shot while preserving its approved storyboard contract; do not regenerate already approved shots.

## Step 6: Generate voice-over and recommend BGM after the first final cut

When all video shots are individually approved, prepare the audio for final assembly according to the locked mode. In `narration` mode, generate the voice-over before assembly if the user confirmed narration, using the exact shot-level narration references and preserving wording and order. Use the Storyboard's locked `narration_voice` block and its fixed `voice_id` for every narration clip; do not substitute another voice without revising and re-locking the Storyboard. In `dialogue` mode, do not generate new dialogue TTS after shot approval: use and preserve the original character dialogue audio generated inside each approved video shot. In mixed mode, generate narration from the locked voice profile, preserve the approved in-shot dialogue audio, and place both tracks according to the approved `audio_timeline`; never mix them as unscheduled full-length tracks. Only create replacement or separate dialogue clips when the user explicitly requests them.

For `narration` mode, produce one narration clip per paired shot, or another explicitly timed structure that retains the same shot boundaries. The narration clip duration is the shot duration contract.

Before assembly, validate every pair:

- narration text exactly matches the approved storyboard copy;
- narration duration equals the approved narration window in the paired shot;
- in mixed mode, narration and dialogue speaking windows do not overlap and every track follows the approved `audio_timeline`;
- no narration clip is truncated, padded by accidental silence, or forced into unnatural speed;
- the full narration is present in sequence.

If any pair fails, repair only the affected narration or shot timing and recheck the pair. Do not assemble until all pairs pass. Confirm the voice-over version separately.

In `dialogue` mode, validate the original audio embedded in each approved shot: verify speaker attribution, approved line, timing, audio presence, and mouth-state alignment against the dialogue table. Check that the active speaker is the only visible character with an open-speaking mouth unless the shot is an intentional reaction or off-screen exchange. If a line or mouth state fails, repair only that line or shot. Do not replace the original dialogue audio with separately generated TTS unless explicitly requested.

Do not ask about or generate BGM before this first final cut. After the voice-over version has been assembled and checked, recommend a matching instrumental BGM as an optional enhancement. State the exact final-cut duration in the recommendation. Ask whether the user wants a BGM version. Only after approval, generate one instrumental track targeting the final cut duration. If the music tool returns a longer track, trim it directly to the final cut duration; do not regenerate solely for being longer. If it returns a shorter track, loop it as needed and trim the looped result to the final-cut duration; do not stretch it unnaturally or regenerate solely because the native track is short. Mix it at a clearly audible level beneath the voice-over and shot ambience, using ducking or automation around speech when needed. Export the BGM version as a separate asset while keeping the no-BGM voice-over cut unchanged and available. Confirm the BGM version separately.

## Step 7: Final assembly and delivery

Assemble all approved shots in storyboard order. First create the voice-over final cut with exact shot/narration duration matching. Add BGM only in a later optional mix after that first final cut is generated and reviewed. Add only audio layers explicitly approved by the user. Keep shot audio behavior consistent with the SFX contract and avoid duplicated audio tracks.

Before finalizing, verify:

- the final ratio exactly matches the locked project ratio;
- framing, safe areas, element sheets, shot prompts, and final assembly all use the same locked ratio;
- all generated image assets use the locked image resolution, and all generated video assets use the locked video resolution;
- every required shot is present and ordered correctly;
- approved character and scene identities remain consistent;
- no storyboard labels, guide lines, subtitles, or prompt artifacts are visible;
- voice-over is complete and every narration/shot pair has exactly matching duration;
- whenever narration is used, every narration clip uses the locked Storyboard `voice_id` and matching voice settings;
- in `dialogue` mode, every original in-shot dialogue line is audible, correctly attributed, time-aligned, and paired with the intended speaking or reaction state;
- in `dialogue` mode, original shot dialogue audio is preserved unless the user explicitly approved replacement or an additional dialogue track;
- every transformed, disguised, or state-changing character has a validated before/after reference binding and remains visually continuous across the transition;
- optional BGM is added only after the voice-over final cut is generated and reviewed;
- BGM is not unnaturally stretched; an overlong BGM is directly trimmed to the final cut duration, while a short BGM may be looped and then trimmed to cover the full picture;
- BGM is audible but does not mask the narration;
- the original no-BGM voice-over cut remains available and unchanged;
- the BGM version is a separate asset, not an in-place replacement;
- total duration and audio alignment are exact enough for the approved timing contract.

Present the final video and its key production assets. Then guide the user to export the finished file. Never claim completion without a usable final asset reference.
