---
name: prehistoric-animation-generator
description: Create prehistoric 2D hand-drawn comedy videos from topics, jokes or scripts, using actions, expressions and brief dialogue. For satire, fables and fun explainers; not archaeology or realistic film.
---

# Prehistoric Animation Generator

Project-local v0.2.8, retaining this project's v0.2.5 creative and permission requirements. Attribution: [references/provenance.md](references/provenance.md). Modify this project copy only; never change or reload a global installation as part of a project edit.

## Style, identity and permissions are separate

- STYLE: fixed earth-toned two-dimensional hand drawing, a large head over a small hide-covered torso, thin black limbs and solid drawn hands and feet. Rich eyes, lids, brows and mouth enable acting. No style-choice menu. Read [references/visual-direction.en.md](references/visual-direction.en.md).
- IDENTITY: design a new cast for each new story from plot, role, actions and relationships. Choose face shape, hair, grooming, costume construction and props per character; messy hair and stubble are optional, never universal. Do not duplicate one default worker across unrelated stories.
- INPUTS: a topic or script is sufficient. No reference image is required. Do not search for old calibration images, fixed asset paths or saved nodes. External references and previous-story characters are reused only when the user explicitly designates them for the current story. A canvas presence, old test result or past approval alone is not designation.
- CONTINUITY: character images are internal video identity anchors. After video confirmation, prepare them and reuse that sample across this story's shots. A new story does not inherit identity. Style references donate rendering; identity reuse requires explicit designation.
- ACTION: actions, camera reveals and physical consequences drive the story. Brief English character dialogue supports understanding; no default narrator. Later explicit language or silent-video requests override this project default.
- TEXT: No subtitles, on-screen titles, end cards, labels, watermarks, player controls or visible text. A document title is not permission for screen text; speech does not imply subtitles. Only an explicit later change of this lock can authorize text.
- INTAKE: for each new video or independent test, collect current duration, resolution and frame size/aspect ratio in ONE multi-question interactive dialog; never automatically inherit previous-task settings. Do not re-ask values explicitly provided or answered for this task. Platform is only a framing recommendation aid, not another required field; once frame size is chosen, do not ask for platform.
- NO SEPARATE IMAGE CONFIRMATION: video confirmation covers its necessary character images and subsequent video. Images are an internal prerequisite, not a standalone stage or review delivery. On generation success, continue directly to video without asking again. Pause for image review only when explicitly requested. Only explicit image-only requests get standalone images; generic testing must not become a separate sample test. Skill edits, static audits and prompt-only requests authorize no generation.

## STEP 1: Collect missing settings and a story

First identify a new video or independent test. Collect duration, resolution and frame size/aspect ratio for this task; old task values are not current answers. Do not write a timed storyboard or generate media until these three are supplied. Record explicit current values and ask missing fields together. Inherit old settings only if expressly requested; do not re-ask answered settings in a same-task revision. For missing duration, ask instead of using a 60-second default. Frame options may show suitable platforms as recommendations, but platform is not an additional required question. Once the user selects a frame, do not ask platform. Only if the user is unsure of framing or volunteers a platform, recommend a frame for their choice. Platform never changes the fixed style, dialogue language or subtitle permission. Preserve the topic without requiring references; dismissal is not confirmation.

## STEP 2: Develop the story and its cast

Read [references/story-and-continuity.md](references/story-and-continuity.md) and fill [references/character-template.en.md](references/character-template.en.md) from the current story, leaving optional reference inputs empty unless explicitly designated. Each role gets distinct facial silhouette, hair/grooming choice, hide costume, action-relevant props and story-relevant expressions. Use a clean-shaven, tidy-haired character when appropriate; do not add hair or stubble merely to imitate a prior preview.

For video requests, show a concise complete story, exact brief English lines and a timed storyboard. Each shot connects action, camera purpose, contact, consequence and reaction. Tracking follows displacement; a tilt reveals height; a pullback reveals scale. Avoid static two-person conversation and meaningless camera moves. Leave time for natural speech and reactions. Document headings and translations remain off screen. Preserve locked copy and do not invent historical facts.

Show one script confirmation/revision dialog authorizing video production from the current proposal, including necessary character images. Confirmation starts continuous image and video generation without separate image approval or repeated video authorization. If already confirmed, execute directly. Copy approval alone is not a production request. Prompt-only requests receive text.

## STEP 3: Prepare internal character images for video

Design the preview layout, view count, poses and emotions from this story's actions and the user's requested deliverable. There is no fixed full-body-plus-four layout, fixed emotion list or default previous character. A composed sheet is one artifact when requested; separate character cards remain separate when requested. For multiple characters, keep identities distinct. Do not invent output quantities or choose framing from old screenshots.

With no references, create a new preview from the current story's character description and the general style rules. If a user explicitly designates a reference, use only its designated identity/style/pose contributions; never silently drop required references. An inaccessible explicitly required input is a blocker to resolve, not permission to guess. Captions, player UI and watermark remnants do not contribute. A composite sheet is not an opening frame or multiple actors.

Keep the facial acting system: large eye whites with separate small pupils, independently variable upper/lower eyelids, separate brushstroke eyebrows, a small oval nose, a readable black mouth cavity when open, changing mouth corners, and a few simple front teeth plus a small tongue only when the pose warrants them. Closed mouths need not expose teeth or tongue. Specific head shape, hair, beard/stubble, tooth design and costume are story identity choices, then stay consistent for that character. Preserve large-head/small-torso proportions, thin limbs and solid palms, fingers, soles and toes rather than bare line ends.

When video is confirmed and required inputs are complete, generate its necessary character images within the same production flow, with no separate image confirmation gate. On generation success, continue directly to video without automated image acceptance, repair or standalone testing. Wait for image review only if the user explicitly requested it. Explicit image-only requests end at image delivery. Pause for actual tool failures, missing required inputs or scope changes. Reuse user-designated identity as requested; do not add another approval gate. Keep anchors in current-story state.

## STEP 4: Continue directly with the confirmed video

Require confirmation to produce the video and generated character images or existing user-designated references. Do not add automatic quality checks, extra user sample approval or repeated video authorization. Reuse current-story identity across shots; new stories default to new identities. Do not duplicate one identity into unrelated roles.

For each story prop record owner, hand, count, silhouette and state. Keep ownership stable without a visible handoff; show contact before effect. Use isolated character shots to establish props when crowded staging causes confusion, then bring characters together. Never force a torch, axe or any other prop into a story that does not need it. Preserve the chosen costume and facial identity through acting, not identical expressions.

Use supported production capabilities and the user's duration, framing and resolution. In the creative brief, request complete short English dialogue, stable voices and balanced sound, without default narration or overlays. These are generation requirements, not post-generation inspection steps.

## STEP 5: Deliver directly for the user to inspect

Follow [references/delivery-and-feedback.md](references/delivery-and-feedback.md). Deliver upon generation success. Do not automatically review, listen, score, probe duration or produce acceptance reports. The user judges visuals, sound, acting and continuity; make changes only after specific user feedback.

Do not automatically trim, pad, transcode, regenerate or create alternatives based on self-detected or presumed defects. In particular, do not create multiple files to correct a tiny provider timing variance. Execute editing or assembly only when explicitly requested or already within the approved production scope. Report actual tool failures or interruptions without blind resubmission. Never claim an unperformed review passed. Preserve returned paths and existing versions; avoid duplicate canvas nodes.

Historical calibration and acceptance records stay in local test history, not runtime guidance or distribution. Package the bilingual runtime instructions, metadata and referenced rules and templates, excluding local test history and raw media. Modify only the project copy, not global installations.
