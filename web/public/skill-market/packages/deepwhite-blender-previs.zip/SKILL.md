---
name: deepwhite-blender-previs
description: Turn ideas or previs videos and appearance references into editable Blender previs and stylized films. Covers staging, cameras, identity and sound; not production character assets or routine editing.
trigger-words: [Blender blockout, shot previs, blockout to final film, previs video stylization, previs to cinematic]
---

# Deepwhite Blender Modeling and Previs

A workflow for testing action, space and camera design, then producing a finished film with appearance references. Supports local previs only, existing-previs conversion, and the full idea-to-film path. Suitable for action, dialogue, vehicle pursuit and product staging with explicit spatial relationships.

Use the current user's language for interaction, instructions and prompts; preserve the language and exact wording of supplied dialogue. Reference-document language must not change response language. Execute this workflow directly without invoking other Skills or delegating its creative planning to another workflow.

## Progression and Choice-Card Rules

- Shortest path: approved silent previs plus sufficient reference images → analyze and map assets → capability and sound preflight → compile a synchronized canvas film prompt → prompt approval → resolution choice → generate with the previs video and the full reference-image set → review. Insert only the missing-reference step. From an idea, first complete the previs prompt, production and preview review.
- Advance only the current phase. Track entry, confirmed specifications, resource versions, accepted results, current review target and one next action in the current prompt document so users need not reconstruct progress from chat.
- Reuse supplied duration, framing, medium, image source and dialogue. Intake cards ask only missing questions and combine compatible gaps; never ask users to reselect established choices.
- Use the interactive cards below for phase decisions, with free-text supplementation. Explicit chat acceptance of the single pending version is equally valid. Choosing upload, revise or pause changes the next action; it does not mean an asset arrived or a revision was completed.
- Cards identify the document or result, its version and the action authorized. Explain generation scope and possible cost. Put a justified recommendation first; do not automatically recommend spending.
- Resolution is a mandatory per-generation gate. Before every new image-asset batch or image regeneration, show the Image Asset Resolution card with 1K and 2K. Before every video generation or full video regeneration, show the Video Asset Resolution card with 768P and 2K. Bind the answer only to the named batch and prompt version; an earlier phase, previous output or default does not authorize a later generation. An explicit chat choice for that exact pending batch counts as the card answer and must not be asked twice.
- Do not display every card at once. Trigger each only when needed, resolve its feedback, then advance. If interactive cards are unavailable, offer the same concise choices in chat without claiming a card was displayed.
- Substantive changes invalidate affected prompt approvals and dependent acceptances only. Preserve still-valid outputs. A style-only change does not require rebuilding motion previs; a changed route requires renewed preview and related film-prompt approval.

## STEP 1: Select the Entry and Delivery Boundary

Choose the shortest path supported by the inputs:
- **Existing previs video plus appearance images:** analyze the actual silent previs and images directly. The approved previs is always the motion/camera reference for final generation; it controls shot order, cuts, camera motion, staging, trajectories, timing and events. Reference images control final identities, subjects, world, vehicles, props, materials and style. Use this unified input route without requiring clean plates or per-shot keyframes.
- **Existing previs without appearance images:** confirm appearance direction from the user's descriptions. Create only necessary identity anchors; do not split a legible group reference without reason.
- **Idea, shot requirements or Blender project:** build or revise editable previs, then proceed to final generation only if requested.
- **Blockout, project or prompt only:** stop at that deliverable; do not automatically spend on video generation.

Establish medium, deliverable, duration, frame, source-audio treatment and required dialogue. Explicit instructions take priority. When matching a source, use measured media facts. Ask once for missing duration or framing only when intent and media cannot establish them; do not repeat answered intake.

Do not turn historical fifteen-second examples into universal limits. Cinematic quality does not imply live action: lock 2D, 3D game rendering or live action separately. Production topology, character rigging and long-series management are outside scope.

## Core Rule: Separate Geometric Motion Carriers from Character Performance

This is the default for stylized-film production and overrides later wording that might otherwise imply frame-by-frame pose constraints. Represent each moving character with one stable proxy root and the smallest readable assembly of simple geometric modules. A torso mass, head/direction marker, pelvis or base, and optional coarse limb/contact modules may be combined when a single primitive cannot distinguish identity, facing, silhouette, reach side or action phase. The assembly remains a low-detail proxy rather than a reduced mannequin or animation rig. The approved previs video may retain geometric proxies, mapping marks and path lines as spatial, motion and camera references. Same-composition style frames produced after previs approval, and the final stylized film, must contain no proxy geometry, mapping marks, path lines or placeholder shadows and reflections. Do not remove the previs video from the reference inputs merely to hide its proxies.

### What Carriers Express

- Preserve subject count, identity slots, physical scale, relative positions, leading/trailing relationships, direction, spatial paths, rhythm, speed and acceleration, cameras and event windows.
- Anchor translation to a ground projection or independent path root, recording dimensions and height offset. Do not use a head, hand, foot or gait-swaying pelvis as the path. Remove only gait bob and performance sway from legacy roots; retain real turns, sidesteps, starts, stops and whole-subject airborne arcs.
- Keep the proxy root, identity markers and overall proportions stable. Use root translation and vertical-axis heading for the authoritative path. Modules may show coarse facing, body envelope, crouch/extension or which side approaches a contact target, but must not encode a continuous gait cycle, detailed joint angles, a performed somersault, squash/stretch or periodic walk/run bob. A somersault retains displacement, takeoff, flight duration and landing window while rotation remains written action semantics for the final film.
- Use the fewest large modules that make the scene readable. Simple head, torso, pelvis/base and optional arm/leg/contact blocks are allowed; fingers, facial features, costume pieces, anatomical joints, deforming skin, detailed hands/feet and production skeletons are not. Different subjects use stable proportions, module layouts or simple surface marks for mapping, never as final identity design.
- Obstacles, doors, vehicles and independent props may retain necessary structure and physical motion. Proxy assemblies validate whole-subject envelopes, facing, rough reach side, corridors and gross clearance. They do not prove final sole support, fingertip contact, balance, muscle mechanics or joint collisions.

### Action Semantics and Pose Ownership

- Separately record action intent and event windows: sidestep avoidance, one forward somersault after takeoff, landing absorption followed by running, or reaching without contact. Preserve explicit action type, count, target, order and outcome; autonomous performance does not authorize dropping a flip or changing the story.
- Let the film model synthesize stride, arm swing, shoulder/hip coordination, balance, anticipation, rotational poses, landing absorption and secondary motion from identity, anatomy, speed, obstacles and written intent. Do not copy previs poses frame by frame or specify per-frame joint angles or source gait phase.
- Lock subject paths, event rhythm, cuts and narrative outcomes; organize limb motion naturally inside event windows. No teleporting, foot sliding, waiting still or moving actions outside their windows to disguise poor performance.
- Hand/foot close-ups retain camera, framing and timing, with written actions and independent contact props guiding the final image. A coarse contact-side module may enter the review frame only when needed to test reach, occlusion or available space; it is not a hand, foot or final pose reference. Describe contact targets and outcomes in text, and revise genuinely infeasible framing rather than adding detailed anatomy or a production skeleton.
- Geometric carriers are motion and spatial references, not final designs. For stylized generation, always submit the approved silent previs together with the complete reference-image set and synchronized prompt. The previs donates camera motion, cuts, paths, timing and event order; images donate final identities, creatures, props, world, materials and style. Map every visible carrier slot to one final subject and explicitly replace geometry, flat materials, markers and rigid sliding with final assets and natural performance.

### Migrating Articulated Legacy Previs

1. Classify the input as compliant geometric carriers or articulated legacy motion. Writing “natural action” alone is not a completed conversion.
2. With an editable project, preserve the old project and video. Revise the previs prompt and contribution map first; after authorization create a new version retaining cameras, environment, timeline, paths and events. Deliver one complete silent geometric previs video; do not add mandatory clean-plate or per-shot keyframe production.
3. With video only, do not claim exact 3D trajectory extraction. Explain geometric reconstruction and its uncertainty, and obtain conversion authorization; offer supplying the project or a compliant carrier video. If conversion cannot be completed, pause generation rather than silently using the old video or claiming a still/text is a converted video.
4. Review the converted video for path, rhythm, cuts and camera consistency. Once every visible carrier slot has an accepted image mapping or an explicit user decision to proceed from text, submit the approved silent previs with the reference images and synchronized prompt.
5. Editing the Skill does not mutate the current Blender project, canvas prompt or submitted job. New rules cannot alter in-flight generation. Preserve its outcome; actual migration and regeneration require their phase authorization, without duplicating running work.

## STEP 2: Inspect the Local Project (Blender Entry Only)

Prompt-only tasks and existing compliant geometric-carrier videos skip startup and production; converting articulated legacy previs requires authorization. Read-only inspection is permitted when a prompt depends on an existing project. Verify the environment before new previs execution; modeling and animation mutations wait for previs-prompt approval.

Prefer the platform's available Blender connection and verify it through a read-only scene response. A connection record alone does not establish liveness. If no usable instance exists, start and verify an isolated instance where supported, without redundant confirmation of authorized normal startup.

Inspect filepath, scenes, collections, objects, cameras, frame rate, frame range, units and save state. Save a safe copy before changes; never overwrite unrelated projects or close unsaved windows. Do not substitute another window when the user explicitly requires the existing one.

The uploaded package's file bridge is a fallback design, not a script to execute by default. Before enabling a fallback, review code, permissions, queued requests and the actual consumer. Keep the directory private and off network shares. Allow one consumer, one client and one outstanding request per queue. Resolve stale requests before activation; inspect execution evidence after timeouts rather than repeating mutations.

Report missing installation, denied permission or unavailable connection precisely. Do not install software, weaken security settings or repeatedly launch instances without authorization.

## STEP 3: Previs Prompt, Action and Cameras (Skip for Existing Video)

Previs output is always silent, with no audio track. Do not generate, record or mix voice-over, spoken audio, sound effects, ambience or music, and do not attach a silent placeholder track. The previs prompt explicitly specifies silent output without an audio stream and directs action, space and cameras only. Dialogue text and windows guide translation, pauses and events only; gestures and lip movement remain written final-film requirements, not carrier animation or synthesized speech. Review visual quality and absence of an audio track, not sound or voice quality. Generate final sound during stylized video production. If an uploaded previs contains placeholder audio, use its visual track only and do not copy that audio into the final film.

### 3.0 Lock an Executable Shot Script Before Previs

When the input is a story idea without a shot table, convert it into a reviewed shot script before authoring the previs-production prompt. Any user-specified shot or viewpoint is a hard constraint—for example, a low-angle view from behind pursuers when a character rises overhead—and cannot be replaced by generic cinematic wording. Each shot includes at least:
- Time window and one dramatic purpose; opening state, key change, ending state and next-shot handoff;
- Subject count, identity, depth order, entry/exit, whole-subject path and speed phases;
- Shot size, viewing side, height, camera endpoints, tracked subject and movement motivation;
- Ownership, path, rotation, contact and state changes of doors, vehicles, weapons, projectiles, boxes and other independent objects;
- Required POV, shot/reverse-shot, axis limits, occlusion, slow motion or single-take structure;
- Action goal, contact causality, environmental response, dialogue/sound window, and states that must not appear early or must be absent.

The shot script describes visible outcomes and direction, not faces, fingers, gait cycles or full limb performance for carriers. Its approval authorizes only the previs-prompt phase, not modeling, rendering or final generation.

### 3.1 Map the Required References First

Before producing previs, map the actual story or idea, action videos, layout drawings, environment references, object dimensions and existing Blender project needed for this phase. Record each resource's name, type, real path or canvas location, purpose, corresponding subjects and shots, required contributions and boundaries. With no external resources, use approved written requirements and label new design decisions rather than inventing sources. Ask when missing references prevent resolution of important action or spatial relationships.

Apply relevant modeling, staging, cinematography and continuity knowledge. Consult only available professional references relevant to the task; do not treat example settings as user decisions.

### 3.2 Author the Previs Production Prompt on Canvas First

Before modeling or animation, create a separate canvas document titled Previs Production Prompt, localized to the user's language, with a version, status and resource map. This is a complete Blender-executable production brief, not a short summary. Include at least:
- Goal, duration, framing, frame rate, scale units and previs delivery scope;
- Subject inventory and distinct markers, world coordinates and forward direction, staging or lanes, obstacles and contact surfaces;
- Shot times, sizes, camera positions, focal lengths, camera and target paths, cuts and opening/landing compositions;
- Carrier path anchor, dimensional offsets, position/speed checkpoints, heading, event windows and ordering; separately written final-film action goals, contact targets and outcomes, without limb key poses;
- Continuity, occlusion, collision, physics constraints and silent output without an audio track;
- Modeling scope, animation controls, preview-video and project delivery, continuous-playback and timeline acceptance criteria. Do not require or deliver separate verification stills unless the user explicitly requests them.

Professional means explicit, executable and verifiable, not jargon-heavy. If the user supplies a complete prompt, resolve its references and fill genuine omissions without rewriting approved action.

Place the complete document on canvas and obtain approval of this phase's prompt before producing previs. Approval of an earlier concept does not approve a newly introduced shot plan. Use the approved version as the production authority, translate it into scene, animation and camera settings, then render the previs in Blender. A written prompt is not a rendered preview.

### 3.3 Build and Verify Against the Prompt

The production steps below implement the approved document's shots and actions. Present rendered previs for user review. If rejected, update relevant prompt sections and revise the preview before proceeding to stylization. Compliant carrier-video entry skips this phase; legacy articulated videos follow migration to a new version. Do not invent a retrospective prompt claimed to have generated the old video.

1. Define each shot's single dramatic purpose, opening and landing compositions, size, camera height, focal length, subjects, look targets, time range, transition and reviewable opening/action/ending states in the timeline.
2. Establish scale, silhouettes, contact surfaces, action corridors and separation before decorative detail. Separate environment, subjects, motion controls, effects and cameras using stable names and editable parent structures.
3. Moving characters use low-detail composite proxy assemblies under one stable root, with paths, speeds, facing, whole-subject envelopes, clearance and event windows. Add only the coarse modules needed to distinguish subjects or make approach, crouch, reach side and contact staging readable. Foot support, detailed balance, gait, sitting mechanics, flips, gestures, cloth and hair remain written final-film requirements. Vehicles retain lanes, steering and necessary grounded structure without articulated driver mannequins transmitting poses.
4. Control camera and look target separately. Establish the action axis; avoid unmotivated crossings and use establishing views or visible camera moves when changing sides.
5. Test timing with linear motion, then refine easing. Smooth translation does not guarantee smooth rotation, particularly when a target passes near the camera.
6. Render one inexpensive preview video and review it continuously; scrub the timeline only where a problem needs diagnosis. Do not render, publish or deliver standalone key verification frames by default. Create stills only when the user explicitly requests them as deliverables.
7. Correct action and collisions, then camera and target, lens and composition, timing, and secondary motion. Compare identical time positions and log specific revisions.

Save or deliver the editable project, previs video and shot manifest. Continue only when a stylized final is requested.

### 3.4 Local Shot Revision

When a user rejects one shot, classify the issue as composition, viewing side, camera height/path, subject travel, contact order, speed or handoff, then revise only that shot and necessary adjacent handoff frames. Record the previous ending and next opening state first; compare matched times after revision without resetting separation, prop ownership or environment state. Update the corresponding sections of both the shot script and Previs Production Prompt. Preserve every accepted shot whose dependencies remain valid.

## STEP 4: Prepare Appearance Images and Assign Contributions

### 4.0 Analyze Inputs Before Choosing or Generating Images

Read actual dimensions, duration and format for every input. Semantic observations establish meaning, not exact cut measurements or frame counts. Reuse relevant existing analysis. Analyze new references incrementally without reanalyzing unchanged sources.

Register every currently specified input in attachment order:
- **Video:** classify carriers versus articulated legacy previs; contribute count, position, direction, paths, speed/rhythm, event order, cameras and temporal continuity only. Record contact targets/events, not limb poses or source gait phase; do not submit articulated legacy video for final generation.
- **Character/object images:** identity, silhouette, hairstyle, costume, materials, equipment and distinctive structures.
- **Scene/style images:** architecture, furniture, world structure, light direction and rendering medium.
- **Audio:** original soundtrack retention, voice identity, performance or timing; distinguish these from visual-only video reference use.

Images supply appearance by default, not timeline keyframes. During previs production, do not create a per-shot keyframe-rendering prerequisite. After the approved previs video is complete, however, the user may request a small set of post-previs anchor frames at representative action nodes. Extract those frames from the actual approved video, generate same-composition appearance/style images from them, and use the generated images as supplemental visual references for final film generation. These post-previs style frames never replace the full motion video or become a hidden first/last-frame route.

Let images carry color visually. Preserve user-specified colors and brand rules; do not invent palette instructions from analysis.

After inspecting the files, compare the reference inventory against every appearance-bearing subject required by the approved previs: each identity-bearing character, principal creature, environment/world, vehicle, product and story-critical prop. List every missing reference explicitly. A text description, blockout, carrier proxy or low-detail previs model does not count as a completed appearance reference. Before an appearance brief, film prompt or film generation, show the missing-reference choice card and let the user decide whether each missing item will be uploaded, generated, or intentionally left without an image. Never silently design, replace, omit or import unrelated historical assets. If numbering conflicts with content or identity mapping remains ambiguous, inspect paths and ask rather than guessing.

Draft the subject map before generating appearance images. STEP 5 finalizes that map against accepted references; it must not be the first opportunity to discover count or identity conflicts.

### 4.1 Choose Upload, Generation or Both

Analyze existing previs and references first, compare them with the complete required-subject inventory, then establish the source for every missing appearance reference. If any character identity, principal creature, environment/world, vehicle, product or story-critical prop lacks a usable image, stop and show the missing-reference choice card before drafting the film prompt or generating video. Name the missing items in the card. Let the user choose upload, generate, or intentionally proceed without an image; when several items need different sources, collect all item-level choices in one combined card. Only skip this card when the reference inventory is complete or the user already made an explicit source decision for every missing item.

- **Upload branch:** verify that subjects, vehicles and environments are legible, map identities, then reuse the images. Uploading communicates intent to use them; do not force redraws or another approval of the original images. Ask only when identity mapping or suitability is unclear.
- **Generation branch:** confirm appearance descriptions, generate necessary references, and obtain image approval before producing the film.
- **Mixed branch:** retain uploaded identity and design anchors and generate only missing material. Do not replace approved subjects or objects.

### 4.2 Confirm Appearance Descriptions

Use the previs subject count, relationships and user requirements to prepare a compact appearance brief: target medium, identities and defining visible traits, clothing and equipment, vehicle or prop structure, environment materials, and each image's purpose. Establish image framing and quantity in the brief; obtain 1K or 2K through the mandatory Image Asset Resolution card for the exact pending batch, then write the choice into the approved brief before generation. References are not automatically opening frames.

Present the brief for approval. Do not repeat approval of an already approved complete appearance brief. Unspecified facial, costume or style choices are not established facts; explicitly describe unreferenced identities as newly created designs.

### 4.3 Generate Reference Images

After the appearance content is approved, show the mandatory Image Asset Resolution card for the current batch and wait for a 1K or 2K choice. Record that choice in the appearance brief, then generate the smallest sufficient reference set. Prefer a legible group or relationship image rather than requiring separate cards for every person. Split only when identity, costume, vehicle details or environment structure cannot remain readable, or when explicitly requested. A revised or additional image batch requires its own new resolution choice.

When one subject appears in several images, establish a common identity anchor first and use it for additional views or scene images; repeated text alone does not lock identity. A suitable existing shared reference can serve as that anchor. Batch independent images at the same dependency level.

When designing appearance from previs alone, extract a representative frame if useful for subject and environment layout, but do not automatically make it the film's opening frame. Skip this when uploaded appearance references already suffice.

### 4.4 Post-Previs Anchor-Frame Style References

This optional step begins only after the complete previs video has been rendered, reviewed and accepted. It is not a prerequisite for building or approving the previs.

1. Select a small set of real frames from the approved video: normally the opening composition and a few decisive mid/end action nodes such as a turn, contact, drift, overtake or final state. Do not force one frame per shot, and do not invent a driver close-up or action that is absent from the source video.
2. Record each source timestamp or frame interval, shot identity, camera height, framing, subject count, relative positions, orientation, route state and event state. The frame is evidence of the actual composition, not a replacement for the video timeline.
3. For each selected frame, generate a style/appearance image that keeps the source frame's composition boundary: camera, shot size, subject count, relative placement, orientation, road/world geometry and event state. Replace proxy geometry and flat materials with the accepted final appearance references. Ask for the Image Asset Resolution card for this new image batch; treat a revised batch as a new resolution decision.
4. Inspect every generated style frame against its source frame. Reject or revise any frame that flips vehicle direction, swaps identity, changes the camera height, moves a subject to another lane, invents a missing subject or turns an absent shot into a new event.
5. Accepted style frames receive ordered labels and source timestamps, then enter the final film prompt as supplemental image references. The prompt must state which timestamp each frame corresponds to and that the full approved previs video remains authoritative for continuous motion, cuts, camera movement, paths and timing.
6. If the video capability cannot combine these supplemental images with the previs video, explain the limitation and ask whether to keep the unified previs-plus-appearance-image route or omit the supplemental frames. Never silently replace the video with stills.

### 4.5 Review Reference Images

Present generated images with their subject mappings and wait for explicit acceptance or revisions. Check distinct identities, costumes, defining structures, medium, environment and readability. Revise only rejected images and retain accepted ones. Successful image generation alone must not trigger video production.

After acceptance, use those images as appearance and environment references and continue locking shots and sound. Image approval does not authorize later added costs or newly introduced shot plans. If the final shot plan was already approved and remains unchanged, do not ask for the same approval again.

## STEP 5: Lock Identity, Action and Shot Continuity

Create a compact subject map: stable name, source-video position, appearance reference, required visible traits, permitted adaptation and shot membership. Verify facial and costume mappings separately. Unmatched characters retain distinct identities rather than copies of a reference face.

Examples include lead/middle/trailing runners; two HR staff and an applicant; leading and pursuing vehicles with separately bound drivers. Derive all roles from current material, never inherit an example's count, colors, genders or car designs.

The shot manifest records start/end times, cuts, shot size, camera endpoints, path/speed checkpoints, event windows, action semantics, contact targets/outcomes, gaze/axis, dialogue speaker/window, location sound and ending state. Separate fixed motion constraints from freely synthesized poses; never lock source skeletal motion.

Explicit timing and action instructions outrank source-video observations. If the user demands frame-exact source timing alongside a conflicting new timeline, ask. Never override explicit cuts based on approximate semantic analysis.

These are final-film natural-action checks, not limb animations or frame-by-frame templates to build into carriers:
- Parkour: last foot plant, takeoff, gravity arc, landing absorption and recovery stride; preserve staggered timing instead of cloned synchronous actions.
- Interviews: specified approach side, turn, sit, grounded feet and resting hands; maintain pose and tabletop continuity across cuts.
- Racing: turn direction, inner/outer lanes, screen direction, countersteer and suspension; show closing, drawing level and clearing the front bumper instead of teleporting the lead change. Bind each driver to a specific car.

## STEP 6: Stylized Film Sound and Preflight

Sound requirements in this section apply only to the stylized film, not previs. Create final sound during stylized video generation from the approved dialogue and effects plan; do not copy previs placeholder audio. Generating sound in this phase does not authorize unsolicited narration or music.

Complete these checks before final prompt approval so accepted plans do not immediately need to change:
- Preserve dialogue verbatim, including language, speaker and time window. Only the speaking character performs corresponding lip movement; listeners react naturally with closed mouths.
- Verify that formal inputs contain the approved silent previs and all accepted reference images. Every carrier slot maps to one final subject or an explicit user-approved text design. State that previs geometry, flat materials, shadows, markers and path graphics donate no final appearance; images provide visible identity and style.
- Check speaking rate. If a line cannot fit naturally, ask about extending time, revising copy or audio-first production; do not silently rewrite it.
- When rebuilding sound, do not copy previs placeholder audio. Synchronize steps, clothing, chairs, paper, pens, engines, tires, wind and spray; maintain acoustic continuity across interior/exterior cuts.
- Treat music, narration, dialogue and subtitles independently. Subtitles are opt-in. No-music requests exclude non-diegetic scoring.
- Consult current capabilities for per-file and total durations, input counts, framing, resolution, audio support and prompt length. Do not hardcode a model or historical limits.
- When current capabilities support the full duration and all reference inputs, generate the complete film in one pass by default; multiple shots or consistency requirements alone do not authorize segmentation. Propose segmentation only when a hard capability limit prevents full-film execution, explain the reason, scope, cost and assembly method, and obtain user confirmation first. Never split the middle of an airborne action, continuous contact or performance that must remain coherent.
- If the user explicitly requests endpoint frames but current capability cannot combine them with the approved previs reference, explain the incompatibility and ask whether to keep the unified previs-plus-images input or change the requested endpoint-frame constraint. Never switch inputs silently.
- For long prompts, remove redundant definitions and embellishment while preserving every input's role, identity, actions, cut times, dialogue, sound and exclusions. Compare constraints before and after compression; never truncate the tail.

Prompt-only tasks still check feasibility but do not launch Blender or paid generation. Check actual text length again after compilation; this technical check is not another creative approval.

## STEP 7: Compile and Confirm the Film Brief

Before final generation, create a separate canvas document titled Stylized Film Generation Prompt. Map the approved silent previs, every accepted character/creature/scene/vehicle/prop/style image, any accepted post-previs anchor-frame style references with their source timestamps, sound requirements and real timeline. Record each path, purpose, subject mapping and contribution. Formal generation input is the previs video plus the complete mapped image set; clean plates and per-shot keyframes are not required.

Include version/status, resource map, final specifications, complete prompt and acceptance checklist. Structure it as: final goal → previs/image responsibilities and conflict rules → unified visual design → synchronized timecoded shots → continuity → optional user-requested sound. Each shot specifies source interval, cut, framing, viewpoint, camera path, subject trajectory, spatial relation, action change and end handoff.

Include the approved silent previs in the formal input list and state: “@Video1 governs shot order, cuts, camera motion, viewing side, shot size, trajectories, speed phases, event windows and end states. It does not govern final identity, anatomy, costume, creature design, environment, material, lighting or style. Replace every carrier with its mapped asset from @Image1…@ImageN while preserving paths and outcomes with natural performance.”

Give every reference its own ordered input label and purpose; never collapse several images into one undifferentiated reference. Post-previs anchor-frame images must include their source timestamp and shot role, and must be described as supplemental composition/style references rather than motion sources. Each shot describes size, camera movement, action, meaningful environmental response, dialogue and sound. Faithfully compile complete user-authored shot plans without adding story beats or cuts.

Name concrete identity and design anchors: hairstyle, glasses, implant, wedge silhouette, louvers or wings. Generic style matching is insufficient. Translate 2D requests into linework, painted texture, shapes and natural animated acting rather than mixing live photography or 3D surface rendering.

Before generation, ask the user to approve this phase's complete prompt on canvas or in chat. A brief chat introduction is navigation, not a substitute for the complete document. Previs-prompt approval, preview acceptance, appearance-image acceptance and final-film-prompt approval concern different objects and cannot authorize one another. Do not repeat approval of the same explicitly accepted version. Approval of the workflow or its inputs does not approve a prompt introduced later. For prompt-only tasks, deliver the document and stop without generating video.

Apply user revisions as targeted changes in the existing canvas document, maintain version and status, then execute corresponding revisions. Changes to subjects, action, cuts, dialogue, reference roles or output specifications require renewed approval. Do not create competing authoritative documents.

### 7.1 Stronger Reference Adherence: Staging and Cinematography, Not Limb Copying

The goal is close adherence to previs space, paths, rhythm, cuts and cinematography, not pixel- or joint-exact copying. Autonomous performance applies to limbs and secondary motion, not routes, staging or viewpoints. Generate one full-length film when capability supports it; segment only for a hard limit and confirm scope, cost and assembly.

#### A. Build an Evidence-Based Space–Path–Camera Record

Reuse approved shot manifests and valid analyses; inspect specific reference windows only for missing facts. Extract these dimensions per shot without inventing unseen or unmeasured precision:
- **Spatial anchors:** choose a few fixed landmarks that determine travel. Record which side subjects occupy/pass, occlusion order and connections between corridors and exits. Scene images provide art direction/materials, while previs provides these spatial relationships; image compositions or object placements must not override them.
- **Subject paths:** separately record each stable identity's start → necessary turning/passing points → end, leading/trailing relationship, approach/separation and frame entry/exit. “Chasing,” “S-shaped running” or “follow previs” alone is insufficient. Describe routes against landmarks, not screen-left/right mistaken for world-left/right across cuts.
- **Three directions:** distinguish world travel, screen travel and body facing. A proxy head/direction module may establish coarse facing, but never gaze, expression or limb pose. Record gaze separately only when supported or requested. If the proxy does not reveal facing, leave it to natural performance rather than claiming travel proves facing; ask only when an important ambiguity cannot be resolved.
- **Rhythm and speed:** record sustained progress, slowing into turns, accelerating to close distance, flight, absorption and renewed acceleration. Use event windows and landmark passage order instead of one generic “fast.” Distinguish subject speed from apparent motion caused by the camera.
- **Camera anchors:** record shot size, observed side of the subject (front/side/back/oblique), relative height/tilt, fixed/following/trucking behavior, main tracking subject, opening/ending composition and foreground/midground/background. Never replace close detail, rear-oblique follow and overhead wide shots with generic “dynamic cinematic camera.”
- **Cuts and handoffs:** retain approved timecodes/order and record each subject's landmark interval, motion state and next-shot entry across cuts. Offscreen subjects continue moving; cuts do not reset positions or distances.

Reuse real approved timecodes. Label semantic estimates as approximate; never invent milliseconds, camera angles, focal lengths, meters per second or normalized coordinates. Real project values may remain in production/QA records, but final prompts prioritize visible relationships without claiming numeric text is hard generation control.

#### B. Lead with Responsibilities and Degrees of Freedom

Open with the user's stylization goal, then a compact staging-authority paragraph, followed by appearance and shots. Labels must match actual reference order. The following is a compilation skeleton to fill from evidence, not submit with placeholders:

> Generate the film with [approved silent previs label] as @Video1 and [list every accepted appearance image with its identity/world/design contribution] as @Image1…@ImageN. Follow @Video1 for shot order, cut timing, camera motion, viewing side, shot size, start–waypoints–end trajectories, speed phases, event windows and end states. Replace every visible proxy slot with its mapped final asset from the images; preserve spatial relationships, paths and outcomes while synthesizing natural gait, balance, contact and transitions. Proxy geometry, flat materials, markers and rigid sliding are not final appearance.

Explicit new user instructions always outrank the video. Each reference governs only its assigned dimensions: placeholder materials are not final art, and portrait facing or scene-image viewpoints do not replace video cinematography. Avoid global wording such as “freely invent camera moves,” “redesign composition” or “atmosphere reference only” that undermines this task.

#### C. Compile Each Shot as Start State → Change → End State

Begin each shot with its time window and actual source-video interval. Describe camera and subject movement separately; cover the following in concise executable prose rather than repetitive commands:
1. **Camera:** size + viewing side/height + main tracking subject + camera motion + opening/ending composition. State camera behavior before subject behavior so camera travel is not misread as a subject turn.
2. **Start:** each subject's landmark-relative position, ordering and motion state; stable identity labels never change with screen position.
3. **Progress:** each subject's necessary waypoints, relative directions, speed changes and event windows. Use route-defining turns, not a per-frame position list.
4. **End/handoff:** reached landmark intervals, separation changes and action outcomes; the next shot continues this state without camera cuts changing spatial topology.
5. **Natural performance and sound:** fulfill written action goals within this staging while freeing gait phase, arm swing and microposes. Synchronize sound to final contacts/events, not nonexistent carrier footsteps.

“People weave through obstacles with a dynamic camera” is insufficient. Relational phrasing could be “Follow the pursuer from rear-right; the leader passes the outside of the first obstacle, then the pursuer reaches that same turn; separation narrows as they enter the next corridor, with the leader still ahead at the cut.” This illustrates expression only: directions, roles, obstacles and speed must come from current source evidence, never copied from the example.

#### D. Pre-Submission Spatial and Camera Consistency Check

- Does each important shot have identifiable landmarks, individual paths, speed phases, camera viewing side and end state? Fill missing evidence/prose instead of relying on one global “strictly follow reference.” Do not invent absent landmarks or subjects.
- Do start/end positions, screen directions and camera directions conflict? Is a fixed camera also told to orbit, a rear follow asked to show faces, or a subject accidentally told to move with camera trucking? Resolve before submission.
- Does appearance direction invade staging? Does autonomous action accidentally authorize rerouting, new viewpoints or arbitrary extensions? Remove conflicts while retaining identity anchors and natural-performance freedom.
- Write approved windows, cuts and ordering clearly and consistently as generation targets, not guarantees. When shortening prompts, remove redundant aesthetic modifiers and repeated negatives before space–path–camera structure, identities, events or sound.
- Add targeted constraints only for observed or relevant risks, such as keeping a rear-oblique view, passing the specified obstacle side or maintaining order. Prefer positive visible outcomes over generic negative lists or repeated “one-to-one” demands.

### 7.2 Approved Previs + Reference Images to Formal Generation

1. Use the approved complete silent previs as the video reference for final generation.
2. Use the same accepted scene, character, creature, vehicle, prop and style images across the whole video unless the user assigns a narrower scope.
3. Map every visible previs slot to one image reference or explicit user-approved text design. Do not require a new image per shot.
4. Build the synchronized shot table from the actual project or reviewed video, preserving duration, shot count, cuts, camera paths, trajectories, contacts and end states.
5. Confirm one complete prompt, ask for 768P or 2K, then submit the previs and all mapped images together.

### 7.3 H3 Previs + Reference-Image Prompt Compiler

Follow [White-Previs + Reference-Image Prompting Guide](references/previs-reference-video-prompts.md). The approved silent previs is always the motion/camera input, and images are always final visual-design inputs.

For each source shot, write the actual interval and cut → opening composition/shot size → viewing side/height → camera path/tracked subject/end composition → each subject’s start, waypoints, direction, spatial relation, speed and entry/exit → event anticipation/execution/recovery/end state → next-shot continuity. Preserve shot order and cut placement; distinguish camera from subject motion and world from screen direction.

Use: “follow @Video1 for camera motion, cut sequence/timing, trajectories and event rhythm; render every mapped slot with final assets from @Image1…@ImageN.” State that carrier geometry, proxy proportions, flat materials, marker colors, path graphics and rigid sliding are not final appearance. Natural body mechanics and secondary motion may change without redirecting routes, swapping identities, changing the axis or moving events between shots.

Compile the prompt in these fixed layers:
For reference-image–driven jobs that pair a silent geometric previs with scene and character images, also follow [White-Previs + Reference-Image Prompting Guide](references/previs-reference-video-prompts.md): the video owns action, camera, cuts and timing; images own identity, costume, world, vehicle and material; resolve conflicts by responsibility, build a synchronized shot table from the real timeline, and verify frame-level alignment from actual output, not by adding stricter wording. Sound is required only when the user explicitly asks for it.

1. **Asset mapping and authority:** label every image/video slot. Character images donate identity/costume, creature images anatomy/surface, scene images world/medium, prop images appearance/scale/ownership, and the silent previs camera motion, cuts, paths, timing and events.
2. **State ledger:** time winged/unwinged, empty-handed/holding, open/closed, intact/damaged, standing/fallen and similar states. Reference mapping and timecoded shots must show when each state applies, preventing premature appearance, loss, duplication or transformation without a visible process.
3. **Embodied camera:** define viewing side, distance, tracked subject, orbit motivation and delayed reaction. The operator sidesteps after a weapon passes near lens, shakes after impact, and tilts up after sudden ascent. Handheld direction, strength and timing vary with events rather than looping uniformly.
4. **Timecoded causality:** write opening composition → anticipation/start → contact → local force → whole-body/prop follow-through → camera response → end handoff → synchronized sound. Continuous attacks do not reset to neutral; doors stop after contact; suspension compresses before rebound; giant mass transmits force with delay.
5. **Temporal modulation:** slow motion, speed changes and near-freeze affect subjects, props, rain, debris, cloth and environment together. Never freeze one image. When the camera continues moving, define its path and parallax. Exceptional timing stays inside the approved window.
6. **Effects and environment:** effects originate from contact and travel direction, changing nearby material light, shadows, atmosphere, debris, water, vegetation and lens response. Avoid generic glowing balls, rings or smoke pasted onto subjects.
7. **Sound viewpoint:** camera location governs distance, occlusion, reverberation and frequency. Lock dialogue by speaker, shot and window while listeners react with closed mouths. Dialogue-free scenes retain approved environment, breath, weapon, door, vehicle, impact or creature sounds without default music.
8. **Targeted exclusions:** include only evidenced risks such as carrier remnants, identity swaps, multiplied subjects, distant test mannequins, premature props, imported image backgrounds, axis violations, wrong projectiles, repeated actions, anticipatory shake, mechanical sliding or effects hiding the subject.

Shot/reverse-shot dialogue additionally locks the line of action, foreground shoulders, eyelines, prop continuity and contact order. Vehicle, creature, long-weapon and flight scenes additionally lock independent-object trajectories, scale references, inertia, drag and environmental feedback. A prompt may be detailed, but every sentence must trace to user intent, the approved shot script, previs records or formal visual inputs. Never transfer Tokyo, cherry blossoms, rice fields, creatures, vehicle designs or camera-brand examples into unrelated work.

## STEP 8: Generate, Inspect and Repair

Generate from the latest approved complete prompt using the approved silent previs and every mapped image in documented order. Never substitute a short summary, add shots or change reference order. If unwanted carrier geometry remains, treat it as incomplete stylization, revise subject mapping or add the missing appearance reference, then request approval for corrected full regeneration; do not create another handoff workflow.

If submission limits require rewriting, update the canvas document first and verify complete semantic and constraint preservation. Obtain renewed approval for substantive changes. Record the prompt version and source resources associated with each output for traceability.

Finish shared appearance mappings and the synchronized timeline, then generate the full film from the previs plus images. If a hard limit forces segmentation, never cut through coherent actions; assemble against approved cuts and duration without doubling audio.

Inspect actual outputs for subject count, identities, clothing, shot order and timing, paths, sitting/landing contacts, lanes and passing, lip movement, sound, medium and ending. Use frame-level or timeline evidence for exact timing where available. Successful execution proves generation, not frame-exact compliance.

Preserve good outputs and retry only affected items. Distinguish submission failure, capability mismatch, interruption and visual defects; fix the relevant problem instead of sending identical requests. If a user interruption leaves canvas generation running, reconcile that job before starting another. Repeated failure requires a concrete explanation and necessary user decision; never switch models silently.

### Two-Layer Acceptance: Matched Motion, Autonomous Poses

- **Previs-reference preflight:** inspect the complete silent previs for readable subject slots, facing, scale, count, paths, cuts and camera motion. Verify each slot maps to a final image or user-approved text design. Do not require separate verification stills, clean plates or per-shot keyframes.
- **Motion consistency:** compare whole-subject centers/ground projections, corridor sides, obstacle-passing directions, separation, turns, starts/stops, takeoff/landing, speed changes and cuts at matched event times, not hand/foot pixel tracks. With the original project check world paths and key times; with video only report visible projection/event evidence, not exact 3D agreement. Disclose uncertainty; agree numerical tolerances before testing when requested.
- **Natural action:** watch continuously for stride/speed coordination, planted feet without sliding, shoulder/hip rhythm, credible balance, takeoff anticipation, coherent airborne motion, landing absorption and continued travel. Check limbs, equipment, proportions and obstacle intersections. Mere difference from previs is not quality proof.
- **No mechanical copying:** do not inherit stiff arm swings, fixed joint angles, synchronized gait, abrupt pivots or mechanical landings from legacy previs; do not transfer proxy-module angles, block poses, sliding, turn jitter or event-only contact markers to human bodies. “Not the same action” means no source-pose/gait-phase lock, not a ban on performing the same requested action category.
- **Spatial/camera adherence QA:** compare viewing side, shot size, height, tracking subject, composition layers, turns, speed phases and cut order per shot. Mark matches, clear deviations or unverified items with time ranges. Require recognizable direction, topology, event rhythm and camera intent while allowing natural gait phase, limb silhouettes and minor framing differences; do not demand exact copying for those differences, or excuse reversed travel, wrong corridors, rear-to-front viewpoint swaps or clearly misplaced cuts as style freedom.
- **Repair order:** distinguish faulty previs from generated non-adherence. If the previs is correct, preserve it and revise shot wording, subject-image mapping, missing appearance references, landmarks, speed phases or camera description. If carriers remain visible, strengthen positive final-asset mapping or ask for a missing reference, then request approval for full regeneration. Revise the previs only when its path, event or camera is wrong.
- **Pass conditions:** no geometric carriers, mapping marks or path graphics; identities correspond to their mapped reference slots; coordinated natural action; paths, direction and rhythm remain consistent with approved previs; and no mechanical copying of reference limb motion. Carriers reduce pose contamination but do not guarantee natural generation; base every pass on actual output and label unverified checks.

## STEP 9: Deliver

Deliver the final video, necessary appearance references, shot manifest, any Blender project actually produced, and the approved prompt documents and resource maps for phases actually executed. Users can inspect the respective previs and film prompt versions on canvas. Do not invent documents or results for skipped phases. Keep returned filenames and paths; do not rename tracked assets or duplicate canvas cards.

Report actual duration, frame, version and verified checks. Disclose unverified cut, lip-sync or contact accuracy. Do not claim pixel-exact recreation or separate audio stems without evidence. Prompt-only and previs-only tasks must be described as such.

## User Choice Cards

These are production-time interaction rules, not cards to launch while authoring the Skill. Localize titles, questions and labels into the current user's language. Default to single selection with free-text supplementation. Offer only currently supported resolution and model choices and known cost information, never fixed vendors or invented prices.

### A | Entry (Only When Unclear)
Question: Where would you like to begin?
- Use existing previs: skip local modeling and analyze the uploaded preview.
- Build previs from an idea: author the previs prompt first, then produce it after approval.
- Prompt documents only: deliver the required phase documents without production.

Skip this card when an uploaded video and film request already establish the first path. Preserve previs-only requests without forcing final-film production.

### B | Missing Specifications (Combine Compatible Gaps)
Question: Choose the remaining visual specifications.
- Medium: live-action cinema / 2D animation / 3D game cinematic, with custom input. Do not recommend live action after 2D is specified.
- Frame: match source / 16:9 landscape / 9:16 portrait / 1:1 square; expose applicable choices only.
- Duration: match source / enter seconds; do not default every task to fifteen seconds.
- Do not collect image or video generation resolution in this general card; use the mandatory batch-specific cards below.

Ask only missing items. Previs is always silent, so do not show voice or effects selection cards for it. Only when stylized-film sound requirements are unclear, offer generate dialogue and location sound / generate location sound only / silent final. Preserve supplied dialogue, effects and no-music instructions without asking again. Generate dialogue and effects during stylized video production rather than inheriting previs placeholder audio. Do not solicit subtitles that default to off.

### B1 | Image Asset Resolution (Mandatory Before Every Image Batch)
Question: Choose the resolution for [named image batch / prompt version].
- 1K: faster and lower cost, suitable for drafts and reference review.
- 2K: more image detail and higher cost, suitable for approved high-detail references.
Show this card after image content approval and before submission. The choice authorizes only this batch. Show it again for revised, replacement or additional image generation.

### B2 | Video Asset Resolution (Mandatory Before Every Video Generation)
Question: Choose the resolution for [named film prompt version].
- 768P: faster and lower cost, suitable for motion, continuity and composition review.
- 2K: more detail and higher cost, suitable for a high-resolution final.
Show this card after film-prompt content approval and before every initial generation or full regeneration. Record the choice in the prompt document before submission. If the selected capability cannot provide the chosen tier, explain the incompatibility and ask for a compatible decision; never downgrade, switch models or proceed silently.

### C | Missing Reference Completion (Required When Any Appearance Asset Is Missing)
First list the exact missing items, such as Character B identity, environment, principal creature, vehicle, product or story-critical prop. Do not treat a text description, blockout or carrier proxy as the missing item's final appearance reference.
Question: The current references are missing [item list]. How should each missing reference be handled?
- I will upload it: wait for the actual image and verify its mapping; do not generate or continue to the film prompt.
- Generate the missing reference: prepare an item-specific appearance brief, obtain approval, generate only the missing image, and wait for image review before continuing.
- Continue without an image: record the user's explicit acceptance that the item will be newly designed from approved text and may have weaker appearance consistency; do not infer this choice from silence.
When multiple missing items need different handling, present one combined card with one question per item or category. Do not enter film generation until every missing item has an explicit decision and every selected upload or generated image has actually arrived and been accepted.

### D | Previs Prompt Approval (Document and Resources Ready)
Question: Produce previs from the current canvas Previs Production Prompt version?
- Approve previs production: execute this phase only.
- Revise the plan: collect shot numbers and action, layout or camera changes; update the document first.
- Keep prompt only: deliver the document without rendering video.

### E | Previs Review (After Rendering and Inspection)
Question: Can this version's carrier paths, rhythm, events, space and cameras be locked, without locking limb poses?
- Accept previs: lock the version; proceed to appearance preparation only if a film is requested, otherwise deliver.
- Adjust specified shots: collect shot/time ranges and issues; revise affected parts only.
- Change action or space: update the previs prompt and obtain renewed approval before production.

### F | Appearance Brief Approval (Generated References Only)
Question: Generate the reference images from this appearance brief?
- Approve reference generation: approve the listed image content only; next show the mandatory 1K / 2K Image Asset Resolution card, then produce only those images, not video.
- Change appearance or medium: revise the brief before approval.
- Use uploaded images instead: wait for the user's files.

### G | Reference Image Review (After New Images)
Question: Use these subject, object and environment references for the film?
- Accept references: lock images, finish mapping and preflight, then author the film prompt.
- Revise specified images: retain accepted images and correct only the identified ones.
- Upload replacements: wait for actual files and verify their mappings.

### H | Film Prompt Approval (Preflight and Document Complete)
Question: Generate from the current canvas Stylized Film Generation Prompt version?
- Approve film generation: approve this version's content and mapped inputs; next show the mandatory 768P / 2K Video Asset Resolution card, write the choice into the document, then execute and explain scope and known cost.
- Revise the prompt: update specified shots, dialogue or style before approval.
- Keep prompt only: deliver the document without generating video.

### I | Final Film Review (After Completion and Inspection)
Question: How should this film version be handled?
- Accept and deliver: deliver the film and documents.
- Repair specified issues: collect time ranges and issue types, then explain feasible repair scope.
- Make another style: retain this version and usable previs; separately approve appearance and a new film prompt.

A specified issue does not guarantee isolated shot regeneration. If a single-call film cannot be locally edited, explain that the entire clip must be regenerated and may incur cost, then obtain approval. Never promise unavailable local repair.

### J | Failure and Recovery (Actual Blocker Only)
Question: This task encountered [specific cause]. How would you like to proceed?
- Retry the corrected plan: offer only with a concrete correction and terminal evidence for the previous attempt; explain scope. Before any image retry or full video regeneration, show the corresponding mandatory resolution card again and bind the answer to that retry version.
- Adjust production: offer duration, input or capability options justified by the actual limitation; update the prompt first.
- Preserve results and pause: start no new generation and record the resume point.

Do not offer a meaningless continue button. Stop after at most three distinct failed attempts. Never blindly retry identical inputs or duplicate queued/background work.

## Additional Acceptance Checks: Cards and Dependencies

- All inputs and explicit fifteen-second, 16:9, style requirements: skip entry, spec and source cards; review only an unapproved film prompt.
- Idea-only task: previs prompt approval → preview review → appearance brief/images if needed → preflight → film prompt approval; no skipped gates.
- Prompt-only task: no Blender launch or media generation, and no result-review card for nonexistent media.
- Upload selected but no file provided: wait rather than silently generate.
- Style-only change after accepted previs: retain blockout; route changes invalidate related preview acceptance.
- An isolated confirmation with multiple pending versions: resolve its target, never approve several phases together.
- Canvas generation still running: reconcile that task rather than treating waiting as failure and starting another paid attempt.

## Acceptance Examples

Should trigger:
1. Create a 2D film from this interview previs video and character images, preserving all six shots and the English dialogue.
2. Create a racing cinematic from this previs and four appearance references; rebuild the engine sound.
3. Build a three-person rooftop parkour blockout in Blender, then use character images to produce the final film after previs approval.

Should not trigger:
1. Draw a standalone character portrait.
2. Trim this clip to five seconds without changing its content.
3. Create production-ready character topology, UVs and a complete rig for a released game.

Walkthrough: use a two-person kitchen prop exchange. The approved silent previs fixes shot order, camera motion, approach paths, facing, spacing, contact timing and the prop transfer; accepted character, kitchen and prop images define every final visible asset. The synchronized prompt maps each proxy slot once and asks the final film to preserve the exchange outcome while synthesizing natural reach, grip, balance and follow-through. Also test running, turning and jumping: preserve the approved whole-subject trajectory and event rhythm while the final character performs the written action naturally. Editing the Skill never automatically remakes existing media.