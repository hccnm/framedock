---
name: grotesque-handdrawn-animation
description: Turn stories and satire into complete blue-orange, hatched-paper 2D animated shorts, with scripts and character references. Not for 3D or live action.
---

# Grotesque Hand-Drawn Animation

Complete the requested film in this order: story and screenplay → character cards → empty environment cards → full text storyboard → all-purpose-reference video segments → assembly and delivery. For script-only, prompt-only, or asset-only requests, stop at the requested deliverable. [Chinese entry](SKILL.cn.md) describes the same workflow.

## Working principles

- Use only GH-01: flat 2D teal/blue and coral/vermilion shapes, asymmetrical exaggerated characters, fine ink and colored-pencil hatching, matte paper, theatrical space. Read the [style bible](references/style-bible.md); use bundled S0, never the retired original screenshot.
- Choose an image model supporting visual style references; honor an explicit user choice and verify current capabilities before production. Actually supply the bundled [S0 style reference](assets/style-reference.png) and GH-01 prompt for characters, environments and assets, following the [image workflow](references/image-workflow.md). Recommend H3 for multiple visual references and native dialogue; equivalent models are acceptable when they meet the confirmed requirements. Check reference modes, supported lengths and audio availability. Explain any material gap and obtain a decision before changing the plan. Use at most 15 seconds as a planning guideline, shortened to supported lengths at complete action boundaries.
- Continue within existing authorization. Do not require approval after every stage or image, separate calibration tasks, or exhaustive review forms. Ask for the initial image-resolution choice if not already specified; otherwise ask only for user-requested checkpoints, consequential creative changes, budget increases, or blocking capability decisions. Routine corrections follow [QA](references/qa.md).
- Maintain story, asset-card, and storyboard documents in the project, then add clips and the final film. Reuse suitable assets. Templates are optional formats, not additional mandatory deliverables; keep information once.

## 1. Story and screenplay

Use the user's story and chosen duration, format, sound and quality settings. Before the first image generation, present the selected tool’s currently supported image-resolution options and wait for the user’s choice. Reuse that choice project-wide without per-image questions; honor an existing explicit, supported choice. Only other ordinary unspecified settings may use a stated suitable default. Respect cost limits. If no story is provided, offer satire and custom-story options; choose directly when the user authorizes creative discretion.

Write a brief outline and an actionable screenplay with scenes, characters, visible actions, causal turns, ending, and sound. Specify exact dialogue and speaker. Do not add narration, subtitles or music unless requested or part of the chosen story plan. Use [production setup](references/preflight-and-calibration.md) to organize assets, video settings and assembly, then proceed. Do not introduce capability-proof gates or paid tests.

## 2. Character cards

Create a CH card for each independent performer: role, identifying face/hair/body/clothing features, and a clear main reference. Add story-critical transformation, prop or expression references only when needed. Background groups may share an image. Keep clean image sources separate from card labels. See [identity guidance](references/identity-lock.md).

## 3. Empty environment cards

Create one empty SC main image per independent location with layout, entrances, fixed props, lighting and palette. Define a stable scene-facing direction with two or three visible landmarks, then bind CH positions to those landmarks in text; no additional spatial image is needed. Reuse appropriate assets following [asset economy](references/asset-economy.md). Inspect and select usable CH/SC versions before storyboarding; user confirmation is needed only if they requested that checkpoint.

## 4. Text shot plan and video prompts

Do not generate storyboard images, comic grids, or a keyframe image for every shot. Complete the seven-column text shot table before grouping shots into generation segments; the table and segment prompts are the text storyboard, without another duplicate document. Use [production templates](references/production.md). Define visible action, expression, shot size, camera position, movement, cuts, sound and continuity.

Plan segments of at most 15 seconds, within the selected model’s actual supported lengths. A 30-second film may use two 15-second segments only when supported, or more shorter segments; preserve complete actions without speed changes. Each prompt starts at local time 0 and explicitly specifies every shot's timing, shot size, camera movement or fixed camera, movement direction/speed/stop position, and cut time/type. Distinguish a cut to a close-up from a continuous push-in; never label a multi-shot segment a single take.

Use [spatial continuity](references/spatial-continuity.md) to specify landmarks, CH positions, the action axis and movement paths. Include a brief spatial block in each segment prompt and describe camera side and character-state changes at each cut. Distinguish camera movement, character movement and cropping out of frame; a reverse angle does not mean swapping seats. Grotesque deformation may alter shape and perspective without silently relocating characters relative to landmarks.

## 5. Generate video with all-purpose references

Do not generate an opening frame, storyboard images, or per-shot keyframes. Recommend H3 for multi-reference identity and sound, subject to the capability and user-choice rules above. Attach each segment's required CH character, SC environment, and story-critical prop/form images through the video entry's actual image inputs; identify each image and its role in the prompt, then generate directly.

All-purpose references guide identity, space and visual style; no reference must become the exact first frame. Do not create a composite opening image or block production because one is absent. Textual descriptions and unresolved image placeholders do not replace actual image inputs.

Follow [all-purpose-reference production](references/h3-reference-production.md), checking that reference roles and quantities are supported. Briefly record used materials and outputs, without separate review forms. Each segment follows the supported duration and action budget, and may contain multiple timed shots. Specify cuts, camera movements, shot sizes, actions and expressions. Each dialogue shot names its speaker, exact words, timing and consistent voice; others do not make speaking mouth movements.

For a continuous follow-on segment, follow [segment handoff](references/segment-handoff.md): after the previous segment finishes, extract a clear image representing its actual ending state and attach it alongside required CH/SC images in the all-purpose reference inputs. Use it for positions, facing, props and action state only; never bind it to first-frame, start-frame or start/end-frame control. Design the next opening shot separately, without requiring the ending composition to be copied; do not hold the reference image or replay completed action. The first segment needs no prior ending image; explicit scene/time changes establish their own staging.

Inspect returned segments and correct only issues affecting story clarity, identity, action or usability within scope and budget. Do not repeatedly regenerate minor texture differences. If references are insufficient, add only the necessary character, environment or prop asset, not an image for every shot.

## 6. Assemble and deliver

Continue to assemble clips, add planned audio, and export the film at the agreed format. Preserve the storyboard; do not change speed, remove story beats or add filler to force duration. Watch the complete film for story completion, continuity, sound and usable export. Deliver the film plus existing script, cards and storyboard; do not stop at generated clips or pending routine approvals. Report genuine tool blockers and any inspection that was unavailable honestly.

Resume from the unfinished stage using [workflow continuation](references/workflow-gates.md); do not repeat completed work.
