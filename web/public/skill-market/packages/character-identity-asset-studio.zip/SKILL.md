---
name: character-identity-asset-studio
description: |
  Build a reusable character identity and asset package from a brief and optional face or outfit references. Guides candidate selection, look confirmation, and front/back asset delivery.
trigger-words: [character creation, character asset, character identity, face anchor, character sheet, 角色制作, 角色资产, 角色身份, 人脸锚点, 角色资产包]
---

# Character Identity & Asset Studio

For the final asset sheet, use a clean white background by default and keep it consistent across all three panels.

Use this Skill when the user wants to create a reusable fictional or virtual character identity, not merely a one-off portrait. Its primary creative goal is to produce a character with a distinctive, memorable design fingerprint rather than a generic attractive template. The workflow remains three stages—face, outfit, and asset sheet—while embedding personality, profession, lifestyle, narrative props, micro-expression, and silhouette decisions inside the face and outfit design.

## Core principles

- Design for memorability: every character must have a small set of distinctive, repeatable visual anchors that make the character recognizable at a glance.
- Avoid generic beauty defaults and interchangeable styling; personality should be visible in the face, silhouette, hair, outfit construction, accessory logic, or one signature detail.
- Anchor each character to a specific subculture, profession, lifestyle, or social role rather than a broad label such as “cool” or “cute.”
- Give the character one narrative prop that explains what they do or how they live; do not leave every character empty-handed by default.
- Use a deliberate contrast between materials, fit, silhouette, age, and behavior when designing multiple characters so they remain distinguishable as a group.
- Define a characteristic micro-behavior or resting expression that matches the personality; do not use the same neutral smile for every character.
- Lock identity before styling the outfit.
- The selected primary face is the only face authority for the rest of the workflow.
- Use Midjourney only for face candidates and generate one four-image candidate set per round. Present the four candidate images as four independently visible cards for user selection; do not collapse them into one folded result. Do not call GPT 2 or NanoBanana 2 in this step.
- Outfit references contribute clothing, footwear, accessories, hair, makeup, and visible design details as applicable; they do not replace a confirmed face.
- Do not require a separate look confirmation when the outfit direction is already clear and actionable; generate directly and let the user review the rendered look. Ask before generation only when missing information or conflicting choices would materially change the result.
- Preserve successful intermediate assets during revisions; change only the requested part when possible.
- The final package is one generated 16:9 character asset sheet by default, not a collage assembled from separate outputs; it must explain the purpose of each component shown on that sheet.
- A face anchor is also a hairstyle and head-shape reference: do not use a tight crop that touches the top edge or cuts off the hair silhouette.

## The three-stage structure

Keep the production sequence fixed: **face → outfit → asset sheet**. Personality, profession, lifestyle, narrative props, characteristic behavior, material contrast, and silhouette memorability are design criteria within these stages, not extra production stages.


## Generation failure handling

A provider timeout, temporary concurrency error, empty image response, or transient backend failure is not a creative rejection and must not change the selected identity, hairstyle-completeness requirement, design fingerprint, or user-approved source. On the first failure, retry once with a shorter equivalent instruction on NanoBanana Pro while preserving all hard constraints and the same source. Do not silently switch identity, discard references, or ask the user to choose again. If the retry also fails, report the actual failure and wait for an explicit retry rather than repeating indefinitely.

## STEP 1: Capture the character brief

Collect or infer only from the user's request:

- character purpose or campaign context;
- adult/minor status when stated or necessary;
- gender presentation when stated;
- face, hair, makeup, body, outfit, footwear, and accessory preferences;
- available face, character, outfit, scene, or style references;
- requested output ratio and intended downstream use; face-candidate generation defaults to 1:1 without asking.

If the identity or final artifact is materially ambiguous, ask one focused question before generation. Do not ask for a full production brief when the user has already provided an actionable character goal.


## Guided inquiry flow

Use focused questions at creative decision points instead of asking for a long form. Preserve the following sequence:

1. **Character brief** — Ask only for missing high-impact information: purpose, age status when relevant, gender presentation when relevant, personality, profession or lifestyle, body direction, and intended use. If the request is already actionable, infer the rest and do not repeat it.
2. **Face direction** — Before generating candidates, ask a compact choice set covering facial impression, face shape or feature emphasis, eye expression, hairstyle direction, and any face reference path. Include a free-text option. Record the selected direction as the identity constraint.
3. **Design fingerprint** — Confirm or infer two to five visible signature traits and one identity anchor such as subculture, profession, lifestyle, or social role. Ask only when multiple interpretations would materially change the character.
4. **Outfit direction** — Before full-body generation, confirm clothing silhouette, footwear, accessories, narrative prop, and characteristic micro-behavior when they are missing or conflicting. If the user has already supplied a clear, actionable outfit direction, summarize the interpretation and proceed without asking the same question again.
5. **Generation checkpoint** — Before a costly full-body or final asset-sheet generation, briefly restate the locked face, outfit, signature traits, prop, behavior, and output format. Ask for confirmation only when a material choice remains unresolved; otherwise proceed.

Keep questions short, choice-oriented, and limited to decisions that change identity or deliverable quality. Do not ask the user to reconfirm an already approved face or outfit. If the user rejects a result, ask what changed—identity, silhouette, clothing, prop, expression, or framing—and revise only the earliest affected stage.

## STEP 2: Confirm face direction

Use a short guided choice sequence to resolve the highest-impact face decisions, such as overall facial character, face shape and features, eye preference, and the preferred generation path. Keep questions limited to choices that materially change identity. If the user supplies a usable face reference, offer a reference-led path instead of forcing a from-scratch face design.

Record the chosen face direction as an identity constraint. Do not let later outfit references overwrite it. Also define a provisional design fingerprint: two to five concrete, visible traits that distinguish this character from an ordinary generated person. These traits should be compatible with the brief and should be carried into the face, hairstyle, silhouette, outfit, accessories, narrative prop, or characteristic behavior. Include a specific identity tag covering at least one of subculture, profession, lifestyle, or social role.

## STEP 3: Generate the four Midjourney face candidates

Run Midjourney only and request one four-image candidate set. Use a 1:1 square frame by default unless the user explicitly requests another ratio. Apply the same confirmed brief and face decisions to all four candidates, display the four images together, and ask the user to select one. If the user rejects all four, regenerate a new four-image set while preserving the accepted constraints and recording the changed direction. Native model watermarks or platform marks may remain on candidates at this stage; remove them only from the selected candidate before making the primary face reference, without changing identity or composition.

Do not proceed until exactly one candidate is selected.

When the canvas collapses the four Midjourney variants into one generation card, show this user notice: “Midjourney has generated four candidate images. The canvas may display them inside one folded result card, but all four files are available. Please expand the card or choose one through the attached files.” Do not claim that the four candidates are missing, and do not generate another set merely because the canvas is folded.

## STEP 4: Create the primary face reference

Use NanoBanana Pro by default for primary face-anchor standardization, watermark cleanup, and hairstyle-contour preservation. Standardize the selected candidate into a clear primary face reference suitable for identity matching and hairstyle continuity. Normalize the view and presentation enough to make the face legible and reusable, while preserving the selected person's distinctive identity. The framing must be front-facing and eye-level, include the full top and side hair silhouette, leave modest, natural headroom above the hair, and keep the face, ears, neck, and shoulder base readable. Do not allow the hair to touch the top edge or let the crop remove hairstyle information. Name and describe this asset as the **Primary Face Reference** or **唯一人脸锚点**.

Before continuing, check the anchor for face completeness, hairstyle completeness, headroom, side clearance, and a clean neck/shoulder base. If the hair is cropped, repair or expand the anchor before accepting it; do not add excessive empty space that makes the portrait look small or awkward.

This asset becomes the single face authority. Every later look, angle, body separation, and back-detail asset must remain compatible with it.

## STEP 5: Collect and adapt the outfit

Accept an outfit reference, multiple outfit/accessory references, or a text-described look. Identify the usable clothing and styling contribution without importing an unrelated person's identity. Reconcile the outfit with the locked face and the requested body design.

Prepare a concise look summary covering:

- hair and makeup;
- body and silhouette;
- clothing;
- footwear;
- accessories;
- visible construction or design details;
- unresolved areas that require user choice;
- the character design fingerprint and which visible elements carry it;
- the subculture, profession, lifestyle, or social role anchor;
- the narrative prop and characteristic resting behavior or micro-expression.

If the reference does not show a needed area, mark it as an open design choice rather than pretending it is confirmed.

## STEP 6: Confirm or directly proceed with the complete look

When the outfit direction is clear and actionable, skip a separate confirmation prompt and proceed directly to full-body generation. Present the interpreted look in the generation brief and let the user review the rendered result. Ask before generation only if a missing or conflicting material choice would materially change the character. In either case, check that the complete look contains at least one clear signature feature, one identity or profession cue, and one behavior or prop cue, and that the overall combination is specific enough to distinguish this character from a generic version of the requested style.

## STEP 7: Generate the full-body character look

Generate one complete full-body look using the Primary Face Reference and the confirmed styling direction. Preserve the character's identity, body silhouette, clothing construction, footwear, accessories, signature features, and requested presentation. Reject or revise a result that is technically consistent but visually generic, forgettable, missing the approved design fingerprint, or disconnected from the character’s profession, lifestyle, social role, prop, or characteristic behavior. Present the result for look approval.

If the result is rejected, diagnose the requested correction and revise the smallest affected component. Keep the primary face and approved styling fixed unless the user changes them.

## STEP 8: Generate the single character asset sheet

After look approval, generate one 16:9 character asset sheet in a single image-generation pass. Do not use an external layout image as a generation reference, and do not assemble or collage previously generated images. Generate the three-panel asset sheet in one pass from the approved character inputs. Use a clean three-way equal vertical split with two fine dividers on a white background: front body without head on the left, back-detail completion in the center, and the face/hairstyle anchor as a head-and-shoulders view on the right. Do not add text, labels, titles, measurements, or logos. Arrange the approved identity and look components clearly within the one sheet:

### A. Front Body Without Head

A front-facing body and outfit asset with the head and face removed or separated. Preserve the neck transition, body proportions, clothing, footwear, and accessories. This is used when the locked face must be reintroduced without creating a second identity.

### B. Back Detail Completion

A back-facing or back-detail asset that completes hairstyle, garment construction, closures, accessories, footwear, and other details not visible from the front. Do not invent a new face or redefine the identity in this asset.

### C. Unique Face Anchor

The standardized Primary Face Reference. Keep this as the sole identity anchor for future generations, angles, expressions, and motion work.

If the workflow or user requests additional deliverables, add them only as explicitly named variants on a separately confirmed sheet. Do not treat optional variants as required outputs by default.

## STEP 9: Deliver and support revisions

Deliver the single character asset sheet with a short purpose note for each component shown on it. Keep the primary face, approved look, and derived assets linked conceptually so future work can reuse the correct source.

For revisions, preserve the three-stage structure and return only to the earliest affected stage:

- face change → return to face candidate selection and create a new identity chain;
- outfit change → keep the face anchor and revise only styling-dependent assets;
- body or proportion change → keep the face anchor unless explicitly changed;
- missing back detail → revise the back-detail asset without changing the front identity;
- quality or anatomy issue → correct the affected asset and preserve all approved constraints.

Do not claim the package is complete until every requested final asset has been produced and is usable in the project workspace.

## Trigger boundaries

Use this Skill for reusable character identity and character asset creation where recognizability and distinctive design are important. It should make the result more specific and memorable than an ordinary one-off generation. Do not use it for a single unrelated portrait, a simple background replacement, a local repaint with a clearly marked region, a generic image-to-video request, or a full animation/video project whose main deliverable is not the character asset package.
