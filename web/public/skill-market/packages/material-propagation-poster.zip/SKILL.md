---
name: material-propagation-poster
description: |
  Turn a subject visual and optional texture reference into a still key art, restrained material-motion poster, and social variants. Use for visible surface journeys, not ordinary poster design.
trigger-words: [material propagation, material journey, surface takeover, ink spread poster, coating animation, patina growth, crystal growth poster, dynamic material poster, surface growth poster, material spread]
---

# Material Propagation Poster

Turn a subject image plus a texture reference into a controlled, loopable motion-poster package. The package must make the growth behavior explicit: where it starts, how it travels, what remains protected, how the camera behaves, and what is delivered for each format.

## Operating Rules

- Treat the subject image as the geometry and identity source. Preserve silhouette, facial landmarks, product edges, text blocks, logos, and lighting direction unless the user explicitly asks for a transformation.
- Treat the texture reference as a material/mark-making source, not as a second subject. Extract its palette, scale, edge quality, repetition, and motion affordance.
- Separate three layers in every plan: protected subject, growing texture, and unchanged background/layout. Never let growth invent a new face, limb, product part, letter, or logo.
- Lock the camera by default. If a camera move is requested, keep it subordinate to the growth and specify the exact path and amount.
- Define a seed point, a propagation path, a stopping rule, and a loop strategy. "Texture spreads" alone is not an executable instruction.
- Prefer a 4-8 second shot, one visual action, and one dominant material. Create variants through timing, palette, or path, not by adding unrelated effects.
- Do not silently add poster typography. If the uploaded source poster/cover already contains text design, preserve that original typography when the user wants it kept. If the source has no text, or has text that the user does not want to preserve, ask whether a text-designed poster is needed; only create new typography after the user confirms and provides text/theme.
- Never jump directly from raw subject + texture references into final video generation unless the user has already confirmed a still poster/key image in this session.
- When the source image already has text design, treat that text as part of the protected composition. Preserve the original typography through the still-image confirmation step unless the user explicitly requests text redesign or removal.
- Before still-image generation, ask the user to choose the output size/aspect route when it is not already explicit. Offer practical presets such as 9:16 vertical social poster, 4:5 feed poster, 1:1 square post, 16:9 landscape screen, or custom size/ratio. The confirmed size applies to both the still poster/key image and the later dynamic video unless the user changes it.
- If the user provides platform intent instead of numbers, map it to a clear ratio and state it before generation: vertical short-video platforms -> 9:16, feed poster -> 4:5, square social post -> 1:1, widescreen display -> 16:9.
- In the dynamic video, the subject must have appropriate motion and must not remain completely frozen. Use subtle premium motion such as breathing-like parallax, micro rotation, marble surface shimmer, fracture-edge settling, tiny debris suspension, or depth-layer drift while preserving identity and geometry.
- Text motion should be simple, restrained, and readable by default. For source text or user-explicit added text, use minimal motion such as gentle fade-in, slight opacity breathing, very small position drift, or a simple mask reveal. Avoid aggressive kinetic typography, large sliding, heavy scaling, complex 3D extrusion, word-by-word chaos, or background-filling text motion unless the user explicitly requests it. Text must remain legible and must not melt, duplicate, become garbled text, or change wording.
- For still poster typography, use a refined editorial hierarchy. Main titles should create spatial depth through foreground/background layering, partial occlusion by the subject, or a behind-the-head/behind-object relationship. Prefer restrained but high-character display typography for the main title, paired with small clean sans-serif micro-text only when the user provided or requested such information. Do not let new typography flatten the subject or cover important facial/expression areas.
- Poster backgrounds should support the subject, not compete with it. Prefer low-detail atmospheric grounds with subtle micro-textures, faint organic linework, halftone grain, or aged surface details. Keep background contrast low enough that the subject silhouette, typography, and texture growth remain the hierarchy.
- Lighting should feel sculptural and premium: directional top/side light, strong chiaroscuro, readable occlusion in recesses, soft but defined shadows, and semi-matte or semi-satin material response. Texture and typography must inherit the same lighting space.
- Poster design should also support a pop-trend, retro magazine cover look when requested. Use a centered frontal composition with a very high subject-to-canvas ratio; let the hero subject occupy roughly 70% to 90% of the frame so it dominates the poster. Allow the subject to crop slightly against the frame edges when that strengthens impact.
- Use a retro magazine cover hierarchy for typography: a bold masthead or main title across the top, with the hero subject overlapping or partially occluding the title for depth. Supporting text can sit symmetrically at the mid-sides or as a small bottom caption. Keep the title large enough to read as a cover, but do not bury the subject.
- Backgrounds should be dark, graffiti-like, and gritty when requested: low-luminance, low-detail, with subtle street-art linework, print noise, distressed texture, or faint doodle-like marks. The background must stay secondary and should separate from the subject through contrast in luminance and texture density, not by adding visual clutter.
- Pop-art cues may include clear halftone / screen-print texture on the subject or surface pattern, and flowing graphic flame / stream shapes aligned to the subject's form. Keep these cues integrated into the sculpture or hero object rather than floating as decorative noise.
- Lighting should feel sculptural and premium: directional top/side light, strong chiaroscuro, readable occlusion in recesses, soft but defined shadows, and semi-matte or semi-satin material response. Texture, typography, and the dark graffiti substrate must inherit the same lighting space.
- If the user asks for more visible text motion, strengthen it only within simple design language: clearer fade-in, slightly stronger opacity pulse, or a clean single-direction mask reveal. Do not invent new text or change the confirmed poster layout.
- The whole poster should feel like a high-end breathing motion design piece: subject motion, texture growth, typography motion, and camera micro-movement should be coordinated, restrained, and premium rather than static or chaotic.
- Texture propagation must happen ON the subject, not around it as detached decoration. For portrait, sculpture, character, or body-like subjects, default propagation starts from the face and expands outward in a continuous, clean growth action: across facial planes, along eyes/nose/mouth structure, through hair or curled hair masses, down the neck, then naturally over the full body or bust surface. The growth should be fluid, decisive, and elegant, never slow crawling, worm-like wriggling, muddy spreading, or random flicker.
- Preserve the subject's silhouette, gloss, lighting, material relief, and geometry completely. The growth layer only overlays / reveals a texture pattern on top of the existing surface; it must not deform facial features, change hair volume, bend the neck/body, destroy sculptural highlights, or replace the base material.
- Texture on the subject must use 3D surface-conforming mapping. Patterns must bend, stretch, compress, and warp according to facial planes, muscles, hair curls, folds, wings, clothing folds, product curvature, or mascot geometry. Avoid flat 2D stickers pasted across the image.
- Texture color fidelity is required. When the user provides a texture reference, the texture as it appears on the subject must preserve the reference texture's original color relationships, tonal contrast, and palette character while adapting to the subject's lighting. Do not arbitrarily recolor the texture to match the subject, background, or brand unless the user explicitly asks for recoloring.
- Preserve the subject's lighting channels under the texture. Highlights, shadow boundaries, ambient occlusion, relief depth, and material grain must remain visible through the pattern. Treat the texture as a shading-preserved overlay, not an opaque repaint.
- Use structure-aware texture zoning when helpful: sharp decorative motifs on outer contours or hair/crown edges; halftone/grain/gradient fields over face, robe, body, or broad planes; denser growth in recessed areas while keeping facial landmarks readable.
- If the user uploads a poster, cover, flyer, or any source image that already contains typography, keep the source text design intact by default. Do not remove, erase, simplify, or replace the existing text unless the user explicitly asks for text removal or a redesign. The growth layer may pass around, behind, or through the typography only when it does not damage legibility.
- For sculpture or marble-like subjects, keep the sculpture contour and polished/highlight structure fully readable throughout. The texture is a surface motif that grows over the sculpture, not a new anatomy, new cracks, melting, flashing, or noisy particle effect.
- The final dynamic effect must present the confirmed key image state. The video may start cleaner or partially grown, but the peak / hold / final readable poster state must visibly match the confirmed still poster/key image: same subject, composition, texture placement, typography decisions when present, and overall visual design. Do not animate away from the approved key image into a different look.
- For loopable videos, the animation should either return smoothly to the key image state or use the key image state as the main hold/final frame. If a reset is used, it must not erase the user's approved design; the approved key image remains the target visual state.

## Inputs and Defaults

Accept any combination of:

1. **Subject image**: portrait, sculpture, product, garment, architecture, landscape, poster, cover, or abstract base.
2. **Texture reference**: thermal/rainbow, botanical, ink, halftone, chrome/liquid, fabric, glitch, paint, cellular, or custom.
3. **Optional brief**: title/copy, brand constraints, aspect ratio, duration, audio, platform, model/engine, and desired loop behavior.

### Built-in texture recommendations

If the user provides a subject image but no texture reference, recommend a small choice set before generating the key image. Do not invent a hidden texture silently. Offer 3-6 options from these built-in styles, selected to fit the subject and use case:

1. **Vector flora pattern** -- outlined botanical units, vines, leaves, flowers, clover/star blossoms; best for elegant organic growth, brand-friendly illustration, soft IP characters, sculptures, and decorative posters.
2. **Fluid / flame gradient** -- flowing flame-like or liquid wave branches, nested bands, heat-wave rise; best for energetic posters, music/tech visuals, and bold material transformation.
3. **Halftone / risograph texture** -- dither dots, grainy edges, printed bands, scanline-like reveal; best for retro print, zine, streetwear, editorial, and screen/ink aesthetics.
4. **Aura / thermal starburst** -- radial core expansion, soft rings, blurred energy halo; best for spiritual, sci-fi, energy bloom, premium glow, and icon-centered posters.
5. **Sharp jagged / zebra pattern** -- high-frequency angular zigzags, directional stripe spikes, aggressive tearing edges; best for high-tension, punk, sports, action, and fast spreading effects.
6. **Block print / stamp texture** -- repeated stamped motifs, distressed ink holes, handmade uneven edges; best for handmade, folk, archive, poster-print, and sequential stamp-reveal motion.

When recommending, briefly state why each option fits. If the user chooses one, treat it as the texture reference for both key image and video; for built-in textures without an uploaded reference, choose a coherent palette that fits the subject and any text theme. When an uploaded texture reference exists, preserve its color character on the subject.

When details are missing, do not silently choose size/aspect for media generation; ask the size question first. For non-blocking prompt-only drafts, suggested defaults are 9:16 vertical master, 5 seconds, locked camera with premium micro-motion, silent, seamless start/end match, texture-only change unless text design is requested, and a clean final frame for typography.

## Workflow

### 1. Inspect and classify

Create a short asset brief before writing prompts:

- Subject class and visual anchors (face, hands, product contour, architectural lines, title block).
- Foreground/background separation and protected zones.
- Texture properties: palette, contrast, grain, edge softness, repetition scale, and whether it reads as growth, flow, bloom, fill, or contour.
- Best seed area and a plausible propagation route that follows the subject's form.
- Output route: hero loop, social crop, editorial cover, product reveal, or contact-sheet campaign.

If the input is a finished poster, keep the existing layout as a locked plate and grow texture only inside the chosen subject mask. If a mask cannot be inferred, request one or describe a manual masking pass.

### 2. Select a scenario recipe

Read [references/scene-presets.md](references/scene-presets.md) and select one primary preset. Combine at most one secondary modifier. Record the choice as `scenario + modifier`, for example `portrait-sculpture + thermal-spark` or `product + liquid-chrome`.

### 3. Confirm size and source-text handling before media generation

Before generating the still poster/key image or any video, confirm the output size/aspect when it is not already explicit. Ask the user to choose one:

- **9:16 vertical poster/video**: default for Douyin, TikTok, Reels, Shorts, phone lock-screen, and vertical motion posters.
- **4:5 feed poster**: default for Instagram/Xiaohongshu feed-style posters.
- **1:1 square post**: default for square social posts and compact cover loops.
- **16:9 landscape screen**: default for widescreen display, YouTube, presentation, or stage screen.
- **Custom**: user provides exact ratio or dimensions.

Use the confirmed size for the still poster/key image and keep the same size for the dynamic video unless the user explicitly changes it.

Then handle text as follows:

- **Source already has text design + user wants to keep it**: preserve the existing typography, text content, placement, hierarchy, and layout as protected composition. Do not remove, simplify, replace, or redesign it. Generate a still key image that keeps the original poster text and adds only the texture-growth state. Present it for confirmation.
- **Source has no text, or source has text but the user does not want to preserve original text**: ask whether the user needs a poster with text design. If the user says no, generate a no-text texture-growth key image. If the user says yes, ask for the text/theme, then design a still poster that combines the uploaded subject, the text content, and the chosen/uploaded texture style/color language. Present this designed poster for confirmation before any video generation.
- **User explicitly asks to add or replace text at any time**: collect the short copy/theme and generate a complete still poster image with new typography for confirmation.

For new text design, keep typography premium and appropriate to the subject and texture. For dynamic video, text motion remains simple by default: fade-in, slight opacity breathing, tiny drift, or clean mask reveal.

This confirmation still is the visual lock and target state for the video stage. If the user requested a pop-trend or retro-magazine look, the approved poster should be centered, high-contrast, subject-dominant, and the typography/background should follow that layout language. Preserve its subject identity, texture placement, composition, confirmed size/aspect, poster/layout decisions, and final visual condition. The original subject and texture references remain supporting references, but the confirmed still image becomes the main visual authority. The dynamic video must visibly arrive at or hold this key-image state rather than drifting into a new design.

### 4. Design the growth action

Choose one growth mode:

- **Branching flow**: a thin vein or line branches along facial planes, garment seams, product edges, or architecture.
- **Bloom**: a seed expands into cells, flowers, stars, or soft islands while keeping the underlying form readable.
- **Contour fill**: the texture fills a bounded mask from a point or edge, useful for posters, products, and flat illustrations.
- **Wrap and cascade**: the material wraps around a 3D form and continues downward or outward, useful for sculpture, fashion, and bottles.

Specify:

`face seed -> facial features -> hair / curled masses -> neck -> body coverage -> stop -> settle`

For portrait / sculpture / character subjects, use this as the default propagation grammar unless the user explicitly requests another seed. The movement must be continuous and clean: no slow crawling, no worm-like motion, no flicker, no detached floating layer.

Use measurable language: "starts at the left temple at 0.4s, reaches the blindfold edge at 1.8s, covers 65% of the neck by 3.6s, freezes at 4.2s, then returns to the seed by 5.0s."

### 5. Build the shot specification

Write a timeline with 4-6 keyframes. At minimum include:

- **0.0s**: clean source state, camera and lighting lock, but with a planned micro-motion baseline instead of a frozen still.
- **Seed**: first visible mark and its material behavior, plus the subject's subtle response motion.
- **Travel**: route and speed, with no jump cuts; coordinate texture propagation with subject breathing/parallax motion.
- **Typography motion**: if the poster contains text, specify a simple readable plan: gentle fade-in, opacity breathing, tiny drift, or clean mask reveal, then settle into the confirmed layout.
- **Peak**: maximum intentional coverage; this must match the approved key image's texture placement and design state while preserving silhouette, anchor details, and typography.
- **Hold**: readable poster frame for 0.4-0.8 seconds; hold the approved key image state with premium micro-motion.
- **Loop/reset**: reverse, dissolve, or match-cut smoothly without losing the approved key image state; if the video loops, the key image state remains the visual target/final hold.

For each keyframe include subject state, texture state, camera, lighting, and failure guard. Use [references/prompt-templates.md](references/prompt-templates.md) for the exact block order.

### 6. Produce the prompt packet

Return these artifacts in one response or file:

1. **Asset brief** with masks, anchors, seed, route, and protected zones.
2. **Master image-to-video prompt** in the user's language, plus a compact English version when the chosen engine benefits from it.
3. **Negative prompt / guardrails** that forbid identity drift, geometry changes, camera drift, unwanted particles, and text corruption.
4. **Shot table** with timestamps and expected visual state.
5. **Variant set**: at least three variants that change only one variable each (growth path, palette/material intensity, or timing).
6. **Post-production notes** for typography, masking, loop stitching, crop-safe areas, and export.

If the user requests generated media rather than prompts, follow the still-first route above: create the no-new-text poster/key image, ask for confirmation, then generate the dynamic video from the confirmed still. Still provide the shot table and QC report. Generate a clean keyframe first when the texture must align tightly to a face, body, product, or letterform.

### 7. Run quality control

Use [references/qc-checklist.md](references/qc-checklist.md). Reject or revise any result that changes protected geometry, breaks the propagation route, causes temporal flicker, corrupts typography, or loses the intended material identity. Report the failure and the smallest repair prompt instead of silently accepting it.

## Scenario Coverage

Support these routes without changing the core workflow:

- Portrait or sculpture: face/neck/garment masks, landmark protection, contour-following growth.
- Fashion or product: seam/edge-aware wrap, logo and material protection, tactile reveal.
- Architecture or interior: line/grid-following spread, planar masks, restrained parallax.
- Editorial cover or campaign poster: locked type/layout plate, multi-panel variants, clean hold frame.
- Nature or organic subject: vein/branch/cellular growth, controlled asymmetry, soft stop.
- Data, tech, or abstract visual: heatmap, signal, particle, or waveform growth with grid-safe composition.

For detailed choices, load only the relevant section of `scene-presets.md`.

## Failure Repair

- **Texture floats above the subject**: add a subject-normal/contour-following instruction, reduce parallax, and anchor the seed on the face or another visible subject landmark. Require the pattern to grow on the surface, not around the subject.
- **Texture crawls too slowly or looks worm-like**: replace crawling verbs with continuous, clean, decisive growth; specify face-to-features-to-hair-to-neck-to-body propagation and forbid wriggling, muddy spread, and random flicker.
- **Face or product deforms**: strengthen protected landmarks and require "texture changes color/pattern only; geometry and lighting remain unchanged."
- **Growth pops instead of travels**: add intermediate states, specify continuous propagation, and remove scene changes or camera motion.
- **Texture becomes generic noise**: name the reference properties (palette, motif, edge softness, scale, repetition) and forbid unrelated particles.
- **Texture color is lost or recolored incorrectly**: explicitly require preserving the uploaded texture reference's original color relationships and tonal contrast on the subject while keeping subject lighting/shading visible.
- **Poster text melts**: render the motion without type, then composite editable text; keep a clean hold frame.
- **Loop feels discontinuous**: use reverse growth or a matched key-image/state frame, and reserve the last 0.2s for settling into the approved key image state.
- **Final video does not look like the confirmed key image**: rewrite the video prompt so the peak/hold/final frame explicitly presents the approved key image state; reduce extra effects, camera drift, and new design changes.
- **Source text gets removed or simplified unexpectedly**: explicitly lock the existing typography as protected composition and state that it must remain intact unless the user requests redesign/removal.

## Optional Deterministic Helper

For repeatable prompt packets, use `scripts/build_prompt_packet.py` with a JSON config containing `title`, `subject`, `texture`, `scenario`, `growth_mode`, `duration`, `aspect_ratio`, `seed`, `route`, and `protected_zones`. The script only formats a packet; visual judgment and generation remain in the workflow above.
