---
name: reference-video-recreation-workflow
description: Use a reference video to preserve motion, clarify changes, reduce iteration, and improve recreation success through shot breakdown, controlled generation, and evidence-based validation.
trigger-words:
  - reference video recreation
  - shot-by-shot reconstruction
  - recreation director
  - video recreation workflow
  - reference film breakdown
---

# Reference Video Recreation: Direction, Production Decisions and Acceptance

## Opening Intake: Source Video and Requested Changes

Start every new recreation task with one concise intake question:

> Please upload the video you want to recreate and describe what you want changed. For a character, product, logo, or other replacement, also upload the relevant reference asset. Anything not specifically changed will follow the source video by default.

Apply this gate proportionally:
- If no source video and no change request are available, ask for both.
- If the source video is already attached, ask only what needs to change; do not ask the user to upload it again.
- If the requested change is clear but a required replacement asset is missing, ask only for that missing asset.
- If the source, requested changes, and required references are present, proceed to evidence analysis and the change script without repeating the intake question. An attached source alone is not a complete intake.
- If the user explicitly says “recreate it as-is” or equivalent, treat that as the confirmed no-change scope. If a source video is attached but the user only says “recreate this” or otherwise gives no modification scope, ask what they want changed before analyzing or drafting the script; do not infer as-is recreation.
- Treat framing, rhythm, sound, and other unchanged properties as inherited from the source unless a real conflict or missing input blocks execution.
- This intake collects requirements; it is not generation approval. The script-confirmation gate still applies before generation.

Reconstruct a reference film as a traceable MiniMax Design process: source evidence → user-visible change script → explicit script approval → platform video generation → comparison and authorized corrections → rendered video and any requested, genuinely supported editable deliverables. Work in the available project, canvas, models and plugins; preserve user requirements for tools, accuracy, budget and delivery.

This Skill supplies instructions, not APIs, models or editor capabilities. Documentation does not prove that a capability is connected in this session. Read [platform adaptation evidence](references/platform-guide.md) when checking boundaries or updating the adaptation.

Before planning or submitting video work, read the relevant operation reference in `references/` and verify the current MiniMax Design capabilities. Historical documentation is not a fresh capability guarantee. If the approved video capability is unavailable, report the gap rather than silently switching. Still images and standalone audio require their own available capabilities.

## 0. Orchestrator Responsibilities and Credit Protection

The orchestrator is the recreation director, production decision-maker and acceptance lead, not merely a shot transcriber or task dispatcher. Greater responsibility does not grant greater spending authority.

- **Recreation director:** identify information order, visual hierarchy, action triggers and pauses, transition connections, sound and rhythm. State the essential viewing effect of each key section. Separate observation, inference and unknowns; do not present inferred authorial intent as fact. Default to faithful recreation; adaptation and brand replacement follow user instructions.
- **Production decision-maker:** choose editor reconstruction, generated video or a hybrid per shot, stating rationale, shared assets, editable scope, risks and economical alternatives. Default to platform reference recreation: the source video controls motion, timing and layout; replacement assets control subject identity, and instructions define copy and theme changes. Editing is an optional deterministic finishing or repair route, not the default reconstruction pipeline. Disclose missing capabilities rather than lowering hard requirements silently.
- **Acceptance lead:** compare actual results against evidence, distinguish hard failures, viewing-impacting issues and tolerable approximations, and propose the smallest correction and adjacent-shot implications. Do not authorize spending or substitute invented similarity scores for evidence.

**Highest-priority rule: failed acceptance must never directly trigger video regeneration. Diagnose first and prioritize repairs using existing assets. Any video regeneration, generative video edit, extension, model-switched remake, generated replacement shot or extra candidate requires explicit user authorization for that round before execution.**

- Initial production approval, an overall budget, remaining credits, a system retry recommendation, or vague feedback such as “improve it”, “not similar” or “continue” is not regeneration authorization.
- A clear acceptance of the sole pending regeneration proposal is sufficient only when the shot scope, count and single-round limit were already explicit. Record shots, generations per shot, duration, proposed changes and spending scope. Execute only the explicitly approved round; there is no automatic regeneration allowance.
- If the approved round still fails acceptance, stop again, diagnose and request fresh authorization. Do not bypass this gate by calling the work a technical retry, sample, local repair, automatic optimization or missing shot.
- Errors, missing results and timeouts do not authorize another submission. Reconcile existing tasks and outputs first, then ask whether to retry. Never duplicate an unknown-status task. If billing or underlying retry behavior cannot be verified, disclose that uncertainty rather than guaranteeing no charge.
- Repair order: reuse existing candidates or usable ranges → adjust editing, crops, text layers, audio sync and supported effects → user-accepted approximation or downgrade → separately authorized minimal regeneration. Changes to creative direction, specifications or editability still require approval.
- Do not describe all post-production, analysis, rendering or image generation as free. Previously authorized post-production may proceed only when it is confirmed not to add generation-credit spending or change hard constraints. Disclose and confirm any new paid step, execution with unknown cost, or out-of-scope work.
- Use a real quote when available. Otherwise say that additional credits may be consumed and the amount cannot yet be verified. Never invent prices or promise a successful fix. No reply means no regeneration.

## 1. Input and Capability Checks

Accept attachments, local files, canvas nodes, Subject Library references or web links. Subject Library is the current MiniMax Design UI name. Inspect the user-specified source first; do not search unrelated projects as a substitute. A webpage, cover or screenshot is not a complete playable reference. Request the original video or a full recording if unavailable, and do not invent shots.

Record duration, resolution, aspect ratio, frame rate and audio where verifiable. Default to shot-by-shot recreation unless adaptation is permitted. Preserve source specifications and content unless the user requests replacements.

Record only the capabilities relevant to the requested delivery, marking each as available, unavailable, or unverified with evidence:

- Reading the reference media and inspecting the frames or time points needed for this task.
- Creating or updating the media, text, shot-table, timeline, or platform project assets actually required.
- The enabled video, image, or audio capability, its input/output limits, and current pricing when exposed.
- Platform editing features such as tracks, text, cropping, transitions, effects, keyframes, easing, masks, nesting, saving, or exporting only when the user requests them or the chosen repair depends on them.
- MiniMax Design project persistence and the actually available save/export capabilities; verify retained assets and supported editable properties rather than assuming them.

Use existing tools and enabled plugins. Do not invent tool names, parameters or project formats. Without a platform connection, deliver analysis and instructions only; never claim native nodes or projects were created.

## 2. Choose the Production Approach

The default is platform reference recreation, including typography-heavy interfaces and motion graphics. Use the source video as motion, staging, event-order, timing and sound guidance; use the replacement image as subject/design guidance; state the requested copy and theme changes explicitly. Do not default to editor reconstruction, require an editable source project, or force a separate still-image generation step merely because the reference contains exact motion or text.

Only after the complete change script in Section 3A has been explicitly approved, the entire reference fits current limits, and execution scope and spending decisions are settled, produce one complete first-pass video rather than unnecessary samples. A broad request to recreate or replace all text does not approve an unseen script. Existing replacement images may be stylistically translated during video generation if the user requested that transformation. If input limits require trimming, transcoding or segmentation, explain the actual compatibility issue and preserve the user's creative constraints; obtain approval when the proposed treatment changes meaningful content. Do not ask again for the already confirmed generation route.

The precision requirement is the acceptance target, not a guarantee of frame-identical generation. Inspect source evidence, bind references carefully, and diagnose the actual output. If the user specifically requests a sample or the approved plan needs one, obtain approval for that sample scope and spending. Failed samples or full first passes enter diagnosis and user decision, never automatic regeneration.

Requirements such as platform-authored animation, independent scene compositions, a master composition, editable text and keyframes are hard constraints. If any capability is missing, disclose it and continue only independent analysis or asset preparation. Do not substitute unsupported capabilities or claim that generated footage provides them. Canvas groups are not compositions.

Use the default reference-generation route unless the user explicitly requests platform-editable layers or a hard capability gap prevents generation. Generated clips have clip-level editability, not separate internal objects, type or motion layers. If a platform editing step becomes necessary, disclose the reason and obtain approval for the changed delivery approach.

Use MiniMax Design capabilities by default. Video-model selection never cancels editability requirements: generated motion-graphics footage is not a native layered animation project.

### Production Decisions and Shared Visual Rules

Extract common subject identity, composition and type hierarchy, scene materials, motion direction, pause timing and transition conventions. User constraints take precedence. Let reference assets carry colors; exact color values require reliable measurement or user specifications.

When replacing a brand or product, distinguish transferable visual methods from original brand identity that must change. Per shot, record the essential viewing effect, invariants, method and rationale, shared references, unknown capabilities and least-cost alternative. Faster generation does not justify discarding exact text or editable-layer requirements.

## 3. Organize References and Shots on the Canvas

Reuse the designated project or use a separate task workspace only when supported. Do not overwrite unrelated work. Organize references, shots, scene assets, editing and acceptance; use stable S01-style scene names and distinguish candidates from selected versions. Groups organize assets; the timeline determines sequence.

Create a shot table with linked reference frames where supported. These are document fields, not API parameters:

| Field | Content |
| --- | --- |
| scene_id | Stable scene identifier |
| time_range | Time and frame boundaries, end-exclusive |
| reference | Source video, keyframes and timestamps |
| visual_spec | Exact copy, line breaks, layout, typography, color requirements and hierarchy |
| motion_spec | Action, pauses, easing, overlaps and audiovisual sync points |
| assets | Input references, results and selected versions |
| route | Editor reconstruction, approved generation or hybrid, with rationale |
| key_effect | Essential viewing effect and invariants |
| shared_rules | Shared subjects, visual rules and reference contributions |
| acceptance | Agreed hard constraints, review priorities and tolerable approximations |
| approval | Current authorized production scope and pending additional spending |
| status | Planned, generating, awaiting review, awaiting user decision, selected, edited or blocked |

Inspect the opening, settled state, intermediate motion and ending, sampling more densely near transitions. Measure position, size, margins, cropping, occlusion and type attributes only when supported; otherwise label estimates or unknowns. Record relevant shadows, blur and texture. Unknown fonts remain candidates or substitutions, not exact matches.

Use one agreed timeline frame rate and timestamps for variable-rate sources. Record key states for position, scale, rotation and opacity; infer easing from intermediate states with uncertainty labels. Lock structure and main motion before fine detail.

## 3A. Mandatory User-Visible Change Script and Approval Gate

Before any initial video generation or a changed regeneration, create or update ONE readable, editable canvas document named for the recreation change script. This is the source of truth for what will appear, not a vague creative brief and not merely a long prompt. Keep platform reference generation as the default route; this gate does not require editor reconstruction or a separate image generation.

The document must contain:
1. **Scope and version:** source and replacement assets, output scope, approved changes versus preserved content, document version and status: draft, awaiting approval, approved, or needs revision.
2. **Shot-by-shot script:** visible start state, sequence of events, important motion/transition handoffs, end state and sound intent. Inherited motion stays grounded in the reference; do not invent measured timestamps or keyframes. Use the source video’s observable event order and relative timing as the default; clearly label any approximate timing.
3. **Text replacement table:** list key text with stable item ID, scene/time window, unambiguous location, operation (keep/replace/remove), exact final string, case, punctuation, line breaks, appearance/progression rules, and verification status. For background UI text, record the carrier region and visual treatment instead of forcing exhaustive transcription. Include small text only when its role is key to the creative goal.
4. **Element change table:** each subject, image, logo, icon, background and theme component that changes or is intentionally retained; identify its source, final appearance, scope and motion/layout invariants. Do not silently replace an unrelated image, add/remove nodes or transfer a subject identity to supporting objects.

**Text-role precision rule:** classify visible text by its role before deciding the evidence and prompting precision. Brand names, key titles, plot information, user-specified copy, and any text whose exact content affects the creative goal are **key text**: lock the complete string, case, punctuation, line breaks, display state, and progression. Non-focus account names, comments, engagement counts, music labels, and similar recording-interface details are **background UI text** by default: preserve their carrier, placement, hierarchy, visual density, icon relationships, and scrolling behavior, but do not transcribe every string or block generation because tiny characters are unclear. “Keep the interface” does not mean “reproduce every interface character verbatim.” If a comment, account, or number carries story meaning or is explicitly requested by the user, promote it to key text. The orchestrator decides the class; ask the user only when the text's role materially affects the creative goal and remains ambiguous.
5. **Unresolved items and approval:** ambiguous carriers, unreadable text, uncertain counts, incomplete copy, missing assets, and changes needing user choice. Keep a visible approval record for the specific version and execution scope.

No generic word banks, alternatives, “etc.”, unfilled placeholders, “replace the remaining labels with theme-related words”, or model-selected copy may remain in an executable script. Every retained text carrier must have its own resolved keep/replace/remove decision. If the source is unreadable, a precise screenshot/location and a user-approved complete replacement can resolve it; guessing the original is not required. If the carrier itself, its count or target content remains ambiguous, mark that item blocked and do not submit affected generation. Draft proposals can be shown but must never be called ready or approved.

For type-on or animated text, specify exact complete content and the ordered partial states where needed. Keep the reference's display windows and motion separate from the replaced glyphs: preserve text position, hierarchy and animation, not old words or letter shapes. If new copy does not fit, propose an exact revised string or layout for review; do not silently shorten, paraphrase, translate, add duplicated text or change line breaks during dispatch.

Present the actual script version together with its generation scope and relevant cost information, then ask for ONE ordinary-chat confirmation. In an active video-creation task, user approval of that script authorizes one generation round within the stated scope; do not add a second “may I generate?” confirmation. Once content and tool-critical checks pass, execute. This applies to initial production and an explicitly reviewed revised script after failure. If the user explicitly requests script-only review or says not to generate, respect that exception.

Record the approved version, model, reference assets, duration, count and spending scope together. State unavailable cost information honestly in the same review context, not as an excuse for repeated approval cards. A consumed approval never authorizes another automatic attempt. Failed acceptance still requires a fresh user decision; approving the presented repair/revised script can be that decision and must not trigger a redundant permission request. Changes to approved content, scope, model or costs require confirmation of the actual delta. Previous output approval, model selection, silence or approval of an unrelated/older version does not approve a new script. Resolve technical checks yourself; a real blocker must be explained concretely, never mislabeled as missing generation permission.

Immediately before submission, reconcile the approved document against the prompt: all text and element IDs are covered; each final string is copied verbatim; refs and roles match; no unauthorized content or unresolved item remains. Actual current user edits override stale copies. Compile from the approved script, not an earlier brainstorm. Pass all final wording to generation explicitly rather than expecting the model to read a canvas document by filename.

### Source-Timing Lock and Prompt Compilation Boundary

When the user asks to preserve the reference video’s motion, rhythm, or timing, the source video is authoritative for event order, display windows, pauses, overlaps, transitions, and audio-sync relationships. The change script decides what is replaced or preserved; it does not become a newly invented edit schedule.

- Describe timing by source events by default: “the opening board sequence,” “the original slogan transition,” “after the photo lands,” or “the reference ending.” Do not divide the video into equal sections or assign new seconds merely to organize the prompt.
- An estimated timestamp is only a navigation aid when supported by source inspection. If it has not been verified, omit it rather than turning it into a generation instruction. Scene IDs do not create extra cuts.
- The compiled prompt may expand approved visual and textual changes, but may not add unapproved camera moves, materials, animation beats, transitions, or timing. Do not add style adjectives that change the approved subject design, such as turning a requested pixel asset into a soft-vinyl or photoreal object.
- If approved copy cannot fit the inherited display window, stop and propose a concrete copy or layout revision for user confirmation. Do not silently extend, compress, delay, or reorder the reference event.
- Before submission, check every numeric time range and every added motion phrase: each must be source-grounded or explicitly user-approved. Remove unsupported timing instead of rationalizing it after generation.

After generation, compare against that same approved version item by item. Check key text verbatim, including transition frames and temporarily visible old text; check background UI text for carrier placement, hierarchy, density, icon relationships, and scrolling rather than treating incidental character differences as a primary failure. Distinguish authored ambiguity from model rendering failure; explicit wording reduces ambiguity but does not guarantee flawless generated typography. Section 0's separate regeneration-approval rule always remains in force. When evidence conflicts, prefer concrete visible counterexamples over a general semantic summary. Treat sampled frames as samples, never as proof of frame-by-frame success. Do not mark audio as passed unless it was actually heard or independently verified; otherwise mark it unknown.

## 4. Generate and Reuse Assets

Reuse supplied brand, product, character and background assets first. Attach actual inputs rather than mentioning filenames only. Preserve source, result, prompt and scene relationships through supported mechanisms, and avoid duplicate result nodes.

Use MiniMax H3 as the default video model. If the user explicitly selects another model, verify its live reference, duration, format, and audio support before following that choice. After one authorized cause-specific correction, switch to another compatible model if it still fails instead of repeatedly retrying it. Choose still-image and standalone-audio capabilities only from the available range. Respect interactive model-selection settings. Verify actual versions, sizes, durations and prices; reconcile historical guide differences rather than assuming old promotional prices.

- Photos, illustrations, backgrounds and textures: generate or edit through available image capabilities with the required subject, composition, framing, negative space, visual direction and transparency.
- Text, logos and geometry: preserve exact content and structure; use editable text and shapes when required. Incidental generated lettering and canvas text documents do not replace editable timeline typography.
- Video: use only the approved approach and verified frame, reference, audio and duration controls. Do not assume all models share capabilities.
- Video generation: use reference explanation, core idea and timed progression, binding every actual input to its purpose. Revalidate the live MiniMax Design entry for duration, reference and format limits; do not treat historical documentation as timeless model specifications.
- Sound: preserve supplied in-scope audio or use available narration, music and sound capabilities within authorization. Disclose missing sound; do not call silent footage a complete audiovisual recreation.
- Optional staging, multi-angle, storyboard, relighting or workflow tools: use only when needed and actually available. They are not mandatory dependencies.

Check composition, size, alpha requirements and style; leave margins for planned movement and scaling. Spend on approved representative tests and approved corrections, not indiscriminate candidate batches. Save reusable selections to the Subject Library only through an available save capability.

## 5. Async Tasks, Versions and Recovery

Record returned task identifiers, inputs, actual model and settings, scene, results and state. Leave unavailable fields unknown. Follow actual concurrency and approved budget limits.

Stopping an assistant reply may not cancel a generation. After interruption or timeout, inspect existing tasks and canvas outputs before any retry. Unknown state is not failure; do not duplicate a batch.

Even confirmed failed video tasks require a new round-specific approval under Section 0 before resubmission. Record the reason, existing outputs and possible cost. Preserve old versions. Read current user changes and selections before continuing; never overwrite a newly selected version with an old candidate. New outputs require acceptance before selection for editing.

## 6. Editing and Editable Deliverables

Use available editing capabilities only for needed assembly, deterministic finishing, user-approved repairs, or a comparison explicitly requested by the user; comparison videos are not a default production or acceptance deliverable. Do not require a separate editing project before platform video generation. Align shot ranges, dimensions, frame rates, audio and transition overlaps where applicable. Preview movement and rhythm at normal speed.

Historical operation documentation may describe frame rate and sound defaults; verify actual output metadata. Keep the agreed timeline rate and real duration through timestamp-based alignment and supported resampling, not frame-rate reinterpretation. For shorter-than-supported shots, plan a compliant generation and retained range; split longer shots at continuity points. Do not arbitrarily change speed to meet duration. Check clip audio before assembly to avoid duplicated music; explicitly mute and verify a requested silent delivery.

If nested compositions are verified, build scene compositions and a master with correct local-to-global timing. Otherwise use named tracks and scene ranges, explicitly describing the difference. Do not claim hard composition requirements are satisfied when they are not.

Match key static states before implementing supported keyframes, easing, staggering, masks and transitions. Keep the source for comparison, not as an undisclosed replacement for reconstructed footage.

Save versions and dependencies. Use only MiniMax Design's actually provided save or export operation; never hand-write an unsupported project format. After saving or exporting, verify that assets, text, tracks, transitions, keyframes and nesting remain available. If a requested property is not supported, report it plainly.

## 7. Comparison and Minimal Correction

Align previews and references by timestamps, dimensions and color interpretation. Use supported side-by-side or overlay comparisons and review complete motion; disclose unavailable checks.

Record scene, timestamp, difference, correction and recheck. Prioritize missing shots and timing, then layout/text, type/color, motion/easing, transitions and detail. Target cut accuracy within one frame where evidence and tools permit; report actual uncertainty. Never invent similarity percentages.

Failed acceptance enters “awaiting user decision”, not video generation. Provide a concise diagnostic: shot and timestamp, observed difference, severity, possible cause and uncertainty, whether existing assets suffice, lowest-cost repair and adjacent-shot implications. Uncertain causes remain hypotheses.

Offer only applicable, executable choices: keep the current result with disclosed differences; repair using existing assets; pause for more source material; or explicitly authorize one regeneration round for specified shots. Never preselect regeneration. A vague request to improve requires clarifying the repair approach, not adding model calls.

A regeneration request must state shots, count, duration, substantive changes from the previous attempt, why existing material is insufficient, actual or unknown cost, and residual failure risk. Ask explicitly whether to execute that round. Perform only the approved minimum scope, reuse successful shots and recheck neighboring continuity. Another failure requires another user decision.

Examples: repair late action by selecting ranges or adjusting the timeline first; replace erroneous copy with a supported text layer; inspect boundary states and motion direction for discontinuity; propose stronger identity references or fixed assets for subject drift without automatically regenerating footage. User acceptance of an approximation is “difference accepted”, not a claim of exact technical conformity.

Report accepted results or concrete tool, asset and cost blockers. Never replace an honest limitation report with endless iteration.

## 8. Delivery and Acceptance

Keep references, shot table, selected assets, timeline and comparison notes accessible in the project. Deliver:

1. Rendered video in a supported format, preferably MP4/H.264, preserving reference framing, rate and duration unless overridden by the user.
2. When requested, a reopenable MiniMax Design project and only the editable properties that MiniMax Design actually preserves. Default reference generation does not imply a layered editable animation project.
3. Dependencies and concise opening instructions, required fonts/plugins, approximations, unverified checks and remaining limits.

Play the output to check ends, black/missing frames, sync and duration. Reopen editable deliverables to verify resources and editability. Screenshots, Markdown, scripts and MP4 files are not editable animation projects. If required renders or native projects are unfinished, label delivery partial. Keep user-accepted differences visible in the acceptance record.

## 9. Behavioral Acceptance Cases

These are rule tests, not proof of a real video integration run:

1. Result is insufficiently similar; user says “improve it”: diagnose and offer repairs; zero video submissions.
2. Wrong copy with usable footage: prefer a supported text-layer repair; no default regeneration.
3. Initial approval and remaining budget exist: failed acceptance still pauses; budget is not retry consent.
4. User approves one S02 clip for one regeneration round: do only that scope, preserve S01/S03; another failure never triggers an automatic second round.
5. Timeout may have produced output: reconcile state and assets; no duplicate submission, and ask before retrying.
6. No reliable repair quote: disclose possible additional credits and unknown amount; do not execute under a free-cost claim.
7. Failed sample: diagnose and await decision; no automatic sample remake or full-batch generation.
8. User keeps the current version: preserve it and the discrepancy record, stop repairing and do not claim exact recreation.
9. User supplies a reference video and replacement subject and requests the same motion: default to platform reference generation, not an editor-capability detour; neither a separate still generation nor a native source project is a mandatory prerequisite.
14. User asks for a faithful recreation but does not request a comparison video: generate and inspect the main result only; do not create a side-by-side or overlay comparison as an automatic step.
15. User asks to preserve the source timing: compile by source events and verified relative timing; reject assistant-invented equal sections or unverified numeric timestamps before submission.

10. User says “replace all text with burger copy”: produce a complete change script and await its approval; never substitute a keyword bank or immediately generate.
11. A small source label is unreadable: anchor its precise carrier and propose one full replacement for approval; if the carrier remains ambiguous, block that generation.
12. Approved copy is edited by the user: reconcile the latest document, show the delta and obtain revised approval rather than dispatching the old wording.
13. User approves the presented corrected script and its stated scope after a failed output: execute that one round without a second authorization question; another failed result never triggers an automatic additional attempt. Explicit script-only review remains non-executing.
