---
name: half-narrated-live-action-short-drama
description: "Create narration-led live-action drama from scripts and references: continuity assets, timed shots, assembly, narration, and optional subtitles. MiniMax-H3 default; check explicit alternatives."
trigger-words: [半解说真人短剧, 第一人称旁白短剧, 第三人称旁白短剧, 真人写实短剧, 竖屏短剧, 重生短剧, 末世短剧, 悬疑短剧, narrated live-action short drama]
---

# Half-Narrated Live-Action Short Drama

Use this Skill for end-to-end short-drama production on the Design platform. develop an idea, lock the story and visual bible, create character and scene cards, create keyframes, generate shot videos, verify the assembled video's real timeline, then generate a standalone Seed Audio narration track and subtitles. Focus on live-action-style narrated short dramas with realistic performances, grounded scenes, character dialogue, and voiceover-led storytelling. This is not a generic one-image, one-clip, animation, anime, pure-commentary, or ordinary-editing task.

## Core capabilities

- Develop a rough idea, theme, reference, or premise into a focused short-drama concept.
- Create and confirm the logline, characters, setting, episode structure, script, dialogue, and narration.
- Build reusable character and scene continuity anchors.
- Convert the approved script into a timed shot list and shot contracts.
- Generate character cards, scene cards, keyframes, shot images, and shot videos.
- Batch similar image work and generate connected shot videos.
- Assemble shots in story order, read the final video's real timeline, and generate one standalone Seed Audio narration track.
- Review continuity, lip-sync, framing, pacing, dialogue attribution, and final duration.

## Inputs

- A creative seed: idea, premise, theme, story fragment, script, or reference material.
- Optional character, costume, prop, location, style, storyboard, image, video, or audio references.
- Optional audience, platform, aspect ratio, duration, language, dialogue, narration, music, subtitle preference, and content constraints.
- Existing assets or an episode to continue, adapt, or remake.

## Production locks

- Default image model: `Design Image 2`.
- Default video model: `MiniMax-H3`.
- If the user explicitly selects another video model, check that it supports the required references, resolution, duration, dialogue, and lip-sync behavior before following that choice.
- Image generation uses 2K by default; video resolution is selected by the user as 2K or 768P before video generation.
- Video durations are integer seconds only. When using MiniMax-H3, every generated shot must be 5–15 seconds; merge adjacent short script beats when needed. For another explicitly selected model, use its verified supported limits without changing the approved story structure.
- When a video shot fails, retry that shot once after diagnosing the cause. If it still fails, switch the failed shot to another compatible available model instead of repeatedly forcing the same model.
- Do not change the production plan merely because image-generation capacity is unavailable at one moment. Keep the authored shot topology and continue with the affected item when execution is available.
- Do not add a separate capacity or safety-interception workflow to this Skill; follow the platform's normal execution result if a task cannot run.
- Keep subtitles off unless the user requests an SRT or burned subtitles.

## Workflow

### 1. Inspiration and concept

Extract the user's intent and references, then propose a focused direction: premise, genre, emotional hook, protagonist, conflict, world, and ending beat. Confirm the direction before detailed authoring.

### 2. Story and script

Create the short-drama structure for the requested duration: logline, character roles, scene progression, dialogue or narration, action beats, and ending. Keep spoken copy separate from visual direction. Confirm the script before expensive generation.

### 3. Character and scene cards

Create final character cards in 16:9 when they are used as identity references. Each character card must use a pure white background with no scene background, title, labels, or watermark; place a detailed facial close-up on the left and the same character's front, side, and back half-body views on the right. For live-action realism, write the card like a real casting / costume / continuity photo brief, not concept art: specify face shape, brow, eye shape and eyelids, nose bridge and wings, lips, jawline, hair silhouette, age cues, skin texture, natural facial asymmetry, clothing structure, fabric behavior, and identity-defining details. Explicitly preserve realistic body proportions, natural hands, believable wrinkles and wear, and avoid beauty-retouch, plastic skin, over-sharpened outlines, anime traits, CG-rendered looks, or stylized illustration cues.

Create scene cards in 16:9 with a pure white background and no people. A scene card must show the environment and equipment layout from useful views, preserving spatial relationships and recurring objects without inserting characters, body parts, silhouettes, reflections, readable UI, titles, or watermarks.

Use the final approved character cards and scene cards as the continuity sources for all downstream keyframes and videos. Do not reuse superseded cards when the user has reorganized or replaced the card group.

### 4. Storyboard and shot contract

Break the approved script into executable shots. Define each shot's final-video time range, integer duration, subjects, character-card mapping, scene-card mapping, action, spatial relation, framing, camera movement, dialogue or narration timing, keyframe need, transition, continuity handoff, and the exact prompt ingredients that must be carried into image and video generation. Merge adjacent story beats when a source line is shorter than 5 seconds. Keep every MiniMax-H3 shot between 5 and 15 integer seconds; use the verified limits of another explicitly selected model.

For each prompt, list all relevant role mappings explicitly: narrator, each named dialogue speaker, each character reference, scene reference, and keyframe reference. State which named characters appear and which do not appear. Preserve every supplied dialogue and narration line verbatim.

### 4.1 Production unit and internal-shot rules

Keep three identifiers separate throughout authoring, storyboard mapping, prompts, and delivery. The default storyboard topology is one three-panel time-coded sheet per generated video clip; this is the Skill default, not an optional user-requested format:

- **Episode**: the complete short-drama episode.
- **Video clip**: one generated integer-second asset, usually 5–15 seconds for MiniMax-H3, with one clip-local timeline starting at `00:00`.
- **Internal shot**: one camera setup inside a video clip. A clip may contain several internal shots and explicit cuts without changing its clip ID.

Never treat one video clip as one uncut camera shot by default. Before generating video, decide whether each clip is a continuous take or a multi-shot clip. For dialogue-led live action, prefer purposeful internal coverage when it improves readability: establish the spatial relationship, cut to the key prop or reaction, then return to a relationship or speaker shot. Preserve the 180-degree axis unless a deliberate axis change is approved.

For every multi-shot clip, define a local shot table with: clip ID, internal shot ID, local start/end time, shot size, camera position, visible characters, action state, dialogue/narration ownership, transition type, and continuity handoff. The three storyboard times must describe actual internal shots, not merely three poses from one camera.

### 5. Default per-clip three-panel storyboard and hard validation

Read `references/numbered-storyboard-template.md` before generation. The default storyboard topology is **one generated video clip → one storyboard image → exactly three time-coded panels**. Apply this default automatically; do not wait for the user to request it. Do not replace it with one episode-wide sheet, a two-page six-panel board, or an action-before/action-after pair unless the user explicitly changes the storyboard format.

For a three-panel clip sheet:

- Use the clip-local times, normally `0s`, a middle beat, and the final action/dialogue beat; never use whole-episode timestamps inside the clip sheet.
- Every panel must be a genuine 16:9 picture for a 16:9 project. The paper may be any review ratio, but the picture interiors must not become portrait panels, be stretched, or be cropped into an unintended ratio.
- The three panels must show three purposeful internal shots when the clip is multi-shot: for example, spatial two-shot or establishing view → insert/detail or emotional close-up → over-the-shoulder/relationship/reaction view. Do not generate three near-identical wide shots with changed poses.
- Put the clip ID, local time, local interval, shot size, action, and camera movement outside each picture. Never put timestamps, labels, subtitles, or storyboard UI inside the picture.
- State which characters and props are absent from each close shot. Do not add people merely to fill a panel.
- Validate panel order, labels, distinct framing, axis, identity, prop handoff, and action progression before the sheet is approved.

Use the standard numbered multi-panel board only when the user explicitly asks for a different storyboard topology, such as an episode-wide overview, a shot-list board, or a custom panel count. In that exception mode, use a default 2-row × 3-column grid of approved shots, smaller grids for fewer shots, and blank unused cells rather than invented or duplicated shots. Each picture keeps the final video aspect ratio and its information strip stays outside the picture.

Prefer generating or selecting clean 16:9 internal-shot pictures first, then assembling the review sheet and typesetting labels deterministically. Direct whole-sheet image generation is allowed only when the result is validated afterward. If a generated sheet has portrait panels, repeated framing, unreadable labels, duplicated people, or missing time progression, reject it and rebuild from clean panels; do not send the faulty sheet into video generation.

Keep the sheet for review and export or precisely crop each picture interior for video generation, excluding borders and information strips. Record shot ID, page ID, row/column, source dimensions, picture crop bounds, clean image path or asset ID, reference role and version. Review identity, blocking, axis, props, aspect ratio and continuity per panel. Bind each video task to its matching panel explicitly; “use this reference image” is insufficient.

### 5.1 Three-panel storyboard prompt requirements

For every video clip, compose the default three-panel time-coded storyboard prompt in this order:

1. Clip ID, total integer duration, project aspect ratio, and exact local panel times.
2. The role of every reference: identity, costume, scene geography, existing clean panel, or continuity anchor.
3. Paper layout and panel geometry; explicitly say that every picture interior is landscape 16:9.
4. Panel 1: spatial setup and starting positions.
5. Panel 2: a materially different insert, close-up, reaction, or camera angle tied to the middle time.
6. Panel 3: a materially different relationship, over-the-shoulder, reaction, or result shot tied to the final time.
7. Continuity handoff: who moves, what prop changes hands, who remains off-screen, and how the axis is preserved.
8. Labels outside the picture only, followed by negative constraints.

Do not describe a three-panel board as “three stages of one wide shot.” Do not let the model invent panel text. If the model cannot reliably preserve panel layout or labels, generate three clean images and assemble the sheet deterministically instead.

### 6. Image generation

Generate character cards, scene cards, keyframes, and shot images with `Design Image 2` at 2K by default. Use the approved reference roles and preserve identity, subject count, scene geography, and required visual traits. For any live-action project, the prompt must explicitly push photographic realism: cinematic still / continuity photo / casting photo language, realistic lighting, natural skin texture, believable pores and fine hair strands, physically plausible clothing folds, correct lens perspective, and restrained color grading. Only storyboard sheets may contain the required shot IDs and information strips outside picture areas; character cards, scene cards and clean video-reference pictures remain free of those labels. Do not create other unrequested text, titles, watermarks, or background elements, and do not let the output drift into polished AI beauty render, illustration, or CG poster style.

### 7. Video resolution confirmation

Before generating any video, ask the user to choose the output resolution: `2K` or `768P`. Treat the user selection as a production lock and use the same confirmed resolution for every shot in the episode. Do not silently choose, change, or mix resolutions after confirmation.

### 8. Video generation

Generate each approved shot with `MiniMax-H3` by default at the user-confirmed 2K or 768P resolution and an integer duration from 5 to 15 seconds. If the user explicitly selected another model and its capability check passed, apply the same approved shot contract within that model's supported resolution, duration, reference, dialogue, and lip-sync limits. For a single video task or shot, timecodes must start from `00:00`; do not carry over upstream storyboard segment timestamps. When MiniMax-H3 is active, read `references/h3-video-prompt-template.md` and fill it in before generation. Resolve the shot ID through the storyboard mapping and use its clean panel as a composition or starting-state reference, together with mapped character and scene cards. Do not use the full multi-panel sheet as a first frame or whole-frame composition reference by default. Only use it as an auxiliary reference after verifying storyboard-reference support and correct interpretation, explicitly naming the page, row, column, shot ID and excluded panels. Never attach another shot's clean panel to the current task. Submit multiple states of one shot only through verified first/end-frame or multi-reference capabilities; otherwise submit its starting state and describe subsequent states in text. See the storyboard template for binding and fallback rules. Preserve the established character, world, action, camera intent, dialogue timing, and visual style. For live-action projects, explicitly demand photographic realism in the prompt: documentary / drama still / cinema verité / handheld or locked-off camera as appropriate, believable depth of field, natural motion blur, physical facial motion, no anime or CG language, no glossy beauty-filter look, and no exaggerated AI facial symmetry.

Every video prompt must divide the shot into clear internal content beats based on narration, dialogue, and image content: first establish the space and character relationships, then show the narration-linked visuals, then show the dialogue action and reaction, and finally close on the resulting emotional state; if the shot needs a visual shift or information change, the prompt may explicitly ask for an internal cut, push-in, reveal, occlusion-based reveal, or spatial transition, but only within the same approved shot number and total duration. During narration, the narrated subject keeps their mouth closed unless they have a separate dialogue cue. During dialogue, only the assigned speaker performs lip-sync. Keep each character's voice role distinct in the prompt.

### 8.0 Multi-shot clip execution and verification

For a clip with internal cuts, write each local segment as `start–end | shot size | camera position | visible subjects | action | sound owner`. Mark hard cuts explicitly when they are intended; do not rely on vague “cinematic editing.” The narration may bridge a cut, but the visual owner of each beat must be clear. Keep dialogue on the shot where the speaker's mouth is visible whenever possible; only the assigned speaker lip-syncs.

Use the matching clean internal-shot image for composition guidance. A three-panel review sheet is not a first frame and must not be sent as a whole-frame composition reference by default. Never attach another clip's clean panel. A previous video may be used only as an explicitly stated continuity reference for voice, environment, or visual treatment; it must not silently copy the previous clip's action or dialogue.

After generation, verify the actual output before reporting success: duration, aspect ratio, intended cut order, major shot-size changes, speaker attribution, verbatim dialogue/narration, lip-sync, prop continuity, and absence of storyboard labels. If semantic audio/video inspection times out or fails, report the output as **generated but not fully verified**; do not claim that the dialogue, cut points, or lip-sync passed.

If submission returns an unknown or ambiguous backend state, do not resubmit the same request. First reconcile the task card and available outputs. Ask the user whether to cancel or submit a new attempt when the state remains unknown; warn that a late success could create duplicates or duplicate charges.

### 8.1 Video prompt assembly order

Build every video prompt from the following fixed order so the prompt stays grounded and the visual style does not drift:
1. Shot purpose and exact time range.
2. Locked identity sources: character cards, scene card, and the clean panel mapped to the current shot ID with its explicit reference role.
3. Visual realism target for live-action projects: cinematography / continuity-photo language.
4. Narrative-linked visuals and dialogue-linked visuals.
5. Subject blocking: who is on screen, who is not, and where they are placed.
6. Action beat and emotional state.
7. Camera framing and movement, including any internal cut, push-in, reveal, occlusion-based reveal, or spatial transition.
8. Dialogue, narration, and exact lip-sync owner.
9. Continuity constraints: costume, props, wetness, lighting, injury, and spatial handoff.
10. Negative constraints: no illustration, no CG, no beauty-filter look, no facial symmetry exaggeration.

Do not write the shot prompt as a freeform paragraph if the shot has multiple roles, transitions, or continuity constraints; assemble it from the template order. Internal cuts or transitions are only allowed within the shot itself and must not change shot number or total duration.

If a shot execution fails, preserve successful shots and retry only the missing shot once after diagnosing the cause. If the retry still fails, switch only that shot to another compatible available model. Do not rebuild the full project, repeatedly force the same model, or change the shot topology for a transient execution issue.

### 9. Assemble the final video

Order the generated shots by authored shot number, not by canvas return order. Merge them into the final video, then read that final video's actual media duration, actual shot boundaries, and real visual ending time. Use this as the only timing basis for the later narration audio. Do not split original audio, audit preserved dialogue, or perform final audio mixing.

### 10. Final narration generation

Before composing the final Seed Audio prompt, read `references/seedaudio-final-track-prompt-template.md` and use its structure. This template is only for generating one standalone narration audio file from the final assembled video's real timeline. Do not split original-video narration and dialogue. Do not preserve original dialogue as an audio source. Do not build a final mixed audio track.

After the final video is assembled, extract the actual final-video timeline and reconcile narration with the visuals only. Produce a final narration table with:

- exact start and end timestamp
- speaker role
- verbatim narration line
- audio source: Seed Audio narration / absolute silence
- any timing correction required by the actual final video

Use Seed Audio to generate only the narration audio. Put the complete narrator voice map, exact narration timestamps, voice descriptions, silence requirements, and narration lines into the generation prompt's text field. Keep the narration voice stable and distinct. Unless the user explicitly requests otherwise, disable BGM, ambience, room tone, breath noise, transition sounds, and all sound effects. All intervals without a timestamped narration line must be absolute silence. Set the narration audio target length from the real assembled-video duration, not from the planned storyboard duration. Generate the standalone narration from the confirmed final-video timeline. Do not split the original audio, preserve dialogue as an audio source, or create a mixed-audio video within this Skill.

### 11. Deliver final video, subtitles, and narration audio

Deliver three independent outputs: the final assembled video, the subtitle file, and the standalone Seed Audio narration file. Do not mix the narration audio back into the video, and do not create another mixed-audio version. Generate subtitles from the final video timeline and narration script; if the user requests SRT or burned subtitles, use the final assembled video's real timeline.

## Outputs

- Approved concept and short-drama premise.
- Script, narration, dialogue, scene breakdown, and timing structure.
- Final 16:9 pure-white character cards with facial close-ups and three half-body views.
- Final 16:9 pure-white person-free scene cards.
- One three-panel time-coded storyboard sheet per video clip by default, clean 16:9 internal-shot panels, shot-to-reference mappings, internal-cut tables, and clip contracts; use a different board topology only when explicitly approved by the user.
- 2K integer-second images and video assets from MiniMax-H3 by default, or from a capability-checked model explicitly selected by the user.
- One standalone Seed Audio narration file aligned to the actual assembled-video timestamps.
- The final assembled video, plus SRT or burned subtitles when requested.
- Optional SRT or burned subtitle version when requested.

## Boundaries

This Skill is for Design-platform short-drama production. It does not cover external provider setup, API-key management, image hosting, local Electron installation, or unrelated standalone retouching. It does not silently change approved character identity, scene geography, speaker attribution, script wording, shot order, or user-selected output constraints.

## Provenance

This Skill is designed for continuity-controlled narrated live-action short-drama episodes.
