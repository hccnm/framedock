---
name: minimalist-product-ad-generator
description: Turn product images and selling points into a minimalist product ad with product anchors, concise copy, synced typography, and premium camera language. Use for e-commerce and launches.
trigger-words: [minimalist product ad, premium product ad, minimalist product film, Apple-style product ad, ecommerce product film, product launch ad]
---

# Minimalist Product Ad Generator

Use this Skill to guide non-professional users through a flow-style workflow that creates an Apple-inspired product advertising video. The target users are e-commerce sellers, small brand owners, indie creators, and individual sellers; the user should provide at least one product image or related asset.

The core principle is: **confirm assets and brief first, build product facts and a product narrative spine, lock product visuals with independent anchor photos, control video with a precise beat storyboard, then deliver the video with its synchronously generated native music by default. Separate music production and audio replacement are optional and require the user's explicit choice.** This Skill no longer defaults to a 4-panel anchor sheet, because video models may reproduce the panel layout. By default, it uses three separate anchor photos plus one precise beat text storyboard as the video control system.

## Start Gate

Every time this Skill is triggered, run a complete but lightweight start gate before any analysis, copywriting, anchor generation, or video generation. Confirm only the information required for production. Do not ask about music here. Without a special user request, the video model generates the picture and music together; no separate music stage is required.

The start gate must confirm all of the following in one pass:

1. **Product images and related materials**
   - Ask the user to upload product images and related materials, such as product photos, packaging images, renders, detail shots, existing video assets, or visual references.
   - If the current message or current canvas / session already contains materials, state that materials have been detected. Do not ask the user to upload again; only confirm whether to use the current materials.
   - If there are multiple candidate materials and their roles are unclear, ask which one should be the main product image.

2. **Product variant status**
   - Confirm whether this is a single variant or multiple variants / colors / models.
   - If there are multiple variants, confirm which one is the main variant.
   - If the user does not specify, the agent may recommend one based on the product image, but the later storyboard must still write the concrete color or variant name.

3. **Target duration**
   - 5s / 10s / 15s, with 10s as the recommended default.

4. **Aspect ratio**
   - 16:9 / 9:16 / 1:1 / 4:3 / 3:4 / match reference image.
   - Once selected, the anchor sheet, video, and final delivery must strictly keep this ratio.

5. **Apple-style template**
   - White-tech / dark rim light / brand color field / light lifestyle scene.

6. **In-frame copy**
   - User-provided copy, or agent-generated Apple-style English copy.

7. **Video model strategy**
   - Default model is MiniMax-H3, because it often produces cleaner Apple-like product close-ups, negative space, and premium product-film camera language.
   - Do not ask the user to choose a video model during the start gate. Show default model: MiniMax-H3 as part of the adopted start-gate result.
   - If the user explicitly asks for another model, follow the user's model choice after capability checking.
   - Another video model is used only when the user explicitly selects it, H3 is unavailable, or a hard capability requirement excludes H3.

Start gate is mandatory. If the user has already uploaded product material, only skip the upload request; do **not** skip the rest of the start gate. The agent must still confirm product variant status, target duration, aspect ratio, Apple-style template, and in-frame copy mode in one pass before analysis, anchor generation, storyboard, or video generation. The video model is not a start-gate question: use MiniMax-H3 by default and display it in the completed start-gate result. If the user says "you decide / just do it," the agent may choose recommended defaults for the remaining fields, but must still display the adopted choices as the completed start-gate result before continuing.

## Operating Principles

1. **Independent anchor photos are the default visual control system**
   - Generate three separate anchor photos by default, not one 4-panel sheet, because video models may copy panel layouts into the final film.
   - The three anchor photos usually cover: hero / striking main view, material or functional detail, and final copy composition.
   - Do not create a separate structure-action anchor when it overlaps with the hero view. Merge structure / action cues into the material-detail anchor unless the product truly needs a distinct mechanism reference.
   - Each anchor photo must be a complete standalone product photo. Do not create grid layouts, split screens, collage boards, framed panels, product walls, or storyboard sheets.
   - The precise beat storyboard determines the actual shot order, action, and text behavior. Do not use anchor photos as direct shot replacements.

2. **In-frame copy must appear as integrated video motion, not a subtitle fallback**
   - Text in the copy anchor photo is only a reference for font, position, single-line layout, and two-part color treatment. It does not mean the whole video can use only that one copy line.
   - The precise beat storyboard may define multiple short English copy lines across shots. Each line must be 3-5 English words, single-line, readable, and follow the two-part color rule: in white-tech style the first half uses black or dark gray, in dark rim-light style the first half may use white, and the second half always uses the specific product color. Do not use isolated 1-2 word feature labels.
   - Video generation must include the storyboard copy inside the frame.
   - The copy does not need to appear in every shot. If the video model tends to make typography mistakes, reduce copy frequency proactively. For a 10-second film, usually keep only one mid-film copy moment plus one final copy moment; do not put text in every shot. The final shot must include one stable single-line copy.
   - By default, ask the video model to generate in-frame typography and its timing directly. Do not silently degrade text into post-production subtitles or reserve empty space for later overlay. Use post-production fallback only when the user explicitly asks for it or when integrated video typography fails and the user accepts a fallback.

3. **Product body color is a hard fidelity constraint**
   - Apple-style means clean composition, premium light, restrained motion, and negative space; it does **not** mean turning the product itself white, silver, or AirPods-like.
   - The product's original body color, accent color, material tint, and visible finish from the user's image must be preserved in all anchor photos and videos.
   - Only the background, lighting environment, and composition may shift toward the selected Apple-style template. Never recolor the product body unless the user explicitly asks.
   - The final copy emphasis color must come from the real product main color, not from a generic silver / white Apple palette.

4. **Every product needs a product-specific narrative**
   - Do not reuse a fixed earbud template or write vague phrases like product state changes.
   - The storyboard must be based on product category, form, material, structure, and visible actions.
   - Product motion must be visual and concrete, such as "the lid opens 30 degrees and inner reflection appears," or "the crown rotates while a highlight slides along the edge."

4. **Progress must be visible**
   - After each step, show what was produced and what decision is needed next.
   - Do not auto-run the entire pipeline without user confirmation.

## Style Background Contract

- **White-tech / white minimalist** means a pure white or very light neutral seamless background, minimal studio presentation, restrained soft shadow, and no real-world environment, lifestyle set, tabletop scene, decorative props, or scene-specific background.
- **Black rim-light / black tech** means a pure black seamless background, minimal studio presentation, controlled rim light, and no real-world environment, lifestyle set, tabletop scene, decorative props, or scene-specific background.
- **Light lifestyle scene** is the only style that permits a real-world environment or scene props, and it may be used only when the user explicitly selects it.
- The selected style contract must be copied consistently into the production brief, every anchor prompt, every storyboard, and the final video prompt. Do not reinterpret white-tech or black-tech as lifestyle or quasi-realistic product photography.

## Typography Rules

- In-frame advertising copy must be English.
- If the user provides Chinese copy, translate it into concise English or ask for approval of the English version.
- Visible in-frame copy must be 3-5 English words, preferably no more than 32 English characters including spaces. Do not write isolated 1-2 word feature labels.
- Copy should feel like an Apple product film: sensory, benefit-led, material-led, or a light value proposition; avoid promotional slogans and ecommerce feature-tag wording.
- Font reference: SF Pro Display / SF Pro Text. Prefer `SF Pro Display Semibold` in prompts.
- Use no more than two text colors in a shot.
- In white-tech style, the first half of the text must use black or dark gray; white text is forbidden on white backgrounds. In dark rim-light style, the first half may use white. The second half always uses the specific product color.
- Text must stay on one line. Do not wrap, stack, or split into multiple lines.
- At any moment, only one single-line English copy line may appear in the frame. Do not show two rows of text, two-line titles, title + subtitle pairs, or multiple text blocks at the same time. Two-part typography must continue or replace within the same line, never split into upper and lower rows.
- Do not place text in a lower subtitle position. Prefer the vertically centered visual zone, left-aligned or right-aligned as part of the composition. Text should be slightly larger and feel like a product-film visual element, not an explanatory subtitle.
- Approved mid-film pattern: clean negative space, product motion or product close-up leads the frame, the frame stays uncrowded, and only one single-line English copy appears. Text may sit near the product edge, product surface, or close-up highlight area so it feels integrated into the product image rather than floating like a subtitle. Do not damage negative space or add a second text block just to add copy.
- Default two-part text motion must remain visible: the first half fades in or slides in subtly first, then the second half fades in or slides in subtly later. When the second half appears, the first half shifts gently within the same line to make room.
- The shift should be subtle, around 10-15px or 8-12% of text width. Motion should be smooth and restrained; avoid bouncy, neon, or flashy UI effects.
- Do not make typography completely static just to avoid two-row text. The correct solution is same-line two-part entrance, subtle shift, fade-in, or gentle slide-in; the wrong solution is upper/lower line splitting, two-line titles, or removing text motion.

## STEP 1: Asset Check and Product Fact Summary

If no product material is available, ask the user to upload it. If material is already available, use it and analyze:

- Product category.
- Subject position and frame occupancy.
- Image quality: sharpness, lighting, composition, and visible details.
- Product main color and possible main variant.
- Showable structure: opening, rotating, lifting, snapping, folding, popping, glowing, screen, texture, etc.
- Real appearance features usable for the storyboard: material, edge, button, port, packaging, transparent part, screen, or distinctive silhouette.

If the image quality is not usable, stop and give concrete reshoot advice.

Output a short product fact summary:

- Material used.
- Product category.
- Main color candidates and main variant suggestion.
- Quality pass / fail.
- Showable structure / feature.

## STEP 2: Confirm the Production Brief

Turn the start gate answers into an executable production brief. Do not ask again for parameters that have already been confirmed. The brief drives the narrative spine, copy, anchor sheet, and storyboard.

The production brief must include:

- Product material used.
- Main variant / product main color.
- Aspect ratio.
- Target duration.
- Selected Apple-style template.
- Single-variant / multi-variant strategy.
- In-frame copy mode: user-provided copy, or agent-generated Apple-style English copy.

Multi-variant product rules:

- The user selects a style; do not automatically remove all other variants.
- Every multi-variant project must decide one main variant first.
- Other variants should not all appear at the very beginning; they appear only in process beats, transitions, or the final full set.
- If the user does not specify a main variant, the agent may choose the most visually stable one and use the others for rhythm and layering.
- Avoid ecommerce matrices, nine-grid displays, stacking, scattered layouts, all colors laid flat, or full-screen product walls.

## STEP 3: Choose a Product Narrative Spine

Before copywriting and anchor generation, choose a lightweight product narrative spine. Do not use a broad corporate brand-film structure; this Skill focuses on short Apple-style films for physical products.

If the user has not selected a direction, offer 2-3 concise directions, recommend one, and continue after confirmation. If the user says "you decide," use the recommended one.

Recommended spines:

1. **Product Launch** (default recommendation)
   - Negative-space opening -> main variant establishes hero view -> material / structure detail -> natural product action -> variants or color relation -> full-copy closing.
   - Good for earbuds, watches, digital accessories, small appliances, fragrance devices, etc.

2. **Feature Touch**
   - Product stillness -> interaction trigger -> feature action -> detail magnification -> result / feeling -> closing frame.
   - Good for products with clear opening, rotation, magnetic snap, light change, screen, folding, mist, or similar actions.

3. **Color Family**
   - Main variant appears alone -> supporting variants slide in lightly -> color order forms -> material and structure stay unified -> full set closes -> copy lands.
   - Good for multi-color, multi-variant, or multi-model products.

Output one sentence describing the selected narrative spine, for example:

> This film uses the Color Family spine: the purple main variant establishes the hero view, other colors enter as supporting layers, and the full product set closes with the English copy.

## STEP 4: Direct the Motion Language

Before copywriting and anchor generation, define the motion language of the film. This step does not generate assets; it defines motion intensity, transition logic, and rhythm peaks for the later storyboard.

Rules:

1. **Transitions are driven by real product or visual elements**
   - Prefer product edges, material highlights, opening / rotation / snapping / sliding actions, geometric changes in variant arrangement, color entry and exit, matched camera direction, or matched product silhouette.
   - Do not use meaningless white flashes, abstract particles, random light effects, or random cuts to fake premium motion.

2. **One main action per beat**
   - Secondary elements should appear with slight delay and should not compete for attention at the same time.
   - Examples: product enters first, then text appears; main variant stabilizes first, then supporting variants slide in; material highlight sweeps first, then text motion begins.

3. **Set strong and quiet moments**
   - 5s film: 1 small peak + 1 stable closing.
   - 10s film: 1-2 peaks + 1-2 braking moments.
   - 15s film: 2-3 peaks + 2 quiet braking moments.
   - Peaks may be product action completion, variant entrance, second-half copy reveal, or full-product closing.
   - Braking moments may be material-detail pause, readable copy hold, or final frame hold.

4. **Keep safe space clear**
   - Product silhouette remains clear, single-line copy stays readable, and the main variant is not blocked.
   - Add a logo only when the user provides one. Do not generate a fake logo.

5. **Avoid fake tech decoration, mirrored white stages, and empty openings**
   - Avoid fake technology interfaces, meaningless glass cards, decorative text walls, unconfirmed metrics, random particles and stacked light effects, one identical easing style across the whole film, and full-screen product walls.
   - White-tech style is not a mirrored white stage and not dead flat white lighting. Do not place the product on reflective floors, glass tables, or cheap studio mirror surfaces.
   - Apple-style white space should be a simple white background; impact comes from striking product angles, real product actions, camera rhythm, and negative-space composition, not from mirror reflections or waiting on empty frames.
   - The opening must not be empty dead time. It should quickly reveal an attractive product action or angle, such as the product rotating smoothly out of its own structure, emerging from an opening mechanism, sliding along its silhouette, or being revealed by an edge highlight. The exact action must be inferred from the current product form, not hardcoded to earbuds.

Output one short "motion language" statement, for example:

> This film uses product-edge highlights and the purple main variant sliding motion to drive transitions. The main peaks are variant entrance and full-copy landing, with a stable final hold for the product and copy.

## STEP 5: Generate or Confirm Apple-style English Copy

Before generating the text anchor and storyboard, obtain a final English copy line for the frame.

Rules:

1. Analyze product category, usage feeling, and narrative spine.
2. Generate 2-3 Apple-style English options, each 3-5 words.
3. Do not use fixed templates or fixed slogans; infer new copy for every product.
4. Avoid promotional language.
5. If the user already has copy, prioritize it. Chinese copy must be localized into concise English.

After the user confirms the copy, proceed to anchor generation. If the user says you decide, choose the recommended copy and continue.

## STEP 6: Generate Three Independent Product Anchor Photos

Generate **three independent anchor photos** in the same aspect ratio and resolution as the user-selected video setting. They must be three separate image outputs, not one combined 3-panel or 4-panel sheet. Background follows the selected style, and all three photos must share unified light, shadow, grade, and background language while remaining standalone product photos.

Anchor photo roles:

- Photo 1: Hero / striking main-view anchor, locking the most attractive product view, silhouette, and opening visual direction. Avoid ugly extreme material close-ups as the opening reference.
- Photo 2: Material / functional detail anchor, locking surface material, grain, reflection, tactile quality, and the most important visible mechanism or structure. If the product needs opening, docking, folding, clasping, button, port, lid, screen, or touch cues, merge those cues into this photo.
- Photo 3: Final copy anchor, locking final product composition, font feeling, text position, single-line layout, and two-part color treatment. The copy is a format reference and does not limit the later video to only this one line.

Multi-variant handling:

- The anchor photos must inherit the selected narrative spine and style strategy.
- Photos 1/2 prioritize building the visual system around the main variant.
- Other variants only support rhythm; do not lay everything flat or fill the frame.
- Photo 3 may show the main variant plus a few supporting variants, or a full-set closing composition, but must preserve negative space and order.

Final copy anchor typography rules:

- Must include the Step 5 confirmed copy; do not use placeholder copy.
- Text must stay on one line.
- Font: SF Pro Display Semibold.
- Text color must be split explicitly into two parts: the first half of the copy uses black or white, and the second half uses the specific product main color. If the main color is purple, write first half black / white, second half purple. Do not write only product color + black or white.
- Photo 3 may contain only the confirmed final format-reference copy line and no other text; when multiple copy lines are confirmed, use the final closing line in Photo 3 and place the other lines only in their assigned storyboard beats. Every visible anchor copy line must use the exact wording, stay on one line, use first-half black or dark gray plus second-half product color, and leave room for the same-line two-part motion described in the storyboard.
- Photos 1 and 2 must contain no advertising copy unless the user explicitly requests text in those references.

Show the three independent anchor photos and ask the user to approve, edit, or regenerate a specific photo before proceeding to the precise beat storyboard.

Anchor review and repair authorization:

- A failed anchor check identifies a problem; it does not authorize regeneration. Show or report the affected photo and its concrete defects, propose the smallest correction, and wait for the user to approve editing or regenerating that specific photo. If the user already names the photo and requested correction, that request is authorization for that bounded action; do not ask for the same permission again.
- Repair only the authorized photos and preserve unaffected acceptable outputs. Show every replacement again for user approval before proceeding. Approval of an earlier version does not transfer to a replacement.
- If an approved anchor already used by the storyboard or video changes, explain the downstream impact. Approval to repair or approve the anchor does not authorize a downstream video rerun; obtain a separate explicit decision for affected downstream work.
- If the user chooses to keep a known defect, record the accepted deviation rather than marking the failed check as passed. Do not proceed while a material defect remains unresolved without a user decision.

## STEP 7: Precise Beat and Text Storyboard Table

Before generating any video clip, create and read back a precise beat text storyboard table. It is not artwork; it is the execution table for the video model. This step is mandatory and cannot be skipped, even when the user says “generate it” or “go ahead”.

The storyboard table must be organized as "User Choice Statement -> Beat Content -> Principles."

### User Choice Statement

Write the confirmed style, aspect ratio, duration, narrative spine, main variant, product main color, variant strategy, and copy. Example:

> White-tech style, 16:9, 10 seconds, Color Family spine, purple as the main variant, other colors as supporting layers, copy: Color Meets Sound.

### Beat Content Table

Recommended columns:

| Time range | Shot | Shot purpose | Visual lead | Visual / camera move | Variant state | Copy | Text color | Text effect | Transition / continuity | Rhythm intent |
|---|---|---|---|---|---|---|---|---|---|---|

For every beat that contains copy, the table must explicitly state the exact copy line, first-half color, second-half product color, first-half entry time, second-half entry time, same-line shift direction, and readable hold time. A row that only says “copy appears”, “text sync”, or “show the slogan” is incomplete and cannot be confirmed.

Table rules:

- 5s suggests 3-4 beats.
- 10s suggests 5-7 beats.
- 15s suggests 6-9 beats.
- Use seconds as time ranges; do not require frame numbers.
- Keep one main action per beat; secondary layers appear with slight delay.
- Clearly define when the main variant appears alone, when supporting variants enter, and when the full set closes.
- Copy splitting may only be described in plain language as first half / second half. Do not write arrow symbols, slashes, plus signs, or separators, because the model may render them as in-frame copy.
- Text color must use the specific product color name and must be split by style: in white-tech style write first half black or dark gray, second half the specific product color; only in dark rim-light style may the first half be white. For example, in white-tech style with purple as the main color, write first half black or dark gray, second half purple. Do not write product color + black or white.
- If typography is error-prone, reduce text beats first: for a 10-second film, usually use only one mid-film copy moment and one final copy moment, with all other beats marked as no text. Do not put text in every shot.
- When multiple copy lines are requested, assign each exact line to a separate beat or time window and repeat the full typography specification for each line. Never collapse multiple lines into one generic text instruction.
- The final beat must be a stable single full-frame product closing + full single-line copy. Never end on four panels, split screens, storyboard boards, anchor-sheet layout, product windows, or framed grids. Text still belongs in the vertically centered composition zone, left-aligned or right-aligned as part of the frame, not in a lower subtitle position. Add a logo only when the user provides one.

Rhythm intent vocabulary: setup, establish, prepare, impact, brake, settle.

### Principles

1. Keep core text on a single line.
2. At any moment, only one single-line English copy line may appear; forbid two text rows, upper/lower line splits, title + subtitle pairs, or multiple text blocks at the same time.
3. Use exactly two text colors: black or white + confirmed specific product color.
4. The text must appear inside the video; do not rely only on post-production fallback.
5. Shot continuity = element continuity + motion continuity + form continuity.
6. Smoothness = easing + no awkward timing + seamless entrances and exits.
7. Total pacing follows the user-selected duration.
8. Text motion must be visible: the first half fades in or slides in subtly first, then the second half fades in or slides in subtly later. When the second half appears, the first half shifts subtly within the same line to make room. Do not make the text completely static, and do not split it into upper and lower rows.
9. If the style is confirmed, the table must strictly follow that style.

After the storyboard table has been shown, proceed to video generation when the user signals continuation with natural language such as “continue”, “go ahead”, “generate the video”, or “make the video”. Do not require a fixed confirmation phrase. If the storyboard table has not been shown, any request to continue or generate must first trigger storyboard creation and presentation; do not call the video generator. If the user requests revisions, apply them and present the revised storyboard before proceeding.

## STEP 8: Video Generation

Generate video directly from the confirmed three independent anchor photos + precise beat text storyboard table. Video style, background, lighting, mood, and pacing follow the selected style. Aspect ratio and size must strictly follow the user-selected setting; if the user chose 16:9, generate 16:9 and do not auto-change to another ratio.

Video reference rules:

- During video generation, do not pass the original low-resolution product image to the video model. Use it only for product analysis and anchor generation.
- The three independent anchor photos generated in Step 6 are mandatory video references. They must preserve product identity, hero view, material / functional detail, final composition, and typography layout.
- Before calling the video generator, build a reference manifest containing the actual workspace paths of all three generated anchor photos and their roles.
- Pass all three anchor-photo paths in the video tool's `reference_image_paths` input. Writing their descriptions or paths in the prompt is not sufficient; the images must be attached through the tool parameter.
- If any anchor photo is missing from `reference_image_paths`, do not dispatch the video generation. Stop and restore the missing reference first.
- Creative control comes from the precise beat storyboard: shot order, product action, copy, text motion, continuity, and transitions.
- Anchor photos are only product anchors used to protect identity, body color, material, and layout. Never treat them as the storyboard itself, and never turn the three photos into three sequential video segments.
- The video output must be one continuous full-frame ad film. Do not show four panels, split screens, collage layouts, frames, storyboard boards, grid layouts, or any shot that reproduces an anchor-sheet layout inside the video. This is especially critical for the ending: never return to a grid, storyboard board, small-window montage, or product wall.
- Default to one H3 full-frame product film, not multiple first-frame clips, unless the user explicitly asks for a different construction.
- Duplicate-prevention and retry rule: submit one initial generation attempt per user-intended final video, and never keep more than one attempt active for the same task. After an interruption, timeout, transport failure, or ambiguous result, reconcile the original task status and all available outputs first. A missing canvas output is not proof that the original task has ended. A recovery retry is permitted only after the original task is confirmed ended, no reusable output exists, and the user explicitly authorizes the retry. If task status is unknown or it is still running, do not submit another attempt. Allow at most one such recovery retry; this is a ceiling, not automatic permission. A completed but rejected output instead follows Failure Handling as an explicitly authorized, targeted repair, never a duplicate recovery submission.
- Without a special user request, the video model generates the picture and music together. Include the Step 9 default music direction in the video prompt and keep native audio enabled. Do not create a separate music asset or replace the audio by default. Respect explicit silence requests. If a user-selected model cannot generate the requested music with the video, explain the limitation and ask for a compatible choice rather than silently adding a separate music workflow.

The video prompt must include:

- The three independent anchor photos, their roles, and confirmation that their actual paths are attached through `reference_image_paths`.
- A hard pre-dispatch check: exactly three generated anchor-photo references are present in the tool input; prompt-only references do not count.
- The full precise beat storyboard table; read every beat and rewrite every beat into the video prompt. Do not summarize only early beats or omit later typography, variants, or closing requirements.
- The exact copy lines. The video prompt must spell out every in-frame copy line verbatim, its time window, first-half / second-half entry timing, colors, and single-line behavior. Do not rely on the storyboard table alone, and do not summarize this as text beat sync or leave space for copy.
- Prompt completeness check: if the final video-generation prompt does not literally contain every intended English copy line, the task is not ready to dispatch. Rewrite the prompt before video generation.
- Single-line typography hard constraint: at any moment, only one single-line English copy line may appear in the frame; forbid two rows, two-line titles, title + subtitle pairs, or multiple text blocks at the same time. If typography is error-prone, reduce copy frequency instead of putting text in every shot.
- Two-part text motion rules: the first half and second half must continue or replace within the same line, never split into upper and lower rows; motion must be visible, with the first half fading in or sliding in subtly first, then the second half fading in or sliding in subtly later, while the first half shifts gently within the same line. Do not make the typography completely static.
- Shot continuity hard constraints.
- Native audio and music direction: request synchronous picture-and-music generation by default; respect explicit user audio requirements or silence.
- Final dispatch check: the original low-resolution product image is absent, and all three generated anchor-photo paths are present in `reference_image_paths`.

## STEP 9: Native Music by Default; Optional Music Replacement

This step defines audio behavior; it is not a mandatory separate generation stage. Without a special music request, the video model generates the music together with the picture in Step 8. Preserve the generated native audio, proceed directly to delivery verification, and deliver when checks pass. Do not ask an extra music question, call a separate music generator, analyze beats for a new edit, cut a music segment, or replace the soundtrack by default.

Include the following default direction in the video prompt unless the user specifies another direction:

```text
Around 100 BPM, fast tech feeling, block chords, pluck and airy noise bed, kick + sub-bass + sine sweep, wooden percussion, sudden cut-off, within 0.5s everything stops, leaving only the pluck tail to decay.
```

Extended interpretation:

- Techy, Apple-style, product launch feeling.
- Rhythmic drive is allowed, but it must not become cheap EDM.
- Pluck should be crisp, pleasant, and forward; airy noise should feel premium.
- Kick and sub-bass serve edit points; avoid boomy bass.
- Wooden percussion adds tactile texture, not a complex drum loop.
- No vocals, no synthwave, no retro, no gaming, no cheap corporate stock music.

A preference for a different musical style does not by itself request a separate music workflow; express compatible preferences in the video prompt. Only when the user explicitly chooses standalone music replacement may a separate music asset be generated or selected and the video soundtrack replaced. If native audio is unsatisfactory, report the problem and offer repair options under Failure Handling rather than automatically generating replacement music or rerunning the video. A user request already specifying replacement is authorization for that bounded action; do not repeat the same permission question. Confirm any material cost or output tradeoff outside that scope before proceeding. An explicit silence request takes precedence over native music.

## STEP 10: Delivery Verification and Optional Audio Replacement

### Default path: preserve native audio

Without an explicit request for standalone music replacement, preserve the video model's generated picture and native soundtrack. Do not mute, replace, or remix that soundtrack, and do not require music analysis, segment selection, or beat-synced re-editing. Verify the result and deliver when it meets the confirmed requirements. If the user requested silence, verify that requirement instead. A failed check reports a problem; it never independently authorizes a repair.

### Optional path: user-authorized standalone music replacement only

Run the following only when the user has explicitly chosen standalone music replacement:

- Generate or select music within the authorized scope. Analyze rhythm, strong beats, energy sections, and clear single-note hits only as needed for the requested replacement or explicitly requested beat-synced edit.
- Select a continuous audible segment that covers the confirmed final video duration. Do not hardcode an 8-12-second range, default to the first 10 seconds, or shorten or extend the film to fit music. If the source cannot cover the duration, explain the limitation and obtain a decision on the required adjustment.
- Prefer a clear musical entry, continuous sound without unintended dropouts, and enough stable time for the closing frame.
- For audio-only replacement, preserve the video picture, cut the chosen music segment to the confirmed timeline, mute the original soundtrack, and use only the replacement track. Changing picture timing, cuts, or total duration requires a separate explicit editing request; choosing replacement music alone does not authorize it.
- Keep music loudness restrained: do not maximize loudness, use aggressive limiting, or raise it excessively; also do not reduce it so far that the pluck and rhythm lose clarity.
- Do not use long fade-outs. Only apply a 0.1-0.3s tail fade when needed within the authorized replacement.
- After replacement, check for long unintended silence, audible dropouts, and full-duration coverage. Do not automatically regenerate or reassemble if a check fails.

### Pre-delivery verification

- Video aspect ratio, duration, and language match the brief.
- Product appearance, main variant, and variant timing match the approved anchor photos and storyboard.
- Copy is readable, single-line, not crowded, and contains no extra arrows or symbols; no two text rows, upper/lower line splits, title + subtitle pairs, or multiple text blocks appear at the same time.
- The final frame has a stable product + copy closing.
- The delivered audio matches the chosen path: native soundtrack by default, replacement only when explicitly chosen, or silence when requested. For audible outputs, check reasonable loudness and absence of unintended dropouts.
- Output is on canvas, and multi-asset outputs are grouped.

Pre-delivery verification is diagnostic only; it does not independently authorize regeneration, reruns, replacement, model changes, or fallback. If a check fails, preserve existing outputs, identify the affected asset and unmet requirement, and propose the smallest repair. Follow Failure Handling and wait for explicit user authorization before executing that repair. Do not present an unresolved failed result as compliant delivery. If a repair changes an anchor photo, return to Step 6 for approval of the replacement before dependent work continues; verification cannot bypass that approval or authorize a downstream rerun.

Delivery includes:

- Final video path or canvas output.
- Duration, aspect ratio, and language.
- Short creative summary and copy used.
- Audio actually used: native music, an explicitly chosen replacement, or requested silence. Report a selected music segment only when one was actually used.
- Whether beat-synced editing was actually applied; do not claim a separate edit for synchronously generated native music.
- Specific next improvements, such as pacing, copy, main variant, audio, or platform crop.

## Failure Handling

### Authorization boundary

A failed generation, quality check, or pre-delivery verification identifies a problem; it is not permission to regenerate, rerun, replace an asset, change the model, or use a fallback. Preserve existing results and unaffected acceptable assets. Explain the affected asset, the concrete failure, the proposed repair scope, and any material cost or output tradeoff, then wait for the user's explicit decision before executing a repair.

- Prior approval of the brief, copy, aspect ratio, anchor photos, or storyboard authorizes the corresponding planned work, not automatic failure retries. Earlier "you decide / just do it" answers about defaults or creative choices do not authorize later retries.
- A user request that already names the affected asset and repair is authorization for that bounded action; do not ask for the same permission again. If the intended scope is unclear, clarify only that scope.
- Each authorization covers only the specified assets and action. It does not carry over to another failed attempt, other assets, downstream regeneration, a different model, or a fallback. Retry limits are ceilings, not execution permission.
- Repair only the authorized subset. Recheck the repaired result without automatically triggering another repair. If it still fails, report the outcome and wait for a new decision.
- Revised or regenerated anchor photos must return to Step 6 for user approval. Do not substitute a newly generated anchor for an approved one silently. Anchor repair or approval does not authorize a video rerun.
- If the user chooses to retain a known defect, record that explicit deviation and do not describe it as passing the original requirement. Otherwise, pause affected downstream work and compliant final delivery while the failure remains unresolved.

### Failure-specific proposals

The following actions are repair proposals, not automatic execution instructions; apply the authorization boundary above.

- Product image too weak: stop, give reshoot guidance, and wait for a better image.
- Copy too long: propose a 3-5-word English revision and ask for approval before using it.
- Text anchor is wrong: identify the incorrect copy or typography and propose editing or regenerating that specific photo. Execute only the authorized correction, then return the revised photo to Step 6 for approval before storyboard or video work continues.
- Anchor photos fail product fidelity: identify the mismatch against the original product image and propose a targeted repair. Repair only the authorized affected photos, retain acceptable photos, and obtain approval of replacements under Step 6.
- Anchor photos are too similar: explain which roles are not visually distinct and propose regenerating only the detail and/or copy anchor with a different crop, camera distance, subject scale, and spatial placement while preserving identity. Execute only the authorized subset and return replacements for approval.
- Anchor photos are mentioned in the prompt but not attached through `reference_image_paths`: block dispatch and attach all three actual approved generated-image paths. This is a reference correction, not authorization to regenerate any image or video.
- Storyboard table was skipped or not shown: block dispatch, generate and show the complete storyboard table first. Once it is shown, natural continuation instructions such as "continue" or "generate the video" are sufficient to proceed.
- Duplicate video outputs or ambiguous generation result: reconcile task status and available outputs without submitting another attempt. Reuse an output that meets the confirmed requirements, or ask which duplicate to keep. If no reusable output exists, apply Step 8: confirm the original task has ended and obtain explicit retry authorization before the single permitted recovery retry. Unknown or active task status blocks a new attempt. A completed but defective result follows the targeted repair proposals below, not an automatic recovery retry.
- A generated video drifts from the product anchors: identify the fidelity drift and propose a targeted video regeneration with all three approved anchors attached. Wait for explicit authorization before rerunning.
- Storyboard is templated: explain the product-specific omissions and propose revising the relevant beats. Obtain approval of the revised storyboard before video generation; the storyboard correction does not authorize an automatic video rerun.
- Copy does not appear in video: identify the missing confirmed copy and intended time windows, then propose a targeted video regeneration. Wait for explicit authorization before rerunning.
- Video typography deforms: explain relevant options, such as repairing the copy anchor, regenerating the video, restrained anchor-based motion, or a post-production fallback. Do not silently choose or execute an option. Respect anchor and storyboard approval gates where affected.
- Aspect ratio is wrong: report the measured ratio and confirmed target ratio, and pause affected downstream use and compliant delivery. Propose regeneration at the confirmed ratio; do not immediately rerun or silently crop, stretch, or change the target. Execute only the user's chosen repair.
- Music quality is poor: report the specific problem and offer relevant repair options. Do not automatically generate a separate track, replace the native soundtrack, or rerun the video. Only if the user explicitly chooses standalone music replacement, follow the optional path in Steps 9-10; otherwise preserve the existing soundtrack while awaiting a decision.
- The delivered video has unintended silence or an audio dropout: report the affected time window and propose an audio-only repair that preserves the picture. Execute only the authorized repair; use standalone music replacement only if the user explicitly chooses it. Do not regenerate the video for an audio-only failure.

## Trigger Examples

Use this Skill for requests like:

- "Make an Apple-style product ad from this product photo"
- "Create a premium minimalist ecommerce product film"
- "Turn this product image into a minimalist launch ad"
- "Make a premium ecommerce product video"
- "Create a clean Apple-inspired product short"

Do not use this Skill for general video editing, documentary explainers, KOC talking-head ads, or complex UI/screen-text demos unless the user explicitly wants the Apple-style product ad workflow.
