---
name: scene-reference
description: Generate scene references and spatial references from multiple camera positions
---

# Scene references

Establish spatial references for the actual shooting directions when a location will recur across shots or the user asks for a setting sheet. Reuse sufficient existing references; describe a one-off transition directly in its shot prompt when a separate setting sheet is unnecessary.

- Default to a 16:9 landscape reference image unless the user specifies otherwise. The reference aspect ratio is independent of the final output; keep the prompt and generation parameters aligned.
- Establish spatial structure, entrances, landmarks, fixed furniture, and key props and their relationships, together with scale, materials, time of day, and light positions. Anchor directions to specific fixed objects. Separate visible facts from areas that still need design; an unseen rear area is not an established layout.
- Cover the views required by the shots. One wide view usually suffices when only shot size changes in the same direction. For reverse angles, side views, or movement revealing another direction, add only the required uncovered views. A 2×2 sheet can represent multiple reusable directions of the same space.
- In a four-view sheet, place the main view at top left, reverse view at top right, and the two side views below. State each camera's position and direction relative to fixed objects instead of merely saying front, back, left, or right. The panels depict one space, not four decoration options. By default, show a clean empty setting with fixed furnishings and story props, without added people, titles, or direction labels.
- Moving the camera changes screen left and right, occlusion, and perspective while preserving objects' physical positions, counts, scale, and materials. Light sources keep their spatial positions as their screen projections change.
- Anchor each view to the same relationships among doors, windows, landmarks, and furniture; a grid alone does not ensure spatial consistency. Correct a reported mismatch when it affects downstream framing or story-relevant spatial relationships. Flaws in unused views alone do not require more images. For damage or rearranged furnishings, retain the base layout and state the current condition.
- Downstream references specify the location, state, and shooting direction. Use the spatial structure, furnishings, and materials, rather than importing the grid into a single shot. Describe character positions and actions for the current shot separately; retain reusable spatial facts in the existing scene record.

For example, a window on screen left when filming from the entrance toward the stage may appear on screen right in the reverse shot, while remaining on the same wall.

During planning, assess coverage against this round's required directions. Once they are covered and the relationships among fixed objects are explicit, no additional references are needed.
