---
name: sitcom-story-video
description: |
  Turn a premise, script, storyboard, or references into an AI sitcom short with consistent characters, comic beats, shot prompts, and continuity QA. For narrative comedy, not generic prompts.
trigger-words: [AI sitcom, sitcom short, comedy short, narrative comedy short, sitcom video, comedy video, add music to final video, sound design, sitcom sound mix, canned laughter, comedy sound effects]
---

# AI Sitcom Short Generator

Use this Skill when the user wants to turn a premise, script, storyboard, or reference package into a production-ready situation-comedy short. It preserves character identity, set geography, props, lighting, screen direction, and comedic causality across shots, and produces a story bible, cut map, prompt pack, and QA guidance for image-to-video or text-to-video production.

## Failure Classification, Shared Budget, and Confirmation (v1.0.1)

This section governs the main flow and every reference. Recovery ladders, difficult-shot variants, and low-cost validation never open independent retry allowances. Inspect actual job state and existing outputs before classifying a failure; a QC verdict does not authorize extra work.

- **Execution failure**: an explicitly rejected request, a terminal failed render with no usable output, or a retrieval/registration failure. Diagnose first. If media already exists, recover or register it instead of generating again. A timeout or unknown state is not proof of failed generation: reconcile job identity, existing results, and liveness; pause if unresolved rather than resubmitting. Technical correction preserves the approved content, refs, duration, model, and spec.
- **Content failure**: media exists but identity, action, continuity, cuts, framing content, or dialogue violates the approved contract. Retain it, record shot/version/timestamps/evidence and unverified items, and propose the smallest repair. Another generation is additional content production, not an automatic execution retry.
- **Audio/mix failure**: distinguish defective generated BGM from gain, alignment, fades, routing, or export errors. Reuse approved picture, original sound, and qualified music, repairing only the affected music segment or mix operation. A remixed/remuxed video file is not regenerated picture. Do not invoke video generation without separate picture-defect evidence and authorization.

Maintain one project authorization/operation ledger recording shot/asset, operation class (image/video generation, BGM generation, deterministic post), source version, job identity, result, actual outputs/attempts, known or unknown cost, approved scope, and remaining allowance. Initial generation, retries, content repairs, low-spec probes, extra variants, and high-spec regeneration all consume their generation allowance and the shared project budget. Calling work a “validation” does not make it free or preapproved. A proven preflight rejection before generation is not a produced generation, but record technical attempts and corrections; unknown cost is not zero.

For the same issue on a shot/generation unit, allow at most three actual generation attempts: **initial plus two further attempts, not three retries or at least three variants**. All references share this count. Model/spec changes, splits, and reclassification do not reset it; each generated split output consumes the original unit's remaining allowance. Stricter user/platform limits prevail. A diagnosed execution failure has at most one targeted retry by default, only when explicitly covered by remaining authorization, its cause has actually been corrected, and the common cap permits it. Report after exhaustion; never switch models automatically. A failed deterministic operation has at most initial plus two substantively corrected attempts; do not substitute video generation for mix repair.

Before initial batches, state the exact outputs/count. Before extra work, state failure class, evidence, affected shots/files, retained items, proposed change, specs, attempts, cost exposure, and stop conditions. If precise authorization is missing, ask with a choice card; default approval covers one operation per listed artifact. Explicit bounded retry/mix-repair preauthorization may be reused within its remaining scope without asking twice. Storyboard approval, model/resolution selection, BGM interest, and an unscoped “continue” are not unlimited-generation permission. “Default” applies only to the currently displayed bounded proposal.

A low-spec probe needs an approved frame, duration, resolution, count, and budget. Passing it does not authorize an upgrade. If the plan explicitly preauthorizes a conditional target-spec render after a passing test, proceed only within the remaining allowance; otherwise ask first. Distinguish deterministic enlargement/transcoding of existing media from high-spec regeneration: the former consumes post budget without resetting generation counts; the latter is a new generation attempt needing fresh review. Enlargement/transcoding does not prove new native detail or make a below-spec test a qualified final.

Dropping/replacing refs, reducing cast/props, simplifying action, changing duration, splitting, adding bridge shots, switching models, or changing specs are proposals for explicit approval, never automatic ladder steps. Repair only evidence-backed affected assets. Inspect neighboring dependencies and handoffs instead of rerendering the group. Preserve unaffected qualified outputs and the last approved version; new outputs remain candidates pending review.

Stop on acceptance target, exhausted authorization/budget/time, cumulative cap, user pause/cancel, external blockers, unknown job state, no material improvement, or an unapproved next step. Report existing results and unresolved findings. Never restart a capped issue under a new name. Failed/unverified items cannot be called passed, but clearly labeled review/partial outputs may be delivered without generating until all checks pass.

## STEP 0: CHECK RESOURCES

1. Accept a premise, script, storyboard, or existing visual references. If the primary story idea is missing, ask for one concise premise.
2. Preserve concrete user choices such as duration, aspect ratio, platform, language, dialogue, visual style, and target generation system.
3. When references are supplied, assign each a role: scene, character, prop, pose, or approved tail frame. Do not treat a contact sheet, UI screenshot, or bordered panel as a clean scene reference.
4. If the brief is incomplete, use the progressive interactive choice cards in [references/choice-cards.md](references/choice-cards.md), one decision at a time. Present selectable options so the user can click; keep typed replies as a fallback. Skip choices already specified.
5. Before the first image-generation operation of any kind, show the interactive image-resolution card in [references/choice-cards.md](references/choice-cards.md). Ask the user to choose 1K or 2K, then lock that choice for every subsequent character card, scene card, prop card, and storyboard image. Do not generate images before this choice is confirmed. If the user has already explicitly specified image resolution, record it and skip the card.
6. If a character-sheet reference image is supplied, inspect its format and information architecture before generating character cards. Treat its visible character-design content as the source of structure, while ignoring carrier-only decoration.
6. If a scene-card reference image is supplied, inspect its layout, spatial views, floor plan, circulation, furniture, and detail organization before generating scene cards. Preserve useful scene-design information, not the reference board's carrier decoration.
7. Use MiniMax-H3 by default and capability-check explicit alternatives. Apply the shared failure classification and ledger: allow at most one targeted execution retry only when already authorized and the cause is corrected; report content defects and obtain repair authorization. If still failed, stop and propose compatible options. Model switching requires explicit approval and never resets allowances.

## STEP 1: ANALYZE THE INPUT

Identify:
- the comic engine: status mismatch, literal-minded helper, visible secret, overconfident plan, incompatible rules, or escalating prop malfunction;
- the characters' conflicting wants, roles, immutable visual anchors, and performance habits;
- the primary location, screen geography, hero props, lighting direction, and recurring background anchors;
- the intended duration, aspect ratio, dialogue/audio approach, and visual finish; apply the default late-1990s/early-2000s indoor TV-sitcom look unless the user selects another preset;
- the global palette and material system: honey wood, caramel brown, cream, dusty pink, brick red, and low-saturation teal; keep the palette warm and natural rather than neon; keep palette choices subordinate to any user-provided brand or reference constraints;
- any continuity risks in the supplied references.

Use [references/story-comedy.md](references/story-comedy.md) for beat timing and dialogue economy. Use [references/visual-style.md](references/visual-style.md) to lock the visual language before writing shot prompts. The default global look is an original late-1990s to early-2000s indoor television sitcom: front-facing eye-level television photography, warm multi-camera studio coverage, cozy cluttered lived-in rooms, soft high-key light, natural mid-to-high saturation, and a softened early-TV broadcast finish. If the user explicitly selects another visual preset, that choice overrides the default. For MiniMax-H3 full-reference production, also use [references/h3-full-reference.md](references/h3-full-reference.md).

## STEP 2: LOCK THE CREATIVE BRIEF

When choices are missing, guide the user through production mode, format, sitcom world, comic engine, cut strategy, audio, and—only when relevant—H3 generation packaging. Do not ask for a visual-texture choice: the warm retro indoor television-sitcom preset is locked by default and may be overridden only when the user explicitly requests another visual style. Maintain a visible state block:

`Mode / Duration / Aspect ratio / Comic engine / Visual preset / Cut strategy / Audio / Current generation spec / Authorized outputs and attempts / Used and remaining budget`

For a complete brief or an explicit one-shot request, infer only compact defaults: 45–90 seconds, one primary location, 2–4 speaking characters, and 6–10 shots. Show the locked state and request confirmation before expensive prompt writing or video production.

## STEP 3: BUILD THE STORY PACKAGE

Deliver:

1. **Premise and comic engine**: logline, audience, tone, and the repeatable misunderstanding or rule that generates jokes.
2. **Character bible**: role, want, flaw, comic behavior, silhouette, wardrobe, voice, and immutable visual anchors. State what must never change.
3. **Set and prop bible**: geography, hero props, recurring background details, time of day, lighting, and continuity locks.
4. **Beat sheet and cut map**: for every shot, include timecode, duration, framing/lens, camera move, blocking, single dominant action, dialogue or captions, sound cue, joke function, cut point, transition, and start/end continuity notes.
5. **Generation prompts**: one master style lock plus shot prompts with explicit timing, framing, lens, camera movement, action peak, cut-in/cut-out point, transition, and reference roles. Keep the negative block focused on identity drift, extra limbs, duplicate props, warped text, unstable texture, and unwanted camera behavior.
6. **Edit and QA pass**: variant selection, eyeline and screen-direction checks, tail-frame handoff, broken-frame trimming, joke rhythm, and audio intelligibility.

Every joke should follow setup → escalation → reversal/tag. Every beat should specify objective, obstacle, behavior, turn, and reaction. Keep dialogue short, bind each line to a visible speaker, and leave room for the reaction to land.

For every animated prompt, write the CUT MAP before the visual prose. Each shot must include timecode, shot ID, framing, focal length, camera position, camera movement, single dominant action, action peak, and exact cut point. Use concrete transitions such as hard cut on eye-line, hard cut on action, hard cut on reaction, match cut by prop direction, or a motivated J-cut/L-cut. Keep the default camera language frontal and eye-level, with 28–35mm masters, 40–50mm dialogue coverage, and 65–85mm reaction close-ups. Comedy should come from entrances, prop misuse, pauses, eye-lines, and reaction shots rather than aggressive camera moves.

## STEP 4: GENERATE AND REVIEW INTERMEDIATE ASSETS

After image resolution and the batch's asset count are authorized, generate the required character, scene, and hero-prop anchors. Keep the locked 1K/2K resolution, visual style, and immutable identities. Preserve the default retro indoor sitcom's honey-brown cabinetry, cream walls/tile, lived-in kitchen/living-room density, appliances, refrigerator magnets, dishes, photos, table textiles, carpets, and recurring props. Use broad soft studio light, window fill, and practical lamps with stable exposure and readable faces, hands, and paths. Period clothing/hair apply only when compatible; story identity takes priority. Review intermediate assets before costly motion. A rejection records the affected issue and a local proposal; extra image generation needs scoped authorization, while other assets remain locked. Storyboard frames still require review before animation.

### Character-card reference format

When the user provides a character-card reference with this structure, reproduce its information architecture for each character rather than making a generic portrait:

- use a landscape 3:2 sheet when the reference controls the frame; otherwise preserve the user's confirmed output ratio;
- organize a modular multi-column sheet with a text/specification area, a main full-body display area, an expression area, and a lower detail area;
- show four consistent full-body views in order: front, 3/4, side, and back, with the same ground plane and character proportions;
- include a 2×3 expression grid covering readable emotional states and mouth/eye performance states needed by the sitcom;
- include several close-up windows for face, hair, hands, footwear, costume construction, and other identity-defining details;
- include a flat-lay breakdown of wardrobe, accessories, and recurring hand props when those items matter to continuity;
- label views and detail areas with short, legible production annotations, but keep labels subordinate to the character art;
- keep the character as one stable person across every view, expression, close-up, and wardrobe detail. Do not turn the sheet into a storyboard, action sequence, contact sheet of unrelated images, or multiple alternate identities.

For a two-character sitcom, generate one separate sheet per character when the user requests separated character cards. Do not place both identities on one sheet merely to save outputs.

### Scene-card reference format

When the user provides a scene-card reference with this structure, reproduce its production-oriented information architecture rather than making a single beauty shot:

- use a landscape 3:2 sheet when the reference controls the frame; otherwise preserve the user's confirmed output ratio;
- organize a modular grid with a scene title/specification area, one large hero perspective view, a row of three complementary angle views, a floor-plan area, and a lower strip of detail close-ups;
- use the hero view to establish the main camera position, spatial depth, entrances, windows, furniture relationships, and usable action surfaces;
- use three complementary views to reveal the opposite side, front alignment, and side/rear relationships that a single view cannot establish;
- include a simplified orthographic top-down floor plan showing walls, doors, windows, major furniture footprints, and the primary movement paths;
- include approximately seven labeled detail close-ups for recurring furniture, hero props, surface/material construction, lighting fixtures, and background anchors that matter to continuity;
- describe the scene's users, time/usage context, spatial zones, entrances/exits, actor circulation, camera coverage, and continuity locks in a compact text area;
- label the hero view, angle views, floor plan, and details with short production annotations. Keep decorative borders, separator lines, palettes, and board substrate subordinate and do not mistake them for diegetic scene content.

For sitcom production, explicitly map the scene card to shot geography: identify the master-shot position, the interaction triangle, the screen-left/screen-right paths, the hero-prop zone, and any doorway or bathroom/kitchen entrance used by a character.

**Pitfall:** never use a multi-panel storyboard, contact sheet, UI screenshot, or bordered reference as a character or scene source; the model may reproduce the panels as scene content.

## STEP 5: CREATE STORYBOARD FRAMES

Create storyboard-frame images for every scene and shot before producing animated video, using the image resolution already locked before the first image-generation operation. These frames are visual planning assets: they guide camera placement, blocking, screen direction, key poses, action peaks, facial acting, prop states, and the exact visual handoff between shots. They are not final video frames and must not be treated as decorative posters.

### Storyboard content-source rules

Storyboard frames must be generated from the current production sources, in this priority order:

1. the current story package or approved script/cut map: story events, shot order, timing, dialogue, sound, action peaks, and transitions;
2. the approved character cards: identity, face, hair, body/silhouette, wardrobe, accessories, expressions, and recurring handheld props;
3. the approved scene card: location geometry, camera geography, entrances/exits, furniture, actor paths, spatial zones, and recurring background anchors;
4. the approved prop cards: object shape, material, placement, hand occupancy, and state changes;
5. the current project style lock: medium, camera language, lighting, texture, and finish.

Do not automatically use any previously attached storyboard image, example image, or canvas-connected image as a story, character, scene, prop, or action source. A storyboard-format image is unrelated to the story unless the user explicitly says to use it as a storyboard-layout reference. If the user explicitly requests that use, assign it only the role `storyboard-layout-reference`: it may donate panel arrangement, numbering, caption placement, or annotation style, but it must not donate plot, character identity, setting, prop design, action, pose, color, or visual content. If no such request exists, omit it from storyboard generation entirely.

### Storyboard generation rules

- create storyboard-frame images for every scene and shot in the current cut map, in shot order;
- use a structured multi-panel layout only as a planning carrier, not as final animation content;
- number panels in shot order and show the decisive dramatic or comedic instant from the current story package;
- pair every panel with a compact text block containing shot ID, time range, framing, dominant action, dialogue or sound cue, and transition/handoff note;
- bind each panel's characters to the approved character cards, its geography to the approved scene card, and its objects/states to the approved prop cards;
- use clear visual symbols for motion direction, impact, gaze, prop movement, or effects when they help animation planning;
- make facial expressions, body poses, hand occupancy, and action peaks readable as animation keyframes;
- show foreground, middle ground, background, entrances, exits, actor paths, and recurring props needed for continuity;
- include the start state, action peak, and end state required for the next shot's handoff;
- keep all storyboard captions and annotation language aligned with the approved dialogue and story package; never invent a different event to fit a reference layout;
- treat borders, panel frames, title bars, number badges, caption boxes, and decorative marks as carrier elements that must not appear in the final animated scene.

Record approved storyboard composition, actor positions, gaze, prop state, motion vector, effect shape, and start/end pose; review frames in order before animation. If one is unclear, propose a repair from the current story package and approved cards. A document edit does not prove the image is repaired, and extra image generation needs scoped authorization. Do not import unrelated refs or hide ambiguity in video wording.

### Video resolution choice card

Before dynamic video generation, show the clarity/cost card only if video resolution is not yet explicit; reuse an existing choice. Start shots only when the spec and this batch's outputs/attempts are authorized:

```text
Video Resolution
A. 768P (Recommended) — Validate motion, continuity, and comic rhythm with lower generation cost
B. 2K — Higher detail for final output, with increased generation cost and resource use
```

Lock the selected resolution for shots and assembly. Explain unsupported choices and ask for alternatives; never silently upgrade or downgrade. Resolution selection does not include extra probes, three variants, or failure retries. Reuse an explicit existing choice rather than asking again; resolve only missing output/count/budget authorization. Separately classify and approve low-spec validation, deterministic enlargement, and high-spec regeneration in the shared ledger.

## STEP 6: PRODUCE SHOTS

Generate shots in cut-map order, using the approved character, scene, prop, and tail-frame references. Each shot has one dominant action and one motivated camera move. Preserve the 180-degree axis, screen-left/right positions, hand occupancy, prop state, wardrobe, lighting, and emotional state.

For H3 full-reference packaging, retain the complete CUT MAP, explicit segment timelines, and edge-to-edge photographed-frame requirement: no border, frame-within-frame, contact sheet, panel layout, UI, letterbox bars, or poster typography. Classify failures first, then propose a minimal recovery under [references/h3-full-reference.md](references/h3-full-reference.md). It shares this budget and confirmation policy; it does not automatically remove refs, simplify actions, shorten duration, or generate probes.

Do not default to three variants for difficult shots. Produce the authorized take first. Explicitly requested alternatives need stated counts/costs and share the same allowance; “variants” cannot bypass the three-total-attempt cap for the same issue. Select among existing versions by continuity, then performance, then polish. Do not hide broken frames with vague wording.

## STEP 7: ASSEMBLE AND QA

Within authorized post scope, trim broken frames, select existing takes, match eyelines/screen direction, and use approved outgoing tail frames as continuity anchors where supported. Preserve existing room tone. Mix and duck music only in an authorized BGM branch; retain a short pause before the punchline. Assembly checks never authorize automatic room-tone, music, or bridge-shot generation. Verify:

- all shots have explicit timecodes and a clear joke function;
- no unexplained axis, lighting, wardrobe, prop, geography, or identity change occurs;
- faces, hands, and hero props remain readable;
- transitions are motivated and named concretely;
- dialogue is intelligible within the shot duration;
- the final tag visually callbacks the opening when intended;
- no boxed, storyboard, collage, flickering, waxy, or plastic-looking take remains.

After the final video is successfully assembled and passes the basic QA check, proactively offer the user a clickable choice: **Add instrumental BGM** or **Keep the original sound only**. Do not generate, analyze, or mix BGM before the user confirms the BGM option. If the user declines, deliver the video with its original audio and close the sound branch. If the user confirms, enter STEP 8.

QA content findings identify affected shots and evidence, not automatic additional variants. Assembly/export execution errors should first be repaired using existing approved clips. Do not mark unverified checks passed; when authorization ends, deliver clearly labeled review/partial outputs and findings if appropriate.

## STEP 8: DESIGN AND MIX FINAL-VIDEO SOUND

Enter only after an explicit choice to add instrumental BGM. Generic “sitcom feel” or “sound design” requires clarification rather than bypassing STEP 7's BGM gate. This branch provides instrumental BGM only, not canned laughter, new Foley, transition effects, room tone, or other new sounds. Explain the boundary and obtain confirmation before continuing with instrumental BGM; do not use prohibited effects to repair video or mix failures.

1. **Analyze the completed picture first.** Review the final video, split it by shot, and identify its rhythm, dialogue windows, emotional peaks, transitions, action nodes, and intentional silence. Produce a **BGM Design Table** with one row per music event: timecode, section, instrumental style, intensity, entry/exit, and relationship to dialogue or action. Do not invent music events without a visible or explicitly timed reason.
2. **Confirm the BGM plan and operation scope.** Show the design table, instrumental direction, boundaries, levels/fades, music-segment count, generation attempts, final mix count, optional bounded mix-correction allowance, and cost exposure. Do not generate before approval. Choosing BGM authorizes analysis, not automatic music creation, retries, or video regeneration. Reuse precise preauthorization; preserve dialogue priority and deliberate silence.
3. **Generate instrumental BGM segments.** After confirmation, use seed-audio T2A to generate one non-vocal instrumental segment per defined timing block. Prompts must request only instrumental music and silence: no recognizable human voice, spoken words, lyrics, whispering, dialogue, vocalization, audience laughter, canned laughter, sound effects, Foley, room tone, or language content. Do not split a block by dialogue line; let the original video carry all dialogue and original sounds.
4. **Align and mix.** Trim or time-align the instrumental segments, then mix them under the original final-video audio. Preserve the original dialogue, narration, production sound, and sound effects unchanged. Voice remains highest priority; keep BGM approximately 12–18 dB below speech and lower it further during dense dialogue. Do not replace or clean the original audio unless the user separately requests audio restoration.
5. **Replay, validate, and classify.** Check instrumental-only additions, timing/fades, and original-sound clarity. For gain/alignment/routing/export errors only, reuse existing media and correct/remix within authorized post scope. Do not invoke video generation or automatically regenerate BGM.
6. **Defective BGM content.** Mark any added music containing prohibited voices/effects as failed and retain evidence. Propose excluding that segment from the mix or regenerating only that segment, with explicit scope/attempt/cost approval first. Do not delete source files, alter original dialogue to conceal a defect, or generate laughter/Foley as a workaround. A failed music segment does not make the source picture defective.
7. **Separate picture defects.** Record affected shots/timestamps and request distinct video-repair authorization and counting. “Remix” never includes regenerating picture. Only explicit video-repair approval permits generation; new picture and native audio need fresh checks.
8. **Stop and deliver.** Mixing/export share the project budget and deterministic-operation cap. Stop at acceptance, limits, no improvement, blockers, or a scope change; preserve source video/audio and the latest qualified version, report usable results and open findings, and do not loop until every check passes.

For the default sitcom-comedy direction, use light jazz, vaudeville, piano, marimba, or restrained instrumental stingers inside the BGM only. Use quieter underscore during emotional or dialogue-heavy moments and short instrumental accents at motivated reversals. Canned laughter and all picture-grounded sound effects are out of scope for generated audio and must not be regenerated.

## OPERATING MODES

- **Concept mode**: premise, characters, set, comic engine, and concise style bible.
- **Storyboard mode**: numbered shot table and image prompts.
- **Animation mode**: approved storyboard frames converted into timed video prompts with motion, audio, and tail-frame handoffs.
- **H3 full-reference mode**: explicit reference roles, shot timeline, cut direction, anti-box safeguards, and recovery ladder.
- **Revision mode**: diagnose identity, continuity, pacing, or comedy failures and patch only affected shots.

Do not claim a clip is rendered or consistent unless actual generated outputs are available for inspection.
