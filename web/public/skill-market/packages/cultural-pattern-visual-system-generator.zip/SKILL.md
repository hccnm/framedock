---
name: cultural-pattern-visual-system-generator
description: |
  Extract cultural, architectural, or craft references into reusable patterns, colorways, mockups, packaging, and motion showcases. Use for cultural-brand visual systems, not full brand strategy.
trigger-words: [文化纹样, 纹样提取, 花砖纹样, 铁艺纹样, 建筑纹样, 文创品牌, 品牌样机, 连续纹样, 配色方案, 文创产品]
---
# Cultural Pattern Visual System Generator

This skill extracts reusable visual motifs from cultural, architectural, folk-craft, and ornamental references, then develops them into a coherent visual system for a cultural or creative brand. It is intended for complete brand extension and presentation, not a one-step image result.

## STEP 0: Enforce Sequential Creation

Always follow the documented workflow in order. Never jump directly to a later deliverable or compress the full workflow into one generation call.
If the user asks for a later-stage result, complete the earlier stages first and only then continue.
Every stage must produce its own output before the next stage begins.

## STEP 1: Gather the Theme

Collect the brand name, brand category, cultural or regional theme, and any reference images or written descriptions.
If the user provides text only, extract the core motifs, symmetry, structure, decorative density, and brand direction.
References may depict wrought iron, tiles, walls, columns, gates, floors, furniture, architectural ornament, or any other carrier. Use the visible design language regardless of the material type.
If multiple images are uploaded, treat every image as an independent reference. Do not merge their motifs. Each image must receive its own complete asset set and remain clearly labeled by reference order.

## STEP 2: Create the Master Motifs

For each independent reference or theme, generate two separate outputs:
1. a front-facing realistic motif master showing the source design clearly
2. a clean white-background master isolating the reusable motif

The white-background master must be centered, legible, easy to extract, and suitable as the source for later pattern work. Preserve the reference's meaningful structure while adapting it to the stated brand direction.

## STEP 3: Derive the Pattern System

For each white-background master, generate separately:
- one seamless continuous repeat pattern
- four coordinated colorway variants
- readable hexadecimal labels for the four colorways

Do not combine pattern systems from different reference images. Each repeat and palette must remain traceable to its own reference and brand direction.

## STEP 4: Produce Full Brand Mockups

For each independent reference, use its own masters, repeat pattern, and four colorways to create a full brand mockup board with 6-8 product concepts.
Automatically adapt the product list to the brand category. Possible category branches include:
- high-end fragrance: bottle, gift box, shopping bag, scent card, sample pack, display tray, outer packaging, gift set
- cultural-creative: notebook, bookmark, postcard, tote bag, washi tape, memo card, collectible, gift box
- beauty: carton, bottle, tube, label card, set box, pouch, sample kit, display insert
- food packaging: outer box, inner tray, bag, label, canister, gift set, seasonal box, carry bag
- other categories: infer a relevant 6-8 item product family from the stated brand category without changing the motif identity

Use a simple, orderly flat-lay presentation with a slight perspective tilt, clear hierarchy, balanced spacing, and the brand name visible where appropriate. The motif masters, white-background masters, continuous pattern, and four colorways must be the core design basis.

## STEP 5: Generate Wallpaper and Motion Assets

For each independent reference, create separately:
- one 16:9 wallpaper
- one 9:16 wallpaper
- one 5-second 16:9 motion showcase

Wallpapers should preserve the reference-specific motif identity. The motion showcase should use a tasteful ornamental reveal, growth, unfolding, or pattern transformation and work as a brand opening or closing asset.

## STEP 6: Check Consistency and Deliver

Before final delivery, verify that:
- all outputs preserve the correct reference-specific motif family
- non-iron references were handled through the same full workflow
- multiple references were never mixed
- every reference has its own masters, continuous pattern, mockup board, wallpapers, and motion output
- each colorway belongs to its own pattern system and includes a hex label
- the mockup product list matches the brand category
- the brand name and overall presentation fit the requested tone

If the user changes the reference, theme, brand name, or brand category, rebuild the dependent outputs from the affected master rather than mixing old and new systems.
