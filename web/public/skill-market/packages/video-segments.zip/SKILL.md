---
name: video-segments
description: Plan video storyboards from scripts or concepts
---

# Video storyboards

Use this skill to plan a storyboard outline from a confirmed script, story, or concept, and to revise the storyboard when needed.

- Reuse the concept, assets, frame format, and visual style already confirmed with the user; do not redesign them.
- Stop at the storyboard. Segment prompts, music composition, script writing, character/product/scene reference images, and detailed visual packaging are out of scope.
- Reuse valid analysis and confirmed documents; focus revisions on affected content.

## Shot planning

Plan shots from the script or concept.
- Timing: estimate Chinese dialogue at about 3 characters per second for slow speech, 3.5 for ordinary speech, and 4 for intense speech; 4.5 is an extreme ceiling. About 210 characters of ordinary dialogue need one minute. Estimate English at about 120–160 words per minute. For other or mixed languages, prefer actual spoken timing or existing voice samples; use agent judgment when samples are unavailable.
- Unit length: plan each generation within the duration limit of the selected video model's current mode. If no model is selected, provisionally target roughly 30 seconds and recheck after selection.
- Shot table: organize by the content of each generation. Include day/night, location, shot number, shot size and angle, and plot.
- Segment boundaries: the last shot of one separately generated segment and the first shot of the next must not show the same character from the same angle. Transition through a story-motivated listener reaction, prop close-up, or wide scene view.
Save the complete shot plan and request user confirmation.
