---
name: design-libtv
description: Create images and video in LibTV from briefs, scripts or selected assets, continue existing projects, and return verified media to the canvas. Use when the user chooses LibTV.
---

# LibTV visual creation

Use LibTV when the user chooses it for image or video creation, asks to continue a LibTV project, or wants its results on the current canvas. Do not move unrelated work to LibTV. Connection alone is not permission to generate paid media.

## Establish the work

Identify the deliverable, subject and style, reference assets, target project, model preference, framing, resolution, output count and any budget the user supplied. For video, also identify duration and whether sound is required. Explain that selected reference assets will be uploaded to the user's LibTV account; do not upload unrelated canvas assets.

Before generation, resolve missing basic information:

1. Reuse choices explicitly provided in the current request, earlier confirmed conversation or selected reference assets. Do not ask again for known information. A model used in an earlier attempt is not automatically the user's model preference for the next one.
2. When the model is unspecified, ask the user to choose a model or explicitly select automatic recommendation. Offer only currently available, compatible models, briefly explaining relevant quality, reference or sound differences. If availability cannot yet be read, ask for the preference first and check support after connection; do not invent a model menu.
3. Ask about missing output-defining information in one concise round: image or video, subject/style and reference needs, framing, resolution and count; for video, include duration and sound. Omit fields that do not apply or are already settled. Group related choices into a small number of questions and offer a recommended complete specification the user can accept, rather than asking one field at a time. Ask about a spending limit when it affects the proposed scope, and never invent a price or budget.
4. Wait for the user's answers or explicit permission to choose the missing details before submitting generation. An unanswered question or a suggested default is not confirmation. If the user says “choose for me” or accepts a recommended specification, select compatible settings within that scope and briefly state the final model and output specifications before generating; do not ask for the same confirmation again. Account connection and read-only capability discovery may proceed while awaiting creative choices, but no paid generation may start.

For existing work, inspect the named project before editing. In LibTV a workspace contains projects; a project is a canvas. Keep that distinction when selecting the destination. Never replace or delete existing remote content without authorization.

## Verify account access

LibTV is an online creation service. Use its available remote capabilities; account connection, browser authorization and credential renewal belong to the application's LibTV connector. This workflow requires no local application, addon, service or connector-preparation script.

1. Verify account access with an available account or project read before creating or resuming work. A visible website, a connected channel or the user's report of signing in alone does not establish that creation access is authorized.
2. If the capabilities are missing or account access is rejected, briefly tell the user that you will open LibTV sign-in, then use the available account-authorization capability to initiate it once from the conversation. Keep the application’s connection dialog and let its account-authorization capability open LibTV consent in the system default browser. Let the user complete sign-in and consent, and wait for the connection result. Do not switch to the Design built-in browser or ask the user to copy an authorization URL. Do not send the user to settings before attempting this capability. Only when it is unavailable or reports a failure should you explain the failure and offer the application's LibTV connector as a manual recovery entry. Never ask for passwords, callback codes or tokens.
3. After authorization, refresh the available capabilities and verify account or project access again before continuing. If access is still rejected, preserve the project and task context and report the exact connection failure. Do not claim that reconnection succeeded or repeatedly ask the user to sign in to the website.

A successful connection does not prove an image/video task succeeded. Use live capability descriptions to discover project browsing, asset upload, generation, progress and export support; never invent operation names or copy stale model menus.

## Report remaining credits

After authorization succeeds and before the first paid creation in this request, read the remaining credits of the account that will actually pay and report them briefly in the conversation, for example “Your LibTV personal account has 120 credits remaining.” The number is illustrative: always replace it with the observed value. One account read can satisfy both access verification and the credit check; do not duplicate it.

Use the currently available account or credit-reading capability and report only the current available credits explicitly returned. Label personal and team balances separately; do not add them together or change the spending account. If it returns only identity, membership or plan information without a balance, state that the current capability does not provide it. Do not automatically open a website, load a browser-control workflow or request another sign-in just to check credits. Do not read browser credentials, storage or hidden authentication data, or invent a query endpoint.

If the balance cannot be read, say “LibTV is connected, but I cannot read the remaining credits right now.” Do not derive it from membership status, plan allowances, an earlier balance or estimated charges. Missing balance information does not mean insufficient credits. Existing generation authorization may proceed when no budget verification is required; pause paid submission if the user requires a strict budget that cannot be checked. If insufficient credits are confirmed, explain the evidence and stop rather than probing the balance with generation requests.

When the current capability provides a balance, refresh it once after the task reaches a terminal state and report it briefly alongside the creative result. A failed balance refresh must not block delivery of completed media; say that the post-generation balance could not be refreshed. Read again after an account change, recharge or an explicit balance question. If the current capability is already known to omit balance information and has not changed, avoid repeated ineffective reads. Do not query credits on every progress poll. Keep credits, membership information and query failures in the conversation, off the canvas.

## Create and iterate

1. Inspect or create the agreed destination and retain its link and identifiers as internal continuation records. Record source asset identities, remote workspace/project/node identifiers, generation task identifiers, versions and imported result identities as they become available. Use an available internal record capability that does not publish files to the asset library or canvas. If no such capability is available, retain the information in the conversation for continuation; do not create a `libtv-project.json` or similar handoff file in a project or output directory that may be automatically imported. Keep credentials and signed download links out of these records.
2. Inspect selected references and transfer only the necessary files using the available upload capability. If local file transfer is unsupported, explain the missing capability and ask for a supported reference source; do not pretend a local path is a remote asset.
3. For multi-shot work, prepare a shot list with subject, action, composition, continuity and expected output for each shot. Generate one representative image or shot when a style decision is still open. A direct, fully specified single-output request can proceed immediately within its authorized scope.
4. Check currently available models and limits against the requested work. Honor the user's model choice. Explain material substitutions before proceeding. Confirm any added batch, extra paid attempt or spending beyond the user's request. For images, follow the prepared-node workflow below.
5. Before submitting the agreed work, save its operation identity, stable deduplication key, original creation choices and submission time in the internal continuation record described above, excluding credentials and signed links. Immediately add any returned task or operation receipt and inspect that same task until a terminal result. Preserve failed and unresolved attempts for recovery; follow the recovery rules below before another write.
6. Review generated media for reference fidelity, visual defects, motion continuity and agreed framing/duration. Iterate on the same project with clearly named versions and preserve accepted results.

## Image creation and remote delivery

1. Prepare an image node in the agreed LibTV project without starting generation. Let LibTV validate and normalize the selected model and creation settings. Reuse an existing node only when it is the intended destination and its preceding operation has settled.
2. Read the prepared node back and check its prompt, model, image count, framing, resolution and quality against the agreed work. Correct preparation errors before spending credits. Generate from this same prepared node using its saved settings, rather than independently assembling a standalone generation request. Do not switch to another submission route after an uncertain result.
3. Record the returned generation task identity separately from any canvas write receipt. The task is not complete while its status is `PENDING`, `PROCESSING`, `RUNNING` or another non-terminal state: keep querying that same task until a terminal success or failure, and do not end the turn with only a project link or a progress message. On a transient tool or connection failure, preserve the stable task identity and report recoverable progress instead of submitting a second paid attempt.
4. At terminal success, retain the original media reference and check the raw persisted project node as well as the task result. A read helper can synthesize an image reference from a completed task even when the saved node has no displayable output. If this mismatch occurs, use the supported node-edit capability to attach that same completed image to the same node without generating again, with a freshly read project revision. Preserve the original prompt, settings and task identity. Stop on a conflict or unsupported edit; do not overwrite the whole node to force delivery.
5. Verify that the persisted node now contains the output reference, then use the current canvas media-import capability to import the original image into the local canvas and verify that the new local node actually displays it. Remote write-back and local import are separate delivery steps: if either fails, retain the successful task and image, report exactly which destination is incomplete, and recover delivery without another generation.

## Video compatibility before generation

Before spending credits, inspect the selected model’s current duration, framing and resolution choices, and validate the proposed video with the available planning capability. A recommendation or passing preflight alone does not prove that generation will accept the settings. If the advertised resolution default contradicts its allowed choices, or a previous terminal task rejected an advertised choice, treat that model configuration as unavailable. Do not guess alternative spellings or try paid variants to discover one that works.

If the user has delegated model selection, choose another available model that meets the confirmed duration, framing and reference requirements, explain any material difference, and validate it before submitting. If model selection remains unanswered, follow the basic-information questions above first. If the user selected a specific model, explain the incompatibility and ask before changing it. Respect the existing spending authorization; a replacement after a failed paid task still needs authorization for the new attempt. If the user requires the affected model, or no compatible alternative is verified, preserve the project and explain the service limitation.

Record and follow the real video task through its terminal result. Recover a missing task identity from the persisted project node before attempting anything else. At success, verify the saved video and import it to the current canvas; at terminal failure, preserve the exact reason and do not label a schema or service rejection as a login or membership problem.

## Recover interrupted or rejected work

A missing image, empty canvas node or unchanged project revision does not prove that the service has no pending operation. After a rejected or interrupted submission, recover the original operation before changing the generation route, model or deduplication key. Use its returned task identity when available; a canvas write receipt is not a generation task identity.

If the service reports an unresolved preceding write, pause further writes to that project and inspect the available recovery capability. Replay only when the live capability explicitly supports recovery of that operation, retaining the original action, inputs and deduplication key within the user's authorized scope. Do not invent a task identity or recovery action. If no usable recovery identity or supported recovery path is exposed, preserve the project, original operation record, exact error and timestamp, and explain that service-side recovery is required. Do not silently switch to a new project to bypass the unresolved work.

A user asking to retry or purchasing membership does not establish that the preceding operation has settled. Recheck relevant account entitlements when the user reports a change, but distinguish account readiness from operation recovery. Report insufficient balance or membership restrictions only when supported by an explicit service response; a generic rejection or project-busy response does not establish either cause. Start a fresh paid attempt only after the preceding operation is resolved and the user's authorization covers it.

## Return and hand off

Only place creative deliverables requested by the user, such as completed images or videos, on the canvas. Internal handoff records such as `libtv-project.json`, task status, operation receipts, model settings, diagnostic logs and other supporting JSON or Markdown files are not creative deliverables: do not import them, create canvas text/file nodes for them, or convert them into screenshots or documents for display. Internal recordkeeping must not create a canvas node, including through automatic file import. Keep project links and brief progress or failure explanations in the conversation.

Import completed media into the current canvas through its available asset import capability. Reuse the associated result node on subsequent versions when possible. Verify that each image displays or each video plays, and that the imported asset is durable rather than only an expiring remote preview. If import fails, preserve the remote result and task identifiers and report delivery as incomplete; do not regenerate it.

Deliver the verified image/video on the canvas and provide the LibTV project link and concise revision notes in the conversation. Retain continuation records internally. Distinguish editable LibTV project content from rendered media: returning a video does not recreate LibTV's editable graph in the local canvas.

If account access is lost, preserve the project/task context and follow the account access checks above. If balance, region or capability restrictions prevent generation, report the specific supported limitation and stop that operation. Completion requires a terminal task, verified media, a persisted remote output reference when the connector supports remote projects, and a verified local canvas import. Account connection, a project link, a remote node, a queued or processing task, a canvas-operation receipt, or an export URL alone is not completion.
