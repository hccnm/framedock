---
name: transcript-broll-planner
description: Turn a transcript, voiceover, data, or talking-head script into a semantic B-roll plan, missing-material checklist, approved prompts, and video assets. Use for knowledge edits, not simple trimming.
trigger-words: [transcript B-roll planner, B-roll planning, transcript-driven B-roll, talking-head B-roll, voiceover B-roll, narration B-roll, B-roll shot planning]
---

# Transcript B-roll Planner

Use this Skill when the user already has a transcript, voiceover draft, data-rich narration, or talking-head script and wants a repeatable workflow that turns it into B-roll planning and generation. It is designed for knowledge videos, explainers, market analysis, and transcript-led editing where the model must decide what should stay as A-roll, what needs visual support, and what should become a separate B-roll shot or a beat inside a continuous one-take.

## Inputs

Required:
- A transcript, voiceover draft, or script with enough text to segment by meaning.

Optional:
- Existing footage, screenshots, logos, UI captures, product photos, documents, maps, charts, data tables, or other reference materials.
- User constraints such as aspect ratio, duration per shot, continuous-shot requirements, style direction, on-screen text language, target generation model, or whether the output should be more literal or more abstract.

Do not use this Skill for a one-off image prompt, pure subtitle export, simple trimming, or unrelated long-form editing tasks.

## STEP 1: Split the Transcript by Meaning

Read the transcript and break it into semantic units, not just punctuation-based sentences.

For each unit, decide whether it should become:
- A-roll retention
- Evidence-driven support
- Existing-material reuse
- text packaging / motion typography
- pure visual B-roll

Rules:
- Keep one core idea per shot whenever possible.
- Prefer fewer, clearer shots over over-cutting the script.
- If the user asks for a continuous one-take B-roll, design all units as beats inside one continuous camera move instead of separate disconnected shots.
- If a line contains claims, numbers, brand names, legal text, citations, or any word that must be exact, mark it for evidence or deterministic handling instead of free-form visual invention.
- If the transcript is too weak to segment confidently, ask the user for the full script or a cleaner transcript before continuing.

## STEP 2: Choose the Best Template Route

Match each semantic unit to the most suitable template family from T01-T21.

Use the template family that best fits the content type:
- conclusions, reversals, punchlines → kinetic statement
- concepts, single metaphors, hero ideas → concept hero
- verified numbers and rankings → number impact
- evidence, articles, reports, and citations → evidence excerpt or evidence desk
- processes, causality, workflows → relation flow or chapter sequence
- comparisons and contrasts → split system comparison
- systems, organizations, mechanisms, taxonomies → white diorama system, branching taxonomy network, or technical mechanism explainer
- products, parts, or assembly logic → 3D product assembly
- geography, maps, supply chains, or global distribution → geospatial intelligence map

Rules:
- Choose the simplest template that still expresses the meaning clearly.
- Do not force a visual metaphor when the content is better served by evidence or a clean overlay.
- If the transcript contains multiple ideas that would fight each other in one shot, split them into separate shots or separate beats inside a continuous one-take.

## STEP 3: Identify Missing or Required Materials

Check whether the shot needs assets the user has not provided yet.

Common missing materials:
- logo or brand lockup
- product photos
- app or website screens
- charts, papers, screenshots, or source tables
- identity references for a recurring person or character
- maps, diagrams, or technical illustrations
- precise text that must appear on screen

Rules:
- Call out missing essentials before generation.
- Do not invent factual content, brand claims, citations, legal text, or source references.
- If a shot depends on exact wording, require the exact wording from the user or a trustworthy source.
- If the user specifies an on-screen text language, keep all on-screen text in that language while keeping the generation prompt in the user's requested prompt language.
- Do not bind the workflow to one specific video model. Use the user's explicit model choice when provided; otherwise let the host orchestrator choose an available model for the approved plan.

## STEP 4: Produce a Reviewable B-roll Plan

Create a shot-by-shot or beat-by-beat plan that the user can review before any video generation.

Each plan item should include:
- shot or beat id
- source transcript segment
- template family
- visual purpose
- required assets
- on-screen text limits and language
- motion and continuity notes
- whether it needs generative video, evidence, or a deterministic tool instead of free generation

Rules:
- Keep each shot or beat focused on one core semantic unit.
- Keep on-screen text short and readable.
- When the text load becomes too heavy, split the shot or remove free text and move the idea into a cleaner visual solution.
- When the user requests continuity, explicitly describe how one visual form transforms into the next.
- If the user asked for a more polished, more literal, or more continuous result, adjust the plan accordingly while preserving the semantic structure.

## STEP 5: Ask for Approval Before Generation

Stop after the plan is ready and wait for the user to approve the shots or request edits.

Approval is required before any real video generation.

Do not skip this gate even if the plan looks obvious.

## STEP 6: Generate the Approved Shots

After approval, generate only the approved shots or approved continuous take.

Rules:
- Batch similar work together when possible.
- Preserve continuity across shots that share the same subject, product, data system, or visual world.
- Use the review plan as the source of truth for shot order, beat order, motion continuity, and asset requirements.
- Report any invocation failure, generation failure, unknown outcome, or observed content flaw and follow the user-decision gate below; never retry automatically.
- Keep generated outputs organized so they can be reviewed and reused in later edits.

### Failure and Quality Review: User Decides

These rules apply to every generated image and video shot, including reference images, keyframes, and continuous takes. They replace automatic retry behavior in this workflow.

1. **Invocation failure:** If a request is rejected, cannot be submitted, or returns an invocation error, report the affected shot/image, the known error, and whether any output exists. Do not invent a cause. A timeout or interrupted response alone does not prove generation failed: check the existing task or returned assets when possible, otherwise report the outcome as unknown. Do not submit a duplicate request to resolve uncertainty.
2. **Generation failure:** If the generation task explicitly fails or finishes without a usable output, report that separately from an invocation failure. Preserve any successful outputs from the same batch.
3. **Successful output with content flaws:** Inspect available results and disclose concrete observed flaws, such as text errors, subject drift, continuity breaks, artifacts, or a mismatch with the approved plan. Keep the output as successfully generated and pending user quality review; a flaw is not an execution failure. Show the asset for review. If inspection is incomplete, state that limitation instead of declaring quality passed or failed.
4. **Stop for a decision:** After reporting a failure, unknown outcome, or content flaw, pause new generation and dependent work and ask the user what to do. Already-running batch tasks need not be discarded; retain and report their results. For failures, offer retry, revise the plan, skip, or stop. For flawed but successful outputs, offer accept as-is, specify an edit, regenerate, skip, or stop. Recommend a choice if useful, but do not choose on the user’s behalf.
5. **No automatic recovery:** Do not automatically retry, regenerate, repair, change models or parameters, or rewrite prompts after a reported issue. Original plan approval, rejection of a result, or a general request to continue is not blanket permission for a retry or repair. Obtain an explicit decision identifying the affected asset and intended action; clarify only if the scope is ambiguous.
6. **Scoped authorized follow-up:** Once explicitly authorized, perform only the chosen action on the named failed, missing, or user-selected asset. Reuse all other successful outputs, keep the original available for comparison, and never rerun the entire plan by default. Each authorization covers one attempt, not a retry loop. If that attempt fails or has new flaws, report again and wait for a fresh decision.

Issue reports should include the shot/image identifier, outcome category (invocation failure / generation failure / unknown / generated with content flaws), available asset, observed error or flaw, affected dependencies, and the decision requested. Do not claim unverified cost, refund, completion, or quality results.

## STEP 7: Deliver the Plan and Assets

Return the final B-roll plan, generated shots and images, and any missing-material notes in a form the user can review immediately. List unresolved failures, unknown outcomes, and disclosed content flaws separately, with the user’s decisions and any pending choices. Do not present incomplete or unaccepted work as fully completed or approved.

This Skill is best for transcript-driven B-roll planning and approval-gated video generation. It is not intended for pure subtitle translation, simple trimming, long-form scriptwriting, or unrelated branding workflows.
