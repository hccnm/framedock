---
name: miniature-person-scene-compositor
description: "Create realistic miniature-person interactions from person and scene photos, with optional approved video plans and clips. Supports stills or prompts only; not toys or long films."
metadata:
  version: "1.0.0"
trigger-words: [miniature person, tabletop photography, miniature interaction video, forced perspective, 微缩人物, 桌面微缩摄影, 缩小合成, 微缩互动短片, 合成图转视频]
---

# Miniature Person Scene Composite

Create miniature-world videos from one or more real-person photographs and one main environment photograph, using an approved photoreal miniature composite as the intermediate visual anchor. Support still-only and prompt-only requests without generating extra media. The result should look like the same real people optically reduced in size, not figurines or cutouts. Confirm that the available capabilities can inspect the references, create the requested composite, and deliver accessible results before execution.

## Core boundaries

- Preserve each person's recognizable identity, hairstyle, body characteristics, clothing, accessories, and requested props. Physical scale and scene-consistent lighting may change; appearance redesign requires an explicit request.
- Preserve the main scene's framing, viewpoint, important objects, existing people, and spatial relationships unless the user requests changes. Do not reuse an inserted person's identity for background people.
- Match support-plane perspective, illumination, depth of field, sharpness, grain, and contact shadows. Do not force an eye-level camera or shallow focus onto a scene photographed differently.
- Preserve the depicted person's actual anatomy, assistive devices, and intentional occlusions. Reject unintended extra, missing, fused, or distorted visible body parts; do not force hidden fingers or limbs into view.
- This Skill creates still composites and, after approval, related short interaction videos through an outline and detailed prompt. It does not create long films, layered editing projects, toy designs, ordinary background swaps, or simple image resizing. Quality requirements are inspection targets, not guaranteed identity, scale stability, or pixel-perfect reconstruction.
- Still-only and prompt-only requests stop at the requested deliverable. Video continuation stays within this Skill; do not load another Skill or replace the approved identity and scene. Never treat image approval as video-generation approval.

- Objects invite interaction; miniature scale determines movement. A goal, obstacle, achievement, or emotional turn is optional. Observing, touching, leaning, testing a surface, resting, or playing can sustain a complete clip. Physical scale must govern reach, stride, grip span, support, and plausible relative force, not merely remain visually consistent.

## User workflow and distinct approvals

Analyze people, environment and feasible interaction → offer 2–3 image interactions and wait for a choice (reuse a specified action or explicit delegation) → generate, inspect and approve the composite → resolve video intent only if unknown → confirm video ratio, total duration and resolution → choose a video direction → deliver the complete timeline-based production document → obtain document approval → separately summarize the actual model and execution specifications and wait for final generation authorization → execute, inspect and deliver.

The numbered sections below implement this one workflow. Image acceptance, direction selection, document approval and final video authorization have distinct roles; do not merge them. Reuse settled decisions. A still-only request stops after image delivery; direction-only stops at directions; prompt-only delivers the production document without media generation or mandatory new assets. For approved segmented shorts, record each accepted clip's actual ending before authoring a dependent continuation. Acceptance alone does not authorize another clip or assembly; existing explicit authorization for a clearly scoped operation remains valid. Do not impose a fixed duration or segment count.

## Execution boundaries and issue reporting

Execute only the generation tasks, versions and quantities explicitly authorized by the user. If generation fails, the service times out, inspection finds a problem or the user expresses dissatisfaction, retain existing results, report the issue honestly and stop further processing of the affected asset.

Do not automatically retry, regenerate video, add alternatives, replace clips, mute or replace audio, even when free. If task status is unknown, only query the original task; do not resubmit it.

Inspection findings, revision feedback, prompt updates and plan approval do not authorize regeneration. Execute again only when the user explicitly requests it and the corresponding scope is confirmed; never extend earlier generation approval into permission to repeat. Do not re-ask an already clear object or scope.

## STEP 1: Resolve inputs

Identify person photographs, the main scene, and optional marked placement guides from user instructions and actual media. Resolve usable project assets before proceeding. Do not invent asset references or assume file titles prove their contents.

Use existing semantic observations when sufficient. Otherwise inspect the media for subject count, identities that must remain separate, poses, supporting surfaces, camera geometry, world structure, and defining visible clothing or accessories. Obtain dimensions from media metadata, not visual descriptions. Reference images carry their colors directly; do not turn observed palette or complexion into invented textual color specifications.

For several photographs of one person, establish one primary identity reference and explain the supporting role of every other reference. If clothing or other appearance details conflict, ask which version to preserve. For different people, assign separate identities and positions. Ask only when roles, identities, or requested relationships remain ambiguous.

Marked placement guides donate location and orientation, not visible marks. Use all specified references for their intended role. Prefer the clean scene as the generation base; convert guide annotations into placement instructions. If no clean scene exists, explain the limitation and request one or obtain approval to remove the marks.

Before preparing assets, identify each existing reference's role and status: original identity, supporting appearance, scene geometry, approved scale, action mechanism, or inter-clip continuity; distinguish pending, accepted, superseded, and rejected versions. Every proposed new asset must resolve an outstanding visual uncertainty. Reuse sufficient assets. Turnarounds, prop sheets, empty scenes, and multiple camera references are not mandatory. A small set of props may share one sheet when their relationships remain legible and identities do not become ambiguous. Batch independent necessary assets; sequence assets that depend on approval of earlier results. Retain older versions for traceability, but exclude superseded or rejected versions from active execution references. Explain conflicts and obtain permission before retiring a user-specified reference.

## STEP 2: Determine scale, pose, and frame

Choose scale primarily from recognizable environmental objects and their relative proportions, balancing miniature-world contrast, identity readability, and reachable interaction rather than a fixed default height in centimeters. Explicit user scale takes precedence. Without reliable object measurements, describe relative size and visual estimates, not precise measurements. Once approved, keep physical scale fixed; never enlarge the person to complete an action.

Before any composite, inspect actual nearby objects, support, reach, clearance, occlusion and light. By default offer 2–3 distinct image interaction proposals and recommend one. Each identifies object and placement, the captured action moment, facing/gaze/expression/pose, hand/foot/seated support, relative scale, visual interest and feasibility. Wait for selection, revision or explicit permission to choose before generating; candidates are not multiple-output authorization. Reuse a clearly specified interaction without forcing another choice. Preserve identity, body characteristics, clothes and accessories while adapting pose, gaze and expression to the selected interaction, including still-only work. Preserve the source pose only when explicitly requested. Unclear viewing geometry does not prove free space or support; inspect or report uncertainty. Never thicken a support surface, shift an edge or prop, stretch limbs or enlarge the person to enable the pose.

Choose placement within the selected or explicitly delegated interaction. A clear location alone does not bypass interaction selection. For multiple people, resolve each position, facing, interaction and occlusion.

User-selected framing takes precedence. Otherwise let the main scene own the frame and use its verified dimensions to select a compatible supported ratio. Do not infer framing from portrait references. Ask before material cropping or expansion when exact scene framing cannot be preserved.

For a new pose, specify balance, limbs, and support points in clear language. Do not merge different poses from identity references. If the input lacks essential full-body or facial information, request a clearer photograph or explain what would need reconstruction before proceeding.

When reach or support is uncertain, do not conclude from prose alone that contact is impossible or that an extra prop is mandatory. Re-examine visible body proportions, contact locations, and occlusion. If necessary, propose a minimal pose, reach, or support test image and generate it only within the applicable authorization. Preserve approved scale and environment, varying only the uncertain pose rather than building another asset set. First assess repositioning, nearer contact, or plausible posture changes within the existing environment. Assistive props are not universally prohibited, but any added prop and its carrying or platform transitions must be plausible and user-approved. Never resolve reach by enlarging the person or silently resizing objects. If the user explicitly accepts revised scale relationships, use the latest approval and retire conflicting earlier constraints instead of repeatedly restoring old proportions.

## STEP 3: Check execution readiness

Check the live image capabilities and choose a currently available model that can accept all required visual inputs and perform reference-guided compositing. Respect any explicit user model selection. Verify per-image dimensions, formats, reference count, output ratio, and resolution limits.

If a capability or asset is missing, state the actual blocker and offer compatible choices. Never silently discard identities or required references, change a user-selected model, or claim an unperformed conversion. Do not hardcode model names or provider defaults into this Skill.

Use standard quality unless the user explicitly authorizes a more expensive tier. A request for larger pixel dimensions alone is not authorization to increase the compute tier. Ask before costlier quality settings or other material changes to the requested operation.

Proceed when the interaction is selected, explicitly specified or delegated, and placement and image output requirements are clear. Resolve only remaining ambiguity or cost changes; do not re-ask settled decisions.

## STEP 4: Compile a reference-bound image brief

Use the current interaction language unless the user requests another artifact language or a provider imposes a documented requirement. There is no mandatory English prompt.

Lead with the requested composite. Keep the main scene as the existing visual state; describe the added miniature person and the few continuity relationships that matter. Include only observed or user-specified details. The following sections are a flexible checklist, not a mandatory long template:

1. Goal and reference roles: name each image individually using numbered reference labels matching the actual attachment order. State which scene supplies the composition and which image supplies each identity. Preserve user attachment order unless the selected capability requires a different order.
2. Identity and appearance: name the defining observed hairstyle, clothing structure, accessories, body silhouette, and important held objects. Keep references visually authoritative for fine facial details and colors. Do not beautify, age-shift, mix identities, or redesign clothing without permission.
3. Pose and support: state the requested action or starting pose established in step 2, balance, and actual foot, hand, or seated support points. Allow natural occlusion.
4. Placement and scale: identify the support surface, location relative to specific props, facing direction, overlap relationships, and relative size.
5. Camera and optics: match the scene's viewpoint and support-plane geometry. Match local focus, sharpness, grain, and lens behavior without changing the scene camera to hide integration errors.
6. Light and contact: match the scene's observed main-light direction, softness, fill, and reflected illumination. Distinguish tight contact shading from the longer cast shadow; do not impose one generic oval or a single shadow direction on a complex lighting scene.
7. Continuity: preserve important scene elements and deliver a coherent photograph of real miniature humans, not a collage or manufactured figurine.

Omit unused sections and unresolved placeholders. Do not add elaborate art direction that contradicts the source scene. Read no additional vendor or workflow prompt documents unless a hard capability issue actually requires clarification.

## STEP 5: Generate and deliver the image

Produce one image for one intended outcome, unless the user requests alternatives. Use the same original identity and scene references across variants. Change only the requested placement, pose, or scale; keep other constraints stable. Different output ratios are separate artifacts, not extra samples of one frame.

Deliver the actual generated image as an accessible file or preview. Preserve its correspondence to the approved variant and references; clearly label multiple outputs. Do not claim a layered source was produced when only a flattened image exists.

## STEP 6: Inspect images and report issues

Visually inspect the generated image before claiming it passed. Check:

- the selected interaction is actually visible, including posture, gaze, expression and intended contact/support;
- recognizable identity and separate identities for different people;
- retained clothing, accessories, silhouette, and required props;
- plausible relative scale and correct support-plane perspective;
- actual support points, natural contact shading, and consistent cast shadows;
- scene-consistent light direction, softness, and reflected illumination;
- matching focus, sharpness, grain, and photographic material appearance;
- plausible visible anatomy and intentional occlusions;
- retained scene objects, existing people, composition, and required text.

Inspection only reports whether the result meets confirmed requirements; it does not trigger automatic repair or regeneration. Report the specific location, visible issue and unverified content, retain the original result and wait for user instructions. Do not mark a failed result as passed or use an earlier inspection to dismiss user feedback. Do not unilaterally remove user references, change appearance or scene viewpoint, switch models or incur extra costs to address inspection findings.

## STEP 7: Deliver and approve the composite

Provide an accessible image and its filename, plus a brief note on placement and any unresolved issue. Do not expose internal prompts unless asked. If output inspection was unavailable, say the image was generated but visual verification is incomplete. Delivery is incomplete if the user cannot access the output.

Keep original identity photographs, clean scene and accepted composite as separate reusable references. Ask the user to confirm identity, selected interaction posture, placement, miniature scale and integration; do not repeat existing acceptance. End for an explicit still-only request or refusal of video. If video intent is unknown, ask whether to continue. If video was already requested, proceed after image acceptance to the video specifications below without asking intent again. Composite approval is not video authorization.

## STEP 8: Confirm video specifications, then choose a direction

Before designing video directions, collect missing video aspect ratio, total finished duration and explicit resolution together. Reuse confirmed values; if the user says only “HD,” offer concrete currently supported options. Do not treat image ratio, platform duration or resolution defaults as user choices. Check current capabilities, including reference compatibility. If unsupported, explain the affected limitation and offer compatible specifications, model or segmentation; do not silently shorten, lower resolution or change a selected model. Resolve only missing choices. If the video ratio differs from the composite, propose crop, extension or reframing and protected content in the document; never stretch the source.

After these specifications are confirmed, refine the step 2 interaction against the approved composite. Inspect actual object height, shape, curvature, texture, stiffness, reachable surfaces, walkable gaps, support and occlusion. Reuse adequate observations. Design movement for the small body's real reach and scale.

With video specifications confirmed, offer 2–3 concise video directions unless a clear action plan is already specified; then use it directly. Each gives the main interaction and change, start/process/end states, optional interest or emotion, contact/support/scale constraints, camera and cut approach, and feasibility within the confirmed duration. Wait for selection before writing detailed prompts. Selection alone never authorizes video, and alternatives never authorize multiple outputs. Do not force a notice–approach–operate–succeed plot.

Sensing, observing, leaning, testing, or playing can be the whole interaction. Moving the object or achieving something is optional. Significant gestures relate to the object, sensory experience, balance, or comfort; avoid empty-air gestures and automatic smiles toward the camera.

Favor interest arising from scale contrast between ordinary objects and the small body. Let actual shape, texture, stiffness, or local material response participate in the interaction, without invented props, exaggerated strength, or forced success. For example, local compression may invite a balance adjustment, or a partially reachable curve may invite closer inspection; use such ideas only when supported by the scene, not as mandatory plots.

Check miniature embodiment:

- Reach: hands contact only areas within the current arm span. Preserve unreachable edges; observe, touch a nearer area, or change the route instead of enlarging the body.
- Movement range: strides, crossings, and grip spans fit the small body. Arms that cannot surround an object contact only part of its curve.
- Support: judge whether a foot fits, a hand can grip, or the body can pass using existing proportions.
- Relative force: fixed or massive objects generally stay stable while the person adjusts. Small, loose, or soft regions may respond. Do not invent measured force values.
- Local experience: a fold, texture, or small ledge may invite a testing step, closer inspection, or detour; not every detail must become an obstacle.

For physical manipulation, establish contact, secure grip or support, apply force, show a response, then release or re-support. Metal and ceramic usually remain stable; soft surfaces compress locally; cloth develops tension and folds; fragments originate at the actual contact location. Gentle contact need not visibly deform an object. Observation need not include touch. Never extend limbs, shift props, or enlarge the person to make an action possible.

If action-reference videos are supplied, distinguish visible contact from editorial omissions. Do not claim that unseen rope anchoring, climbing onto a platform, or loading a bag has been verified. Borrow interaction mechanisms, but complete necessary transitions or simplify the action for a continuous shot. Do not automatically import reference identities, clothes, props, music, or exaggerated strength.

Prefer normal real-time movement with overlapping gaze, head motion, reach, and weight transfer rather than joint-by-joint pauses. A small body implies neither slow motion nor mechanical acceleration. Preserve real-person characteristics rather than exaggerated eyes or cartoon acting.

Approved independent variants may begin beside their selected objects. Explicit continuations retain the approved starting placement and show plausible transitions.

Do not invent props or nonexistent interaction affordances. Keep one dominant interaction per short clip; do not overload its duration with actions.

Keep video direction selection, production-document review and final execution authorization separate. Direction-only requests stop at the selected deliverable. Reuse known choices without collapsing these approval responsibilities.

Separate essential visible actions from repetitive work that may be omitted. Essential actions may include the first meaningful grip, load-bearing contact, material transfer, release, or a necessary transition from holding a tool to empty hands; visibility requirements follow the approved story rather than a rule to show every movement. Only when multi-shot editing is approved may clear temporal ellipses compress repetitive walking, fetching, or operation. Resulting object states must remain causally understandable; do not excuse within-shot teleportation, intersections, or unexplained changes as editing. Budget actions for normal speed. If overloaded, propose simplification, timing redistribution, or segmentation instead of mechanical acceleration. Allow gaze, head motion, grip, and weight transfer to overlap rather than pausing at every joint movement.

Prefer an ending that continues the preceding posture and support relationships, using gaze, gesture, expression, or a user-requested short line. Avoid unnecessary standing, stepping back, repositioning, or posing toward the camera. When a result reveal is requested, allow a natural release, open-hand gesture, or head lift from the current posture while keeping the person, hands, and result readable. Camera address and speech require user intent. Do not impose crouching, open palms, or a fixed catchphrase on all videos; observation, rest, or continued interaction may also provide a complete ending.

## STEP 9: Deliver and review the production document

Use the current interaction language. After direction selection, deliver the complete production plan as an accessible, copyable document in a format the user can review. Use the video specifications confirmed in step 8, not assumed image settings. If the requested document format is unavailable, explain the limitation and offer a compatible alternative; do not claim an unsaved document was saved. For variants, clearly distinguish versions and counts.

Reference authority:

- Action videos supply observed interaction mechanisms, contact presentation, or an approved camera approach. They do not replace the original identity, scene, or approved composite scale. Name the contribution of each submitted reference in order.
- Original person photographs own recognizable identity, facial proportions, real skin, hair, clothing, and accessories. Do not use only a generated composite when the original identity reference is available.
- The original clean scene owns environmental geometry, object placement, lighting, and photographic perspective.
- The approved composite owns miniature scale, subject placement, and the approved frame. Do not carry over its accidental plastic skin or facial drift.
- Name every reference individually in its actual submitted order. Generic references are not opening keyframes. Only use an image as an exact first or last frame when the user explicitly requests or approves that role and the current capability supports it. Do not silently discard required references to satisfy a keyframe mode.

State how the composite is used in the video plan:

- Continue from this image: preserve the approved starting placement, pose, and frame, using it as a first frame only when supported and user-approved. If the mode cannot guarantee an exact first frame, disclose the limitation and obtain approval for a compatible approach.
- Scale and environment reference only: permit approved changes to starting pose or placement, without implying that motion begins directly in the original image.

If unspecified, name the proposed mode in the recommended plan and confirm it together with the full plan, without adding a mandatory separate selection gate. Generic references do not automatically become first or last frames; never discard necessary identity or scene references to enable first-frame mode.

Mandatory scale and camera contract:

- Reach, stride, grip, foothold area, and plausible relative force must fit the same small body. Being unable to reach, encircle, or lift something can be a natural state rather than a failure that must be forced into success.
- Anchor the same physical body throughout the clip using head size, shoulder width, torso and limb segment lengths, hands, and shoes relative to stable nearby props.
- Standing extends joints and increases the visible bounding height; it must not enlarge the head, shoes, or body segments. Do not force identical screen bounding boxes across seated and standing poses.
- Preserve normal perspective: moving farther away can look smaller. Do not enlarge a subject behind an object to keep the face visible. Permit natural occlusion.
- Do not impose a new height relative to a bowl, cup, or other object if it conflicts with the approved composite scale. Adapt the gesture to existing proportions instead.
- Permit purposeful moderate camera movement and cuts suited to action and duration; do not impose fixed-camera or one-take defaults or a fixed shot count. Honor an explicit fixed-camera or one-take request. Camera-induced screen-size changes must not change physical body scale.

The production document must contain:

1. Goal and confirmed requirements: interaction, output count, aspect ratio, total duration, resolution and audio.
2. Individual references and roles, including whether the composite is a general reference or an explicitly approved supported first frame.
3. Ratio adaptation and scene relationships to preserve.
4. Complete action synopsis faithful to the chosen direction.
5. A timeline from zero continuously covering the confirmed total: time interval, framing/viewpoint, camera motion, person position, concrete action, hands/feet/contact/weight, gaze/expression, object response, sound and cut joins. No unexplained gaps or overlaps; simultaneous actions share a stated interval.
6. Complete copyable prompts by timeline interval, with all necessary reference, action, camera, scale, support, continuity and audio instructions. Do not substitute “natural interaction,” “play happily,” or “same as above” for execution detail. Each interval has an inherited start, visible transition and next state. Walking specifies route/direction/stride/weight; sitting specifies lowering, hand support, seated contact and leg position. Alternating or crossed limbs need distinct roles and real clearance. Budget normal-speed action; obtain agreement to necessary load/timing changes rather than accelerate, teleport or omit essential transitions.
7. Acceptance criteria and actual risks: identity, scale, chosen action, contact, joins, sound and unverified geometry/capability.
8. Proposed currently available user-visible model name, generation count, segmentation and assembly scope. These remain proposals until final authorization.

Use wide views to establish space and scale, medium views for body action and details for real contact where helpful. Cuts need an observational or narrative purpose. Keep grip, load-bearing, sitting and release transitions readable and maintain position, facing, hands, feet, held objects and action phase across joins. Do not conceal teleportation or geometry defects with cuts. An explicit one-take request excludes cutaways.

Maintain one current production document. Local action changes update synopsis, timeline, complete prompts and acceptance criteria together, preserving unrelated accepted requirements. Keep exact lines, hand roles, counts and times unambiguous.

Audio defaults for this Skill: quiet environment and subtle synchronized physical sound effects only, with no BGM, melody, rhythmic accompaniment, dialogue, narration, or subtitles unless explicitly requested. Only describe available audio capabilities. Confirm a compatible alternative if the selected capability cannot produce the requested sound. Music permission must not be inferred from the word video.

After delivering the production document, wait for its approval or revisions. Document approval does not trigger generation; it leads to the separate final execution summary in step 10. Prompt-only requests stop at document delivery without media generation. Approval of one version does not approve all variants.

Before authoring a dependent continuation, make a concise handoff from the accepted footage: (1) subject position and facing, (2) posture, support points, and balance, (3) held objects and grip relationships for each hand, (4) prop locations, counts, and material or work-progress states, and (5) camera direction and the next action's starting point. Use actual footage, not the intended ending in an earlier prompt. Do not repeat completed actions unless replay is requested.

Original photographs retain identity authority; supporting views provide evidenced side and rear appearance; approved composites provide scale and environmental relationships; the accepted clip's actual ending supplies the continuation's action state. Resolve conflicts by role rather than overriding the ending with a static pose. Exact keyframe use still requires compatible user intent and capabilities; a video reference does not guarantee seamless continuation.

When observations disagree about hands, stance, or held objects, stop treating them as established facts and inspect the relevant ending excerpt and actual final frame. If anatomical left and right remain unclear, use view-specific screen directions or held-object/support-hand roles, without equating screen sides with anatomical sides. Mark occluded details unknown. Maintain one current handoff record and correct outdated descriptions that downstream work would otherwise reuse.

For local prompt revisions, cross-check prerequisite pose, current action, ending, audio and acceptance. Adding a spoken line removes only the conflicting dialogue ban, not restrictions on music, narration or subtitles. A posture-preserving reveal must have a compatible prior pose. Text edits alone never authorize generation; preserve existing approvals only for unchanged scope and follow step 10 for a new execution version.

## STEP 10: Final execution summary, authorization and generation

Only after the latest production document is approved, separately show a concise final execution summary: exact currently available user-visible model name; confirmed aspect ratio; total finished duration and any segment durations/assembly scope; explicit resolution; output count; document version; and confirmed audio. State that generation starts after confirmation, then wait for explicit execution authorization. Image acceptance, direction choice and document approval are not this authorization. Once the user confirms this summary, execute immediately without asking the same settings again. If they change model or specifications, check compatibility, update affected document sections and confirm the revised scope first.

Recheck supported modes, reference count, per-file and aggregate constraints against the confirmed requirements. Technical defaults must not override the approved ratio, total duration or resolution. Name the actual selected model in the execution summary. Preserve approved references and exclude rejected versions.

Execution authorization covers only the confirmed tasks, versions and generation quantities; it does not include automatic resubmission after failure, timeout or unsatisfactory inspection. After an execution completes or fails, do not add another generation for that output without a new explicit user instruction. This does not prevent other independently authorized outputs, but do not repeat a failed or noncompliant output or launch downstream work that depends on it. Reuse original identity, scene anchors and approved scale across the series. Retain original outputs and clearly distinguish versions. Successful generation proves output exists, not quality or audio compliance.

## STEP 11: Inspect video continuity, report, and deliver

Inspect actual footage at the beginning, transitions, and ending, and whenever the subject stands, crosses an occluder, or changes direction. Compare the head, shoes, and limb proportions against stable scene objects, accounting for perspective and pose. Report qualitative observations as such; do not invent measurements or guarantee fixed physical dimensions from visual inference.

Check separately: real-person identity and material appearance; wardrobe; body-scale continuity; camera cuts or reframing; route when movement occurs; applicable hand and foot contact; weight transfer and shadows; plausible object responses; intended occlusion; normal action speed; natural expression; and sustained or ending state. Hidden hands cannot prove surface contact. A final frame alone cannot prove full-clip continuity.

Beyond visual scale continuity, check whether the action is actually performed by the small body: reachable contact, proportionate strides and crossings, adequate footholds, plausible arm span around objects, and forces that do not unrealistically move fixed or massive props. Check contact–force–response order, prevent fragments appearing without contact, and do not excuse teleportation through cuts or occlusion. Mark obscured support as unverified.

Lack of achievement, an unmoved object, or continued leaning or observation is not a failure. Evaluate the approved interaction, reachability, scale constraints, and natural state rather than adding a requirement for success or an emotional climax.

Listen to the actual audio when available. An audio-enabled setting or a no-music prompt does not prove sound effects are present or BGM is absent. If analysis times out or cannot access sound, state what remains unverified. Do not repeatedly submit the same failing inspection or re-generate solely because inspection failed.

If the actual soundtrack conflicts with confirmed requirements, report it honestly and retain the original video. Do not independently mute, replace audio or regenerate video; wait for explicit user instructions.

Inspection only reports whether the result meets confirmed requirements; it does not trigger automatic repair or regeneration. Report the specific location, visible issue and unverified content, retain the original result and wait for user instructions. Do not mark a failed result as passed or use an earlier inspection to dismiss user feedback. Do not conceal scale or continuity problems by globally resizing, replacing clips or rewriting approved actions.

Deliver each usable video as an accessible, playable file with its filename, brief verified observations and unresolved limitations. Clearly label multiple current outputs and their versions. Do not describe generated-but-unverified output as fully accepted. Ask for result review before using a new video as a continuity anchor.

Inspect the opening, critical contacts, transitions, and ending according to risk; do not repeatedly analyze entire media when existing evidence is sufficient. If full-clip analysis times out or observations conflict, target the missing evidence using an excerpt, actual frame, or audio review instead of looping the same request or regenerating the work.

Classify findings as observed compliance, clear noncompliance, approved editorial omission, or unverified. An approved ellipsis is not automatically a failure and does not excuse teleportation or causally unexplained changes. Ending-only inspection supports only ending claims; a final frame does not prove whole-clip continuity, and enabled audio does not prove music is absent. Report spoken lines as actually heard, distinguishing exact wording from approximate pronunciation; do not infer speech from lip motion. Keep generated, inspected, and user-accepted statuses distinct.

When final assembly is requested, use only the accepted versions and verify actual durations, dimensions, order, action joins, and audio continuity. Nominal segment lengths do not establish final duration. Apply approved trim or audio strategies and ask about unresolved trade-offs. Single-clip authorization does not imply assembly. Specific settings, prop counts, holding hands, prohibited individual aids, catchphrases, shot counts, and durations remain project decisions rather than Skill defaults. Preparation–operation–reveal is an optional story scaffold, not a replacement for observation, leaning, testing, or other non-task interactions.
