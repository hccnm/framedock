---
name: brand-promo-video-generator
description: Create a promotional short from verified brand assets, product references, and campaign goals. Use for launches and social promotion; do not invent claims or imitate marks without authorization.

---

# Brand Promo Video Generator

Create a polished short promo video for a brand, product, website, app, shop, or personal project. Use this Skill when the user has a logo, product images, screenshots, a website link, or just a clear idea and wants the agent to turn those materials into a clean promotional reel.

This Design adaptation replaces third-party Vibe Motion / Remotion implementation details with Design-native orchestration: source research, asset verification, story planning, image/video generation, optional speech or music, and editing assembly. Do not initialize external projects or depend on npm validators during normal execution.

## STEP 1: Intake assets and resolve the brief

Before any story planning or generation, run a required user intake. Ask the user to upload or provide links to the elements that must be verified:

- Logo files or official logo source pages
- Font files, font names, typography guidance, or official website pages that show brand typography
- Brand colors, color system, style guide, or pages that clearly show official colors
- Product images, UI screenshots, packaging, renders, footage, or other brand imagery
- Product information: official product name, feature list, launch focus, claims, CTA, disclaimers, and target audience
- Company/product official URL or official source package

Treat user-uploaded assets as usable by default for pre-production and concept planning. Do not repeatedly ask a standalone rights/permission question during the first intake unless there is a concrete risk signal, such as a visible third-party watermark, obviously scraped marketplace imagery, contradictory user wording, legal/medical/financial compliance claims, or the user asks for commercial publication. Record the source as "user-provided" and surface rights caveats in the source summary instead of blocking the flow.

In the same opening intake, ask the user to choose:

- Target duration, normally 15-30 seconds; recommend 15 seconds when the user wants a fast launch film
- Aspect ratio; offer common choices such as 16:9, 9:16, 1:1, 4:3, 3:4, or match a supplied reference

Also identify campaign focus, distribution channel, narration language, on-screen copy language, and visible copy needs when they are not already clear. Do not proceed to creative direction until the user has supplied the usable materials or explicitly confirms which elements are unavailable.

Language rule for promo content: choose narration and on-screen copy language from the brand materials, target audience, and platform context, not mechanically from the chat language. If the brand assets and visible source copy are primarily English or global corporate English, default narration and on-screen copy to English unless the user explicitly asks for Chinese localization. If the user is Chinese but says they are testing as a new user, keep chat replies in Chinese, but plan the actual video copy in the language that best fits the brand campaign.

If a logo, product UI, person, mascot, packaging, font, color system, or other identity-bearing asset cannot be authenticated, stop and ask for an authorized original instead of generating a plausible substitute.

## STEP 2: Build the brand truth sheet

Research or inspect the strongest available sources and summarize the brand truth sheet before creative production:

1. User-provided original exports
2. Official company website, static bundle, newsroom, brand portal, media kit, press kit, or official repository
3. Company-controlled media library
4. Licensed stock or authorized partner kit

Extract:

- Exact logo variants, clear space, and usage constraints
- Official fonts or visible typographic behavior
- Primary, secondary, and dynamic brand colors
- Brand tone, principles, visual motifs, and interaction language
- Current product names, features, scenarios, metrics, slogans, CTA, and disclaimers
- Official photography, renders, UI screenshots, footage, press assets, and media kit material

Do not use logo aggregation sites, search thumbnails, fan recreations, Pinterest reposts, or AI-generated substitutes as identity-bearing sources. Procedural graphics are allowed only as non-representational motion layers: masks, gradients, color fields, grids, glows, particles, trails, typography, verified-data charts, and transition geometry.

## STEP 3: Create a provenance manifest

Record every identity-bearing asset in a compact manifest that can be delivered to the user. The manifest may be a text node or table and should include:

- Stable asset ID and role
- Local path or canvas node reference when available
- Exact source URL or user-provided source note
- Source type, such as official website, media kit, user-provided original, or licensed stock
- Verification target used for comparison
- Rights or publication note
- Authenticity status: verified, user-supplied, licensed, or blocked

The manifest does not grant publication rights by itself. If authorization is unclear, label the video as an unofficial concept and tell the user commercial publication requires permission.

## STEP 4: Choose the story spine

Present 2-3 concise creative directions when the user has not already chosen one, recommend one, and continue after confirmation. Use the product category to pick a spine:

- AI / SaaS: user intent -> thinking or planning -> capabilities -> execution -> useful output -> proof -> logo
- Physical product: hero reveal -> interaction -> feature macro -> usage context -> result -> logo
- Service / company: context -> process -> evidence -> outcome -> promise -> logo
- Image-led brand: authentic imagery -> visual motif -> benefit -> emotional payoff -> logo

Keep the story product-specific. Show actual features, interactions, scenarios, outputs, and proof instead of hiding the story behind abstract effects.

## STEP 5: Plan exact beats

Plan a frame-aware timeline before generation. Use 30fps as the planning convention unless the output pipeline requires otherwise.

For a 15-second film, target 5-8 major beats. For a 30-second film, target 8-12 major beats. Each beat should define:

- Start and end time or frame range
- Visual owner and authentic asset IDs
- Primary action
- Product or brand proof shown in the shot
- Copy and readable hold
- Color state
- Incoming and outgoing transition
- Motion intent: setup, anticipation, commitment, impact, brake, settle

A useful 15-second pattern is: brand hook, user intent or setup, product mechanism, capabilities or scenarios, output or proof, product payoff, final logo and CTA. Use 6-12 frame overlaps when outgoing motion naturally supplies the next shot.

## STEP 6: Direct the motion language

Build intensity with control:

- Let product motion, cursor paths, UI flow, light, scrolling content, object edges, or matched geometry drive transitions
- Use 2-5 deliberate color states tied to meaning
- Keep one primary action per beat; delay secondary layers slightly
- Establish 2-3 high-energy peaks and quieter braking moments
- Preserve readable silhouettes, copy, and logo clear space
- Avoid fake HUDs, arbitrary glass cards, decorative text walls, unverified metrics, and identical easing everywhere

For AI products, include at least one readable chain such as: prompt -> planning -> parallel capabilities -> generated result -> proof. For physical or service products, show cause and effect from user action to concrete outcome.

## STEP 7: Hard confirmation before generation

Before generating any video, image sequence, speech, music, or final edit, stop and show the user the completed pre-production package:

- Provenance manifest or source summary
- Brand truth sheet
- Chosen creative direction
- Exact beat / shot plan
- Visible copy, CTA, narration, and audio plan
- Known authenticity, rights, or placeholder caveats

Use a concise confirmation step before generation. If the user clearly expresses approval or intent to proceed after seeing the pre-production package  for example "confirm", "generate", "go ahead", "continue", or similar  treat it as permission to generate, unless the message also asks for changes. If the user asks to skip the process, still provide a compact source summary, brand truth sheet, and beat plan first, then proceed when they indicate approval. Offer revision choices only when the user's reply is ambiguous or requests changes.

## STEP 8: Produce Design assets

Use Design-native generation and editing only after the hard confirmation gate has passed. Keep each dispatch self-contained with the chosen model, aspect ratio, authentic reference paths, and original request.

Typical production flow:

1. Treat all user-uploaded logos, UI screenshots, packaging, product images, people, mascots, footage, and other brand materials as identity, design, layout, or factual references by default, not as production-ready elements to paste directly into the final film. First assess what each asset should contribute and prepare verified still frames, UI plates, product hero frames, or motion-ready story images that preserve those approved reference contributions.
2. Generate video clips from the prepared frames or precise text prompts, preserving the same ratio and the verified identity, product structure, interface facts, packaging characteristics, people, mascots, and other approved brand signals carried by the references. Do not assume that an uploaded file is suitable for direct compositing merely because it was provided by the user.
3. Default audio policy for native brand reels: when the user asks for BGM, music, soundtrack, ambient sound, or says nothing beyond needing a finished promo video, prefer video-native audio from the selected video model instead of generating a separate music track. For the default MiniMax H3 route, set native audio on (`generate_audio=true`) and prompt for brand-safe instrumental music / UI sound design inside the video prompt.
4. Generate separate speech or music only when the user explicitly needs controllable narration, voiceover, dialogue, replaceable standalone BGM, exact music duration independent of the video, post-production remixing, or when the selected video model cannot generate suitable audio. Do not duplicate a soundtrack between video-native audio and separate audio generation.
5. Assemble clips, any explicitly separate audio, and final brand lockup in editing. Add subtitles only when the user explicitly asks for subtitles.

Use logos, wordmarks, product UI, packaging, mascots, people, and brand scenes as verified reference inputs rather than assuming the uploaded files should be pasted directly into the final film. Generated or prepared production assets must preserve the approved identity, structure, wording, interface facts, packaging characteristics, person or mascot identity, and other defining brand signals from those references. Do not invent, loosely approximate, or replace identity-bearing details. Abstract motion, atmosphere, transition geometry, and clearly conceptual scenes may be newly generated, but they must not impersonate unverified official product evidence.

## STEP 9: Verify before delivery

Before final response, check:

- The logo and identity-bearing assets came from verified or user-authorized sources
- Product names, feature wording, claims, metrics, slogans, and CTA match official sources or are clearly marked as concept copy
- The video duration, aspect ratio, and language match the brief
- Copy is readable and not overcrowded
- The final logo is not stretched, cropped, or rebuilt
- Motion has clear visual ownership and does not obscure the product
- The output is on the canvas and multi-asset outputs are grouped

Pre-delivery verification identifies problems; it does not independently authorize asset replacement, regeneration, or re-editing. If the output fails an authenticity check, first report the questionable asset and specific issue, and propose replacing it with an official or user-authorized source. If no usable source is available, pause the affected work and ask for the asset. Obtain the user's explicit authorization for the repair before replacing assets, regenerating, or re-editing, and follow the scope constraints under Failure recovery below. Never improve an imitation.

## STEP 10: Deliver

Provide:

- Final video path or canvas output
- Duration, aspect ratio, and language
- Short creative summary
- Provenance manifest or source summary
- Rights/disclaimer note when needed
- Specific suggestions for the next iteration, such as pacing, claim clarity, CTA, audio, or platform crop

## Failure recovery

The following are repair proposals, not automatic execution instructions. Explain the specific problem and proposed repair scope, then obtain the user's explicit authorization for that repair before replacing assets, regenerating, or re-editing. Approval of the pre-production package does not automatically authorize repairs after failure. If the user has already explicitly requested the repair, do not ask for the same permission again. Execute only the authorized scope and preserve unaffected acceptable results. If checks still fail after the repair, report the outcome rather than automatically continuing to repair.

- Wrong or approximate logo: report the specific issue and propose removing the incorrect version; locate the current official file or ask for the user's original. Perform any necessary replacement, regeneration, or re-editing only after the user authorizes the repair.
- Fake-looking product/UI: propose replacement with official, user-supplied, or licensed media. After authorization, repair only the affected parts. Do not polish the imitation.
- Beautiful but generic: propose adding a complete product interaction, verified claim, or real output. Execute after the user authorizes the corresponding content change.
- Fast but chaotic: propose reducing simultaneous actions, assigning a visual owner, and preserving matched motion across cuts. Execute after the user authorizes the corresponding changes.
- Smooth but slow: propose shortening holds, overlapping transitions, and braking only around key messages. Execute after the user authorizes the corresponding pacing changes.
- Asset unavailable: ask for an authorized original; never guess. Receiving the original does not by itself authorize regeneration or re-editing. If the user provides it with an explicit request to replace or repair, act within that authorization.
