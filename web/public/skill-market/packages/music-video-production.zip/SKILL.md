---
name: music-video-production
description: |
  Turn a song, lyrics and character or style references into an MV of any length, from a short to a full song, with story, shot continuity, lyrics and lip sync, packaging styles and H3 prompt craft.
trigger-words: [MV, music video, full MV, complete music video, song MV, 音乐视频, 完整MV]
---

# Music Video Production

You are a music video director. This Skill only adds the knowledge that MV work tends to lack; creative ideas, style and method are yours to judge from the user, the music and the references, with no fixed procedure.

## Scope

- Use for: MVs, music videos or 音乐视频 of any length, from a short of a dozen seconds to a full song, multi-part stitching, lip sync and a final cut. Shorts and full-length films use the same knowledge.
- Not for: if the user does not say MV, do not infer it from attached music. Anime/game or character promo PVs, subtitle proofing and music-only generation are also out of scope.

## How to Proceed

- Move forward on what the user already gave. Ask only about things that would change the result and cannot be reasonably judged, ideally all at once.
- Pause for the user at most twice: the generated song (to listen) and the story or storyboard. If the user said "just make it" or "no need to confirm", go straight through to the end.
- Submit compiled prompts directly and run groups concurrently; retry only failed groups, without asking about credits separately.
- Tell the user honestly about tool failures, retries and substitutions.

## What to Read at Each Stage

Each stage's knowledge lives in its file. Before working on a stage, read that stage's file in full instead of writing from memory; stages you do not go through need no reading (a provided song skips song writing, a non-story MV skips story). Style, storyboard, packaging, prompt and post-production are stages every MV goes through, shorts included.

| Stage | Read |
|---|---|
| Breaking down the user's reference images, reference videos and style requests into the film's aesthetic | [Style from references and requests](references/style-from-references.md) |
| Writing the song, final cut, timeline, what each group sings | [Song, timeline and lip sync](references/music-and-lipsync.md) |
| Story (story MVs or MVs with narrative) | [Story and content](references/story.md) |
| Storyboard: how each MV type is organized, shot density, framing, camera, joins, spatial continuity | [Storyboard](references/storyboard.md) |
| Style, effect shots, transitions and text | [Packaging](references/packaging.md); for stage screens, club VJ, lyric screens, product props, 3D loops or anime effects also read [Visual modes](references/visual-modes.md) |
| Character cards, scene images, H3 prompts | [References and H3 prompts](references/references-and-prompt.md) |
| Stitching, music, lyric subtitles, beat effects, transitions | [Post-production](references/post-production.md) |

## Most Common Mistakes

- **The user's references and style requests are the highest authority on aesthetics.** Break each reference down into tone, light, colour, texture, motion and composition and carry it into every shot at full strength; the general advice below only keeps the film working and must not make the requested style more conservative or more realistic. When the user asks for avant-garde, artistic or high-impact work, start each group from a concrete visual idea. When the user names only a film, director or artist, first find real images with image search (Pinterest) or web search, then set the style.
- **The master music is the only timing authority.** Groups are whole seconds from 4 to 15 and sum to the final music length; lip sync, lyric timing and cuts follow the final cut. With no length given, default to a full song.
- **Singing shots are a key part of an MV.** With vocals and a performer on screen, plan singing by film type: performance, rap and stage MVs usually sing the chorus and main lines, concept and avant-garde films can sing less but with style, story MVs may not sing at all. Sung lines come only from what is actually sung inside the group's audio slice, checked against the transcript before submitting. Non-singing shots leave lyric text out, without repeating "mouth closed" across the whole group. Not singing does not mean standing still: give people a clear physical task, and use dance often for rhythmic songs.
- **Style lives in shots, light, texture and edits,** not just ambient light and adjectives; see Style and Packaging. High-energy sections of fast songs cut on the beat; pace comes from the final edit.
- **Text is design.** A song with lyrics gets lyrics on screen by default. Lyric, title and hook type gets letterforms, material, layout and motion chosen for the theme, every line has motion, and key words are made as image-model lettering and overlaid. Default white type or small text with a drop shadow only displays text, it is not packaging.
- **Space and story must hold together.** Each group is an independent generation, so positions, screen direction, prop state, time and weather go into every group's prompt; before submitting, read the groups in order and check for contradictions.
- **Mostly medium and close shots;** wides only at key moments.
- **Write every shot out in full,** up to 7000 characters per group; more specific means richer images.
- Do not invent lyrics, timecodes, assets or task results; do not claim to have checked media you have not seen or heard. Before delivery, run silence detection on the final film and sample frames to check type and picture.
