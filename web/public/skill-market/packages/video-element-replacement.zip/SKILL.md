---
name: video-element-replacement
description: |
  Replace video subjects, backgrounds, products, or props while preserving motion, framing, continuity, and audio. Supports multi-element and cross-species edits; not for subtitles or ordinary editing.

trigger-words: [video element replacement, video subject replacement, replace person in video, replace video background, product replacement video, prop replacement video, cross-species replacement, H3 video editing, video repainting, 视频元素替换, 视频换人, 视频换背景]
---

# Video Element Replacement / 替换万物

## Scope

Use this Skill when a user provides a video and wants one or more visible elements replaced while the original performance and temporal structure remain usable.

Supported cases include:

- **People**: person-to-person, person-to-animal or anthropomorphic character, person-to-CG or anime character, face-only, or full-subject replacement
- **Backgrounds**: rooms, streets, stages, outdoor locations, natural environments, and moving scenes
- **Products or objects**: packaging, devices, vehicles, furniture, props, handheld objects, and other visible items
- **Multiple elements**: people, backgrounds, products, and props replaced together

Do not use it for subtitles, ordinary cutting, color grading, compression, transcoding, or making a still image move.

## STEP 1: Receive and Analyze the Source Video

Analyze duration, aspect ratio, shot structure, cuts, subject count, subject positions, actions, motion paths, camera movement, depth of field, occlusion, contact relationships, and audio content.

Check whether the target persists across shots, exits and re-enters frame, or has similar subjects that could be confused. Preserve the original action, camera, edit rhythm, spatial relationships, dialogue, and ambience by default. If the video exceeds a single generation duration, plan segments by shot or time range and bind the same replacement identity across every segment.

## STEP 2: Confirm Replacement Type and Scope

Use the user's stated target directly. If the target is unclear, ask whether they want to replace a person, background, product/object, or multiple objects. Confirm the scope: the full video, selected shots, selected time ranges, or only part of a multi-object replacement.

Also identify what must remain unchanged, such as action, relationships, framing, background, product interaction, dialogue, ambience, or another explicit requirement. Do not repeat questions that the user has already answered.

## STEP 3: Use Natural Adaptation

All replacement tasks use **natural adaptation** rather than a user-selectable replacement-strength setting.

- Preserve the original main action, camera, composition, timing, spatial relationships, and story meaning.
- Let a new person, animal, toy, robot, cartoon character, product, or object adapt naturally to its own anatomy, scale, structure, material, and viewpoint.
- Preserve the new subject's defining identity and structural traits; do not force incompatible anatomy, proportions, or motion details from the source subject.
- Change action, camera, story, or spatial relationships only when the user explicitly requests it.
- Do not add a confirmation step about replacement strength; ask only for information required to execute the task.

## STEP 4: Evaluate Reference Fit, Difficulty, and Expectations

For each replacement reference, inspect subject count, identity traits, silhouette, viewpoint, pose, clarity, occlusion, and scale difference from the source video. Classify it as:

- **A**: clear subject with a close angle and composition; generally ready to use
- **B**: clear identity and appearance but substantial angle, pose, or scale differences; usable with natural adaptation
- **C**: severe occlusion, insufficient detail, missing key views, or highly complex video motion; recommend more references or a short preview

Also assess expected stability, not just technical feasibility:

- **Low**: one subject, limited motion, little occlusion, close reference angle, simple structure
- **Medium**: visible movement, angle changes, local occlusion, limited viewpoints, or major scale differences
- **High**: multiple subjects, fast choreography, transparent occluders, mutual occlusion, frequent exits and re-entries, major perspective shifts, cross-species conversion, or extreme body differences
- **Very high**: insufficient reference information combined with multiple overlaps, fast motion, complex transparency, strong camera movement, or several replacement targets

Explain what is likely to survive, where artifacts may occur, what they may look like, and whether the result is best treated as a test, creative preview, or release candidate. Never promise perfect or frame-perfect replacement. Record applicable risks such as occlusion, transparency, missing side or back views, anatomy differences, fast motion, small accessories, product lettering, camera movement, or mismatched light, depth, and perspective.

## STEP 5: Bind Reference Roles

Assign every source a clear primary role:

- **Source video**: action, camera, timing, spatial relationships, and sound
- **Person or character image**: identity, face, hair, clothing, body shape, design, and material
- **Background image or video**: new environment, spatial structure, perspective, and world setting
- **Product image**: product identity, shape, structure, material, packaging, and brand information

A person reference does not automatically change the background; a background reference does not automatically change the person; a product reference does not automatically change hand motion. Distinguish multiple subjects individually instead of listing filenames without assignments.

## STEP 6: Establish the Edit and Audio Strategy

The edit brief must state the replacement target, new content, scope, natural-adaptation rule, preserved motion and camera, occlusion and contact relationships, continuity requirements, aspect ratio, duration, and sound treatment.

Use one of these audio strategies:

- **Picture replacement only**: retain original dialogue, ambience, and music
- **Picture replacement with dialogue timing retained**: preserve the original speech timing and adapt the new subject's mouth movement
- **Voice replacement**: only when explicitly requested, with a voice reference or confirmed synthetic voice
- **Mute or ambience only**: only when the user explicitly requests dialogue or music removal

Replacing a person visually does not imply replacing their voice. Do not create or burn subtitles unless requested.

## STEP 7: Cross-Species and Non-Human Subjects

For animals, toys, robots, cartoons, monsters, and other non-human subjects, prioritize their species traits, facial and mouth structure, and body proportions over human anatomy. Preserve the source performance's timing, emotion, and meaning, while redirecting mouth and facial motion to the new subject.

Keep species-specific noses, teeth, whiskers, ears, tails, paws, horns, wings, and other silhouette-defining structures stable across frames. Do not copy human lips, teeth, tongue, jaw, hands, hair, or clothing when those details conflict with the new subject. Adapt the new subject to the source's occlusion, handling, standing, and interview actions.

## STEP 8: Pre-Generation Confirmation and Preview

If the target, references, and required execution facts are already clear, proceed using natural adaptation without asking about replacement strength or reference grade. Use a short preview only when tool limits, very high risk, or an explicit user request makes it appropriate:

1. Generate approximately 4–6 seconds to inspect identity, silhouette, motion adaptation, occlusion, and fusion.
2. After the preview is accepted, generate the full duration using the confirmed references and edit plan.

A preview is not mandatory for ordinary low- or medium-risk work, and a user request for direct generation should not be blocked unnecessarily.

## STEP 9: Generate the Replacement Video

Use the available video editing or multimodal generation capability with the source video as the basis for action, camera, and timing, and each replacement reference as the identity, appearance, environment, or product source it represents.

The generation brief must state what changes and what remains, the role of every reference, the source motion and edit structure, how the new element follows position, scale, movement, occlusion, and contact, how identity stays consistent across shots, and the confirmed audio treatment. Add only execution-critical camera, action, continuity, and sound details; do not invent characters, props, plot, or an unrelated style direction.

## STEP 10: Inspect the Result

Check replacement accuracy: whether the target is fully replaced, whether the original returns in any frames, whether the new element duplicates, deforms, flickers, or drifts, and whether multiple targets are confused.

Check temporal continuity: identity, appearance, cuts, exits and re-entries, turns, fast movement, mouth motion, blinking, head movement, and product motion.

Check spatial fusion: foreground/background integration, occlusion, contact, perspective, scale, depth of field, motion blur, edges, material, and lighting. Confirm that hands, microphones, tables, floors, and other foreground elements occupy the correct layer.

Check audio for duplicate dialogue or tracks, synchronization, retained dialogue/ambience/music, and the absence of unrequested subtitles.

## STEP 11: Targeted Correction and Retry

Do not resubmit the exact same request. Correct only the diagnosed cause:

- identity drift → clearer identity traits, more angles, or stronger continuity
- awkward cross-species mouth → reinforce species mouth structure and natural adaptation
- product deformation → add multi-angle product references and structural constraints
- background errors → clarify silhouette, occlusion boundaries, ground contact, and perspective
- action discontinuity → reinforce source motion path, timing, and handoff
- multi-object confusion → split reference roles and bind each to its target
- multi-shot inconsistency → add per-shot angle, scale, and identity continuity
- duplicate or abnormal audio → retain one dialogue track and restate the sound strategy

Keep the confirmed goal and references. Make limited, cause-specific retries; after repeated failure, explain the cause and ask only for the shortest necessary decision.

## STEP 12: Deliver

Deliver the replacement video and briefly state the replaced elements, preserved source content, output duration and aspect ratio, and any observed minor issues or suggested next step.

When the user requests a revision, reuse the confirmed replacement targets, audio strategy, and references instead of asking again.

## Defaults

- Use MiniMax H3 as the default video model.
- If the user explicitly selects another model, verify its replacement, reference, duration, and framing support before using it. After one cause-specific correction, switch to another compatible model if the selected model still fails instead of repeatedly retrying it.
- Preserve source action, camera, edit rhythm, aspect ratio, duration, and sound by default.
- Do not add subtitles by default.
- One source video produces one replacement video by default.
- If aspect ratio or duration is unspecified, inherit them from the source.
- Cross-species replacement uses natural adaptation.
- Recommend a short preview for high-risk work, but do not force it when the user explicitly requests direct generation.
- Every replacement reference must have a clear role binding.
- References contribute to the replacement and do not override source structure the user explicitly wants preserved.
