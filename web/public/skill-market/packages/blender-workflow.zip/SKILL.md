---
name: blender-workflow
description: |
  Create/edit Blender models and animation from briefs, references or blend files. Deliver editable projects and rendered image/video canvas previews. Excludes concept Q&A and Director Stage.
---

# Blender Modeling, Execution and Deliverables

Follow four stages. Project binding in stage 1 and media-output isolation in stage 2 are prerequisites for production, before modeling knowledge, quality, speed or requests to put results directly on the canvas. Stop dependent production or delivery until the relevant checks pass. Define each constraint in its stage; retries return through stage 3 rather than starting a second workflow.

## When to use

Use when the user asks to create or edit in Blender, requests an editable blend project, or continues the current Blender project. Generic “3D,” “camera move,” “blockout” or “animation” alone does not select Blender over Director Stage or generated media. Style references, source attribution, negations, concept questions and installation-only requests do not trigger production.

## STEP 1: Connect and bind the work

### 1.1 Establish the connection and recover by observed state

Read the scene through the available Blender connection, then inspect the project. On failure, distinguish causes using the host's existing application or connection-state inspection capabilities instead of handing every error to the user. Do not guess connection settings or invent recovery capabilities.

For first use or a missing connector, use this skill's preparation script (`scripts/prepare-connector.mjs`) when local command execution is available: read its help, inspect status, install and enable when needed, then refresh the current conversation's connection capabilities. It reuses the client's registered Blender community connector installer; do not replace another provider chosen by the user or an existing working connection. Complete required system authorization in the client or system UI. Download and authorization waiting are outside the 30-second recovery cycle below. After an unknown outcome, check status before installing again. If the host lacks this entry, use available connector UI or explain the specific gap. Installation does not prove scene access; do not download Blender itself or unrelated plugins.

On Windows, the preparation helper diagnoses a confirmed addon installation failure before requesting manual setup. It can restore the specifically supported missing Windows dependency inside the registered connector package, verify the import and retry installation once. It uses a fixed official release with an integrity check; unsupported runtimes, conflicting existing files and unknown outcomes remain explicit blockers. Do not replace this bounded repair with a global Python installation or an arbitrary download.

Use `scripts/blender-host.mjs` for local application discovery on Windows and macOS, including verified custom installation paths. On macOS, read help, inspect and launch only when needed, then use the trusted plugin's existing controls and read the actual scene. On Windows, use the combined service entry below for launch and connection. Both paths reuse a unique running instance and refuse a new launch when process ownership is unknown or multiple instances exist. Opening Blender alone does not enable the addon or prove scene access.

On Windows, after connector preparation use `scripts/blender-service.mjs`: read `--help`, inspect with `--status`, then use `--start` when the service is disconnected. This entry opens or reuses Blender, enables the installed matching addon for this session, starts its service and verifies an actual scene read. It obtains the registered package from the current Design conversation, or accepts that verified path through `--package`; `--app` selects a verified installation. Allow 120000 ms. It briefly uses Blender's Python Console, so keep the application free of dialogs and concurrent user input. Do not run a separate launch first. macOS continues with the existing host/plugin controls.

The preparation response's `startupSupported: false` does not disable this skill-owned Windows entry. It is not evidence that Windows cannot start the addon. No project is switched, saved or reset, and preferences are not saved globally. Multiple instances, addon identity mismatch, a busy application or an unknown dispatch outcome require inspection of the specific blocker; do not reinstall or replay blindly. After helper success, read the scene again through the current conversation before creative edits.

| Observed state | Recovery action |
|---|---|
| Blender is installed but not running | Tell the user and open the installed application; do not require manual launch or try to start it through its own disconnected internal controls |
| Blender is running but its connection service is stopped | Use an existing recovery entry or available local UI to start the trusted plugin already used for this task or just installed through the preparation flow, without switching plugins or changing unrelated preferences |
| The service is ready but scene reads fail | Use the host's existing reconnection capability; repeated application launches or killing other sessions' processes are not substitutes |
| A project switch or known render is in progress | Allow a short readiness interval and read state again; a timeout does not justify restarting or rerunning production scripts |

Limit one recovery cycle to three checks and 30 seconds of accumulated waiting. This stops unproductive recovery; it is not a deadline for restarting the application or interrupting a render. Take necessary state-dependent actions between checks, retain progress and files, and avoid duplicate instances. Success means an actual scene read, not merely a visible window or ready service.

Only when these actions are unavailable, permissions are insufficient, a plugin is untrusted, or bounded recovery fails, report the observed state, attempted actions and the specific step the user must perform. Prepare connectors through the supported installation flow above; recovery of an existing connection must not arbitrarily change ports, credentials or persistent preferences, or bypass permissions. Acknowledge missing host recovery capabilities instead of claiming success.

For an explicit restart request, protect current work under 1.3, quit normally, confirm the original process ended, reopen and verify scene access. Ask when unsaved content cannot be established; do not force-kill. Sending an open-application request alone is not a restart. A Blender task must not switch to Director because of blockout/camera keywords or a lost connection. If routed incorrectly, report it and stop further production on that route without disturbing other tasks.

### When Blender itself is missing

A failed connection or an empty standard-path scan does not prove Blender is uninstalled. Check the application host, running instances and known custom paths first; if the location remains unknown, ask whether it is installed and request its application path only when needed. An unavailable inspection remains unknown. Reuse a verified installation instead of recommending reinstallation.

When Blender is confirmed missing, explain that the prerequisite is the desktop application. Provide the [official Blender download page](https://www.blender.org/download/) and only the user's OS-specific steps, in their language:

| System | User installation steps |
|---|---|
| Windows | Choose a stable build matching the machine's architecture and the connector's documented support. Run the official installer and follow its prompts. For the official ZIP distribution, extract the entire package to a persistent folder and keep the location of `blender.exe`. See [Windows installation](https://docs.blender.org/manual/en/latest/getting_started/installing/windows.html). |
| macOS | Choose a stable build supporting the actual Mac and OS; the newest build may not support every Mac. Open the DMG, drag `Blender.app` into Applications and complete first-launch prompts. See [macOS installation](https://docs.blender.org/manual/en/latest/getting_started/installing/macos.html). |

Do not merely say “search online and install.” Give the official entry, steps and what comes next. Disclose inaccessible pages or unverified compatibility instead of inventing a download URL or promising support. The user installs the application and handles system prompts; this preparation flow installs only the connector.

Retain the brief, assets, target work and last verified step while installation is pending; pause dependent startup/production instead of repeatedly installing the connector. When the user reports completion or fresh inspection finds the application, recheck its path/version, prepare or reuse the connector, follow the platform's connection steps above and read the scene. Resume after verification without asking for the brief or another “continue.” If discovery still fails, request only the installed path or specific installation error.

### Bounded preparation recovery

Keep the original brief, asset paths, target project and last verified step in the conversation throughout preparation. The preparation helper already rechecks status and retries a confirmed package failure once through the managed installer; it does not retry unknown outcomes or authorization failures. Allow the full time budget documented in its help. Do not wrap it in another retry loop, delete cooldown markers, edit private settings or download a replacement from an unregistered source.

If installation is still running, check status up to three times over at most 30 seconds without starting another installation. If still busy, retain the task and report that preparation is pending; do not call it a failed installation. For an unknown result, inspect status before any further action. Repeated package failure requires diagnosing the client/network/extraction stage, not blindly sending the user to repeat the same installation in Settings. If no supported recovery is available, explain the specific blocker and the smallest required action.

After successful preparation, follow this skill's application connection steps to start the application and read the real project/document/scene, then resume the original task automatically. Do not ask for the brief again or for an “opened” acknowledgement. Never restart an application with unverified unsaved work or replay a creative write whose result is unknown.

### 1.2 Identify the work

- A new conversation defaults to a new work. Bind an existing `.blend` only when the user clearly continues, edits, opens or reuses an identifiable work. Continue a work already bound in the same conversation without recreating it each turn; bind again for an explicit new work.
- Read the absolute project path, unsaved state, scene and object ownership, for example through `bpy.data.filepath` and `bpy.data.is_dirty`; record unnamed files too. A filename, Collection name or shared Design directory is not authorization to reuse work. Ask the user to identify an ambiguous continuation target.
- Track the target path, existing work identifier, previous work's recovery path and current stage in the conversation. Compare a helper-created scene identifier with the helper's output rather than requiring a platform field name. Do not add a separate explanatory canvas node. For mixed works, establish a recovery plan before splitting or deleting anything.

### 1.3 Verify saved work and announce the switch

- Continue the bound work without repeated questions when no switch is needed. Before switching, verify that a supposedly saved and unmodified previous file exists; `is_dirty=False` alone does not prove recovery is possible.
- For unsaved changes, unnamed work or insufficient recovery evidence, save to an authorized persistent location or create a unique recovery copy without overwriting another file. A copy operation such as `save_as_mainfile(copy=True)` does not update the original. Confirm the save result, file existence and required dependencies before switching; stop and ask if the location or permissions are unclear or saving fails.
- Before switching, tell the user the previous work's name, save status, full recovery path and new target path. Distinguish “already saved; no new save needed,” “saved now,” and “recovery copy saved,” and claim only observed results. Describe switching files while preserving the original; do not call it cancelling the previous conversation's task.

### 1.4 Prepare an independent file, switch and verify

Create, switch and model in separate operations, not one long script. For new work, prefer the clean-file helper (`scripts/create_clean_work.py`). Run the same installed Blender version in a separate background process to generate a unique file, then open it normally in the connected instance. The helper rejects foreground execution, an already loaded user project and an existing target; it does not start the connection service.

```text
<Blender executable> --background --factory-startup --disable-autoexec --python-exit-code 1 --python <Skill directory>/scripts/create_clean_work.py -- --output <work directory>/scene.blend --name <work name>
```

Use actual absolute paths and correct host quoting. Record the returned path, scene and work identifier on success. On failure, inspect files and errors, preserve uncertain partial output, and do not reset the current instance as a fallback. Without background execution, use only a verified clean template containing none of the old work; report a blocker if no safe source exists.

For existing work, use the identified file and skip generation. Verify file existence, then open normally with `bpy.ops.wm.open_mainfile(filepath=target_path, load_ui=False, use_scripts=False)`. Do not call `read_factory_settings`, reset preferences or close the user's running application to create a new work. Adding a Collection, hiding old objects, or appending into the old scene before saving under another name does not create an independent project.

In a separate read after opening, verify path, scene, objects and work identifier. A new empty project must contain no old objects; continued work must match its expected identity. If responses disconnect, recover under 1.1 and inspect state instead of blindly opening or generating again. Announce the completed switch and begin production only after verification.

Exit condition: previous content has a recoverable file whose location the user knows, the intended target is open, scene access still works and work identity matches.

## STEP 2: Establish delivery type and output locations

### 2.1 Distinguish source projects, process files and deliverables

Identify the real Design creative-project directory, not the application's source-code repository. Completed creation or revision defaults to an editable `.blend` plus a rendered preview returned to the canvas; the user need not separately request rendering or canvas display. Honor an explicit request to skip rendering or canvas display. Classify the intended result of this task, not unrelated animation data left in an existing file.

| Intended result | Default canvas preview |
|---|---|
| Static model, blockout, scene or still composition | One rendered image, such as PNG or JPEG, showing the finished work |
| Animation, camera movement or simulation whose result changes over time | One finished, playable rendered video covering the intended motion range; prefer MP4 with a supported codec |

Do not add animation to a static modeling task. Do not substitute a still, contact sheet, viewport screen recording or frame directory for a dynamic result's rendered video. The final preview and editable source must represent the same saved work version. Reuse a requested final image or video as its preview; do not render or publish a duplicate. Honor explicitly requested multiple deliverables instead of multiplying final previews by default.

| Type | Storage and display |
|---|---|
| Editable source project | Save at the path bound in stage 1 with required dependencies; it is not an intermediate frame that must be withheld |
| Bulk render frames, unselected internal previews, caches, temporary audio and all unverified images/videos | Create a unique task directory under the system temporary directory, outside the project; render, assemble and validate there without automatic or explicit canvas registration |
| Selected key-stage previews, final canvas preview and requested media or exported models | Validate before delivery to the destination; do not write unverified media into a scanned project directory |

- Resolve the actual process directory and verify it is outside the creative project's asset-scanning scope. Do not share a fixed directory between tasks. A folder name such as `frames/` or `renders/`, or a newly written ignore file, is not proof of isolation. Do not change existing exclusion settings or use application-owned startup-cleaned temporary folders for resumable data.
- Automatically return one representative rendered image from each meaningful visual checkpoint, such as completed modeling or materials/lighting, to the canvas after it passes that stage's checks. Label it “Process preview · <stage>” to distinguish it from the final result; the user need not request it. Do not publish every object check or iteration. Honor an explicit request to skip process previews or canvas display.
- Keep bulk frames, caches and unselected or unverified previews isolated. Clarify delivery form for an entire frame sequence instead of filling the canvas with frames. Writing into the project and later moving, hiding or grouping the frames is not isolation.

### 2.2 Verify actual output settings

- For a static preview, select a representative camera composition when none is specified. Read back the active camera, render frame, dimensions, image format and isolated absolute output path. Render the work itself, not an application-window screenshot.
- Before rendering video, read back the active camera, dimensions, output type, isolated absolute path, full intended frame range and frame rate, and identify the assembly target. PNG/EXR frame sequences need a frame prefix in the isolated directory and separate video assembly. Selecting H.264 or adding an `.mp4` suffix does not establish the correct output type.
- For a video preview that will be returned to the Design canvas, use 24 or 30 fps by default and verify the rendered file's actual average frame rate before publishing. When the preview is intended as a MiniMax H3 reference, the actual average frame rate must be between 23.5 and 60.5 fps; a playable 20 fps file is not H3-compatible and must remain isolated until a compatible render or conversion passes.
- Assemble unverified media only with local media-processing capabilities that explicitly write into the isolated directory without automatic publication. A processing route that automatically publishes outputs to the canvas is unsuitable for this step. If no suitable local assembly capability exists, report the blocker instead of bypassing isolation.

Exit condition: output type matches the real path, and process files will not be scanned or automatically published. Complete these checks before generating previews, rendering or assembling; they do not require another user confirmation. Static modeling needs only an isolated image render; establish video settings if later work adds motion.

## STEP 3: Create and inspect within the bound project

### 3.1 Choose modeling methods as needed

- Before creating or changing geometry, read “方法选择” and “几何约束” in modeling knowledge (`references/modeling-knowledge.md`), then the relevant operation and acceptance sections. The shared reference can be used directly without downloading examples or opening source demo projects. Skip geometry details for camera-only or rendering work on an existing scene.
- Extract primary structure, dimensions/units, cross-sections, thickness, connections, symmetry and repetition from the brief, sketch or reference. Select a method for each main structure. Record unseen backs or internals in a single image as assumptions; do not invent precise measurements.
- Use suitable curves, lofted sections, continuous meshes or modifiers for continuous curves, arcs, arches, rounded forms, curved walls and streamlined shells. Do not default to stacks of cubes. Blockouts may simplify details while retaining defining silhouette and spatial continuity; actual bricks, panels and assembly parts may remain separate.

### 3.2 Work in verifiable stages

- Modify only the bound work. Establish adjustable primary silhouettes before thickness, openings, fillets and detail. Preserve editable curves, profiles and modifiers; retain recovery sources before converting or applying them.
- After each main structure, read actual geometry and inspect silhouette, proportions, continuity, intersections and camera visibility through the viewport or a low-cost preview. Measure evaluated geometry in world space. Validate for display, animation, printing or export as appropriate rather than copying sample polygon counts or node settings.
- Generate and inspect previews in isolation under stage 2. At a meaningful visual checkpoint, verify that the selected image decodes and clearly shows the current stage, then publish it under 4.2 before proceeding to a long final render; do not wait for the final video to show progress. Continue after self-checks; wait for user approval only when requested. Then render the final static image or the full intended animation and assemble its video in isolation. A process preview does not replace the final deliverable.

### 3.3 Recover and resume

- Connection failures return only to 1.1. After recovery, read work identity and actual operation results under 1.2 and 1.4 before resuming. Script errors or timeouts do not mean preceding edits rolled back; do not replay initialization or append duplicate objects.
- For code/API errors with a working connection, inspect current-version capabilities and completed stages, then repair only the missing part of this task. Diagnose geometry using the reference instead of silently reducing continuous forms to stacked blocks. After changing output format, engine or path, repeat stage 2; a compatibility retry must not reset the project or send frames into the project directory.
- Resume automatically when verified progress permits, without repeatedly asking the user to say “continue.” Otherwise explain the blocker and recovery location, preserving the source project and process files.

## STEP 4: Validate and deliver

### 4.1 Validate by artifact type

- Save the work's editable `.blend` and separately export any requested format. Verify file existence, saved state, primary objects and dependencies; provide the path and real limitations. The preview accompanies the source project; neither replaces the other.
- For static work, verify that the actual image decodes, has the intended dimensions and shows the finished work with readable framing, lighting and materials. Select one final image for the canvas.
- For dynamic work, wait for the full intended render and any video assembly to finish. Verify that the actual video decodes and plays, then check dimensions, duration against the frame range and frame rate, and required audio. Inspect beginning, middle and end frames for the intended subject/camera motion and missing or black frames. Return the finished video, not a thumbnail or unfinished preview clip.
- For a video preview returned to the canvas, treat the final file's actual average frame rate as a delivery gate. When it is an H3 reference, accept only 23.5–60.5 fps; a playable 20 fps file still fails the gate and must be re-rendered or converted before delivery.
- Command success, completion markers or filename suffixes are not acceptance evidence. Files named `*.mp4####.png` remain a frame sequence: return to isolated assembly instead of registering a nonexistent MP4. After changing the work, refresh and revalidate the preview so it matches the delivered `.blend`.

### 4.2 Deliver verified files

- After validation, copy or import the selected stage preview or final preview to the requested persistent delivery location and use available media import/display capabilities to return it to the current Design canvas. The node must reference the verified file with the correct image/video type. Do not leave published nodes dependent on temporary render files.
- Confirm that the image is displayed or the video is available for playback on the canvas. A file path or chat attachment alone does not prove canvas delivery. Reuse a node already created by automatic collection. Reuse/update the same stage's node for revisions instead of adding one per iteration; keep its process label distinct from the final result. Do not duplicate the same media or add an extra video-thumbnail node. If publication has an unknown outcome, inspect existing nodes before retrying. Do not rerender merely to register existing verified media.
- On failed rendering, validation or canvas delivery, repair the failed step or report the specific unfinished step while retaining the source and resumable files. Distinguish “rendered” from “returned to canvas”; do not claim completion from only a saved `.blend`, frame sequence or unconfirmed publication. Without confirmed cleanup scope, retain existing nodes, assets, source projects and resumable data.

Completion requires the verified editable source, confirmed delivery locations, and one rendered image for static work or one playable rendered video for dynamic work returned to the canvas, unless the user explicitly waived that preview or display. Report only actual results.
