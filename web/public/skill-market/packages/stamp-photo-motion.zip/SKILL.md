---
name: stamp-photo-motion
description: |
  Restyle a photo, build a split postage-stamp composition, and animate it with a fixed camera while preserving layout and the style boundary. Use for mixed-media collage scenes.
trigger-words: [postage stamp, stamp frame, dual style, picture-in-picture, Korean naive illustration, flat illustration motion, 邮票框, 双风格, 画中画, 韩式稚拙插画]
---

# Stamp Photo Motion

This Skill turns a user-provided photo into a three-step visual workflow: a naive flat illustration restyle, a mixed-style postage-stamp composite, and a fixed-camera motion version where the scene animates but the stamp frame and style split remain stable. It is designed for mixed-media collage scenes that need strong spatial alignment, especially when the same building, horizon, or route line must continue across the stamp border.

## STEP 1: Restyle the Source Photo

Use the user-uploaded photo as the source image and transform it into a Korean naive flat illustration.

### Goals
- Preserve the scene contents and the rough spatial layout.
- Keep the same objects, main structures, and overall composition.
- Convert the photo into a childlike, playful flat illustration style.

### Visual rules
- Use rough, shaky, broken hand-drawn black outlines.
- Remove photographic lighting, shadows, perspective depth, and surface texture.
- Replace all shaded areas with solid flat color fills.
- Simplify objects into rounded geometric shapes.
- Keep the composition readable and cute, with a naive and playful feeling.
- The result should look like a flat illustrated version of the original scene, not a traced photo.

### Output
Produce the restyled image as the visual reference for the next stage.

## STEP 2: Build the Postage Stamp Composite

Use the original user photo as the base image and insert a postage-stamp frame in the center.

### Goals
- Keep the base image outside the stamp frame in its original photo style.
- Put the Step 1 illustration style inside the stamp frame.
- Align the inner and outer scenes so shared buildings, horizon lines, roads, rails, or other major structures match horizontally.

### Visual rules
- The stamp frame must be centered and clearly visible.
- The stamp border should feel like a real perforated postage stamp edge.
- The same scene element that appears inside and outside the stamp should stay horizontally aligned.
- Do not let the two styles blur into one another; maintain a visible style split.
- Keep the outside region faithful to the original photo and the inside region faithful to the illustration style.

### Output
Produce a combined still image with a stable stamp overlay and clearly separated inner/outer visual styles.

## STEP 3: Animate the Composite Image

Use the Step 2 image as the source for motion generation.

### Goals
- Use a fixed camera.
- Animate the scene content naturally.
- Keep the postage-stamp frame static.
- Keep the inside style unchanged.
- Keep the outside style unchanged.
- Let the scene move according to the content of the image: trains may move, small animals may move, leaves may flutter, water may ripple, pedestrians or vehicles may shift slightly.

### Motion rules
- The movement must come from the image content itself, not from arbitrary motion effects.
- If an object crosses the stamp border, both styles must remain visible at the same time.
- Do not deform, drift, or dissolve the stamp frame.
- Do not merge the inner and outer styles into one look.
- Preserve the fixed spatial split while allowing natural scene motion.

### Output
Produce a short animated video where the scene moves but the stamp composition remains locked and visually legible.
