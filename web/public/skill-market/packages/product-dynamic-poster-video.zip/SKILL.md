---
name: product-dynamic-poster-video
description: |
  Turn product photos into faithful commercial posters, four lighting studies, and coherent 10–15-second product ads. For beverage or product campaigns; not unrelated editing or multi-clip films.
trigger-words: [wanwu poster, product poster, product ad, poster to video, four lighting studies, 15-second product video, 万物海报, 产品海报, 产品图转广告, 四种光影, 海报转视频, 15秒广告视频]
exported-by: MiniMax-hub
---

# Wanwu Product Poster and Video

Use this Skill when a user provides one clear product image and wants a commercial poster followed by four controlled lighting variations and a single 10–15-second product advertisement. The product image is the identity source of truth. Keep the supplied package, label, logo, readable text, proportions, material, color identity, closure, and flavor cues unchanged unless the user explicitly requests a redesign.

This is a strict linear workflow. Complete each stage before using its output in the next stage. Preserve the bundled authoritative prompt and preset resources byte-for-byte; do not summarize, translate, reorder, or “improve” them when they are used as source instructions.

## Stage 1: Intake and source check

1. Require one product image with the package silhouette, label, logo, and visible text as clear as possible.
2. Confirm the user-facing choices that materially affect the deliverable: poster aspect ratio, visual style, delivery channel, campaign copy, audience, and any explicit color direction. The poster aspect ratio must be chosen by the user from exactly `9:16`, `3:4`, `4:5`, or `16:9`; do not silently choose one. The advertisement duration must be between 10 and 15 seconds. If the user does not specify a duration, ask them to choose the duration before video generation; do not default silently. If the user specifies a duration within that range, use it exactly and adapt the timeline proportionally. If the requested duration is outside that range, explain the supported range and ask for a valid choice. If the user does not specify a visual style, analyze the uploaded reference content and propose exactly three distinct, reference-grounded style directions with concise descriptions, then wait for the user to choose one before creative generation. After the user chooses, preserve that style choice through all stages. For other unspecified choices, use social-media advertisement, copy derived from the product, audience inferred from the product, and surrounding colors derived from visible product colors.
3. Check the bundled authoritative resources before creative generation. If the integrity check fails, stop and report the affected resource; never continue with approximate or reconstructed source instructions.
4. Treat the source image as the primary evidence for product identity and as the basis for any proposed style directions. Do not invent unreadable label text, hidden package details, legal claims, barcodes, QR codes, or flavor ingredients.

## Stage 2: Poster specification

1. Analyze the product image and the user-selected style direction internally, then produce exactly one structured poster specification using the bundled poster source instructions.
2. The specification must preserve the exact photographed product while describing a dense commercial beverage composition: a product-led hierarchy, dynamic but safe placement, dimensional white campaign typography, a product-derived environmental palette, and physically appropriate beverage effects.
3. Keep campaign typography separate from packaging typography. Do not cover the logo, product name, readable label text, closure, or other identity-critical details.
4. Validate the result against the bundled schema and structural validator. If validation fails, repair syntax or structure only; do not change the source instructions or creative intent. Preserve the known source discrepancy: the prose mentions 12 example fields while the explicit machine-checked structure contains 13 named fields.

## Stage 3: Master poster

1. Use the original product image together with the validated poster specification to create one master poster.
2. Use image-conditioned editing or compositing rather than an independent product render. Build the advertising environment around the supplied product and apply the user-selected style direction.
3. Verify that the same commercial SKU remains recognizable, the package silhouette and label remain intact, exactly one hero product is present by default, and campaign text does not cover critical packaging information.

## Stage 4: Four lighting studies

1. Use the master poster as the sole base image for four separate outputs.
2. Run one preset per generation, in this order: edge/rim light, side key light, overhead key light, and low-angle/bottom key light.
3. Each study changes illumination and shadow behavior while preserving geometry, framing, subject count, package identity, text, material, and composition. Do not combine presets, average them, or turn them into a slideshow.
4. Verify exactly four independent images exist and each derives from the same master poster. If one fails, retry only that study and keep successful studies.

## Stage 5: Video prompt

1. Supply all four lighting studies together as one complementary reference set to the bundled video source instructions.
2. Produce exactly one concise, production-ready English prompt for a coherent commercial whose duration equals the user-confirmed value between 10.0 and 15.0 seconds. It must use the clearest study as the identity anchor, use repeated product details as continuity constraints, and turn lighting differences into a controlled progression rather than morphing between images.
3. Use five phases scaled to the confirmed duration: atmospheric hook, product reveal, energy build, visual climax, and hero resolution. The phase boundaries must add up exactly to the confirmed duration, and the final product lockup must hold sharply for about the last 1.5–2.0 seconds.
4. Include camera continuity, focus behavior, material physics, motivated cause-and-effect motion, lighting continuity, and negative constraints against package deformation, label errors, duplicate products, slideshow behavior, and unstable camera or exposure.

## Stage 6: Final video

1. Generate one video using the user-confirmed duration from 10 to 15 seconds, the four lighting studies, and the validated video prompt.
2. Keep the product as the hero: gentle, trackable product motion; camera and lighting as the main drivers; liquid, ice, fruit, bubbles, and typography as secondary or tertiary motion with readable depth and delayed reactions.
3. Verify duration, product continuity, readable packaging at the climax, a stable final frame, and the absence of simple cross-fades or random image morphing.

## Failure and delivery rules

- Never skip a failed validation gate or substitute a missing authoritative asset.
- Preserve all completed outputs when a later stage fails, and report the exact stopping stage.
- Generate same-stage items in batches where possible: create all four lighting studies together conceptually, then create the one video; do not alternate poster and video generation per preset.
- Deliver the master poster, four named lighting studies, the final 15-second video, and the raw Stage 2 and Stage 5 text outputs when available.
- All outputs stay in the current project workspace; use returned asset paths for downstream work.

Bundled resources are under `references/authoritative/`: the immutable source prompts, four lighting presets, source manifest, poster schema, and validation scripts. The Skill describes creative intent and gates; the runtime maps these actions to the current MiniMax Design capabilities.
