---
name: brand-kinetic-typography-promo
description: Make a 10–30 second kinetic-typography brand promo from selling points and product facts, with selectable motion, colors, assets and music. Code-rendered; not live action or generated video.
trigger-words:
- motion graphics
- MG video
- kinetic typography
- promo video
- product launch animation
- code animation
- 动效视频
- MG动画
- 动态图形
- 品牌动效
- 产品宣传动画
- 代码动效
- Python FFmpeg 视频
---

# Code-Rendered Motion-Graphics Promo

Use when the user gives a brand, theme, selling points or product information and wants a dynamic motion-graphics video (kinetic type, shape morphs, transitions on the beat) made with code rather than AI video generation. Every frame is drawn with Python + Skia and encoded with FFmpeg; music is synthesized in code or supplied. Output is deterministic and re-renderable from one JSON spec.

Bundled engine: `scripts/mgfx.py` (+ `mgfx_core.py`, `mgfx_scenes.py`, `mgfx_recipes.py`, `mgfx_chapters.py`, `mgfx_portfolio.py`, `mgfx_ignite.py`, `mgfx_ideaform.py`, `mgfx_typeform.py`, `mgfx_reelcraft.py`, `mgfx_chrome.py`, `mgfx_audio.py`, `setup.sh`). Read `references/spec-reference.md` before writing a spec, `references/creative-planning.md` before planning, and `references/motion-library.md` to choose motions for the theme. `references/example-spec.json` is a complete working example.

Two user checkpoints: the production plan (copy + scene list), then the storyboard stills. Do not render the full film before both are approved, unless the user explicitly asks to skip.

## Step 0: Prepare the render environment

1. Create a virtual environment in a temporary directory outside the project (not inside the project folder; it is large): `bash scripts/setup.sh <tmp>/mgfx-venv`. Reuse it if it already exists. It installs numpy, skia-python and imageio-ffmpeg; FFmpeg comes bundled, so a system FFmpeg is not required.
2. Work in a temporary working directory. Copy user assets (logo, product images, music) there as local files. If an asset exists only as a project resource, locate its local file in the project workspace; if none can be found, ask the user to attach it.
3. Final deliverables (video, spec, storyboard) are copied into the project workspace and imported into the project canvas.

## Step 1: Intake

Extract from the request; ask only for what is missing and matters:
- **Subject**: brand or theme name, the one-line promise, 3–5 selling points, product facts, offer/date/slogan, CTA.
- **Assets**: logo and product images (transparent PNG floats best; opaque photos are shown in a rounded card). If the user wants a product cut out and a background-removal capability is available, offer it.
- **Facts**: numbers used in `stat` scenes must come from the user. Never invent data, prices, certifications or dates.
- **Language** of on-screen copy (Chinese and English both supported).

## Step 2: Motion recommendations and choices (one question card)

First recommend motions for the theme, following `motion-library.md` §2 (tone profile, industry table, catalog Best-for column) and §2b (presentation format):
- Name the industry and tone you read from the brief, then give **2–3 options** (推荐 / 稳妥 / 大胆). Each option lists style + palette, pace, a scene table (motion name in the user's language, what it shows for this brand, why it fits), what the user must supply (product image, real numbers, logo) and the estimated render time. Do not show module code names to the user.
- Let the user pick an option or swap individual scenes; the choice becomes the scene list in Step 3.

In the same card also settle (with a recommendation based on the brand tone, `creative-planning.md` §4):
- **Motion style**: 冲击快剪 `punch` / 极简瑞士 `swiss` / 科技HUD `hud` / 活泼弹性 `bouncy` (already proposed per option; confirm or change).
- **Palette**: preset `ember` `bauhaus` `cyber` `candy` `mono` `earth`, or brand colors (1–3 hex) which derive a full palette.
- **Format**: 16:9 / 9:16 / 1:1 / 4:5, duration 10–30 s (default 15 s, 16:9, 60 fps).
- **Music**: code-synthesized (free, beat-exact, default) / platform AI music (may cost extra) / user file (rights confirmed) / silent.

If the user is unsure, render quick comparison images (cheap, seconds): `mgfx.py palette --brand ... --out palettes.png` and, after a draft spec exists, `mgfx.py styles spec.json --out styles.png`; import them and let the user pick.

## Step 3: Production plan → checkpoint 1

1. Build the message hierarchy and pick an arc from `creative-planning.md`. Choose scene modules by content: selling points → `kinetic_words`; product image → `product_hero` / `product_glow`; real numbers → `stat`; scenarios or steps → `shape_morph`; energy peak → `rapid_cuts`; close → `end_card`. Or fill narrative slots from `motion-library.md` (catalog roles + tone tags, matching procedure, variety rules). Never replay a whole source reel unless the user asks for that preset. `depth_tunnel` and `ribbon_loop` are opt-in only: use them only when they match the product or brand, never as defaults.
   - Designed chains in `motion-library.md` for a tighter film: R5 idea-to-form (graphic / UI-led creative platforms), R6 type-led (big type carries every beat), R7 reelcraft (fast showreel / showcase cuts: `line_split` → `marquee_swap` → `orbit_morph` → `style_cuts` → `converge_lockup`, plus `split_flap` `slice_type` `outline_echo` for type variety). Lift single links or the whole chain; swap copy, colours and logo.
   - Kinetic type leads; graphic motion only connects scenes. Fit the module to the brand tone (bold sans for sport and energy; avoid styles that clash with the brand, e.g. serif for a tech brand).
2. Write `spec.json`. Lengths are in beats; the sum must equal duration × BPM / 60. Alternate `bg` roles so every cut changes value. Keep big words short (≤8 Chinese characters / ≤12 Latin letters).
   - Rhythm that reads natural: ~1.25–2 s per scene (`format.min_scene`, default 1.0); each scene is burst → hold → fast exit; letters rise out of a mask with overshoot; something always moves in the background; hand-offs are match cuts (`transition: iris` from a point of the outgoing scene, a shape that fills the screen in the next colour, `blinds`). `beats` may be fractional (2.5).
   - Too many ideas for the length? Drop modules — never squeeze them under ~1 s or just speed old scenes up; that reads as rushed, not as new design.
   - Global texture: top-level `fx` overrides the style's post FX, e.g. `{"shake": 24, "rgb": 12, "grain": 7, "vig": 0.35}` for beat shake + RGB split with grain and vignette throughout.
   - Keep letters on their reading line; scrambled-letter effects read as noise.
3. Run `mgfx.py validate spec.json` and fix every ERROR.
4. Save a plan document to the project: concept, style and palette, music choice, and a scene table (time, module, on-screen copy, purpose). Ask the user to confirm or edit copy and order. Apply edits to the spec and re-validate.

## Step 4: Storyboard stills → checkpoint 2

1. `mgfx.py stills spec.json --out storyboard.png` renders one representative frame per scene plus the palette strip (720p, a few seconds).
2. Import the storyboard into the project and ask the user to confirm the look, or request changes (copy, colors, scene swaps, style). Iterate on the spec; re-render stills only for the changes.

## Step 5: Music

- **synth**: nothing to prepare; `audio.mood` = `energetic` / `bright` / `cool`. Drums, bass, pad, whooshes, booms and blips are generated on the exact beat grid and scene cuts.
- **Platform AI music**: generate one instrumental track at the spec BPM, mood matching the style, length ≥ duration + 3 s. The user confirms any cost in the app. Then go to the analysis step below.
- **User / AI file**: `mgfx.py analyze-audio music.mp3` → set `format.bpm` to the measured bpm (re-balance beats so the sum still matches the duration), `audio.mode: "file"`, `audio.path`, `audio.start` = one of `suggested_starts`. SFX layer on top by default (`audio.sfx_gain` 0.5).

## Step 6: Render

1. Optional fast draft: `mgfx.py render spec.json --out draft.mp4 --height 720 --fps 30`.
2. Final: `mgfx.py render spec.json --out <name>.mp4` (1080p60, about 1–3 min for 15 s). It renders frame chunks in parallel, caps bitrate, muxes AAC audio and adds faststart.
3. Technical check only: file exists, duration, resolution and an audio stream (ffprobe-style probe). Do not self-review creative quality; the user reviews.

## Step 7: Deliver and revise

- Import the video, the spec (as the editable source) and the storyboard into one project object for the film. Summarize the style, palette, scene list and music.
- Revisions: edit the spec only (copy, order, beats, colors, style, music) → `validate` → `stills` if the look changes → re-render. Save a revised film as a new version of the same video resource.

## Pitfalls (learned in production)

- **Bitrate explosion**: film grain makes x264 bitrate jump past 100 Mbps (a 15 s file of 200+ MB). The engine caps maxrate; keep it if you write your own encoder call.
- **Parallel contention**: each FFmpeg uses all cores by default; running many workers made a render 3× slower. The engine limits each encoder to 2 threads and uses at most 4 workers.
- **CJK glyphs**: Latin display fonts have no Chinese glyphs. The engine falls back per character to PingFang SC / Hiragino / Noto CJK; `validate` fails if no CJK font exists, so set `fonts.cjk` to a font file on such systems.
- **Storyboard timing**: frames sampled during a transition look broken; `stills` already avoids transition windows. Use the `still` fraction per scene to pick a better moment.
- **Long words** auto-shrink and lose impact; move long copy to `callouts`, `label` or `subtitle`.
- Do not use AI video generation for this skill's output; this skill is code-rendered motion graphics.
