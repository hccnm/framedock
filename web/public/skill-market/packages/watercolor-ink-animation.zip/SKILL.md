---
name: watercolor-ink-animation
description: 'Make watercolor-ink cartoon MP4s drawn in code: shorts, music or lyric videos, GIF loops, samples first. Use for 水彩水墨动画, 手绘动画/MV, 歌词动画. Not for AI image/video generation or 3D.

  '
trigger-words:
- watercolor ink animation
- painted animation
- watercolour cartoon
- lyric video
- 水彩水墨动画
- 水彩动画
- 水墨动画
- 手绘动画
- 手绘 MV
- 歌词动画
- 卡通短片
- 动画样片
- 循环动图
---

# Watercolor Ink Animation

Make short cartoons entirely in code: every frame is painted by p5.js + p5.brush (watercolour fills, boiling ink lines) in headless Chrome and encoded to MP4 with ffmpeg. Use it for animated shorts, music and lyric videos, and seamless GIF loops, starring Clawd or any character drawn with the same tools. No image or video generation model is involved; the look is flat 2D by design.

The method comes from [JohnHeibel/PDoomVideo](https://github.com/JohnHeibel/PDoomVideo) (a 156 s painted music video) and its kit [ClaudeAnimationBase](https://github.com/JohnHeibel/ClaudeAnimationBase) (MIT), bundled here as `template/`. Every frame is a pure function of time `t`: `studio.html` loads the scene files, each shot paints the whole 1920×1080 frame, and `render.mjs` renders contact sheets for review or every frame for the final video.

## STEP 1: Scaffold the project

```bash
bash <skill-dir>/scripts/new_project.sh <project-dir>     # <skill-dir> = the folder holding this file; --keep-demo keeps the example; --help
```

- It checks node / npm / ffmpeg / Chrome first and exits 2 with an install hint for anything missing, then copies the template, unhooks the demo scene and installs packages. If npm or ffmpeg live off PATH, set `NPM="node /path/to/npm-cli.js"` and `FFMPEG_PATH=/path/to/ffmpeg` (`render.mjs` also takes `--ffmpeg=<path>`). Every script answers `--help`.
- **Read `<project-dir>/ANIMATION_GUIDE.md` in full** before designing: it holds the rules, the animation principles and the complete engine / Clawd API. Look at the model sheets `docs/emotions.jpg` and `docs/views.jpg`.
- For a music video or anything longer than ~20 s, also read [references/music-video.md](references/music-video.md).

## STEP 2: Lock the music (when there is a soundtrack)

The picture is cut to the beat, so the music is fixed before any shot is designed; changing it later means re-timing shots.

- **Listen to the mood first.** Before building on a track, have it described section by section (instruments, harmony, anything shrill, droning or eerie). A track can be technically fine and still scare the viewer; a gentle story needs a melodic, consonant score. When the music is generated, ask for melody, instruments and "no drones, no dissonance, no shrill highs" explicitly.
- **Measure, don't trust.** Run `scripts/beat_grid.py` on the actual file: generated music often ignores the requested BPM, and a "feel" of 120 can be a 78.9 BPM track. Use the measured tempo and a measured beat time.
- **Pick the window by energy.** Choose the stretch whose quiet intro, lift, peak and calm ending land where the story needs them, starting on a beat so beats fall on clip time `n·BEAT`.
- If the music changes after shots exist, re-snap shot starts and beat-driven events to the new grid; time-stretch audio only for small differences (≲ 5 %), because larger stretches audibly change the track.
- Details (LRC, lyric timing, clip cutting): [references/music-video.md](references/music-video.md) §1.

## STEP 3: Storyboard before code

- Write `STORYBOARD.md` (format in the guide: logline, world + palette arc, motif, the character's emotion arc, then shots with **reads**: the timed list of what the viewer must understand). Worked example: [references/examples/xiaozhen/](references/examples/xiaozhen/), a 31 s lyric video with storyboard and full scene code.
- Write the **whole film's** storyboard even when only a sample is wanted, and mark the sample stretch as `Sample: a–b s` (usually the drop / climax / payoff, not the opening).
- Show it to the user before building, unless they said to just go ahead or only asked for a sample.

## STEP 4: Build shot by shot

- Set `duration`, `bpm`, `offset` and `audio` in `src/config.js`.
- One IIFE-wrapped file per scene/chapter in `src/scenes/`, ending with `shots([[t0, fn], ...])`; add its `<script>` to `studio.html` in order.
- Block key poses first, check them as stills, then add the motion between them.
- Snap shot starts to beats (`B(n) = n·BEAT`) rather than to round seconds, so a tempo change only needs new beat numbers.

## STEP 5: Render and look, every shot, several times

Motion can't be judged by reading code. From the project dir:

```bash
node render.mjs --sheet=0.1,0.8,1.6,2.4 --cols=4 --w=480 --out=out/check/a.jpg        # key frames
node render.mjs --strip=2.1:2.6 --out=out/check/strip.jpg                             # every frame of a moment
node render.mjs --sheet=2.3 --crop=760,420,500,400 --w=500 --out=out/check/face.jpg   # full-res detail
```

- Look at each image and check it against the guide's review list: event clear? character big enough? reads timed for a first-time viewer? anticipation / follow-through, no snaps? contacts touching? a transition at every seam? no text, no 3D, no pure black/white, no muddy glows? Fix and look again.
- Budget: at least one sheet per shot, a strip per key motion and transition, a crop per story-carrying face.
- When asking for a visual check, state what each time **should** show under the current timeline; stale expectations (after a re-time) produce false alarms.
- A full-frame cut flash reads as a blank frame on a still; keep it to ~0.1 s and use it on purpose.

## STEP 6: Sample first, then the full film

A sample is the most telling stretch of the real film, built in the same project, so the full video reuses everything.

1. Build only the shots covering the sample stretch, checked with at least one contact sheet.
2. Render it: `node render.mjs --sample=a:b` (or `--sample=20` for 0–20 s) → `out/sample.mp4` with the matching slice of `PROJECT.audio`. It prints ms/frame, the full-film render estimate and the shot starts built so far.
3. Report and stop: path, stretch, duration, resolution, the estimate, and which storyboard shots remain. When the user only asked for a sample, deliver it and stop there.
4. When the user wants the full film, stay in the same project and keep the sample's shot code. If the sample becomes the middle of a longer film, export its shot functions and register them shifted (`shot(t − S0)`), with `S0` on a beat; remove the sample's own ending (iris / fade) so the film carries on, and build the new shots around it.

## STEP 7: Render and deliver the video

```bash
node render.mjs --clip --out=out/video.mp4                                 # short videos (≲ 20 s), one worker
node render.mjs --frames && node render.mjs --encode --out=out/video.mp4  # longer ones, resumable
```

- `--encode` muxes `PROJECT.audio` by default (`--audio=x` overrides, `--audio=none` for silent) and warns when it wrote no audio.
- Long renders outlive a tool time limit. Start them fully detached so a timeout doesn't kill Chrome, then poll: `(nohup node render.mjs --frames > out/render.log 2>&1 < /dev/null &)` and `ls out/frames | wc -l`. Frames resume only while project inputs, frame rate and loop settings stay unchanged; edits invalidate cached frames automatically, so rerun `--frames` before encoding. `--workers=N` is faster on a strong GPU but can hit navigation timeouts on laptops.
- **Before reporting, probe the MP4**: duration, size, fps, and that it has an audio stream when there is a soundtrack. A silent delivery is the easiest mistake to miss.
- Report the output, length, ms/frame, what was spot-checked and what was not (the full film is rarely watched frame by frame), and the medium's limits (flat 2D; orbits and dolly zooms are faked with parallax layers).

## The rules that matter most

These are the guide's rules condensed; the guide is authoritative.

1. **Handmade medium.** Only `paint()` / `inkLine()` (p5.brush), never plain p5 `rect` / `ellipse` / `fill`. Flat 2D only: turns go through drawn key views (`turn()`, `spinView()`), never 3D projection. Light via `glow()` (additive), because pigment mixing turns yellow-over-blue green.
2. **No text.** No captions, labels, signs or word bubbles; show it instead. Reactions are painted emotes. The exceptions are karaoke in a lyric video and at most a few big SFX.
3. **Something happens in every shot**: an event, cause → reaction, set-ups that pay off.
4. **Time for the viewer.** List each shot's reads; one read at a time; fast actions, held meanings; lead the eye; the reads set the shot length. This is where generated animation fails most.
5. **Alive.** Nothing is still (idles from `feel()`, drifting cameras, boil); faces change through `emotions()`, never by swapping; the character is big (medium shot u≈20–28, close-up 40–70); everything rides the beat.
6. **Transitions at every seam**, chosen to fit the story (brush wipe, iris / shaped iris, whip pan, match cut, cut on action, camera carry-through).
7. **One piece.** One world, a colour arc, an emotional thread, linked scenes, an ending that rhymes with the opening.

## Engine gotchas

- **Pure functions of `t`.** Frames render in parallel and out of order: no state across frames, no `Math.random()`, no frame-by-frame physics. `hash(i)` for stable randomness, `jit()` for boil.
- **`boilSeed(key)`** before each separate background element or prop, or a moving thing makes everything drawn after it re-boil every frame.
- **Don't name globals after p5's** (`line`, `text`, `color`, `scale`, …): a top-level `function line()` fails with `Cannot redefine property` and the page never becomes ready. Keep helpers inside the scene IIFE.
- **Layering in doorways, windows and screens:** draw what's inside, then paint the surrounding frame back over it.
- A `NaN` in a point list throws `Failed to construct 'OffscreenCanvas'`; guard degenerate geometry.
- Under camera zoom ≳ 2, outline weight scales with zoom, so scale `sw` down in close-ups.
- Cost = number of fills and strokes. Aim for ≤ ~1.5–2.5 s/frame (the log prints ms/frame); prefer fewer, bigger shapes. Without a real GPU, watercolour fills are slow; `--soft-gl` is a last resort.
- macOS: the renderer uses `--use-angle=metal` and finds `/Applications/Google Chrome.app`; otherwise pass `--chrome=<path>`.

## Adapting

- Clawd is the default star, not a requirement. New characters, props and emotions use the same tools (`paint`, `ribbon`, `through`, `glow`) and stay on-model across shots; new emotions go in `EMO` in `src/clawd.js`.
- `src/karaoke.js` adds word-by-word karaoke for lyric videos via `window.overlayHook` in `core.js`.
- `LOOPS.name = t => {...}; LOOPS.name.len = 4;` + `node render.mjs --loop=name --png` makes a seamless loop for GIFs.
- For long videos split across parallel helpers, see [references/music-video.md](references/music-video.md) §4.
