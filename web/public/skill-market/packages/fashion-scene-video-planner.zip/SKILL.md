---
name: fashion-scene-video-planner
description: |
  Plan a repeatable fashion showcase from garment references or a clothing brief, including outfit assets, scenes, storyboards, video, music, and assembly. Use for lookbooks and apparel films.
trigger-words: [fashion showcase, lookbook, apparel workflow, clothing short, fashion video, showcase video]
---

# Fashion Showcase Planner

Use this Skill when the user wants a repeatable fashion showcase workflow rather than a one-off prompt. The workflow turns garment references or clothing concepts into a locked Final_Video_Spec, structured garment analysis, step-by-step outfit confirmation, scene selection, storyboard binding, a six-panel storyboard preview, one complete 30-second fashion short per outfit, matching BGM, and final assembly.

## STEP 0: LOCK THE FINAL SPEC

Create `Final_Video_Spec.md` first and lock these decisions before any downstream generation:

- title / project name
- aspect ratio
- target duration and length intent
- visual tone
- output language
- shooting route: `Runway` or `Lifestyle`

This lock is permanent for the current round. Later steps must not re-decide the route.

### Route lock rule

Choose the route from the garment type and user intent:

- **Runway**: couture, formalwear, conceptual fashion, strong show language, restrained pose, controlled expression
- **Lifestyle**: casualwear, streetwear, daily outfits, warmwear, ethnic/traditional looks, natural interaction

If the route is ambiguous, resolve it here. Do not postpone this judgment to later stages.

## STEP 1: ANALYZE GARMENT ASSETS

If the user provides garment images or reference video, extract and record structured information for later storyboard and motion planning:

- silhouette: collar, sleeve, hem, trouser or skirt shape
- fabric: texture, sheen, transparency, weight, drape
- color: dominant color, secondary color, pattern hue/saturation
- motion physics: how the fabric falls, swings, or resists movement

Write the analysis in a compact structured form so later steps can reuse it without reinterpretation.

## STEP 2: CONFIRM THE OUTFIT IN STAGES

Proceed one substep at a time. After each substep, stop and wait for explicit user confirmation before continuing.

### STEP 2A: Generate the technical garment sheet

Create a horizontal three-panel technical garment sheet with front / side / back views only. Use NanoBanana Pro at 2K for this step unless the user explicitly requests another image model.

Rules:
- no model
- no background scene
- pure garment structure display
- emphasize seams, closures, pattern layout, and construction details
- use the garment analysis from STEP 1 as the visual anchor

Then pause and wait for the user to reply with confirmation or revision requests.

### STEP 2B: Generate the model outfit card

Only after the garment sheet is confirmed, generate a model outfit card based on it. Use NanoBanana Pro at 2K for this step unless the user explicitly requests another image model.

Rules:
- horizontal layout
- left panel: face close-up / upper body portrait for identity and makeup read
- right panel: full-body front / side / back views wearing the garment
- preserve fabric physics and garment drape
- keep the background neutral

For multiple outfits or multiple characters, generate one card per outfit in A/B/C order.

Then pause and wait for the user to confirm the model look and fabric fidelity.

### STEP 2C: Present scene candidates in text only

After the model card is confirmed, present 3 scene candidate directions in plain text. Do not generate an image here.

Each candidate should include:
- scene type
- atmosphere
- recommended lighting direction / color temperature
- why it fits the garment and route

If the user already specified a scene, follow that direction directly instead of offering candidates.

Then pause and wait for the user to choose a candidate or provide a custom scene direction.

### STEP 2D: Generate the empty scene image

After the scene direction is confirmed, generate one empty scene image for each scene. Use NanoBanana Pro at 2K for this step unless the user explicitly requests another image model.

Rules:
- no people
- no garments
- environment only
- horizontal wide framing
- preserve lighting, depth, and negative space needs

For multiple scenes, generate one anchor image per scene.

Then pause and wait for the user to confirm the scene look and lighting before entering storyboarding.

## STEP 3: DESIGN THE STORYBOARD AND BIND ASSETS

### STEP 3A: Declare the storyboarding contract

Write the key elements and shot list before any preview image is generated.

Key elements must include:
- element character: facial traits, skin tone, makeup style, hair, and other visible identity details that must match the model card
- element garment: silhouette, fabric, sheen, weight, key construction details, trims, patterns, or special textures
- element scene: confirmed spatial structure, light direction, color temperature, contrast, and negative space logic
- element props: any accessory or prop that materially affects the image

Also define the shot list, including shot size strategy, motion type, and audio layer needs.

### STEP 3B: Register and bind the assets

Before preview storyboards are generated, bind the confirmed model card and scene image assets to the storyboard elements.

Rules:
- bind the model outfit card to `element character`
- bind each empty scene image to the corresponding `element scene`
- do not proceed until the binding is complete

### STEP 3C: Generate the six-panel storyboard preview

Using the bound character and scene assets, generate a single six-panel cinematic storyboard preview. Use NanoBanana Pro at 2K for this step unless the user explicitly requests another image model.

Rules:
- vertical 9:16 composition
- 3 rows x 2 columns
- each panel represents one core shot beat
- keep all panels consistent with the locked character, garment, and scene
- use filmic tone and clear shot progression

Then pause and wait for the user to confirm composition, scene pairing, and shot rhythm.

## STEP 4: GENERATE THE VIDEO

After the six-panel storyboard is confirmed, generate one complete 30-second fashion short. Use MiniMax H3 as the default video model unless the user explicitly requests another video model.

Rules:
- use the six-panel preview as the main reference
- reuse the bound garment, character, and scene assets as continuity anchors
- do not split the video into separate shot-by-shot generation tasks unless the user explicitly requests that later
- one outfit set produces one independent video unit

### Outfit round rule

One round equals one outfit + one scene + one storyboard + one 30-second video.

If the user later changes the scene, restart from STEP 2C and keep the existing outfit card when it still fits.
If the user later changes the outfit, restart from STEP 2A and redo the full pipeline.

## STEP 5: GENERATE BGM AND ASSEMBLE

Generate BGM that matches the garment style and route.

- Runway: chamber jazz, orchestral strings, or similarly controlled high-fashion scoring
- Lifestyle: nu-jazz, lo-fi hip-hop, or similarly relaxed daily-life scoring
- traditional / ethnic looks: contemporary arrangement with ethnic instrumentation
- concept / technical looks: industrial, minimal, or dark ambient textures when suitable

Then assemble the video with the approved music and any other final elements.

## STEP 6: RETURN THE RESULT AND ASK FOR THE NEXT ROUND

Deliver the final assets clearly by round and outfit name. After each completed round, ask whether the user wants to change the scene or change the outfit for the next round.

## CONSISTENCY RULES

- Never re-decide Runway vs Lifestyle after STEP 0.
- Never generate the storyboard before the model card and scene binding are complete.
- Never skip the user confirmation pauses after STEP 2A, STEP 2B, STEP 2D, and STEP 3C.
- Keep all references within the same outfit round isolated from other outfits.
- If multiple outfits exist, process them as separate rounds and combine only at the assembly stage if the user asks for a merged final.
