---
name: digital-drawing-timelapse
description: Generate a 15-second digital drawing timelapse from one prompt and one finished-artwork image. Use MiniMax-H3 by default; check explicitly selected alternatives first.
trigger-words: [digital drawing timelapse, speedpaint video, drawing process video, 手绘过程, 手绘延时摄影, 绘画过程视频, 数字绘画过程]
---

# Digital Drawing Timelapse

Generate one 15-second character-creation timelapse using one finished character or digital-art reference image and the fixed default prompt stored in this Skill. Use MiniMax-H3 by default; if the user explicitly selects another model, check its capabilities first and follow that choice when compatible. If generation fails, retry once for the diagnosed cause, then switch to another compatible available model rather than repeatedly forcing the same model.

The fixed default prompt is the complete English prompt in STEP 3. Whenever the user invokes `/digital-drawing-timelapse` with one image and does not provide a replacement prompt, use that prompt automatically and unchanged. The same prompt remains the default for every subsequent generation and must not vary with generation count, previous results, or session history.

The user may explicitly provide a different complete video prompt to override the default for that invocation only. A replacement prompt must never modify the stored default prompt.

Before every video generation, show a card-style popup asking the user to choose and confirm the output resolution, aspect ratio, and audio treatment. These are execution settings, not edits to the fixed prompt. If an audio file is attached, include it as an option in the same card and ask whether to use it as the soundtrack. Do not start generation until the user submits the card confirmation. If the user declines audio, generate without an audio track.

This Skill is a direct generation path. Do not inspect, attach, or use an original process video, interface screenshot, secondary style reference, storyboard, script, audio, or other creative asset. Do not add interface reconstruction rules, software-layout requirements, thumbnail restrictions, cursor-shape changes, camera changes, audio instructions, or other creative constraints that are not present in the user’s prompt.

The reference image is not an opening frame. It is used only to guide the final character’s appearance, proportions, clothing, hairstyle, colors, distinctive features, and other traits explicitly requested by the prompt. The generated video must follow the user’s prompt as closely as the selected video capability allows.

## STEP 1: Accept the Image and Resolve the Prompt

Require one finished-artwork reference image.

Use the first supplied image as the image reference. Do not reinterpret another asset as a layout or style reference. If the image is missing, ask for it instead of inventing one.

Prompt resolution is deterministic:

- If the user invokes `/digital-drawing-timelapse` with an image and no replacement prompt, automatically use the complete fixed prompt in STEP 3.
- Use the fixed prompt byte-for-byte in meaning on every generation. Never rewrite, shorten, expand, reorder, or add constraints to it.
- Do not inherit prompt changes from earlier generations, previous results, attached process videos, interface screenshots, or session history.
- Only an explicitly supplied new complete prompt overrides the default for the current invocation; it does not update the stored default.

The reference image is used only as the final visual target described by the fixed prompt or the user’s explicit replacement prompt.

## STEP 2: Confirm Execution Settings

Before starting video generation, show one card-style confirmation popup with selectable options for:

- Output resolution, with no preselected default
- Output aspect ratio, with 16:9 offered as a suggestion but requiring confirmation
- Audio treatment: no audio or synthesize audio
- If audio synthesis is selected and an audio attachment is available, whether to use that attached audio as the soundtrack

The card must have an explicit confirmation action. Use the fixed prompt unchanged while applying the confirmed execution settings. Do not start video generation before the user confirms the card. Do not ask the user to confirm the prompt again when it is the stored default. If the user dismisses, edits, or leaves any required choice unresolved, wait and do not generate.

## STEP 3: Generate Directly

Generate one video directly from the resolved prompt and the single reference image.

When no replacement prompt is supplied, the resolved prompt is the fixed STEP 3 prompt. Do not perform a separate interface-analysis stage, use a process-video reference, add the Skill’s previous interface rules, or add or remove any creative instruction. The default prompt must remain identical across repeated generations.

If an explicit replacement prompt is supplied, use that prompt for the current invocation only and do not alter the fixed default. Preserve any duration, aspect ratio, resolution, audio, camera, interface, cursor behavior, timing, style, or constraints stated in the active prompt. If the active prompt does not specify output aspect ratio, use 16:9. If it does not specify audio, leave audio off.

Use the supplied finished artwork as a reference input, not as a first-frame keyframe. The prompt remains the primary instruction for the process, interface, motion, camera, and final presentation.

## STEP 4: Internal Prompt Template

The following English prompt is the immutable default generation prompt. Use it automatically whenever the user invokes `/digital-drawing-timelapse` with one image and no replacement prompt. Do not append, remove, rewrite, or reorder any instruction. It remains unchanged across all generation counts and repeated invocations. Only an explicit replacement prompt may be used instead for one invocation.

```text
Create a 15-second fast-paced character creation timelapse inside a professional digital drawing and character design interface.

Use the provided character reference only as the final target for the character’s appearance, proportions, clothing, hairstyle, colors and distinctive features. The process must visibly start from a completely blank canvas and reconstruct the referenced character from scratch.

Show a visible mouse cursor actively controlling the entire creation process. Every major visual change should feel caused by cursor interaction with the UI.

0:00-0:02
Start on a blank white or neutral canvas inside a clean professional drawing interface. The cursor quickly creates the first loose construction lines, head shape, body proportions and basic pose using rough sketch strokes.

0:02-0:05
Accelerate into detailed sketching. The cursor rapidly defines the face, hair, anatomy, clothing silhouette, accessories and characteristic features of the referenced character. Use believable drawing gestures, short strokes, selections, transforms and occasional undo corrections.

0:05-0:08
The rough sketch becomes clean line art. The cursor switches tools, adjusts brush size and cleans the silhouette. Unnecessary construction lines disappear while precise facial details, clothing folds and small design elements are added.

0:08-0:11
Rapid coloring phase. The cursor selects regions and fills the character with the correct colors from the reference. Show quick palette selections, color picking, layer changes, clipping masks and brush passes. Add shadows, highlights and material details in fast succession.

0:11-0:13
Rendering and polish. The cursor adds final lighting, hair detail, skin shading, fabric texture, reflections and small accent details. Briefly zoom into important areas such as the face or costume while refining them, then zoom back out.

0:13-0:15
The interface clears unnecessary guides and panels. The finished character is shown fully rendered and closely matching the provided reference. End with the cursor making one final small adjustment, then stop on a clean full-character presentation.

STYLE:
High-speed digital art timelapse, polished professional character-design workflow, believable drawing software UI, smooth cursor movement, rapid but readable actions, clean layers and tool changes, no random text, no fake dialogue, no unrelated popups.

MOTION:
The entire 15 seconds should feel continuously productive. Avoid long pauses. Compress several minutes or hours of drawing into an energetic timelapse while keeping the progression clearly readable: blank canvas → rough sketch → clean line art → flat colors → shading → polished final character.

CAMERA:
Primarily screen-recording style with subtle digital zooms and pans following the cursor and active drawing area. Keep the UI stable and readable. Do not use cinematic cuts outside the software interface.

IMPORTANT:
The character must not appear instantly or through a single magical transformation. Every stage should visibly build upon the previous one through cursor-driven drawing, editing, coloring and rendering actions.
```

## STEP 5: Audio and Output Rules

Return one generated video and its exact output filename. Do not create a separate plan document, storyboard, interface reference, subtitle file, or additional image unless the user separately requests it.

Keep the confirmed duration, resolution, and aspect ratio. Use 15 seconds and 16:9 only as defaults for this template. Resolution has no default and must always be explicitly selected and confirmed before generation. Audio is off by default, but a user-confirmed attached audio file may be synthesized or composited as the soundtrack. Never use an attached audio file without explicit confirmation. Audio selection must not modify the fixed default prompt.

If generation fails, retry only with a substantive correction required by the reported error, while preserving the user’s prompt and reference image. Do not add creative constraints merely to force a retry.
