---
name: director-stage
description: |
  Create or revise editable 3D previz in Director Stage (导演台/3D 导演台) from briefs or references: blocking, poses, cameras and shot captures. Not Blender projects, flat storyboards or finished films.
---

# Director Stage

Develop a readable 3D rehearsal from a scene brief, shot list, reference image, or existing Director Stage scene. Deliver editable staging, the requested camera/action timeline, and inspected shot references. This is previsualization, not a promise of final-quality rendering or a finished film.

## STEP 1: Establish the destination and scene

- Use when the user asks to work in Director Stage (导演台 / 3D 导演台), continues the current scene there, or requests editable blocking and camera rehearsal in it. “Storyboard,” “camera,” “3D” or “animation” alone does not select this workflow. Style references, source attribution, negations or questions about the application are not scene-editing requests.
- Preserve the chosen application and deliverable: Blender projects, Photoshop documents, and After Effects compositions stay in their respective applications. Flat storyboard images, video prompts, and generated films do not require a Director Stage scene. A connection failure is not permission to switch applications.
- If the destination is unspecified and a 3D scene versus flat images would materially change the work, ask which deliverable is wanted. Reuse a clear choice from the conversation.
- Establish actual access to the intended scene and its current contents before editing. If the editor or required capability is unavailable, explain the specific missing prerequisite; do not claim a text plan is an edited scene. Continue independent planning only as planning.
- For existing work, bind the intended scene and preserve unrelated objects, cameras, and timing. A request for a new scene does not authorize clearing an existing one. Ask only when the target or a consequential creative choice remains ambiguous.

Record the dramatic beat, primary subjects, spatial relationships, desired shots, and any duration or aspect constraints. Use supplied references for visible evidence; identify hidden geometry and missing information as assumptions.

## STEP 2: Block the scene before detail

Read [blocking and composition](references/blocking.md) for spatial relationships and contact. Establish environment, major masses, foreground objects, characters, and cameras in that order. Use named objects and preserve their identity during corrections.

Keep characters poseable. Use a catalog object only when it represents the requested object. Abstract masses can suggest distant architecture, but a recognizable foreground object needs a coherent editable model rather than unrelated props assembled as a substitute.

For a custom object, read [object construction](references/object-construction.md). Supporting props need readable silhouette, proportions, and contact. A complex close-up or reference-matched object needs a part-layout plan, a verified blockout, and refinement in place; decoration must not conceal a layout failure.

Exit with a readable static scene: correct facing, grounded feet or seat contact, distinct silhouettes, and an identifiable place rather than an empty background.

## STEP 3: Rehearse camera and action

Read [camera language](references/camera-language.md) when designing shots and [motion craft](references/motion-craft.md) when designing acting.

Define what each move reveals before placing its path. Coordinate subject movement, gesture, and camera timing around the same beat. Reuse a suitable motion before creating a custom one. Update existing paths and actions in place so their timeline associations remain intact; remove only superseded material belonging to this request.

Use the editor's current capability documentation for its exact controls and syntax. The creative plan does not authorize invented controls, unsupported exports, or a switch to another production environment.

Exit with an intentional sequence, no accidental clip overlap, a readable arrival facing, and an ending that holds the requested final beat. If timing is outside scope, retain the static scene rather than adding animation.

## STEP 4: Inspect and correct

Read [visual verification](references/visual-verification.md). Verify scene structure, then capture and actually inspect the rendered scene. Check silhouette, proportions and contact, interaction, framing, depth, and the requested dramatic beat in that order.

When the timeline changes, inspect ordered samples at the start, middle, end, cuts, and gaps. Review adjacent moments together for sliding, occlusion, or sudden pose changes; inspect full-resolution frames for uncertain small details. Sampled frames do not prove all intervening motion is correct; preview playback when available and report the extent of inspection.

Correct the highest-impact visible mismatch first. Usually allow one focused scene correction; a complex hero object may need about three blockout and three refinement iterations. These are defaults, not permission to continue indefinitely: use the user's budget and stop with explicit remaining mismatches when it is exhausted. Structural failure returns to layout; material or detail failure is corrected in place.

## STEP 5: Deliver the rehearsal

- Retain the editable scene and report the cameras, poses, paths, or timing changed.
- Provide only shot captures or exports actually produced, using their real locations in the current project. Verify persistence before calling the scene saved; if saving or export is unavailable, say so.
- Explain how to view the intended camera or preview the timeline using the available editor controls.
- Distinguish captured, visually inspected, and playback-reviewed evidence. List remaining mismatches, hidden geometry assumptions, or capability limits.
- Further image/video production or a move to another application is a separate requested step. Carry the scene's shot references forward without presenting them as final film footage.
