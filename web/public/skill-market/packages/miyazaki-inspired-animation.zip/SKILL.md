---
name: miyazaki-inspired-animation
description: |
  Create original warm hand-drawn shorts from stories or references, with watercolor settings, cel-like depth, and natural motion. Covers planning to review; never copies recognizable existing assets.
trigger-words: [miyazaki, ghibli, miyazaki-inspired animation, hand-drawn fantasy short, original anime short, 宫崎骏, 吉卜力, 手绘奇幻动画, 森林飞行, 原创动画短片]
---

# Miyazaki-Inspired Animation

Use this Skill for a complete original hand-drawn animation workflow, from premise or script to an approved final video. Preserve the user's story intent first; the base visual language is a default treatment, not permission to override explicit creative direction. All creative gates use choice cards. Do not replace an approval card with a plain “reply continue” request.

## Boundary and originality

The Skill may use portable qualities such as hand-drawn linework, watercolor or gouache environments, cel-like layering, natural motion, lived-in fantasy, quiet wonder, travel, and emotional growth. It must not reproduce recognizable characters, signature costumes, exact vehicles, named locations, religious structures, logos, written signs, or iconic compositions from an existing work. If the user requests direct imitation, preserve the emotional intention and rebuild the character, world, scene, and composition as original.

## Base visual language and direction variants

Unless explicitly overridden, use original hand-drawn animation with the following base language. Do not force fantasy elements when the selected direction is everyday, realistic, or nature-observation:

- clean warm dark-gray or dark-brown linework for characters and man-made objects;
- flat cel-like color blocks with restrained shadows, not glossy 3D rendering;
- watercolor or gouache backgrounds with paper grain, pigment overlap, wet edges, and dry-brush texture;
- clear foreground, subject, and background depth, with natural elements using softer edges;
- ordinary lived-in spaces, nature, weather, travel, small acts of care, and—only when selected—forests, clouds, flight, oversized plants, magical light, or animated machines;
- readable silhouettes, simple facial construction, block-based hair, practical clothing, and controlled expression;
- asynchronous motion in hair, cloth, leaves, grass, clouds, smoke, water, hanging objects, and machine indicators;
- believable weight, inertia, wind direction, contact, balance, delayed follow-through, and small rebounds;
- warm curiosity, tenderness, quiet observation, travel, growth, and hopeful change rather than spectacle without feeling.

When the user gives no clear direction, present a direction choice card with these options:

1. **Everyday healing** — a small domestic or neighborhood moment, subtle emotion, minimal fantasy.
2. **Nature observation** — a child or ordinary person notices weather, plants, animals, water, or seasonal change; the environment carries the wonder.
3. **Coming-of-age journey** — a simple errand or short trip becomes a visible step toward courage, independence, or letting go.
4. **Gentle original fantasy** — an original magical being or rule enters an otherwise lived-in world, with wonder serving an emotional change.
5. **Poetic mechanical world** — a handmade machine, workshop, train, airship, or wind-powered object expresses care, memory, or connection without copying a known vehicle or setting.

The user may also choose **visual-led short**: a complete short built around atmosphere, gestures, and a simple emotional turn, with little or no plot. This is still a finished animated short, not a single clip or prompt-only output.

The default generated segment is 10 seconds. Use 15 seconds only when one complete action, reveal, flight passage, or emotional beat cannot resolve naturally in 10 seconds. Explicit user duration overrides this default.

## STEP 0: Direction intake, scope, and production lock

If the user has already provided a clear production direction, expand that direction directly into the premise and production plan; do not ask them to choose a competing direction. If the direction is ambiguous, present the direction choice card above as guidance before asking for detailed premise questions. After the direction is clear, capture only the information already available:

- final deliverable: complete short, concept trailer, scene clip, poster, or blueprint;
- premise, script, source document, or reference assets;
- total duration and aspect ratio when provided;
- whether the result needs dialogue, narration, natural sound, BGM, or silent visual storytelling;
- any explicit audience, language, platform, style override, or required text;
- selected direction variant and whether the short is plot-led or visual-led.

If the primary deliverable is unclear, ask one routing question before planning. If it is clear but production choices are missing, do not block routing; establish them during the relevant stage.

Before expensive generation, confirm these project locks with a choice card:

- aspect ratio;
- total duration;
- audio mode: `silent_visual`, `natural_soundscape`, `dialogue_led`, `narration_led`, or `mixed`;
- whether subtitles are required. Subtitles are off unless explicitly requested.

Create a Project Brief containing the premise, emotional promise, audience feeling, deliverables, locked format, audio mode, language if confirmed, visual direction, originality boundary, and initial risks.

## STEP 1: Story direction, premise, and outline

Translate the selected direction into a compact premise before designing assets. For everyday healing or visual-led shorts, the conflict may be a hesitation, missed connection, small repair, seasonal change, or act of care; do not invent a large villain or fantasy quest just to fill the structure. Then create a Story Outline. It must contain:

- protagonist want, need, flaw, and visible growth;
- world rule: natural, magical, mechanical, or social;
- central emotional question;
- 4–8 causal beats appropriate to the selected direction: ordinary state, noticing or disturbance, attempt, emotional turn, active choice, and payoff or departure; include a rule-revealed beat only when the world has a natural, magical, mechanical, or social rule;
- emotional anchor introduced early and re-used at the ending;
- visual motifs and their narrative function;
- audio-spine map for every beat: silent, natural sound, dialogue, narration, BGM, or mixed;
- dialogue or narration draft when selected, with speaker, intent, timing, and language;
- red-line checks: the protagonist drives the story, conflict grows from the flaw, coincidence does not solve the problem, the ending pays off an earlier anchor, and the visual wonder serves an emotional change.

Show a story-direction choice card:

- approve story and continue;
- revise premise or protagonist;
- revise world rule or conflict;
- revise emotional arc;
- revise audio spine or dialogue;
- return to intake.

Do not generate final video before this direction is approved.

## STEP 2: Character, scene, and prop anchors

Generate reusable assets in production order:

1. protagonist character anchor;
2. other principal character anchors;
3. major location scene anchors;
4. prop, vehicle, creature, or machine anchors when they affect story action;
5. optional relationship or scale sheet when multiple identities must remain distinct.

Character anchors lock silhouette, body proportion, face construction, hair masses, clothing structure, core props, expression tendency, material feel, and motion logic. Include front, side, back, and a readable 3/4 view when the character recurs. Include neutral and key emotional expressions; for dialogue-led work include a closed-mouth and speaking reference.

Scene anchors are environment-only whenever possible. Lock spatial landmarks, foreground/middle/background layers, time of day, weather, light direction, emotional sub-spaces, and important environment props. Do not let temporary people or silhouettes become part of the scene identity.

Prop and machine anchors lock purpose, scale, contact points, moving parts, force and inertia, initial state, changed state, and the shots in which each state appears. Every important object must serve a story function.

For any asset with doors, hatches, windows, joints, seats, handles, walkways, landing gear, or other contact interfaces, draw or describe the exact geometry before video generation. Record which side the camera sees, which direction the object faces, where the opening is, its opening path, the permitted contact points, and any structures that must not be invented. Do not infer a step, platform, cargo bay, or opening that is absent from the approved asset. If a character must climb, step, lean, enter, exit, hand off, or operate the asset, encode the full contact sequence and body-weight transfer in the anchor and affected shots.

Show an anchor approval card:

- lock all anchors;
- regenerate protagonist or another character;
- regenerate a scene;
- regenerate a prop or machine;
- adjust a specific visible trait;
- add a required anchor.

Changing a locked anchor may invalidate only the dependent shot-table rows, storyboards, clips, and assembly; identify the affected suffix instead of remaking unrelated work.

## STEP 3: Motion, continuity, and Shot Table

Do not create a separate motion-test stage by default. For ordinary short-film actions, write the complete action chain, contact order, weight transfer, follow-through, and inherited end state directly into the affected formal shot prompts and Shot Table rows. Use a separate test only when a motion interface is unusually high-risk—such as complex multi-character contact, flight or landing, difficult entry/exit geometry, or intricate handoff—and only with user approval when it adds meaningful cost. Repair the smallest failing layer first: prompt and motion direction, then prop or scene anchor, then character anchor only when identity is wrong.

Create one authoritative Shot Table. Embed the required motion and physics rules directly in each affected shot rather than creating a separate test stage. Each row is one final video segment or one deliberately split sub-shot and contains:

- Shot ID and duration;
- dramatic beat and emotional start/end state;
- framing, camera position, and camera movement;
- subject, action, and the single primary dramatic beat;
- foreground, subject, and background structure;
- reference anchors for character, scene, and prop;
- per-second action and environment directives;
- audio track, exact dialogue or narration, and mouth state when applicable;
- audio mode for the row;
- continuity handoff: where each character or object ends and starts, what is held, what changed, and the bridge beat connecting shots;
- exact spatial continuity: camera side, subject facing direction, vehicle/object orientation, door or interface position, permitted contact path, and the next-frame starting state;
- performance map: for every line or important gesture, body orientation, eye target, hand action, facial expression before/during/after, speaking order, and reaction beat;
- space anchor, exit state, light inheritance, timeline, weather, color-tone label, and protagonist-versus-supporting intensity;
- weak-frame or strong-frame choice when frame alignment matters;
- transition intention and generation-risk note;
- a reason for using 10 or 15 seconds.

Rules:

- one row carries one primary dramatic beat;
- dialogue-led rows have one speaking character per rendered clip; use speaker shot, reaction shot, and next-speaker shot when needed;
- silent visual rows keep mouths closed unless a non-verbal expression requires a tiny natural movement;
- narration-led rows keep on-screen mouth movement out unless explicitly requested;
- never skip a reach, turn, step, look, handoff, or emotional bridge needed by the next shot;
- consecutive shots preserve camera side, screen direction, subject orientation, spatial scale, object state, and character action state unless a motivated transition explicitly changes them;
- spoken lines specify who is looking at whom, what the speaker is doing, the expression during the line, and the action after the line; characters do not speak while facing an unrelated direction unless intentionally requested;
- background motion is designed in foreground, middle ground, and background layers with different speeds and restrained, consistent wind/light/weather direction;
- short clips with dense performance are split at a clean action boundary, normally keeping each generated segment within the available duration limit; do not compress multiple contact actions, dialogue turns, and travel beats into one clip merely to hit a target runtime;
- final dialogue and narration are locked here and must not be invented during generation.

Run a self-check for story causality, timing, action completeness, audio consistency, reference coverage, prop and position continuity, light/weather continuity, and bridge-beat completeness. Show the Shot Table approval card before storyboards.

## STEP 4: Text storyboard and optional visual storyboard

Create one authoritative text storyboard document with one section per shot. Each section restates the approved action, camera, depth layers, environment motion, audio, emotional change, references, continuity handoff, and final spoken text if any. Remove planning labels, arrows, timing notes, and panel borders from the material that will become a video prompt.

A visual storyboard or grid is optional and is for review only. The video stage reads the approved text storyboard, not an unapproved sketch. Show a storyboard choice card:

- approve and generate clips;
- revise selected shots;
- revise pacing or transitions;
- create optional visual storyboard;
- return to Shot Table.

## STEP 5: Video generation

After the text storyboard and formal video prompts are ready, show a mandatory generation-settings confirmation card for the final video resolution and aspect ratio. Explain any available options and preserve the user-confirmed values as production locks. Do not generate formal video clips until the user confirms both resolution and aspect ratio. If the user changes either value later, revalidate all shot prompts and dependent assets before rendering. Then confirm the selected video model and any remaining required parameters according to current capability limits. Generate shots in batches by stage, not by alternating asset types shot by shot.

Use MiniMax H3 as the default video model. If the user explicitly names another model, verify that it supports the confirmed inputs and settings before following that choice. When the selected model fails, make one cause-specific correction; if it still cannot complete the shot, move to another compatible model after reporting the change instead of repeatedly retrying the same model.

For each clip, bind the approved storyboard section to the exact latest character, scene, prop, and continuity notes. Treat ordinary reference images as identity, style, design, world, or action references. Use an image as an opening or closing frame only when the user explicitly requests that timeline role. For a continuation, state the prior shot's final pose, facing direction, camera side, object orientation, open/closed state, held items, and sound state before describing the next action. Keep one camera side and one screen direction through a handoff unless the transition is explicitly motivated.

Never let a model resolve an ambiguous physical interface by inventing geometry. When the approved asset does not show a step, platform, hatch, cargo opening, handle, or access path, either use the visible structure as-is, simplify the action, or return to the asset stage for a structural anchor; do not silently add it. When a character contacts an object, name the actual contact surface and the order of hand, foot, body, and object movement.

For performance-led shots, prompt action as a sequence rather than a mood label: setup and eye target, hand/body action, facial change during the action, spoken line if any, listener reaction, and the next movement. For dialogue, one speaker at a time, matched mouth movement, explicit gaze target, and a fixed voice identity across clips.

For background life, specify foreground, middle-ground, and background motion separately. Use different speeds and mild parallax; keep wind, weather, lighting, and environmental motion direction coherent. Do not use generic wording such as “rich background” without naming the layers and their motion.

Prompt each clip positively with:

- the approved dramatic beat first;
- the required subject and continuity state;
- the specific visual language and environment motion;
- camera and per-second action;
- audio mode and approved spoken text;
- bridge beat and end state.

Do not paraphrase approved dialogue or narration, introduce new story beats, or carry storyboard-only labels into the generation prompt.

After all clips are produced, place them in shot order and show a clip approval card checking:

- story beat and emotional performance;
- character and scene consistency;
- camera-side, screen-direction, and start/end-state continuity;
- object geometry, interface position, and permitted contact path;
- motion physics and contact;
- facial expression, eye target, mouth state, speaking order, and reaction timing;
- environment life and depth;
- shot-to-shot pose, prop, light, weather, and bridge continuity;
- audio mode, speaker identity, mouth state, and approved text;
- absence of storyboard artifacts.

## STEP 6: Assembly, sound, and final QC

Assemble only the latest approved clips in approved order. Add or preserve the approved environment sound, foley, dialogue, narration, and one coherent BGM approach. Duck BGM under speech and important natural or mechanical sounds. Keep subtitles off unless approved in Step 0.

Final QC must verify:

- the causal story is understandable without missing action;
- the emotional anchor returns with a meaningful change;
- the protagonist remains visually and emotionally legible;
- continuity of identity, scale, position, props, light, weather, and time is acceptable;
- camera side, screen direction, subject orientation, and object geometry remain coherent across every cut;
- character actions, eye-lines, facial changes, handoffs, and spoken lines are temporally and spatially aligned;
- backgrounds have intentional layered motion and parallax rather than static-plate or pasted-on movement;
- every segment duration has a narrative reason;
- transitions do not pad the runtime;
- sound has no duplicate, abrupt, or competing tracks;
- dialogue or narration matches the approved text and speaker;
- there are no storyboard labels, arrows, panel borders, test marks, or temporary assets;
- the final video and optional poster/cover are delivered as separate, clearly identified canvas assets.

If only one shot is weak, regenerate that shot and the minimum dependent transition rather than restarting the project. If an anchor is wrong, return to the anchor stage and invalidate only dependent outputs.

## STEP 7: Optional poster or cover

After the final direction or final film is approved, create optional poster, cover, or alternate-ratio images from the locked character, scene, and visual language. These are separate deliverables and must not alter the approved film.

## Scope boundaries

Do not use this Skill for a single image, a simple edit, a one-off image-to-video clip, logo design, ordinary subtitles, or prompt-only consultation. Use a prompt-design workflow for prompt writing alone. Use a separate workflow when the user requests a long-form series, many independent final videos, a commercial campaign, or a timeline-heavy edit rather than one cohesive original animated short.
