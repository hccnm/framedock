---
name: storyboard-keyframes
description: Visualize storyboard scripts as boards or keyframes
---

## 1. Confirm the visualization format

Before generating, ask the user in a single question and include a recommendation:

- **Format:**
  - **Multi-panel storyboard:** one or a few multi-panel images laid out in shot order, showing the whole video at a glance;
  - **Single frames:** one image per shot, generated separately and clean of labels, suited to examining composition and color closely and usable as visual references for video generation;
  - Or both: a storyboard for the overview first, then single frames for key shots.
- **Quantity:** how many storyboard images and panels per image; how many single frames and which shots they cover.

When the user has already stated the format and quantity, follow it without asking again.

## 2. Multi-panel storyboard: show the whole video

1. **Analyze the story and references first:** read through the storyboard script to understand the video's arc and each shot's key visuals and emotional change; then review the character, product, scene and style references, stating what each provides (identity, styling, space, art style) and what not to carry over.
2. **Plan the grid:**
   - Cover every shot in the storyboard script in time order. Keep each board to at most 25 panels (5×5); when there are many shots, split them across several boards grouped by generation unit or passage, so that together they still form the complete film.
   - Each panel matches the final aspect ratio; set the whole image's aspect ratio to the standard ratio closest to "panel ratio × columns ÷ rows" rather than reusing the panel ratio, so rows and columns are not squeezed out of shape.
   - Decide the panel count, rows and columns, and reading order first, with one shot per panel.
3. **Write one overall description per board:** in reading order, describe each panel's shot size, subject action, light and color, and state the characters, products, scenes and art style shared by the whole set. Shot numbers and a one-line description may sit beside or below each panel; keep text short and off the image.
4. **Generate multiple boards at the same time:** base every board directly on the original references and the same shared settings, independently of one another; never use an earlier board's output as a reference for a later one, so drift does not accumulate board by board. Keep character identity, styling, light-and-color logic and art direction consistent across the set.

## 3. Single frames: examine key shots

Not every shot needs a frame. Within the quantity the user confirmed, prioritize:

- The opening image of the film and of each generation unit;
- Hero shots, product close-ups, and turning points in style or emotion;
- Images that are hard to describe in words and most worth confirming early.

Single frames are clean images with no grid, numbers or labels, matching the final aspect ratio.

## 4. Think through the image before generating

For every storyboard panel or single frame, decide what this moment should make the viewer understand, then decide how to shoot it:

- **Image state:** take a stable, readable moment—a pose after the action completes, where a camera move lands, or a clear image before or after a transition; leave camera paths, speed changes and sound to the video prompt.
- **Viewing relationship:** where the viewer stands, what they can and cannot see, and how the eye enters, travels and lands.
- **Spatial layers:** what the foreground, midground and background each do, with one dominant source of tension such as occlusion, empty space, depth or a light-dark split.
- **One action, one clue:** one main action plus one detail that hints at cause or consequence, rather than piling up props and effects.
- **Light and color with a source:** light comes from a concrete source and direction; color comes from weather, architecture, wardrobe, materials or practical lights.

## 5. Generate the images

- Carry these decisions into each image description: scene, subject and relationships, viewer position and gaze, light source, material and color sources, negative space, and any product or text that must be accurate.
- Attach references for characters, products or scenes that must stay consistent across shots, stating what each provides and what not to carry over.
- Images without consistency constraints (pure atmosphere, environment, abstract imagery) can prioritize aesthetic quality.

## Delivery and handoff

Deliver the storyboards or single frames, noting the shot each panel or frame belongs to. When the user adjusts a panel or frame, regenerate only the affected images. After approval, single frames can serve as visual references for their shots when writing video generation prompts; storyboards mainly support reviewing overall rhythm and visual flow.
