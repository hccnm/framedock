---
name: handdrawn-product-poster-motion
description: |
  Create a hand-drawn POP product poster and short making-of animation from a small product image. Use for drinks, cosmetics, gadgets, snacks, stationery, or toys; not large products or long ads.
trigger-words: [product poster motion, handdrawn product poster, doodle product ad, sticker poster animation, 小物产品海报, 手绘海报动画, 产品贴纸动画, POP产品广告]
---

# Handdrawn Product Poster Motion

Use this Skill to turn one small product image into a vertical hand-drawn POP poster and a short fixed-camera making-of animation. The output style is realistic product photography mixed with black marker doodles, hand-drawn sticker elements, strict playful POP lettering, bottom micro-copy, and illustrated hands presenting the product.

This Skill is reference-template driven. Do not rewrite the poster or video prompt from scratch. During execution, load and adapt the bundled prompt references:

- `references/poster-image-prompt.cn.md` for the poster image stage.
- `references/poster-video-prompt.cn.md` for the video stage.

The Skill is designed for products that can naturally be held, surrounded, framed, or presented by two hands: drinks, lipstick, perfume, skincare bottles, phones, earbuds, snacks, stationery, small toys, small packages, and similar objects.

Do not use this Skill for cars, furniture, home appliances, real estate, large devices, multi-product catalog pages, UI feature walkthroughs, talking-head creator videos, serious luxury campaigns, or long narrative ads.

---

## STEP 1: Intake and Missing Information Check

### Required inputs

- One product image.
- Product name.

### Product name rule

The product name is mandatory because it becomes the largest top title in the poster.

1. First inspect the uploaded product image for a clearly readable product name.
2. If the product name is visible and unambiguous, use it and briefly confirm it to the user.
3. If the image has no readable product name, the name is blocked, unclear, or there are multiple possible names, ask the user for the product name before generating.
4. Do not invent a product name.

### Subtitle language rule

The poster has a small subtitle under or near the main title.

- If the main title is Chinese, create a concise uppercase English subtitle.
- If the main title is English or a Latin-letter brand/product name, create a short Chinese subtitle.
- The subtitle must remain much smaller than the main title.

### Three-round intake questions

Use three separate rounds instead of one combined question.

#### Round 1: title confirmation

Ask only about the product title when the title is missing, ambiguous, blocked, or needs user confirmation. Do not ask about stickers in this first round.

- If the uploaded image has a clear product name, ask the user to confirm or replace it.
- If the uploaded image has no reliable product name, ask the user to provide the poster title.
- After the user answers, lock the title for the poster and derive the subtitle with the subtitle language rule.

#### Round 2: sticker strategy

After the title is confirmed, ask the sticker strategy in a second question. Offer these options:

1. Extract from the uploaded image.
2. User custom stickers.
3. Random stickers.

If the user selects custom stickers, collect the exact sticker words, icons, motifs, or small notes before generation. Sticker count should normally be four and must not exceed four. The poster should use four fixed stickers: FRESH as the bright sticker that lightly overlaps a product edge, ENJOY as a bright side sticker, one text-free black-and-white scent/steam/motion-line sticker, and one text-free black-and-white round/arc sticker that is partially hidden behind the product. If the poster feels too monochrome, prefer a few bright sticker accents rather than leaving the poster mostly black and white.

#### Round 3: bottom micro-copy

After the sticker strategy is confirmed, ask a third question for optional bottom micro-copy. Ask whether the user has store address, opening time, store note, product note, brand sentence, event information, or other tiny footer information to place at the bottom of the poster.

Offer concise choices:

1. Provide footer info.
2. Use image text.
3. Let the Skill generate neutral decorative micro-copy.

If the user provides footer information, use it as the poster's bottom one or two tiny auxiliary text lines. Do not invent addresses, opening dates, contact information, prices, promotions, or business claims. If the user chooses image text, extract short safe text from the uploaded product image when available. If the user chooses neutral generation or skips this round, use non-claim decorative micro-copy such as product mood words, simple brand-style notes, or generic lifestyle poster text.

### Aspect ratio

Default image and video ratio is 3:4 vertical. If the user explicitly requests another vertical ratio, keep the same ratio for both poster and video.

---

## STEP 2: Generate the Final Poster Image

Before composing the image prompt, load `references/poster-image-prompt.cn.md`. The reference template is the source of truth for the poster's visual structure, title font requirements, bottom micro-copy, hand layer, sticker style, and negative constraints.

### Prompt adaptation rules

- Preserve the template's detailed visual language; do not compress it into a short generic poster brief.
- Replace drink-specific wording with the current product category only where necessary.
- Replace `{{产品名字}}` with the confirmed product name.
- Replace `{{副标题}}` according to the subtitle language rule.
- Replace `{{产品图片}}` with the uploaded product reference role.
- Replace `{{贴纸素材}}` using the confirmed sticker strategy.
- Replace `{{底部小字}}` using the third-round footer answer: user-provided footer info, safe text from the uploaded image, or neutral decorative micro-copy.
- Use the updated four-sticker structure from the reference: FRESH bright color-block sticker lightly overlapping a non-critical product edge, ENJOY bright color-block side sticker, one text-free black-and-white scent/steam/motion-line sticker, and one text-free black-and-white round/arc sticker partially hidden behind the product. Do not reduce the limit back to three.
- Keep the bottom micro-copy requirement. Prioritize the third-round footer answer. If the user provides store address, opening time, event note, product note, or brand sentence, place it in the bottom one or two tiny lines. If not, use safe uploaded-image text or neutral decorative micro-copy; do not omit it.
- Keep the strict handwritten POP title style from the template: thick black marker, solid fill, non-vector jittered edges, rounded bulging corners, loose cute restaurant/lifestyle POP lettering, flat 2D, no shadow/gradient/3D.
- Keep the product realistic and photographic; never cartoonize or 3D-render the product.

### Poster output requirements

The poster must be one complete vertical poster with one product subject, a large hand-written top title, smaller subtitle, realistic product hero, one pair of black marker illustrated hands, one to four sticker/doodle elements, and one or two lines of tiny bottom auxiliary text.

---

## STEP 3: Poster Quality Check Before Video

Before generating the video, verify the poster is usable:

- It is one complete vertical poster.
- It contains exactly one main product subject.
- The main title is correct and readable.
- The title font follows the strict hand-written POP marker requirements, not a standard font.
- The subtitle is correct and not dominant.
- The product remains realistic and matches the uploaded reference.
- A pair of illustrated black-marker hands is present.
- Stickers or doodles do not exceed four major elements, and the intended structure is fixed stickers: FRESH, ENJOY, one text-free scent/steam/motion-line sticker, and one text-free round/arc sticker, with FRESH in front of a product edge and the round/arc sticker partly behind the product.
- Bottom micro-copy exists as one or two tiny auxiliary text lines.
- Sticker layering is intentional: the FRESH sticker may lightly overlap a non-critical product edge, and the text-free round/arc sticker may be partially hidden behind the product; neither may block core product identity.
- There is no split screen, grid, four-panel layout, second product, or random extra readable text.

If the poster fails these checks, regenerate or correct the poster before video generation. Do not proceed to video with a visibly wrong title, missing bottom text, wrong font style, or wrong product identity.

---

## STEP 4: Generate the Seven-Second Poster-Making Video

Before composing the video prompt, load `references/poster-video-prompt.cn.md`. The reference template is the source of truth for the final-poster interpretation, fixed-camera structure, timeline, clap-then-settle hands, sticker/product animation, soundscape, and strict constraints.

### Prompt adaptation rules

- Use the generated poster as `@图片1`, the only final-state visual reference.
- Treat `@图片1` as the completed poster, not as a loose style reference.
- Preserve the template's timing structure and fixed-camera rule.
- Replace `{{产品名字}}`, `{{副标题}}`, product description, sticker list, and ratio with facts from the approved poster.
- The video's stickers, bottom micro-copy, hand positions, product outline, and highlighter edge must match the approved poster image.
- Do not add visual elements that are not present in the poster.

### Required video structure

- 0.00–1.20: title writes on; subtitle appears.
- 1.20–2.40: hands appear, clap once, then pause briefly, then quickly separate and move to final poster positions.
- 2.40–3.80: the single product lands like a sticker and stabilizes.
- 3.80–5.80: existing stickers, doodles, product outline, highlighter edge, and bottom micro-copy attach.
- 5.80–7.00: final complete poster hold, with the last 0.50 seconds stable.

### Soundscape

Use the template's paper-craft soundscape: marker friction, brushy line sounds, one light clap, sticker taps, paper sticking sounds, and low-volume cheerful music. Do not add voice, narration, crowd ambience, heavy bass, or dramatic scoring.

---

## Failure Handling

- If the product name is wrong, regenerate the poster first.
- If the title font becomes a standard printed font, regenerate with the strict POP marker title requirements from the image reference template.
- If the bottom micro-copy is missing, regenerate or patch the poster; do not ignore it.
- If the poster feels too empty or too monochrome, use the full allowance of up to four sticker/doodle elements and let some of them carry bright accent colors while keeping the single-poster structure.
- If the product becomes a cartoon, 3D render, or unrelated object, regenerate the poster with stronger realistic product preservation.
- If the video adds new text, new stickers, a second product, or a changed product category, regenerate the video and emphasize that every visual element must come only from the final poster.
- If the video does not settle back to the final poster, regenerate the video with stronger final-frame hold and fixed-camera instructions.

---

## Trigger Tests

Should trigger:

1. “上传这支口红，做成手绘 POP 海报动画。”
2. “用这个手机产品图生成小物产品海报和 7 秒动效。”
3. “这杯奶茶做成手绘贴纸风产品广告视频。”

Should not trigger:

1. “给这个产品做真人带货口播。”
2. “做一个汽车品牌大片。”
3. “帮我做 App 功能演示视频。”
