---
name: mime-object-video
description: |
  Add one to three referenced objects to a mime-acting video while preserving the person, scene, camera, timing, and performance. Use for no-prop acting enhancement and object insertion.
trigger-words: [mime acting, no-prop acting, imaginary object, prop insertion, object video edit, hand prop, wearable prop, 无实物表演, 无道具表演, 物品增强, 道具植入, 把物品加到视频里, 手上出现物品, 戴上参考物品]
---

# Mime Object Video

Use this Skill when the user provides a video of a person performing without a physical prop, plus 1-3 reference object images, and wants an enhanced video where the referenced object appears on a specified body part. The core promise is: add the object naturally, but keep the original video’s person, scene, camera, timing, action, and overall continuity unchanged. Use MiniMax H3 by default. If the user explicitly selects another model, check its capabilities and follow that choice; on failure, retry once for the diagnosed cause, then switch to another available model.

Do not use this Skill for general object replacement, full scene redesign, product ads, talking-head typography packaging, subtitles-only editing, or generic video generation from text. If the user wants a new scripted commercial, route to a broader video or ad workflow instead.

## Step 0: Collect Required Inputs

Required inputs:

1. **Source video**: one uploaded or canvas video showing the original no-prop performance.
2. **Object references**: 1-3 images of the object, product, accessory, clothing item, or prop to insert.
3. **Target attachment area**: the body part or region where the object should appear, such as hand, wrist, head, face, shoulder, torso, waist, foot, back, or “between both hands”.
4. **Expected interaction**: if not obvious, ask whether the object should be held, worn, attached, floating close to the body, carried, or following a gesture.

If any required input is missing, ask only for the missing item. Do not ask about subtitles unless the user explicitly requests subtitles.

Optional inputs:

- Desired output aspect ratio or platform. If omitted, preserve the source video aspect ratio.
- Whether the reference object must be replicated exactly or only visually matched. Default: natural faithful match.
- Whether the original audio should be preserved. Default: preserve original audio when the source video has useful audio.

## Step 1: Analyze the Source Video and References

Analyze the source video for:

- Visible person count and the primary actor.
- Body part visibility, motion range, occlusion, and contact opportunities.
- Camera movement, framing, timing, and any motion blur.
- Scene lighting, perspective, shadows, and background continuity.
- Whether the target body part is visible enough for the requested insertion.

Analyze the object references for:

- Object category and intended usage: held prop, wearable item, body-mounted item, carried item, or nearby object.
- Main visible structure and silhouette that must remain recognizable.
- Attachment logic: where it touches the body, how it is gripped/worn, and what part should face the camera.
- If multiple reference images show the same object, treat them as one object identity with multiple views. If they show different objects, ask whether the user wants one selected object or multiple inserted objects.

Do not convert colors into prompt text unless the user states a color in words. Let the reference images carry color and texture visually.

## Step 2: Validate Feasibility Before Generation

Before any expensive video generation, check:

- The target body part appears for enough of the clip to support the effect.
- The requested object can physically fit the target area.
- The interaction does not contradict the original motion. For example, a large two-handed object needs two hands visible or a clear carry pose.
- The source video’s original identity, scene, camera, and action should remain the base; the edit must not redesign the person, clothing, background, or shot.

If the request is ambiguous, ask the shortest blocking question. Examples:

- “Should the object be held in the hand or attached to the wrist?”
- “These three images appear to show different items. Which one should be inserted?”
- “The requested body part is mostly hidden. Should I place the object on a nearby visible area instead?”

## Step 3: Build the Edit Brief

Create a compact edit brief that prioritizes preservation:

1. **Source invariants**: preserve original actor identity, facial appearance, outfit, body proportions, scene, lighting, camera, timing, action, and shot rhythm.
2. **Object insertion**: insert the referenced object on the specified body part with correct scale, perspective, grip/wear/contact, shadow, occlusion, and motion tracking.
3. **Reference fidelity**: keep the object’s recognizable silhouette, parts, material cues, and functional details from the references.
4. **No unnecessary changes**: do not add new people, change background, change clothing, alter the pose, change camera movement, or introduce unrelated props.

For short requests, keep the final edit prompt short and close to the user’s wording, appending only required preservation and contact constraints.

## Step 4: Choose the Production Path

Use the shortest available path that can preserve the source video. Prefer MiniMax H3 as the default production model for this Skill:

- Prefer a **MiniMax H3**-based edit path when the task can be solved in one pass with source video plus image references.
- If H3 or the chosen path requires a visual anchor, first create a still object-placement reference frame from a representative source frame and object references, then use it as guidance for the video edit.
- If the edit must preserve the original audio, generate the visual edit first and then remux the original audio back when needed.
- Preserve the source aspect ratio unless the user explicitly requests another platform format.

Do not turn this into a full multi-stage workflow unless the user requests multiple clips, a reviewed shot plan, complex multi-object interactions, or a final assembly with music, subtitles, and separate cuts.

## Step 5: Generate the Enhanced Video

When dispatching video generation/editing:

- Send the source video as the primary video source.
- Send the object images as reference images in the user-provided order.
- State the target body part and interaction explicitly.
- State preservation constraints explicitly: actor, face, clothing, scene, lighting, camera, movement, action, and timing remain the same.
- State physical integration requirements: tracked motion, perspective, scale, contact, occlusion, shadow, and blur match the source.

Avoid negative prompt clutter. Only include exclusions for true contradictions, such as “do not replace the actor” or “do not redesign the scene”, when the model is likely to drift.

## Step 6: Review and Repair

After generation, inspect the output for:

- The object appears on the requested body part.
- The object follows the body through motion and occlusion.
- The object scale and perspective remain plausible.
- The original person, clothing, scene, camera, and action are preserved.
- There are no extra limbs, duplicate objects, identity drift, background redesign, or object flicker.

If the result fails:

- For object placement errors, retry with a more explicit body-part and contact description.
- For identity or scene drift, strengthen source preservation and reduce creative language.
- For object mismatch, emphasize the reference object’s concrete silhouette and functional structure.
- For tracking/flicker, request steadier attachment, consistent scale, and frame-to-frame continuity.

Retry with a substantively corrected prompt; do not repeat the same prompt.

## Step 7: Deliver

Return the enhanced video on the canvas. Summarize only:

- Source video used.
- Object reference count.
- Target body part and interaction.
- Whether original audio was preserved.

Do not expose internal prompts, model parameters, or node ids unless the user asks.
