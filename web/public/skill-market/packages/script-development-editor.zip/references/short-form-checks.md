# 短片与视觉因果校核 / Short-form causal checks

## 使用场景 / Use

适用于短片大纲、关键视觉时刻、无对白动作与幻想机制，不意味着制作视频，也不自动给短片加入幻想元素。
Use for short-film outlines, visual moments, nonverbal action, and speculative mechanisms; this neither authorizes video production nor adds fantasy to unrelated stories.

## 规则先于解法 / Rules before solutions

用最少必要规则说明触发者、触发动作、作用范围、有效时长、可改变与不可改变的内容。规则应在角色利用之前由行动建立，不在高潮临时新增能力。
State the necessary trigger, operator, scope, persistence, and limits. Establish each rule through action before exploiting it; do not invent a new power at the climax.

时间机制另查：看见的是固定时点还是滚动时间窗，影像是直播、静帧还是循环片段，擦拭或其他触发是扩大视野还是推进时间，何时因现实行动更新。若明天与今天同步相差24小时，角色不能在下一秒又看见同一事件提前数分钟发生；需要回看时必须提前建立回放规则。必要时给创作内部做时间对应表，不强塞解释性对白。
For temporal mechanisms, distinguish fixed timestamps from rolling windows, live views from stills or loops, revealing space from advancing time, and update conditions. A synchronized view 24 hours ahead cannot suddenly replay earlier minutes without an established replay rule. Use an internal timing map where needed, not forced exposition.

## 视觉变化推动选择 / Visual change drives choice

每个关键变化都写成：角色看到什么新信息 → 原策略为什么失效或出现什么机会 → 他做什么决定 → 现实后果是什么。只有漂亮倒影、灯光或变形而不改变行动的段落，应合并或删除。
For each visual change, identify new evidence, a failed strategy or new opportunity, the resulting decision, and its consequence. Merge or remove decorative changes that do not affect action.

最后一个视觉变化也要引出选择，哪怕只是停止窥视、承担责任或保护已经取得的结果。不要把所有决定放在最后一个画面之前。
The final visual change must also lead to a choice, even stopping observation, accepting responsibility, or protecting a result already achieved.

## 因果与物理权限 / Causality and practical access

结局必须可追溯到主角行动。工具、开关、逃生出口和权限提前出现；损失或代价必须可辨认，不能只在说明里声称可能被惩罚。预防危险不能引入被忽略的新危险，例如锁门困住现有行人；说明安全区域、撤离状态和封闭范围。
Trace the ending to protagonist action. Establish tools, controls, exits, and access beforehand. Make costs legible rather than asserted only in notes. Prevention must not conceal a new hazard, such as locking existing pedestrians into danger; establish safe zones, evacuation status, and closure scope.

不要把强烈情绪误当行动动机。具体说明人物想保护什么、为什么由他此刻行动、放弃行动会失去什么；人物数量不超过用户上限，不为解释规则增加多余角色。
Ground emotion in a concrete want, a reason this person must act now, and the cost of inaction. Respect the cast cap; do not add characters merely to explain rules.

## 容量与输出 / Capacity and delivery

按时间划分的大纲必须连续无重叠、总和符合用户时长，但只代表预算。为发现、看懂、反应、执行和结果各留辨识时间。复杂机理优先简化，不靠极密动作或微小日期字样承担全部理解。
Timed outlines must be contiguous, nonoverlapping, and total the requested duration, but remain estimates. Allow recognition and reaction time; simplify mechanisms rather than relying on crowded actions or tiny dates for comprehension.

按用户所要顺序给一句话故事、动机、规则、大纲、关键视觉。数量严格匹配请求；未要求的对白、镜头参数和生成提示词不输出。用户只要方向时，此校核仅用于内部判断，不扩大交付。
Deliver only the requested logline, motivation, rules, outline, and visual beats, respecting exact counts. Omit unrequested dialogue, technical camera parameters, and generation prompts. For concepts-only requests, use these checks internally without expanding the output.
