# 模块索引 / Module index

26个内部资料模块，非独立技能。只读当前任务必需的指南，再沿链接查表格与案例。旧模块名是本技能内部别名，不依赖外部安装。

These 26 modules are local knowledge documents, not separately invoked skills. Read the relevant guide first, then only necessary evidence. Legacy module names are internal aliases.

| 任务 / Task | 指南 / Guide |
|---|---|
| 新建、续写、阶段安排、项目记录 / Project workflow and continuity | [流程与状态 / Project workflow and continuity](sw-workflow/guide.md) |
| 点子、主题、戏核、一句话故事 / Premise, theme, and logline | [前提与主题 / Premise, theme, and logline](sw-premise-theme/guide.md) |
| 情节点、节拍、高潮、长片结构诊断 / Story structure and turning points | [故事结构 / Story structure and turning points](sw-story-structure/guide.md) |
| 人物动机、弱点、对手、关系冲突 / Character motivation and conflict | [人物与冲突 / Character motivation and conflict](sw-character-conflict/guide.md) |
| 潜台词、角色声音、对白改写 / Dialogue, subtext, and voice | [对白 / Dialogue, subtext, and voice](sw-dialogue/guide.md) |
| 分场、价值转折、进出点、节奏 / Scene construction and sequences | [场景与段落 / Scene construction and sequences](sw-scene-craft/guide.md) |
| 剧本格式、Fountain、小说或舞台改编 / Script format and adaptation | [格式与改编 / Script format and adaptation](sw-format-adaptation/guide.md) |
| 有机结构、中段松散、道德抉择、对手网络 / Organic story structure | [特鲁比故事解剖 / Organic story structure](sw-truby-anatomy/guide.md) |
| 主副类型、类型节拍、混合类型诊断 / Genre anatomy and genre mixing | [类型解剖 / Genre anatomy and genre mixing](sw-genre-anatomy/guide.md) |
| 剧集单集结构、季结构、多线与出幕悬念 / Episode and season structure | [剧集结构 / Episode and season structure](sw-series-structure/guide.md) |
| 剧集持续冲突机制、人物网、设定集与推介文档 / Series engine and bible | [剧集引擎与设定集 / Series engine and bible](sw-series-engine-bible/guide.md) |
| 情节拆解、编剧室协作、反馈处理和制作限制 / Writers room and production notes | [编剧室 / Writers room and production notes](sw-writers-room/guide.md) |
| 半小时喜剧、情景喜剧、笑点与喜剧格式 / Sitcom and comedy | [喜剧 / Sitcom and comedy](sw-sitcom-comedy/guide.md) |
| 国产剧文档链、分集大纲、长篇小说改编 / Chinese television practice | [国产剧实践 / Chinese television practice](sw-chinese-series-practice/guide.md) |
| 京剧、豫剧、越剧等板腔体写作 / Banqiang opera methods | [板腔体方法 / Banqiang opera methods](sw-chinese-opera-banqiang/guide.md) |
| 元杂剧、传奇、昆曲等曲牌体写作 / Qupai opera methods | [曲牌体方法 / Qupai opera methods](sw-chinese-opera-qupai/guide.md) |
| 板腔体作品的结构和唱段案例对照 / Banqiang opera case studies | [板腔体案例 / Banqiang opera case studies](sw-chinese-opera-banqiang-cases/guide.md) |
| 曲牌体作品的结构和套曲案例对照 / Qupai opera case studies | [曲牌体案例 / Qupai opera case studies](sw-chinese-opera-qupai-cases/guide.md) |
| 美国电影案例与同类型参照 / American film case studies | [美国案例 / American film case studies](sw-american-case-studies/guide.md) |
| 日本创作方法、片段优先、主题后置 / Japanese writing methods | [日本方法 / Japanese writing methods](sw-japanese-screenwriting/guide.md) |
| 韩国／法国方法、情绪、探访、集体创作 / Korean and French writing methods | [韩国与法国方法 / Korean and French writing methods](sw-korean-french-screenwriting/guide.md) |
| 行业推介、职业流程、署名和交易知识 / Pitching and screenwriting business | [行业与生意 / Pitching and screenwriting business](sw-industry-business/guide.md) |
| 契诃夫、多主人公、事件画外、反高潮 / Chekhovian dramaturgy | [契诃夫戏剧法 / Chekhovian dramaturgy](chekhov-dramaturgy/guide.md) |
| 小津、家庭日常、节制表达与对白语气 / Ozu family drama methods | [小津剧本方法 / Ozu family drama methods](ozu-screenplay-style/guide.md) |
| 《继承之战》式群像、权力冲突与容器集 / Dynastic ensemble writing | [继承之战分析 / Dynastic ensemble writing](succession-series-writing/guide.md) |
| 已出版剧集的结构、试播集与跨地区案例 / Television case studies | [剧集案例库 / Television case studies](sw-series-case-studies/guide.md) |

原资料中 _notes 等标记是来源索引，并非已随包提供的扫描件。保持章节号和版本说明；不把推断当作者原话。
Historical _notes markers cite source notes, not bundled scans. Retain section and edition qualifications; do not present inference as author testimony.
