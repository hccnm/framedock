---
name: script-development-editor
description: Develop or revise film, television, stage, and opera writing from ideas or drafts. Deliver concepts, outlines, dialogue, scripts, or revision plans. Writing only; no media generation.
---

# Script Development and Revision

Select internal craft knowledge according to the medium, supplied material, and requested deliverable. All 26 modules are bundled here; no other skill installation or nested invocation is required.

## STEP 1: Identify the task and select knowledge

1. Identify feature, short film, series, stage play, or opera, and whether the request concerns development, continuation, adaptation, diagnosis, or focused revision. Extract supplied duration, episode count, cast, locations, style, and output scope.
2. Ask only for missing information that changes the current deliverable. Label reasonable assumptions. When asked for concepts, outlines, diagnosis, or dialogue, deliver that scope without expanding into a full screenplay.
3. Read the relevant guide below. Follow its local links only when tables, examples, or diagnostic details are needed. Do not load all modules at once; locate headings or keywords before reading windows in long resources.
4. For a complete continuing project, resumption, or next-step guidance, first read [the workflow guide](references/sw-workflow/guide.md) and select the appropriate medium path. Focused requests go straight to their specialist knowledge.
5. Apply the relevant diagnostic checklist and repair substantive issues. Resolve methodological differences by medium and creative purpose; page counts, beat counts, and joke density are not universal obligations.

Legacy module names identify local knowledge. Read the appropriate guide directly rather than calling another skill. Historical _notes paths are source identifiers, not supplied files or proof that the original books have been read.

## STEP 2: Develop and continue by medium

- Features and ordinary stage plays: premise and theme, structure, characters and conflict, scene outline or treatment, draft, revision, and submission material only when requested.
- Shorts and one-act plays: use a reduced path that respects duration and cast capacity, not feature page grids or mandatory forty-card boards.
- Series: renewable story engine, character web and season arc, bible and episode planning, pilot and episode structure, story breaking, drafts and revision, then pitching only if requested.
- Opera: distinguish banqiang from qupai, use the corresponding X or Q workflow and methods, and do not force cinematic structure onto sung passages.
- Existing drafts: extract premise, structure, and character, identify gaps, then revise the requested area while preserving locked settings and endings.
- Ongoing projects: maintain story-bible.md in the user project for accepted decisions, current stage, revisions, and next action. Keep complete outlines and scripts separate. One-off tasks need no archive. Summarize existing status before resuming rather than reopening settled choices.

## STEP 3: Consult specialist guides

| Task | Local guide |
|---|---|
| Project workflow and continuity | [Project workflow and continuity](references/sw-workflow/guide.md) |
| Premise, theme, and logline | [Premise, theme, and logline](references/sw-premise-theme/guide.md) |
| Story structure and turning points | [Story structure and turning points](references/sw-story-structure/guide.md) |
| Character motivation and conflict | [Character motivation and conflict](references/sw-character-conflict/guide.md) |
| Dialogue, subtext, and voice | [Dialogue, subtext, and voice](references/sw-dialogue/guide.md) |
| Scene construction and sequences | [Scene construction and sequences](references/sw-scene-craft/guide.md) |
| Script format and adaptation | [Script format and adaptation](references/sw-format-adaptation/guide.md) |
| Organic story structure | [Organic story structure](references/sw-truby-anatomy/guide.md) |
| Genre anatomy and genre mixing | [Genre anatomy and genre mixing](references/sw-genre-anatomy/guide.md) |
| Episode and season structure | [Episode and season structure](references/sw-series-structure/guide.md) |
| Series engine and bible | [Series engine and bible](references/sw-series-engine-bible/guide.md) |
| Writers room and production notes | [Writers room and production notes](references/sw-writers-room/guide.md) |
| Sitcom and comedy | [Sitcom and comedy](references/sw-sitcom-comedy/guide.md) |
| Chinese television practice | [Chinese television practice](references/sw-chinese-series-practice/guide.md) |
| Banqiang opera methods | [Banqiang opera methods](references/sw-chinese-opera-banqiang/guide.md) |
| Qupai opera methods | [Qupai opera methods](references/sw-chinese-opera-qupai/guide.md) |
| Banqiang opera case studies | [Banqiang opera case studies](references/sw-chinese-opera-banqiang-cases/guide.md) |
| Qupai opera case studies | [Qupai opera case studies](references/sw-chinese-opera-qupai-cases/guide.md) |
| American film case studies | [American film case studies](references/sw-american-case-studies/guide.md) |
| Japanese writing methods | [Japanese writing methods](references/sw-japanese-screenwriting/guide.md) |
| Korean and French writing methods | [Korean and French writing methods](references/sw-korean-french-screenwriting/guide.md) |
| Pitching and screenwriting business | [Pitching and screenwriting business](references/sw-industry-business/guide.md) |
| Chekhovian dramaturgy | [Chekhovian dramaturgy](references/chekhov-dramaturgy/guide.md) |
| Ozu family drama methods | [Ozu family drama methods](references/ozu-screenplay-style/guide.md) |
| Dynastic ensemble writing | [Dynastic ensemble writing](references/succession-series-writing/guide.md) |
| Television case studies | [Television case studies](references/sw-series-case-studies/guide.md) |

## STEP 4: Deliver and respect boundaries

- Respond in the user language; preserve the language of an existing screenplay unless translation is requested. Use [the terminology reference](references/sw-workflow/terms.md) when multilingual terminology needs alignment.
- Diagnosis identifies a concrete problem, dramatic effect, and feasible repair. Creative work delivers actual writing, not methods alone; explanations follow the requested scope.
- Hard production constraints outrank examples. Surface contradictory requirements instead of silently dropping them. Study mechanisms in reference works without copying their characters, plots, or dialogue into original projects.
- If a file is requested, deliver Markdown, plain text, or Fountain appropriate to the chosen convention; otherwise chat delivery is sufficient. Images, speech, and video are outside this skill.
- Industry rules and policies carry source dates. Verify current claims when possible; otherwise state their age and uncertainty.

See [LICENSE](LICENSE) and [NOTICE](NOTICE) for licensing and third-party quotation boundaries.

## STEP 5: Review, confirm, and handle failure

- Stop at concepts when concepts are requested; an outline request does not authorize dialogue, a full screenplay, or generation prompts. Alternatives must differ in desire, opposition, central choice, or emotional mechanism, not just titles.
- Surface and confirm proposed changes to an approved ending, relationship, or medium. A clear instruction to draft under established constraints needs no repeated approval. Routine focused edits need no sentence-by-sentence permission.
- Diagnose shared issues before revising multiple scenes together; preserve unrelated accepted work. On rejection, locate the mismatch and change the affected part rather than repeating the proposal.
- For short films, speculative rules, or visual storytelling, read [short-form causal checks](references/short-form-checks.md). Duration is a narrative budget, not measured finished runtime; allow time to understand each action.
- Name missing sources or internal files and pause only dependent work. Never fall back to deleted standalone skills or invent quotations, page references, legal conclusions, or regulatory approval.
- Do not generate media. Save requested text in the current project using actual paths, never hardcoded directories. Do not force an archive for a one-off task.

## Reading and validation

[The module index](references/index.md) maps tasks in both languages.
