---
name: suspense-title-sequence-generator
description: Generate a reviewed 15-second suspense title sequence from film setup, references, keyframes, credits, and beat-driven motion graphics. Use for retro suspense openings, not generic editing.
trigger-words: [suspense aesthetic title sequence, film title sequence, suspense crime intro, jazz noir trailer, 电影片头, 悬疑美学片头, 悬疑犯罪片头, 复古动画片头]
---

# Suspense Aesthetic Film Title Sequence

`SKILL.cn.md` is the authoritative source for the rules and full prompt template. Read its shot-specific rules and complete final video template before authoring prompts. This English file must follow the Chinese version; if wording differs, the Chinese version governs. Image and video prompts follow the Chinese prompt language specified there, while on-screen titles and credits remain English.

Use this Skill when the user wants a short cinematic trailer title sequence / opening title sequence. The Skill should not send raw character references directly into video as the only visual guide. It first locks six shot keyframes, then uses those keyframes as anchors for video generation.

Default output: a 15-second 16:9 landscape video with retro Japanese animated opening-title language, hard-edge silhouettes, manga collage, asymmetric split screens, bold geometric color blocks, readable English credits, subtle katakana decoration, and a 60% suspense / 40% jazz atmosphere.

## Core Principle

The user provides:

1. Film type
2. Film title
3. One-line plot
4. Cast list
5. Optional reference images

Everything else uses defaults. The one-line plot is an internal interpretation aid only. Do not paste or restate it in the final video prompt; use it to infer motifs, character relationships, clue props, evidence-wall subjects, confrontation sides, and background locations.

Mandatory execution order:

```text
confirm film data and reference-role interpretation → write 6 Chinese keyframe image prompts → generate 6 keyframe images → compile final video prompt from those keyframes → generate final video
```

Do not generate the video immediately after confirming film data.

## STEP 1: Collect Minimal Variables

Collect only missing required variables:

- `film_type`: e.g. light suspense crime, noir romance, retro spy thriller, psychological suspense, female revenge crime.
- `title`: English is preferred because the sequence defaults to English on-screen title/credits only.
- `logline`: one-line plot. It guides motif selection but is not inserted verbatim into the final video prompt.
- `cast`: actor list for the single `STARRING ...` credit.
- `references`: optional images: protagonists, supporting characters, props, scenes, style references, film screenshots, title-sequence screenshots, costume references, or composition references.

If information is missing, ask one concise intake question. If complete, continue.

### Credit parsing rules

- User-provided roles and names have highest priority and must never be overwritten by defaults.
- If the user provides a director, `DIRECTED BY` must use that director's name.
- Cast names are used only for `STARRING {cast_names}`.
- Do not convert a user-provided director into `CREATED BY`; do not replace a user director with a default director.
- Do not automatically generate names for missing roles. Do not automatically use old template defaults such as `EDITED BY JUNE PARK`, `CREATED BY MIRA HOLT`, `DIRECTED BY NOAH VOSS`, or `PRODUCTION DESIGN BY VERA LIN`.
- If a shot template expects a credit role but the user did not provide that role, the keyframe prompt must not mention credit, credit area, blank label, role, name, or English placeholder at all; describe only composition, characters, props, color blocks, line frames, and layout design.
- Use only roles and names supplied by the user. If a role is missing, delete its credit, name, entrance animation, credit area, and all related descriptions from subsequent keyframe and video prompts. Never auto-fill missing credits or include conditional instructions about absent credits in the final prompt.
- If the user provides only director and cast, default to title + `STARRING ...` + `DIRECTED BY ...` only.

## STEP 2: Classify Reference Images

User labels override automatic recognition. Otherwise classify each uploaded image as one or more of:

- `protagonist`
- `supporting_character`
- `prop`
- `scene`
- `style`
- `shot_reference`

Reference rules:

- Determine character identity, gender, wardrobe, and physical traits from user information and references. At the video stage, inherit the approved keyframes instead of adding fixed-template character traits. Preserve running and graphic motion without assuming a woman, long coat, skirt, or long hair.
- Character images are face-identity and character-cue references first. Preserve recognizable face identity, hairstyle, facial structure, distinctive accessories, and broad costume identity, then cinematically restage. Do not copy the original pose, selfie perspective, casual framing, lighting, background, body direction, or seated/standing action unless explicitly requested.
- Supporting characters can become cinematically restaged ensemble silhouettes, confrontation figures, file photos, or split-screen tiles.
- Prop images become clue inserts, collage tiles, evidence-wall elements, close-ups, transition masks, or designed collage panels.
- Scene images donate environment structure and story-world cues.
- Style images donate silhouette language, color blocks, split screens, line frames, typography layout, motion-collage rhythm, and title-package design.
- Film screenshots are only abstract visual-language, composition, atmosphere, and rhythm references; do not replicate existing IP frames or real actors exactly.

Ask only if an ambiguous role materially changes the output.

## STEP 3: Confirm Film Data and Reference Understanding

Before keyframe prompt generation, confirm film data and reference roles. Mention that the next step is keyframe image prompts, not video.

If the user explicitly asks to continue without confirmation, proceed.

## STEP 4: Write 6 Chinese Keyframe Image Prompts

After confirmation, write one Chinese image prompt for each shot. Each prompt creates one 16:9 landscape keyframe image for later image-to-video guidance. Show the six prompts to the user. If the user requests changes, patch only the affected shot prompt.

Prompt requirements:

- Chinese prompt text, except on-image English title/credits.
- One prompt per shot; never combine all shots into one image.
- Explicitly state 16:9 landscape, film-title keyframe, for later image-to-video.
- Lock composition, character placement, prop count, text placement, split-screen/frame/color-block structure.
- Character refs are identity cues only; the image must be cinematically restaged.
- English title/credits must be clear, readable, not misspelled, and not garbled.
- Do not insert the one-line plot as on-screen text.

### Unified keyframe image style lock

All keyframes must follow a high-saturation pop-art collage title-sequence style. Use saturated red, yellow, and blue as the main color system, with black and white for visual weight and layout support. The look must be high contrast, high saturation, and pure color-block based. Do not use soft gradients or complex textures.

Backgrounds use large flat geometric color blocks separated by clean straight lines. Large red fields often serve as the base; yellow and blue become high-contrast support blocks; black is used for silhouettes, vinyl, and heavy typography; white is used for fine lines, borders, highlights, and layout guides.

The visual language combines Pop Art, Swiss graphic design, Constructivist geometry, 1960s vinyl-record covers, retro suspense title sequences, and Japanese magazine layout. It should feel like a saturated retro title-design board, vinyl cover, and movie title keyframe, not a realistic film still.

Character treatment: silhouettes remain the default, but when the user uploads protagonist face references, the protagonist face must appear only in Shot 01 and Shot 06. The face must not be a raw realistic photo face or casual-photo face; translate it into the same high-saturation pop-art / graphic manga title-sequence style, preserving recognizable face shape, facial proportions, hairstyle, eyes/brows, and distinctive accessories through hard-edge color blocks, limited facial shadow shapes, restrained skin-tone or monochrome face blocks, and poster-like linework. Shot 02, Shot 03, Shot 04, and Shot 05 keep full-body silhouettes, backs, profile silhouettes, or archival graphic figures without clear protagonist face reveal.

Prop treatment: props may be realistic still-life cut-outs with clean edges, subtle unified shadows, and commercial product highlights. They must look cut and pasted onto flat geometric backgrounds, not placed in real space.

Typography: text is structural, not a simple label. Use modern sans-serif type, thin English, large titles, small layout text, vertical and horizontal text, edge typography, and color-block intersection typography. Optional English, katakana, or abstract type may appear as graphic design elements, but main title/credits must remain readable; no Chinese on-screen text.

Add ultra-thin white guide lines, crop marks, crosshair marks, grid lines, layout reference lines, and fine frames. These lines must be subtle and professional.

Forbidden: soft gradients, complex textures, realistic backgrounds, photo piles, casual-photo collage, film-still realism, 3D environment staging, heavy shadows, dirty horror style, gore, ghosts, cheerful music-video tone, Chinese on-screen text.

### Shot-specific keyframe rules

Follow the Chinese SKILL file as the canonical shot-specific prompt rules. In summary:

- Shot 01: saturated red/yellow/blue/black/white vinyl opening; geometric division, clear vinyl center; if protagonist face references exist, show one limited stylized pop-art / graphic manga protagonist face reveal, not a realistic photo face; otherwise use a hard-edge silhouette; <=5 props, title only, no crew credit.
- Shot 02: equal diagonal split-screen by cast count; pure black full-body silhouettes; continuous geometric interior background; no props; `STARRING {cast_names}`.
- Shot 03: orderly collage with complete white borders; central parallelogram running silhouette; four corner prop panels; show `EDITED BY {editor_name}` only if the user provided an editor; otherwise do not mention credit, blank label, or placeholder area.
- Shot 04: flat high-saturation evidence wall, no realistic wall; <=3 photos selected by plot analysis; foreground investigator silhouette; show `CREATED BY {creator_name}` only if provided; otherwise do not mention credit, blank label, or placeholder area.
- Shot 05: symmetrical confrontation; conflicting red/blue or warm/cool color-block sides; <=4 props inside designed panels; show `DIRECTED BY {director_name}` if provided; otherwise do not mention credit, blank label, or placeholder area.
- Shot 06: portrait-centered ensemble climax; if protagonist face references exist, make the stylized pop-art / graphic manga protagonist face or graphic cast portraits a central visual focus; never use raw realistic photo faces; giant `{title}` mask behind characters; props around portraits; show `PRODUCTION DESIGN BY {production_design_name}` only if provided; otherwise do not mention credit, blank label, or placeholder area.

## STEP 5: Generate Keyframe Images

After the user confirms the six image prompts, generate six keyframe images. Default to an image model suitable for complex layout, text, and graphic design unless the user specifies model/quality/resolution.

Defaults:

- 6 images, one per shot.
- 16:9 landscape.
- These are video anchors, not final posters.
- Suggested filenames: `shot01-title-vinyl`, `shot02-starring-split`, `shot03-rooftop-run`, `shot04-evidence-wall`, `shot05-confrontation`, `shot06-ensemble-title-mask`.

After generation, present successful keyframes and ask the user to confirm them. If an image execution fails, generation fails, or inspection finds a problem, first inspect available results and error information. Report the affected shot, known cause, uncertainties, and suggested remedy; preserve successful outputs. Do not automatically regenerate images or bypass the issue by generating or rerunning video. Only after the user explicitly requests regeneration may you correct the relevant prompt or execution issue and regenerate the requested keyframe. Ask the user to confirm the replacement.

## STEP 6: Compile Final Video Prompt from Keyframes

After keyframe approval, compile the final video prompt. The final prompt must return to the user's source-prompt style: dense cinematic title-sequence prose, not a technical tool instruction. Keyframes are mentioned once near the beginning as visual anchors; do not repeat `from @image X` in every shot and do not write the shot sections as field lists.

Video prompt compilation rules:

- Write the final video prompt in Chinese, following the authoritative Chinese template. Start directly with: `生成一支15秒16:9横版{film_type}电影片头。电影名字是《{title}》。`
- Then state in natural prose that the six keyframes anchor Shot 01–Shot 06, and that each shot inherits its corresponding keyframe's composition, character placement, prop count, split-screen structure, color-block layout, English credits, title layout, and main visual relationships.
- Keyframe reference should be mostly invisible: mention the six anchors once at the beginning, then write each shot as an actual finished-video description.
- Restore the source prompt's dense structure: overall style paragraph, atmosphere paragraph, motion-graphics paragraph, English-credit rules, Shot 01–06 paragraphs, transition paragraph, and BGM paragraph.
- Use the Chinese source-style shot headings, such as `Shot 01，片名/黑胶开场：`, rather than `Camera 1` or tabular fields.
- Every shot should read like a finished title sequence, not technical execution metadata. The keyframes decide layout; the prompt describes motion.
- Do not paste the one-line plot verbatim. Use only analysis results.
- English title and credits must be clear, readable, not misspelled, not garbled; no Chinese on-screen text.
- The video prompt may only include credit roles provided by the user. Missing roles must not be auto-filled with default fictional names; those shots describe only picture elements, layout motion, and transitions — no blank credit labels or placeholder credit areas.
- Every shot paragraph must include a concrete transition sentence. Do not rely only on one generic `Transition grammar` sentence at the end. Shot 01 uses an expanding vinyl-circle mask; Shot 02 uses diagonal panel collapse or a vertical mirror-cut black mask; Shot 03 uses the running figure's long shadow wipe; Shot 04 uses red-string cutting wipe; Shot 05 uses a giant title-letter mask, conflicting color-block recomposition, or prop-panel hard cut; Shot 06 freezes completely in the final 0.5 seconds.
- The final video prompt must end with a full transition paragraph, not a weakened one-line summary.

### Source-prompt style hard rules

The final video prompt must read like the user's original dense finished-title-sequence prompt, not like a model-card shot plan. Unless the user explicitly asks for a technical storyboard format, never use these structures in the final video prompt:

```text
Global baseline: ...
【Shot 1】...
【Shot 2】...
Start from @image1...
Cut to @image2...
Enter @image3...
```

Mention keyframes only once near the beginning as overall visual anchors. After that, every shot must use the source-prompt style headings, preferably in Chinese punctuation form:

```text
Shot 01，片名/黑胶开场：
Shot 02，主演登场/斜线主角团分屏：
Shot 03，屋顶追踪：
Shot 04，档案线索/主创：
Shot 05，对峙/冲突色块构图：
Shot 06，群像高潮：
```

The fixed final video prompt order is:

```text
1. 生成一支15秒16:9横版{film_type}电影片头。电影名字是《{title}》。
2. The whole sequence uses six keyframes as visual anchors...
3. Overall style...
4. Atmosphere...
5. Motion-graphics collage behavior...
6. English title and credit rules...
7. Shot 01...
8. Shot 02...
9. Shot 03...
10. Shot 04...
11. Shot 05...
12. Shot 06...
13. Transition grammar...
14. BGM...
```

The canonical source-style final prompt template is embedded in `SKILL.cn.md`; read and follow that exact Chinese section structure and keep the dense prose style even when operating from this English file. Resolve its four optional credit-segment variables before output: include the exact user-supplied role, name, entrance animation, and brief hold only when supplied; otherwise remove the entire segment. Never emit unresolved placeholders, absent-role descriptions, or conditional missing-credit explanations. Do not add a restriction that prevents one person from holding multiple user-supplied roles.

## STEP 7: Generate Video

Default to MiniMax H3 unless the user specifies another model or capability requires a different one. Use the six approved keyframes as video references. Do not use raw character references as the only video visual guide.

Defaults:

- Duration: 15 seconds
- Aspect ratio: 16:9
- Orientation: landscape
- Audio/BGM: enabled when supported
- On-screen text: English title and credits only

## STEP 8: Acceptance and Failure Reporting

- After keyframe generation, present successful images and ask the user to confirm them. Do not proceed to final video generation before approval.
- If an image execution fails, generation fails, or inspection reveals a problem, first inspect available outputs and error information without regenerating as a diagnostic step. Report the specific shot, symptom, supported cause, remaining uncertainty, and suggested remedy. Say the cause is unknown when evidence is insufficient.
- Preserve successful images and approved content. Reporting a failure is not regeneration authorization; accepting successful images does not authorize retrying failed images.
- Never automatically retry, regenerate images or video, switch models and rerun, or restart the whole workflow. Only after the user explicitly requests regeneration may you address the issue and execute the requested scope.
- When the user authorizes a replacement keyframe, modify only the necessary content for that shot and regenerate that image; keep other successful images. Ask the user to confirm the replacement.
- If video generation fails, likewise inspect and report first, then wait for an explicit user request before regenerating. Never rerun video automatically.
