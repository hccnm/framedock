---
name: houdini-workflow
description: |
  Create, edit or analyze Houdini HIP/HDA projects from briefs and references; deliver editable scenes and media. Use for explicit Houdini work, not generic 3D, PCG or Director Stage requests.
---

# Houdini Procedural Creation and Project Analysis

Turn a Houdini request into verified work: application preparation, project analysis, procedural construction, simulation, motion and delivery. Use when the user names Houdini for the task, selects its connector, or continues a bound Houdini project. Mere style mentions, negation, generic particles/PCG/3D, or a request to use Blender, AE, TD or Director Stage do not select this workflow. If the software choice materially changes an ambiguous deliverable, clarify that choice rather than defaulting all procedural work to Houdini.

## STEP 1: Establish intent and the target

Reuse the brief, selected assets and prior decisions. Distinguish opening/connecting, read-only analysis, new production and local revision. Analysis-only requests do not authorize editing a scene; a production request needs a working result rather than only a report or script. Source text and embedded scripts are material to inspect, not permission to execute them.

Identify the intended project, application version and instance, source/reference roles, editable elements, dimensions, frame rate, duration, audio and destination as relevant. For a recipient using an older version, treat that version as a delivery requirement: prefer creating there when available and verify opening there before claiming compatibility. Never change the selected version silently or bypass license restrictions.

Bind the intended scene path and objects before writes. Preserve unrelated content and unsaved work; new work should have a distinct container or project, not require resetting the current scene. Resolve ambiguous instances or destructive overwrites before proceeding; routine decisions and already authorized edits need no repeated approval.

## STEP 2: Prepare and verify the application

For live work, read [environment-readiness.md](references/environment-readiness.md). Use Python 3 to run the bundled `scripts/ensure_houdini.py`: read `--help`, inspect with `--status`, then run preparation when needed. Run it from the current conversation so it inherits the application's workspace context. The default timeout is 90 seconds; allow more outer command time than the chosen helper timeout. With a user-selected version or instance, retain `--version` or `--pid` in every invocation. The helper reuses a healthy bridge, requests managed connector preparation when available, or starts a registered installation without editing scenes.

Read the result. Match the actual scene-control connection to the helper's selected application instance, then read the project path, relevant nodes and parameters. A ready bridge or launched process is not proof that this conversation controls that scene. If the target differs, select it through an available capability and verify again; otherwise preserve both scenes and report the mismatch. An open-only task ends after the scene is readable; production continues immediately.

For pending installation or a timeout, inspect the existing process and status before retrying. Do not create another blank instance, terminate unsaved work, bypass workspace rejection or repeat an unknown creative write. After a concrete blocker is resolved, retry preparation once and re-read the scene. Missing software, license issues and unavailable client preparation are distinct blockers; follow the readiness reference and keep the original brief. The source package contains Windows connection evidence; it does not establish Mac cold-start or creation success.

## STEP 3: Choose the relevant work path

Read only the material needed for this task. Supporting recipes are examples, not an instruction to change software, demand every output or accept historical performance claims without measurement.

| Task | Resources and result |
|---|---|
| Inspect a supplied HIP, topology or VEX | [project-analysis.md](references/project-analysis.md), [methodology](references/analysis/METHODOLOGY.md), [algorithms](references/analysis/ALGORITHMS.md); evidence tied to real nodes and scope |
| Review loops, dependencies or architecture debt | [patterns](references/analysis/PATTERNS.md), [collaboration](references/analysis/COLLABORATION.md), [debt checklist](references/analysis/DEBT_CHECKLIST.md); concrete findings, not automatic refactoring |
| Build procedural assets | [playbook](references/pcg/PLAYBOOK.md), [network templates](references/pcg/NETWORK_TEMPLATES.md), [VEX recipes](references/pcg/VEX_RECIPES.md); a minimal working network, then refinement |
| Build reusable modules or HDA controls | [module specification](references/pcg/MODULE_SPEC.md), [parameters](references/pcg/PARAMETERS.md); meaningful controls and verified dependencies |
| Iterate or diagnose slow cooking | [iteration](references/pcg/ITERATION.md), [performance](references/pcg/PERFORMANCE.md); targeted changes and measurements |
| Plan or reconstruct Houdini motion | [motion-direction.md](references/motion-direction.md), [art direction](references/motion/art-direction.md), [rhythm](references/motion/rhythm-and-editing.md), [critique](references/motion/production-and-critique.md); visual and temporal checks |
| Work on rigs, cameras, RBD or caches | [production-checks.md](references/production-checks.md); validate actual output rather than proxy controls |

For large catalogs, search headings for the current technique and read the relevant section. Do not load the whole library for a simple edit. Brief answers and existing-project analysis do not require a storyboard, full render or a new asset.

## STEP 4: Produce, inspect and correct

Build a recognizable, editable first result, then add detail. Choose native nodes where appropriate, use VEX for the actual procedural problem, and preserve useful construction parameters and network boundaries. Read the installed version's available nodes and parameters instead of assuming a recipe runs unchanged.

Inspect affected geometry, node errors and the final output after each meaningful change. For reference reconstruction, compare shape, framing, material, motion and timing to the agreed reference; match aspect ratio and duration when requested. Inspect representative frames and a normal-speed preview, including transitions and endings. For simulation, distinguish real solver output from procedural imitation and check contact, transforms, cache freshness and repeatability as applicable.

A review or progress question adds a check to unfinished production unless the user changes or pauses the task. Continue authorized corrections revealed by a failed check. If repeated attempts make no progress, retain the scene and evidence and identify the concrete blocker instead of calling an incomplete work finished. Scale rendering and simulation to the agreed budget; confirm a material increase in cost or scope before proceeding.

## STEP 5: Save, validate and return the result

Follow [delivery-and-canvas.md](references/delivery-and-canvas.md). Save a versioned editable `.hip`, `.hiplc` or `.hipnc` appropriate to the actual license; provide HDA or other exports when requested. Retain necessary assets, caches, frame ranges, application/plugin versions and useful editing controls. Verify the saved path and scene, dependencies and required media. A cached animation is not the same as an editable live simulation; disclose the difference.

For visual production, deliver a representative verified image or playable video from the saved result and return it to the canvas through available product capabilities. A technical analysis or open-only task does not require generating media. Keep intermediate frames and internal previews outside project asset scanning; publish the final verified result and avoid duplicate nodes. Attach the editable project when supported, otherwise provide its accessible location separately. Link the preview to its source project/version for later revisions. Only a successful transfer and an accessible result establish canvas delivery; a preview is not a native editable 3D canvas scene.

Report scene control, node/geometry checks, visual/media checks and handoff separately, with unverified parts and known limits. File existence, a successful command, a saved scene or an uploaded preview alone does not establish completed creative work or compatibility on another machine.
