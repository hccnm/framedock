---
name: iwai-shunji-cinematic-aesthetics
description: Create original Iwai Shunji-inspired images or short films from stories and references, using emotional detail and natural light. For explicit Iwai-style requests, not generic Japanese styling.
trigger-words:
- Iwai Shunji
- 岩井俊二
- 情书美学
- 四月物语
- 花与爱丽丝
- 关于莉莉周的一切
- 燕尾蝶
- 电影感青春
---

# Iwai Shunji Cinematic Aesthetics

Use this Skill when the user explicitly asks for Iwai Shunji-inspired imagery, names a relevant film, or wants to continue an established Iwai-like visual direction. It can produce stills, image series, keyframes, short videos, and concise production plans. It does not reproduce film frames, claim an exact director formula, or turn ordinary Japanese imagery into this style without a clear request.

## Core operating rules

- User intent, uploaded references, subject identity, setting, era, aspect ratio, duration, language, and purpose override presets.
- Treat the style as an original transformation of observable principles: emotional detail, lived-in spaces, natural light with physical source, meaningful absence, restrained performance, and memory carried by objects or sound.
- Preserve the requested medium. A request for animation, illustration, or stylized graphics receives the same emotional and compositional logic without being silently converted to live action.
- If the user supplies people, places, props, scripts, or visual references, bind those materials strictly. If required assets are missing, create the smallest reusable character, prop, and scene anchors before shot production.
- For text or a clear script, create a reviewable execution brief or script in the project and wait for approval before expensive generation. Users may skip stages whose outputs already exist.
- **Mandatory video gate:** before generating any finished video, create a storyboard script document in the project, then generate storyboard reference images from that approved-or-presented plan. Show the storyboard document and images to the user and wait for explicit confirmation before starting video generation. Never jump directly from a concept, script, or single keyframe to the finished video.
- **Smart segmentation for long videos:** when the requested finished video exceeds 15 seconds, do not assume one generation call will deliver the full length. First author a storyboard document covering the full story, then intelligently split it into per-segment storyboards according to plot, scene, action change, location change, or available model maximum duration. Each segment must have a clear start and end state, fit the chosen model's actual max duration, and preserve character, location, light, prop, and palette continuity with adjacent segments. Combine the confirmed segments into the final cut and verify total runtime and continuity.

## Four visual modes

Choose one primary mode; explain any deliberate mix in terms of which layer comes from which mode.

| Mode | Reference direction | Observable rules | Story fit |
|---|---|---|---|
| Winter memory | *Love Letter* | cool daylight, warm wood, quiet interiors, empty seats and used objects, slow approach | reunion, remembrance, delayed understanding |
| Spring glimmer | *April Story*, *Hana and Alice* | soft daylight, fresh greens, pale clothing, chance encounters, light gestures | crush, friendship, departure, new beginning |
| Summer distance | *All About Lily Chou-Chou* | vivid greens, luminous sky, small figures in wide spaces, slight handheld or early-digital texture | loneliness, alienation, inability to belong |
| Urban drifting | *Swallowtail Butterfly* | lived-in clutter, worn materials, motivated mixed light, purposeful handheld movement, music and selective jump cuts | marginal life, identity search, brief warmth |

## Six-step production path

1. **Extract the emotional change.** Translate a theme into one relationship and a visible change: a hand releases a note, a gaze moves to an empty chair, or a person stops at a threshold. Do not leave emotion as adjectives alone.
2. **Lock the visual bible.** Record subject identity, clothing, props, location, season, weather, aspect ratio, light direction, palette logic, texture, camera distance, and fixed continuity items.
3. **Write the storyboard script document.** Before any finished-video generation, place a project document containing the synopsis, shot numbers, time ranges, framing, one main action per shot, camera behavior, start/end state, light/color, environmental movement, sound, continuity locks, and unresolved decisions. This document is the production source of truth. When the requested total duration exceeds the chosen model's actual maximum (for example, 15 seconds), split the story into per-segment storyboards inside the same document: each segment carries its own scene, action change, start/end state, and continuity anchors (character, location, light direction, prop state, palette), and the document records segment boundaries so the final cut reassembles them into the requested duration.
4. **Generate storyboard reference images.** Create one representative reference image per shot or a clearly labeled storyboard set from the storyboard document. Check identity, spatial relations, empty space, light direction, action readability, and continuity. These are reviewable references, not finished video frames by default.
5. **Request explicit user confirmation, then generate and assemble.** Show the storyboard document and reference images to the user. Do not generate finished video until the user explicitly confirms or approves revisions. After confirmation, turn the approved references or settings into motion, then connect picture, production sound, subjective sound, and original music only when they serve the story.
6. **Review and repair.** Inspect the complete image or video, not only the prompt. Correct the smallest observed problem while preserving successful identity, composition, light, and motion. Normally limit local repairs to two rounds.

## Visual grammar

Use these as physical, opt-in decisions rather than a universal filter:

- **Negative space and breathing room:** simplify background description, isolate the subject when solitude matters, and reserve sky, an empty classroom, a doorway, or an unused chair for emotional space. Do not fill every area with decoration.
- **Backlight with weight:** state where light enters, what it touches, and what remains readable in shadow. Overexposed backlight, soft bloom, volumetric rays, and lens flare are allowed when physically motivated; keep faces, props, and spatial depth legible.
- **Split-toned emotion:** let shadow and highlight carry different temperatures when useful—cool gray-blue in darker areas and restrained warm light in highlights, or a controlled cyan bias for alienation. Avoid automatic high saturation.
- **Analog memory, selectively:** `vintage film still`, `35mm film`, `analog film photography`, `heavy film grain`, `film artifacting`, `faded color`, and `low resolution` are optional texture modules, not a mandatory stack. Early-digital roughness and film grain are different choices.
- Keep skin, fabric, paper, wood, worn metal, and weather physically believable. Do not use “sad,” “dreamy,” or “cinematic” as substitutes for visible behavior.
- **General film-texture suffix:** when a photographic or cinematic film finish is compatible with the request, use this reusable suffix at the end of image-generation or video-generation prompts: `shot on 35mm color negative film, muted desaturated palette, low contrast gently faded colors, soft slightly hazy focus, subtle halation, fine even film grain, slight natural vignette`. Treat it as a finish module, not a replacement for subject, action, composition, lighting, or continuity instructions; omit or selectively shorten it when the user requests a clean digital, highly saturated, graphic, or otherwise incompatible finish.

## Prompt structure

For each image or shot, write in this order and remove unused fields:

`people and relationship + place and season + one main action + framing and composition + one camera behavior + light and color logic + environmental movement + emotional subtext`

For a still, describe the observation position and one decisive instant. For motion, describe start state → one main action and natural pause → end state, then add one primary camera movement and a few realistic environmental motions. References should be passed as actual inputs and assigned a role; do not replace a reference with a vague filename-only mention. When appropriate, append the general film-texture suffix after the content and motion description, so it cannot override the requested story or continuity.

## Model and delivery preferences from the supplied brief

Choose image-generation or editing capabilities that preserve character identity and propagate a consistent style across storyboard references. Honor the user’s selected model after checking its current inputs and limits. Prefer MiniMax H3 for video when its multimodal references and sound capabilities meet the approved storyboard. If unavailable, use an equivalent capability; explain material changes to motion, sound or cost before proceeding. After a technical failure, diagnose and retry once within authorization, then choose a supported alternative or report the blocker.

Deliver the actual media when tools are available, plus only the necessary visual bible, shot plan, prompts, and verification notes. If a capability is unavailable, label prompts, keyframes, or plans as not generated rather than presenting them as a finished film. Report checked facts separately from items still awaiting visual, motion, audio, or metadata verification.

## Reference files

- Image-specific templates and continuity: `references/image-workflow.md`
- Video, timeline, motion, and sound: `references/video-workflow.md`
- Four mode modules and error patterns: `references/visual-presets.md`
- Six-step asset and confirmation workflow: `references/production-pipeline.md`
- Acceptance and targeted repair: `references/quality-review.md`
- Factual source notes: `references/sources.md` (read only when the user asks for research or factual verification)
