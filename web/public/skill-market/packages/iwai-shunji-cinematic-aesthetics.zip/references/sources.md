# 资料依据与创作转化

以下访谈用于区分代表作的表达方式。预设、例子、时长和流程是本 skill 的创作设计，不是导演公开的技术配方。无需每次生成都检索；用户要求新信息或精确拍摄史时再核实。

- [Film Comment：Shunji Iwai](https://www.filmcomment.com/shunji-iwai-interview/)：人物与社会的距离、《燕尾蝶》的街头及音乐影像、不同作品的叙事与摄影差异。
- [Screen Slate：Music and Film: A Conversation with Shunji Iwai](https://www.screenslate.com/articles/music-and-film-conversation-shunji-iwai)：构图与自由摄影机运动、高亮窗户、音乐与数字摄影经历。
- [Objectif Cinéma：Shunji Iwai](https://www.objectif-cinema.com/interviews/112b.php)：宽景中的孤立人物、演员自摄素材及音乐对叙事的作用，这些偏好并非固定公式。
- [A Rabbit’s Foot：Shunji Iwai on 30 years of filmmaking](https://a-rabbitsfoot.com/editorial/confessions/shunji-iwai-on-30-years-of-filmmaking/)：书信与记忆、痛苦经验与明亮天空之间的关系。
- [第一财经：岩井俊二专访](https://www.yicai.com/news/873779.html)：细腻观察、日常微小行为，以及超出“小清新”标签的创作范围。

电影画面来自摄影、美术、表演、音乐等协作；例如篠田昇参与了多部代表作的摄影。分析某一画面以具体作品与镜头为准，避免把每项技术都归为导演独有或全片通用。

结构依据：[OpenAI 官方 Build skills](https://developers.openai.com/plugins/build/skills)。本 skill 使用简短入口和按需参考文件，没有绑定生成厂商，不包含原片素材或服务凭据。
