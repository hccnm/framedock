---
name: shot-by-shot-study
description: Analyze existing videos into shot tables, keyframes and study MP4s; offer an optional interactive HTML report after MP4 completion. For reference study, not footage generation or remakes.
trigger-words:
- shot-by-shot study
- video shot breakdown
- interactive video report
- shot analysis
- click-to-seek report
---

# Shot-by-Shot Study

Turn an existing film into traceable shot data, actual reference frames, a synchronized shot-study video and a concise canvas summary. After MP4 completion, offer an interactive HTML report through a user choice card. Preserve the user's source, scope, language and requested output. The Chinese companion is [SKILL.cn.md](SKILL.cn.md). Attribution and license are in [NOTICE.md](NOTICE.md) and [LICENSE](LICENSE).

## Delivery contract

Unless the user explicitly requests text only or opts out of video export, the default delivery contains the canvas summary and shot table, actual reference frames, quality records and a synchronized shot-study MP4. After the MP4 is exported, verified and delivered, present the section 7 user choice card. Create HTML only after the affirmative choice. Unselected or declined HTML is not a missing mandatory deliverable.

When requested, an interactive report must contain:

- A playable source video and actual keyframes.
- A shot table driven by the video's current time.
- Current-shot highlighting and automatic scrolling inside the shot-list container.
- A follow toggle and click-to-seek on shot rows.

A Markdown document, canvas text/table node, screenshot, HTML code block or animated MP4 cannot replace this interactive page. If a supported runtime or preview is unavailable, deliver the files that can be produced and identify the unfinished interaction or preview explicitly. Do not label a text-only result as a completed interactive report. Source code is an alternative only when the user explicitly accepts that handoff, not the default substitute.

## 1. Resolve scope and available capabilities

Use the selected or attached source. Default to the whole film and the user's interaction language. Ask only for missing media, ambiguous source selection, an unresolved material output choice, and the required post-MP4 HTML choice. Include the synchronized shot-study video as the default media deliverable, but do not add generative footage, music, dubbing or unrelated editing.

Read [references/design-adapter.md](references/design-adapter.md). Inspect the actual tools before mapping source access, metadata, timestamped frames, deterministic processing, artifact creation, canvas writing and browser preview.

Choose one route and record it:

- Platform-native measurement when supported tools provide reliable metadata, cut candidates and timestamped frames.
- Bundled local assistance only when the host actually exposes and permits the required execution environment. Inspect dependencies before running scripts. This skill does not grant tool permissions or override host restrictions.
- An observation draft when only visual playback is available. Mark estimated or unknown timing and do not promise precise synchronization.

If the bundled analyzer cannot start because a local dependency is missing, do not repeat the same command or abandon the analysis. Switch once to an available deterministic media processor: read verified stream metadata, run a scene-change probe, preserve every raw candidate, extract timestamped review sheets, and record that motion-track validation is unavailable. This fallback still supports measured cut timing, but it must not fabricate the bundled motion curve.

Keep all bundled scripts, renderer assets and references during installation or adaptation. If some dependencies are unavailable, mark those routes unavailable; do not silently remove the implementation and replace a requested interactive result with prose. A native replacement must implement and validate the same interaction contract.

## 2. Establish the source and authoritative data

Record the real source identity/version, accessible media path, duration, dimensions, frame-rate/time-base information and audio availability. Unknown values stay unknown. A filename, thumbnail or semantic summary does not establish that the video was inspected.

For an excerpt, record its verified source offset and analyze an accurately produced excerpt or a verified time mapping. Analysis time starts at zero. Variable-rate sources require presentation timestamps rather than average-frame-rate arithmetic.

Maintain authoritative shots.json and an analysis-state.json sidecar using [references/data-contract.md](references/data-contract.md). Canvas tables, requested HTML and video panels are derivatives of the same revision. Preserve measured timestamps and raw evidence; correct boundaries through actual measurement or a traceable recut operation, not by inventing values.

## 3. Measure and review shots

Read [references/analysis.md](references/analysis.md). Detect candidate cuts, extract early/late reference frames near 15% and 85% of each shot, then visually review suspicious boundaries. These are not exact first/last frames.

Use this review sequence:

1. Create one whole-film contact sheet to understand the action and provisional shot order.
2. Around clustered candidates, flashes, explosions or fast camera moves, create denser timestamped contact sheets.
3. Keep accepted boundaries in the authoritative shot list and record rejected candidates with a visual reason.
4. Extract two real reference frames per accepted shot only after boundaries are locked.
5. Batch frame extraction by phase rather than alternating analysis, annotation and report rendering shot by shot.

Review flashes, dark cuts, dissolves, similar reverse angles and unusual short/long intervals. One continuous take may change camera motion without becoming multiple shots. For uncertain movement or hidden internal cuts, inspect additional timestamped frames or the source video.

Use [references/local-tools.md](references/local-tools.md) only when its dependencies and execution route are available. Bundled analysis requires Node.js 18+ and FFmpeg/FFprobe. The upstream motion track is a sampled image-difference signal, not proof of camera motion. Never modify evidence or invent dialogue just to satisfy a validator.

## 4. Annotate with evidence

For each shot record its ID, interval/duration, framing, primary narrative category, camera motion, concrete visible content, evidence and confidence. Add transitions, text/audio, project-local character IDs and pacing judgments as relevant. Use the compatible vocabulary in the analysis reference.

Separate subject movement from camera movement and zoom from physical movement. Describe visible actions and spatial relationships. Dialogue requires actual listening, transcription or clearly labeled subtitle evidence. Subtitles do not prove voice identity. If audio was not inspected, say so.

Pacing labels are interpretations, not measured audience retention. When enabled, cover the selected scope consistently. For N shots over T seconds, distinguish shot frequency N/T*60 from transition frequency (N-1)/T*60; the upstream cutsPerMinute label uses the former convention.

## 5. Organize the canvas

Create or update a coherent project group when supported:

1. Source and scope notes, including evidence level and source revision.
2. Extracted reference frames or contact sheets, with corresponding shot IDs.
3. Shot analysis table with timing, framing/category, camera, visible content, text/audio, pacing and confidence.
4. Concise supported conclusions. Append an interactive report entry only after it is requested and an accessible report exists; never create empty entries or speculative links.
5. Quality results and unresolved items.
6. The synchronized shot-study video after deterministic export succeeds, unless the user opted out.

Reuse actual asset/node IDs and existing nodes where appropriate. Built-in media outputs may already be on the canvas; avoid duplicates. Group the whole-film sheet, dense cut-review sheets and accepted-shot keyframes as one evidence set after extraction. Create a concise summary node plus a structured shot table; requested HTML remains a separate complete package. scripts/canvas-plan.mjs creates local node-content plans and a Markdown table only. It neither writes Design nodes nor renders the interactive report.

## 6. Export and verify the synchronized shot-study MP4

Read [references/sync-video.md](references/sync-video.md). Unless the user requests text-only analysis or opts out, export the MP4 after validating shot data, exact source identity and range. HTML creation and acceptance are not prerequisites and must not block this step. Equal duration alone does not prove identical media.

Use deterministic editing. Preserve aspect ratio, source duration and original audio. Default to video above the panel for landscape/square sources and video beside the panel for portrait sources, unless the user specifies another layout. Burn in the current shot ID, source time range, shot duration, framing, camera movement and concise visible-action description. Keep an always-visible source timecode; add a frame number only when constant frame rate has been verified. Bind panel changes to shot intervals and keep scrolling brief at transitions so pausing, scrubbing and frame-by-frame study remain legible.

The upstream video-sync route additionally requires a supported headless browser for panel rendering. Use it only through an available permitted execution route. Before full composition, probe whether runtime crop/overlay commands actually take effect; a successful process with `Function not implemented` command replies is a failed animation. If unsupported, use `scripts/compose-sync-video.mjs`, which builds per-frame scroll expressions, transparent tail safety space and an immediate safe-anchor placement for the final shot. Both composers reuse the layout saved during panel generation and end with the source picture, including silent footage. Regenerate panels when the saved plan is missing or geometry changes. A native replacement must preserve the requested result. Do not silently replace requested scrolling with static cards.

Immediately apply the rendered-pixel, synchronization, text-readability and original-audio checks in section 9. Report “Synchronized shot-study MP4: completed” only after the actual file is accessible and required checks pass. Deliver that MP4 before the section 7 choice. Name its actual variant accurately; an information-card version without scrolling is not a scrolling version.

Interactive HTML and synchronized MP4 are different deliverables: the former supports navigation; the latter contains rendered motion but does not make its shot table clickable.

## 7. Offer the HTML user choice card

After section 6 succeeds, show a real single-choice user card, not just an ordinary chat question. Do not show this completion card while MP4 is running, failed, or awaiting required checks. Translate the card into the user's interaction language while preserving both choices and their order.

- Title: **Interactive HTML report**
- Question: **The synchronized shot-study MP4 is complete. Would you like an HTML report with click-to-seek, current-shot highlighting and automatic shot-list scrolling?**
- Choice 1: **Yes, create it** — Reuse the completed shot data, source video and keyframes to build and verify the interactive HTML report.
- Choice 2: **Not now** — Keep the completed MP4, shot table and keyframes without creating HTML this time.

Require one explicit choice. Do not preselect an answer or treat dismissal, timeout or silence as consent.

- **Yes:** record acceptance for the current source and analysis revision and immediately execute section 8. Do not merely promise future work, repeat the start question, rerun completed analysis, or re-export MP4.
- **Not now:** record `skipped_by_user`, preserve completed assets and finish normally. Declined HTML is not a failure or missing deliverable.
- **No answer:** record `awaiting_user` and stop. Do not begin HTML production.
- An unambiguous affirmative chat reply while this card is pending has the same meaning as choosing Yes. Clarify an ambiguous reply once, without inventing consent.
- Respect an earlier explicit HTML refusal or text-only instruction without repeating the card. If the user explicitly requests HTML only and declines MP4, execute that request without creating an unwanted MP4.
- In the default flow, an early generic request for the full package does not replace this post-MP4 choice. Do not repeat a choice already made for the same source/analysis revision after resuming, duplicate clicks, or status checks. A user-initiated change of choice resumes only unfinished work.

Use the decision and revision state described in [references/data-contract.md](references/data-contract.md).

## 8. Produce, open and verify the requested HTML report

Execute only after section 7 acceptance or an explicit HTML-only request. Reuse the verified source, shot ledger, annotations, frames and checks. First inspect the bundled builder, preview server, follow resources and actual data, then verify permitted execution, file-writing, dependencies and preview capabilities. Distinguish implementation present, runtime available, files created and interactions verified. User consent does not override host restrictions.

Read [references/interactive-report.md](references/interactive-report.md). With an authorized local execution route, use scripts/build-report.mjs to create the complete report folder. It wraps the upstream HTML renderer, includes the follow-scroll extension and copies the source video and keyframes into relative paths. It does not re-analyze the film or verify source identity.

Run the report in an actual JavaScript-capable HTML preview or browser. Where a local server is appropriate, scripts/serve-report.mjs binds only to loopback and supports HTTP byte ranges required for reliable seeking. Use the actual address it prints. Do not assume localhost is shared between different machines.

A canvas text node is a summary and entry point, not an executable HTML container. Deliver the entire report folder or ZIP, including video and frames. Do not upload only index.html and break its media paths. When the host only supports text/table/media nodes, provide a report link or downloadable package and use a real browser for interaction. Respect the browser tool's own prerequisites and permissions.

If shell execution is unavailable but supported artifact tools can create a runnable HTML application, preserve the same player/time/highlight/follow/seek contract using the supplied renderer as implementation reference. Do not claim this route exists without checking. If execution or dependencies are blocked, set HTML to `blocked`, preserve the completed MP4 and report the precise missing condition. Do not silently replace HTML with a Markdown code handoff; source-only delivery requires explicit acceptance and must be labeled unbuilt/unverified.

Verify actual playback across cuts, highlighting, list following beyond the initial viewport, click-to-seek, backward seeks, the final shot, and follow-toggle behavior. A practical acceptance pass is: confirm the video and every keyframe load; jump to a middle shot and let playback cross cuts; verify the final-shot highlight and list scroll position; disable follow and jump backward without forced scrolling; re-enable follow and confirm the list returns to the current shot. Record actual outcomes in the report checks; file generation and syntax checks are not interaction tests.

### Automatic completion, not a manual handoff

After acceptance, follow [references/automatic-html.md](references/automatic-html.md) without another start confirmation. The executor must materialize a real HTML file, bind the already-known original video and verified frame files with portable relative paths, start an authorized preview service when needed, open its actual address in the supported browser, test the interactions, and deliver the complete bundle plus a real entry point. Do not stop at source code, instructions, or an untested claim that a browser is unavailable.

If only Markdown source exists, extract its HTML into a real file through an authorized file-writing surface, remove Markdown fences, replace mandatory file-picker initialization with the verified relative media binding, and check the resulting application. Existing contact sheets are not independent keyframe files: reuse verified individual frames, or extract only missing frames from the original through available media capabilities. Never substitute the annotated MP4 for the original, invent measured timestamps, or change existing source/generated asset paths to make the report work. A package may contain explicitly tracked copies.

A file picker may remain an optional recovery control, but must not gate normal startup. Manual copying, saving, selecting the known video, or clicking an extract-frames button is not the default user task. Browser autoplay restrictions may require a normal Play click during verification; this is different from missing source binding. If an actual capability, codec, permission or browser-surface blocker remains, record the exact evidence and preserve created files. Ask only for the minimum necessary user action; source-only or manual handoff requires explicit user acceptance. File creation is `created_unverified`, not `verified`; successful structural tests do not prove real playback.

## 9. Verify, recover and deliver

Use [references/quality.md](references/quality.md). Keep passed, failed, skipped and unverified checks separate. Numeric checks do not establish visual accuracy. Validate rendered pixels with contact sheets covering the first shot, stable frames after cuts, and early/middle/late frames of the final shot; the final highlighted row, thumbnail and all text must be fully visible. Preserve successful artifacts and inspect task state before retrying a timeout; make at most two targeted retries before reporting a persistent blocker.

Changes to annotations invalidate affected report/panel derivatives. Boundary changes also invalidate IDs, timing, frame mappings and affected annotations. Source changes invalidate incompatible evidence. Keep revisions and actual node mappings so the task can resume without duplicating the canvas. Reuse the recorded HTML choice only for its bound source/analysis revision; do not relabel old outputs as a new revision.

Deliver real files or accessible report links, analysis scope, shot count, timing precision and unresolved items. The default set includes the canvas summary/table, evidence frames, quality records and synchronized shot-study MP4. Show the section 7 card after video completion. The interactive HTML bundle becomes an additional requirement only after acceptance. Declined HTML is not missing; requested but blocked HTML remains explicit without invalidating the completed MP4. Do not claim installation, browser verification, canvas interactivity or video export that did not occur.
