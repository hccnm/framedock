---
name: architecture-flythrough-video
description: Create editable 3D scenes, 2560×1440 previews, and flythrough videos from building or city briefs using reference research, Blender, FPV design, and visual anchors. Not for complex character acting.
---

# Architecture Flythrough Video

## 1. Goal and deliverables

Turn architectural or urban requests into a researched, editable Blender scene, a controlled FPV camera move, and a generated final video.

Deliver:

- `project.blend`: editable geometry, named scene parts, camera rig, animation, basic lighting, and required references.
- `previs.mp4`: native Blender RGB preview at 2560 × 1440, 16:9; lock the approved version.
- `style_anchor_01..04`: 3–4 styled images with traceable source frames.
- `final.mp4`: H3 video generated from the Blender RGB video, approved consistent images, and the final prompt.
- `visual_bible.json`, `style_consistency_qa.json`, `h3_prompt.txt`: visual specification, group QA, and submitted prompt.
- `reference_manifest.json`, `model_qa.json`: source evidence, observed versus inferred features, model mappings, and geometry QA.
- `shot_manifest.json`: duration, FPS, route, time states, lens, speed profile, versions, and approvals.

Communicate in Chinese by default; tool parameters and code may use English. Follow an explicit user language preference. The English entry file does not change this behavior.

## 2. Responsibilities

The directing agent directs the workflow: interpret the brief, research references, plan space and model fidelity, control Blender, design the FPV move, select visual states, write image and H3 prompts, organize approvals, and locate failures.

Blender is the spatial and motion master: silhouette, proportions, landmark components, layout, indoor/outdoor connections, camera path, continuous movement, basic animation, previews, and optional lighting references.

GPT Image establishes one visual world and propagates it across the selected states. H3 uses the Blender RGB video as its only video input and the approved image group for the final appearance.

Prefer H3 for the final transformation because this workflow needs a video reference and several consistent visual anchors together. Honor a user-selected model after verifying the same input capabilities. GPT Image is a recommendation for identity-preserving style propagation, not a requirement. If either recommendation is unavailable, confirm an equivalent route when output or cost changes; do not silently omit references. In the following workflow, model names describe these roles rather than exclusive provider bindings.

## 3. Scope

Support individual buildings, real landmarks, complexes, skylines, streets, districts, exterior-to-interior flights, and stylized architectural environments. Prioritize hard surfaces and clearly structured spaces.

Complex character acting, animals as principal subjects, dense crowds, soft-body character animation, and detailed facial or body performances are not primary capabilities. If requested as secondary elements, preserve architectural clarity and camera stability.

## 4. Defaults

- Duration: 10–15 seconds, chosen for the route and subject; do not exceed 15 seconds.
- Complete Blender video previews: native 2560 × 1440, 16:9, 100% render scale, square pixels. Never upscale a smaller render to claim compliance. Small internal static tests are allowed; approval A videos cannot be downgraded.
- One continuous take unless the user explicitly requests cuts.
- Realistic cinematic lighting; `Dynamic FPV` camera intensity.
- Exactly 3–4 style images: the state at second 0, the state corresponding to the end, and 1–2 distinct intermediate states. Style every selected image and use all of them as all-purpose references.
- H3: one generation by default; no unlimited retries.
- Approval A covers the Blender model and camera preview. Approval B covers the complete image group after consistency QA.
- The Master Style Frame is an internal step, not a separate approval.

## 5. Required references and workflow

### 5.1 Research and modeling

Research before modeling. Do not build a named landmark from memory alone. Before searching, read [modeling.md](references/modeling.md), including its active image research, reference gate, and embedded design-image prompts. No external Skill is required.

1. Actively search for and inspect relevant online images using the subject, location, aliases, and necessary facade, side, roof, entrance, and interior views. Prioritize user images and supplement missing coverage online.
2. Preserve usable images or accessible visual resources. Record sources, viewing evidence, observed structure, and gaps in `reference_manifest.json`. Text searches, image titles, URL lists, and unviewed downloads do not count as completed research.
3. Assess coverage for the actual route. Missing identity, major proportions, signature parts, or traversed spaces require a specific gap explanation and a question about generating design references. Do not generate substitute designs or invent missing structure before consent.
4. If authorized, use the embedded exterior, aligned-view, and spatial/detail prompts to fill only the gaps. Mark generated and inferred regions and check consistency. If declined, wait for supplied evidence or a user-selected reduction of scope.
5. After the reference gate passes, map observed features to Blender parts. Build an internal blockout, refine it, and compare actual geometry with references. Model QA must pass before approval A; an abstract blockout is not a finished architectural preview.

The conditional reference-generation question is not a new routine approval. Reuse existing authorization for the same scope. The usual approvals remain A and B.

Research real subjects across relevant viewpoints, roof plans, distinguishing details, entrances, interiors, and camera corridors. Explain conflicts with user references and let the user choose; do not silently replace their design.

Use layered fidelity: preserve identity, silhouette, proportions, signature components, major openings, layout, indoor/outdoor connections, and camera-adjacent geometry. Simplify minor ornament, distant repetition, and microtextures. Model nearer or longer-visible features more carefully.

Read modeling.md before any Blender modification. It retains coordinate and scale rules, connection checks, safe saves, collections, editable construction, instances, same-model calibration, and approved-asset reuse.

Use `scripts/prepare_scene.py` as needed to initialize collections, a camera rig, 24fps/10–15-second timing, and native preview dimensions. Preserve approved assets.

### 5.2 FPV, previews, and optional Cycles

Use `Smooth Cinematic`, `Dynamic FPV` (default), or `Extreme FPV`. Suggested durations: simple buildings 10–11s, medium complexity 11–13s, complex landmarks or exterior-to-interior routes 13–15s, city flights 13–15s.

Architectural route grammar: establish → approach → facade arc/orbit → signature reveal → change height or side → motivated entrance → continuous entry → interior reveal → final composition. City grammar: high establishing view → descend → accelerate through streets/buildings → foreground parallax → narrow passage → turn/skim → climb out → skyline landing. These are starting points, not mandatory routes.

Start with Workbench, use Eevee when needed, and move from blocking to polish. Every complete video preview uses 2560 × 1440; higher resolution does not replace model QA. After A, lock Geometry + Camera. Cycles is optional: favor 3–4 low/moderate-sample denoised state images rather than a full high-sample animation. H3 always receives Blender RGB video.

Before camera design, changes, or preview work, read [camera-design.md](references/camera-design.md): planning, intensity, rig/target, lens, roll, angular speed, manifest, representative views, iteration order, A, and Cycles.

Inspect researched images. Authorized pre-model design images may be shown as concept references; these are not Blender preview inspection images. Delivery boundaries must not be used to skip research. Find a non-publishing inspection method if needed; if actual inspection is impossible, report the limitation rather than passing QA.

**Preview delivery:** During preview creation, inspection, revision and approval A, keep extracted images, blockout screenshots, test renders, render sequences and contact sheets as internal project files. Show the preview video with findings in text and timestamps. This delivery choice never cancels internal visual checks. After A, show all 3–4 formal style images for B.

### 5.3 RGB and consistent style images

Before GPT Image, H3, final QA, or failure recovery, read [failure-recovery.md](references/failure-recovery.md).

After A, retain the checked RGB video and locked Geometry + Camera. Every visual style, including sketch, anime, and cyberpunk, follows the same RGB route; do not substitute image-only generation.

Follow this order:

1. Establish one **Visual Bible**: time, weather, sky, world-space sun, key light, shadows, materials, white balance, exposure, grading, and style.
2. Select the state at second 0 and the state corresponding to the end, plus 1–2 distinct intermediate spatial states: **3–4 images total**. Style every one. Follow failure-recovery.md for real source-frame timestamps. Use “second X” in displayed labels and H3 prompts, not first/last-frame role labels.
3. Generate the **Master Style Frame** from one representative Blender image and the Bible. Check it internally; do not request a separate approval.
4. For every other image, simultaneously provide its own Blender image, the same master, and the same Bible. Geometry and composition follow its own Blender image; appearance follows the master. Do not copy the master view, independently redesign each image, or propagate sequentially from one generated image to the next.
5. Run **Style Consistency QA**: compare each image with its source, master, and Bible, then cross-check the group. Inspect sky, time, weather, sun/light direction, material identity, white balance, exposure, grading, subject identity, architecture, and overall style.
6. Regenerate only failing images, preserving successful ones. Recheck repaired images and the entire group. A failing group cannot be presented as ready for B or sent to H3.
7. Once all pass, show the entire group for **B**. Lock Style only after approval of those exact versions.
8. Submit Blender RGB video + the approved 3–4 images + the final prompt, **using H3 all-purpose multimodal reference mode only**.

Preserve camera angle, perspective, composition, major geometry, landmark identity, placement, and silhouette. Appearance changes must follow the Bible. Realistic priority: `Identity > Geometry > Spatial Accuracy > Camera > Lighting > Beauty`. Stylized priority: `Identity > Composition > Camera > Visual Impact > Style > Fine Geometry`. Identity is always protected.

At H3 prompt generation, read [h3-prompt.md](references/h3-prompt.md) and its active embedded expert files. The package contains the adapted framework and all 11 source reference files; inactive modes are isolated in a maintenance archive. No separate Prompt Expert installation or invocation is required. Assess reference fit, reuse confirmed constraints, clarify only material gaps, write the six-field multimodal prompt, and self-check. Preserve spatial, identity, appearance, camera, and continuity constraints inside those fields. H3 runs once by default.

Run `scripts/validate_output.py previs.mp4 --previs --decode-check` to enforce preview dimensions; add expected FPS, duration, frame count, and codec from the manifest. Validate the RGB input and final output. File checks cannot replace visual QA.

## 6. Approvals and state

A: show `previs.mp4` for architectural accuracy, emphasis, route, speed, and entrance approval; then lock Geometry + Camera.

B: after complete group QA, show all 3–4 images together with times and states. Explain their shared reference role; then lock Style after approval. No separate master approval.

Record stages, file versions, QA, and approval evidence in `shot_manifest.json`. “Next” means complete the next valid stage, not skip QA or A/B. Do not ask again for approval of the same clearly approved version.

Before H3: A is valid; RGB comes from the locked scene/camera and passes file/visual QA; 3–4 images share a Bible and pass group QA; B covers the current group; the prompt matches those inputs; the actual endpoint is in all-purpose reference mode and supports video + 3–4 images + prompt. Never switch to endpoint-constrained image modes based on picture timestamps. Fill missing requirements first; do not fabricate support or silently omit inputs.

Geometry/camera edits invalidate affected RGB, style images, and approvals. Style-image/Bible edits invalidate group QA, B, and Style lock. Roll back only affected layers according to the detailed reference rules.

## 7. Recovery

Identity errors → references/geometry; proportions, entrances, or spatial errors → geometry/layout; route/speed → camera/preview; lighting-reference errors → lighting/Cycles; style inconsistency → failing images only; drift with correct RGB and style images → H3 prompt/conditioning.

Do not rerun the whole chain for local failures. Allow at most two automatic image-repair rounds by default. If still failing, report the concrete blocker, preserve successful work, and stop spending on generation. Do not ask the user to treat failed QA as passed. Further H3 generation follows user feedback and layer-specific diagnosis.

## 8. Full workflow

```text
User brief + user-reference priority
 → Active online image search + inspection + recorded evidence/gaps
 → Sufficient? Yes: reference gate
               No: ask about generated references → if authorized, generate/check
 → Reference gate → internal blockout → calibrated editable geometry
 → Model QA → FPV planning/rig → 2560×1440 Workbench/Eevee RGB preview + QA
 → A → lock Geometry + Camera
 → Visual Bible → second 0 + 1–2 intermediate states + ending state
 → Master → each other Blender image + same master + same Bible
 → Group style QA → repair only failures → recheck group
 → Show complete group → B → lock Style
 → RGB + approved 3–4 images + embedded-expert prompt
 → H3 all-purpose reference mode, one generation → final QA
 → final.mp4 + project.blend + RGB + style images + records
```

## 9. Product principles

Accuracy before polish. Camera design before generation. Preview before expensive work. Optional Cycles lighting references, not mandatory full animation. One visual world through Bible, master, propagation, and QA. One continuous cinematic FPV take by default, including visually credible paths beyond practical drone limits. A locks model/camera; B locks the image group. Preserve approved versions, recover by layer, and deliver an editable Blender project alongside the video.
