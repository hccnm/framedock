---
name: plot-twist-ad-generator
description: Create a product-led plot-twist ad from a product image or description and one confirmed benefit; deliver concepts, script, director brief, and video. Not for testimonials or unrelated fiction.
trigger-words:
- plot twist ad
- plot-twist commercial
- product twist ad
- product story ad
- story-driven product ad
- 商品剧情广告
- 剧情反转广告
- 剧情带货广告
- 商品卖点广告
- 用商品图做剧情广告
- 剧情带货
---
# Plot-Twist Ad Generator
Create a product-led plot-twist advertisement from a product image or description and one confirmed benefit. Choose a conflict-building story world, then let the product benefit directly cause the visible plot twist; characters and the world only establish pressure and react to it. Use dialogue or voice-over when it makes the conflict, benefit, or reversal clearer, while keeping the decisive change visible on screen.

## STEP 1: Identify the product and confirm one selling point
Start from the user's product image or product description. Identify only visible product category, structure, quantity, controls, attachments, container relationships, and safe handling. Confirm the product name, one user-confirmed core selling point, one usable product image, and the primary reference when several exist. Do not infer performance, capacity, power, safety, health, or technical claims from appearance.

After the product and selling point are confirmed, present 7-8 concise story-world choices selected specifically for that product-benefit pair, with a custom-answer option. Each choice should name a concrete conflict, pressure, scale contrast, or social rule that lets the selling point create a visible reversal; do not use a fixed world menu or choices that merely change costumes. If the user already specified a world, use it and skip this menu.

## STEP 2: Develop and select the product-led idea
Develop a user-requested number of concise alternatives. When the user does not specify a number, provide a compact, useful set rather than enforcing a fixed count. Each alternative should state:
- the visible problem, pressure, or wrong expectation before the product appears;
- how the product first enters the story and immediately performs a reference-supported action;
- the direct state change caused by the confirmed selling point;
- the product reality the audience understands after that change.

By default, do not show the product in the opening setup. Establish the problem first, then make the product's first clear entrance part of the turn: **product appears -> product activates or is used -> situation visibly changes**. Show it earlier only when the user explicitly requests that structure or the selected premise cannot work otherwise; record the exception in the approved script.

The reversal must be understandable on first viewing without decoding a metaphor. Within the benefit event, create a large, concrete before/after relation: attacker becomes defender, burden becomes surplus, excluded person becomes chooser, impossible work becomes visibly complete, or another equally legible inversion. Dialogue may label what the image already proves; it cannot manufacture a reversal the image does not show.

For disputes, exchanges, or value reclassification, prefer an observable target swap at comparable visual scale. Reuse the same composition or action verb when helpful—for example, two hands fight over money before the benefit, then the same two hands fight over the product after it. Avoid making a tiny worn item, eye movement, several simultaneous gestures, or an interpretive final line carry the main change.

### Mandatory idea tests
- **Benefit cause:** removing the product and selling point must remove the reversal.
- **Product entrance:** the first clear appearance participates in the turn instead of decorating the opening.
- **Direct inversion:** the benefit produces a visible changed state, not only a test, claim, private taste shift, symbolic prop, or final line.
- **World contribution:** the world adds a rule, pressure, or scale contrast but is not the source of the reversal.
- **Integrated payoff:** the selling-point action proves the benefit and causes the memorable change in one causal event; do not bolt a separate demonstration or unrelated second climax onto it.
- **Readable motivation:** any changed choice follows visible or audible benefit evidence strong enough to justify that choice.

Read `references/creative-twist.md` only when the first ideas remain generic, indirect, or replaceable by an ordinary object. If the user asks for new directions, produce a new set and stop again for selection.

## STEP 3: Write the selected text script
Expand only the selected direction. Use the confirmed duration rather than imposing a fixed runtime. Choose enough purposeful shots for that duration, with one primary action and one new fact per shot. Reserve a readable product ending appropriate to the final copy and frame; do not hardcode a fixed number of shots or seconds.

The script is the source of truth for timing, product entrance, benefit action, motivation, state inversion, object continuity, dialogue, ending, and physical state. It must show this order:
1. opening pressure or wrong expectation, with the product hidden by default;
2. the product's first clear entrance as part of the turn;
3. reference-supported activation or use and immediate product feedback;
4. visible or audible benefit evidence;
5. a clear reaction and motivated new action;
6. the concrete before/after state inversion;
7. a stable product ending that summarizes the newly proven value.

### Motivation bridge
When a character changes their valuation or choice, establish: **prior judgment -> personally experienced benefit -> clear attitude change -> motivated new action**. Use behavior, gaze, sound, object choice, or loss of access that reads at normal speed. A tiny smile, slight finger tap, or closing line alone is not enough for an expensive or dramatic choice.

### Physical-state ledger
For every shot, record each important object's count, holder, location, container state, support, contact point, and start/end state. Contents cannot simultaneously remain on a person and inside a container. If an omitted action changes a worn item into a stored item, use a hard cut and declare the new shot's starting state. Containers must show plausible lid, slot, occupancy, gravity, and support relationships. During struggle, characters grip load-bearing body surfaces rather than lids, hinges, delicate attachments, or loose contents. The hero shot must define object count, container occupancy, lid state, and whether anything remains outside the container.

Use dialogue when it materially improves comprehension. Subtitles remain off unless the user asks for them. If dialogue exists and the user has not decided, ask once before generation whether to burn subtitles.

Read `references/evidence-twist.md` only when the plot genuinely depends on theft, planted evidence, hidden objects, documents, identity, quantity, or a knowledge trap.

## STEP 4: Confirm and lock the script
Show the detailed script, the opening state, the product entrance, the selling-point proof, the visible inversion, the motivation bridge, and the ending. Ask for confirmation or revision before compiling a final prompt or spending generation credits. Selecting an idea authorizes expansion only; explicit confirmation of the detailed script authorizes generation.

After confirmation, lock the latest script as the only source of truth. Preserve the integrated selling-point event and direct changed state. Removed dialogue, actions, props, characters, physical states, and endings are forbidden from returning. Do not reintroduce an earlier rejected version during prompt compilation or retry.

## STEP 5: Choose output settings and compile the video prompt
Do not hardcode a video model. Use the current available model capabilities and the user's explicit model choice when provided. Before generation, present supported frame/aspect-ratio choices and supported resolution choices, and obtain the user's selection; also confirm duration and audience-facing language if still missing. Do not repeat decisions already confirmed. Select or validate a model that supports the chosen duration, frame, resolution, references, audio needs, and generation mode.

Read `references/video-execution.md`, then compile the approved script into a time-coded director brief. For premium/cinematic, multi-character, material-sensitive, or text-layout work, also read `references/visual-quality.md`. Read `references/failure-recovery.md` only after a matching risk or failure.

Use this table: `time | only action | visible people/speech | start state | end state | new information | object state`.

The final prompt must:
- keep one main action per shot and declare each state handoff;
- lock character silhouettes, wardrobe, screen axis, speaking roles, and silent mouths;
- keep product identity, count, handling, container relationships, and support physics consistent with the reference and approved ledger;
- preserve the order: opening pressure -> product entrance -> benefit proof -> motivation -> direct inversion -> product ending;
- use scene-motivated lighting with believable direction, falloff, exposure, contact shadows, skin response, and material reflections;
- treat requested palettes as restrained grading, not permission for source-free colored light, universal rim light, oily highlights, plastic skin, crushed shadows, fake haze, or game-render sheen;
- finish the plot before the stable product hero shot.

## STEP 6: Product ending and exact copy
When the user wants direct-rendered copy, specify the exact wording, line count, alignment, position, hierarchy, spacing, safe margins, material/light relationship, and stable reading hold. Forbid all other readable text. Use post-produced copy only when requested, when a targeted direct-text retry has failed, or when deterministic legal accuracy is required.

The ending must obey the physical-state ledger. Define whether the product is assembled, worn, stored, open, closed, occupied, supported, or connected. Do not copy carrier artifacts, player controls, floating presentation, or impossible support relationships from a reference image unless the user explicitly wants them.

## STEP 7: Generate only after approval
Generate only after explicit user confirmation of the detailed script and output settings. Create or update one concise canvas screenplay containing the approved script, timecodes, product states, selling-point proof, motivation bridge, direct inversion, and ending. Do not create storyboard images or a separate approval report.

After a successful generation, do not automatically regenerate, retry, repair, replace audio, or revise the story. If generation or required post-production returns an explicit error, report it and wait for the user's decision. If the user later reports a defect, discuss the smallest correction and obtain explicit approval before any credit-consuming regeneration.

## STEP 8: Subtitles and delivery
When burned-in subtitles are requested, transcribe the actual generated audio and filter the transcript against the approved spoken lines. Keep only approved character dialogue or approved voice-over. Exclude product copy, end cards, slogans, titles, names, labels, interface text, lyrics, laughter, cheers, and sound-effect descriptions.

Before formatting, normalize subtitle text separately from the spoken audio: remove all punctuation and decorative marks from subtitle text, including commas, periods, question marks, exclamation marks, colons, quotation marks, ellipses, dashes, and Chinese enumeration marks. Do not change the spoken audio or the approved script. Merge adjacent transcript cues that belong to one uninterrupted utterance by the same speaker, so each utterance becomes one subtitle block whenever readable. Avoid multiple short blocks for one sentence, overlapping blocks, stacked paragraphs, or more than one subtitle layer. Use a line break only when the single block exceeds the safe width; keep it to the minimum readable number of lines.

No retained subtitle may end after the product hero shot begins. If a cue crosses that boundary, trim its end time to just before the hero-shot start. If the trimmed cue becomes too short to read, shorten the spoken line before generation or revise the script timing so the line finishes earlier; do not let dialogue subtitles intrude into the product ending. Remove cues that begin at or after the hero-shot start and cues that match or paraphrase the ending copy. Preserve transcript-derived timing for retained speech, but use the merged and punctuation-free text for the subtitle content.

Burn subtitles as a visible, opaque text layer. Never use a transparent subtitle source, zero-alpha color treatment, hidden overlay, or any compositing chain that also makes the subtitle layer transparent. Before delivery, verify that the rendered subtitle layer is non-transparent and that each retained block is present during its assigned interval. If subtitles are not visible, do not deliver that file; perform one deterministic subtitle-burn repair and report the issue.

Once required subtitle or deterministic finishing work succeeds, deliver the result without media analysis, preview transcodes, contact sheets, frame extraction, audio probing, visual inspection, or a separate acceptance report.
