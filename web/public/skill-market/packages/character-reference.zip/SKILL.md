---
name: character-reference
description: Generate character look references and three-view sheets
---

# Character references

Establish reusable appearance references for later images and videos. Reuse existing character images when they cover the required views and maintain a consistent appearance; a one-off character image does not need a separate character sheet. Characters who are only heard, such as a mother speaking on the phone throughout, do not need look references.

- Default to a 16:9 landscape reference image unless the user specifies another aspect ratio. Its aspect ratio is independent of the final video's; keep orientation wording and generation parameters consistent.
- A general character sheet includes front, side, and rear full-body views plus a facial close-up, clearly showing facial identity, body shape, side silhouette, rear clothing, and carried items.
- The views show the same person turning, with consistent identity, build, hairstyle, and current clothing. Full-body views can share a standing pose and character height, while the close-up gives facial features enough space. Asymmetric details such as straps and accessories follow camera projection rather than switching sides through mirroring.
- Specify views precisely, such as a full-body left profile or rear view, so they do not all become similar three-quarter views. Leave room above the head and below the shoes when a complete silhouette is needed. Choose the layout within the agreed aspect ratio according to the view count and downstream reference capabilities, without a fixed panel grid or left-right ratio.
- For a general identity master, use a clean background, even lighting, and a natural pose. Strong emotions, handheld objects, injuries, or special lighting can have separate story-state references; retain them when they are part of the current request.
- When referencing the sheet in later scenes, specify that it supplies the character's appearance, rather than importing its multi-figure layout into the shot.

For a new general character sheet, state the agreed views and the identity and appearance details that must match. If a user reports missing views or inconsistency, supplement or revise the affected views. When reusing a reference, add only the missing angles or key appearance details actually needed by downstream shots.
