---
name: vox-style-video-generator
description: Turn a topic, article, or report into an approval-first collage or cutout explainer with keyframes, motion planning, narration, music, and assembly. Use for science and education videos.
trigger-words: [解释视频, Vox风格视频, 科普视频, 纪录短片, 教育视频论文, 自动化视频论文, one prompt to video, explainer video, Vox-style video, keyframe-to-animation]
---

# Vox-Style Explainer Video Pipeline

Produce a complete Vox-style explainer video from a single topic, article, or report. The optimized workflow is a **short confirmation-first pipeline**: confirm the user's needs, infer the most suitable Paper Collage or Cutout Character treatment from the request and references, wait for approval, generate a main visual plus keyframes, wait for style approval, approve the per-keyframe motion-design document, then generate animation and match the final voiceover and BGM.

Core rule: do not jump directly into costly image/video/audio generation after the initial request. The first deliverable after confirming requirements is always a user-reviewable production document.

```
User need → Production plan document → User approval → Main visual + keyframes → Style approval → Per-keyframe motion-design document → Motion-plan approval → Animation → Voiceover + BGM → Assembly + QC
```

## STEP 1: Confirm User Requirements

Before planning or generation, confirm any delivery information that materially changes the output:

- Topic or source material: topic, article, report, transcript, or reference file.
- Target language for in-video speech and visible text.
- Duration: required for time-based media. Typical options: 45–60 seconds, 90 seconds, 3 minutes. Treat duration as pending until explicitly confirmed.
- Aspect ratio and platform: 16:9 horizontal, 9:16 vertical, or 1:1 square.
- Video resolution: required before video generation; do not silently select or infer it.
- Audience and depth: general public, students, professional viewers, children, etc.
- Required subtitles: subtitles are opt-in; do not add them unless requested or approved.
- Visual preference: Vox-style editorial collage is available as one option, with the final visual and motion direction chosen by the user before preview generation.
- Voice preference and music mood if the user has a strong preference.
- **Visual and motion direction**: present a card-style choice after the production plan is created and before any preview image; do not assume or silently default to a style.

### Visual and Motion Directions

Paper Collage and Cutout Character are both supported directions. Choose between them from the user's wording, the visible reference contribution, the subject matter, and the narrative need; do not force a style boundary merely because an element such as a hand, tool, or character appears.

**Paper Collage** emphasizes editorial evidence-board composition: maps, photos, labels, arrows, cards, halftone, tape, pins, stamps, paper layers, and information relationships. It may include stylized 2D illustrated or paper-cutout hands and tools when they belong to the collage medium. It must not introduce realistic live-action hands, photographic skin, or body-part footage. Its motion emphasizes card slides, paper assembly, route drawing, label reveals, layered parallax, and paper wipes.

**Cutout Character** emphasizes paper characters, their gestures, relationships, and interactions with props. It may include complete cutout characters, their hands and tools, walking, turning, pointing, carrying, placing, and restrained puppet-like actions. Its motion emphasizes character-led staging while retaining the same paper medium and physical continuity rules.

Both directions share the same object-entry invariant and may use compatible illustrated hands, paper tools, cards, pins, tape, and character elements when supported by the chosen visual treatment. Record the chosen direction and its rationale in the production brief, keyframes, motion-design document, animation, and final assembly.
## STEP 2: Create the Production Plan Document

After requirements are confirmed, create a single detailed document and place it on the canvas. Record the selected Paper Collage or Cutout Character direction and the content-based rationale for choosing it. This document is the review gate before any costly media generation.

The document must include:

1. **Production brief**
   - Working title
   - Topic angle and core question
   - Target audience
   - Duration, aspect ratio, language, subtitle choice, and video resolution status
   - Visual style direction, pending/confirmed direction-card selection, accent color, and reference-style motion language
   - Audio direction: voiceover tone and BGM mood

2. **Narrative structure**
   - Cold-open hook
   - Context turn
   - Explanation beats
   - Complication or tension
   - Final reframe

3. **Full script / voiceover transcript**
   - Write the complete narration in the requested in-video language.
   - Use present tense for historical narrative when suitable.
   - Prefer concrete facts, short declarative sentences, and one idea per beat.
   - Avoid throat-clearing such as "In this video we will...".
   - Keep total word count aligned with the target duration.

4. **Storyboard and shot plan**
   - One beat per row or section.
   - For every beat include: beat id, estimated duration, narration excerpt, visual description, on-screen text if any, **primary physical action**, **secondary responsive motion**, camera movement, sound cue, and transition note.
   - Keep on-screen kinetic text short and purposeful, ideally under five words; use a moderate amount of text that orients the viewer without replacing the narration.

5. **Keyframe plan**
   - Main visual / style anchor description.
   - Reference-style design rules: 2.5D layered collage, paper edges, framed labels, geometric editorial accents, and the selected visual/motion preset.
   - Keyframe list with visual composition, subject, background, and typography requirements.
   - Consistency rules for palette, collage texture, borders, typography, and framing.

6. **Animation plan**
   - Apply the selected motion emphasis with **moderate-plus physical editorial motion**: one dominant physical transformation per shot and 3–6 coordinated secondary motion layers. Supported transformations include assembly, unrolling, folding, unfolding, stacking, pinning, rearrangement, node growth, exploded view, sliding along a track, and reassembly.
   - **Mandatory layer hierarchy:** before authoring any shot or video prompt, decompose the frame into a bottom background/substrate layer, lower carrier-paper layers, upper paper/object layers, and top fixation/information layers. The bottom background or backing board may exist from the first frame. Any paper, card, prop, route, arrow, label, pin, stamp, or tape above it must be an independent animated layer with an explicit source and entry path.
   - **Parent-child timing:** a child layer may start only after its parent or carrier layer has entered, reached position, and held clearly in a settled state. The required chain is: substrate exists or enters → carrier paper enters and settles → upper object enters and settles → route/arrow may generate when related lower objects are stable → top-level pin, stamp, tape, or label enters and fixes the object. Never generate a complete keyframe first and animate only a few foreground pieces afterward.
   - Use 10–20% 2D push-ins/pull-outs, lateral/vertical pans, visible paper-layer parallax, route-line drawing, card and icon slides, label reveals, controlled cutout puppetry, halftone shimmer, and drifting clouds/smoke/water. Use deliberate punch-ins on key evidence and brief settling holds after major information arrives.
   - **Object-entry audit:** for every visible object, specify its source, direction, path, receiving surface, contact response, and final fixation. Upper objects must not slide through or overwrite already-fixed objects unless the planned occlusion explicitly supports that relation. Fixation hardware is always a later layer: a pin, stamp, tape, or press action enters only after the object it fixes is already in place.
   - Use stepped stop-motion timing: each object enters, makes contact, and settles with visible physical weight. A contact response may happen at most once before fixation: one controlled stop, compression, or small rebound, followed by a single final settling position. Once a paper, card, pin, label, or prop is pinned, glued, pressed, or otherwise fixed, it becomes motion-locked and must never bounce, pop out, slide, detach, re-enter, or repeat its contact animation. Only the camera, explicitly independent environmental elements, or a deliberately triggered later object may move afterward. Graphic information must respond to physical actions; lines grow from moving objects, labels attach to arriving cards, diagrams unfold from paper, and highlights appear after assembly or reveal.
   - Explicitly avoid 3D rotation, camera shake, face morphing, text warping, style drift, and overactive footage-like motion.
   - **Directional graphic generation:** routes, arrows, connectors, and highlights may appear after their related lower objects are stable and before all upper layers are complete. They must have a visible or clearly implied start point, a specified direction, a continuous path across the receiving paper, and a defined endpoint. They may be drawn by a flat paper pen, pulled from a paper strip, extended from a paper node, or laid down by another established paper mechanism. They must travel to the endpoint, settle once, and remain fixed; never use directionless auto-growth, a sudden flash, or an unexplained overlay.

7. **Audio and assembly plan**
   - Generate one continuous voiceover track after animation approval, not separate beat-level master narration.
   - Generate one instrumental BGM bed after the visual rhythm is known.
   - Match final edit to real VO timing; do not time-stretch narration as the first fix.
   - If subtitles are approved, derive them from the final VO timing and burn them in during assembly.

End the document with a clear production-plan confirmation gate. Record the selected direction and rationale; ask for a style choice only when the request and references do not provide enough evidence. Do not generate the main visual, keyframes, animation, voiceover, or music until the direction is selected and the plan is approved.

## STEP 3: Direction Selection and Plan Approval Gate

Infer the suitable direction from the request and references without an unnecessary direction-choice detour. If the evidence is ambiguous, present the supported directions for confirmation and record the selected branch in the plan. Treat ordinary chat approval and canvas/board approval the same.

If the user requests changes:

- Patch the production document first.
- Keep all downstream assets pending.
- Ask for confirmation again only when the changes affect script, storyboard, visual direction, duration, aspect ratio, language, or audio plan.

Proceed only after the plan is approved.

## STEP 4: Generate Main Visual and Keyframes

After plan approval, generate the **main visual / style anchor** first, then the remaining keyframes.

Main visual requirements:

- It should represent the film's hook and define the whole visual system.
- Use Vox-style mixed-media editorial collage unless the approved plan says otherwise.
- Lock a limited palette, paper texture, white sticker borders, halftone accents, editorial typography, generous margins, and one accent color.
- Make the Vox collage craft explicit: important subjects and props should appear as individual contour-cut paper pieces with torn-paper rims, irregular hand-cut edges, sticker borders, paper fibers, tape, folded corners, and layered shadows; avoid props that look merely printed on flat rectangular sheets.
- Use the approved aspect ratio.

Reference-inspired visual rules to prefer by default:

- Build frames as **2.5D layered mixed-media collages**: foreground hero subject, midground landmarks / props / supporting characters, and abstract paper-texture background.
- Combine historical or archival-looking cutouts with modern editorial geometry, stamps, torn-paper scraps, map fragments, diagrams, dots, arrows, and label cards.
- Give important subjects clear paper edges, sticker borders, torn-paper rims, contour-cut silhouettes, or folded-card carriers so the frame feels handmade rather than like footage.
- Preserve readable subject detail inside the collage style: avoid turning people into featureless black silhouettes unless the plan explicitly calls for silhouettes.
- Present key terms in **framed labels** such as placards, scroll cards, sticker tags, map pins, or title panels. Avoid floating text without a carrier.
- Keep visual hierarchy educational: when narration introduces a concept, the matching visual element should pop, scale, slide, highlight, or receive an arrow/label.

Keyframe requirements:

- Generate one keyframe per storyboard beat unless the approved plan defines another topology.
- Preserve the approved style anchor across all frames.
- Keep typography short, stable, and moderate in quantity: enough labels for orientation, but no dense explanatory paragraphs. Put explanation-heavy content in narration rather than in the frame.
- Batch-generate keyframes when possible, but preserve beat order.

After the main visual and keyframes are generated, group them on the canvas and ask the user to confirm the visual style before any motion-design document or video generation. Do not animate yet.

## STEP 5: Visual Style Approval Gate

Wait for explicit approval of the main visual and keyframes.

If the user dislikes the style, ask what they want changed and which specific visual assets are affected. Explain when changing the main visual may also affect keyframes, but do not assume that the main visual or every keyframe should be regenerated. Make only the changes the user identifies, then wait for style and keyframe approval before animation.

## STEP 6: Per-Keyframe Motion-Design Document and Approval Gate

After the user approves the main visual and keyframes, do not generate video immediately. First create a separate reviewable motion-design document on the canvas covering every approved keyframe, one section per beat. This document is mandatory even when only a subset of clips is requested.

For each keyframe, the motion-design section must include:

- Beat id and target keyframe.
- Initial state: which substrate or already-fixed elements may be present at the first frame.
- Exact object-entry order, with one explicit non-character source for every visible object in the default Paper Collage branch: frame edge, paper stack, envelope, archive box, paper fold, pen tip, pin, tape, or another already-established paper object.
- Entry path and physical interaction in the default Paper Collage branch: slide, unfold, pull by a visible paper mechanism, place by a self-contained paper motion, press by a pin or tape, draw, or another motivated non-character action.
- The plan may use a visible illustrated/paper hand, paper tool, or complete cutout character when that element is supported by the selected treatment; distinguish a stylized paper operator from a realistic live-action hand and record the role in the beat section.
- Contact and settling rule: each object gets at most one stop, compression, or small rebound before its final position.
- Fixation rule: once an object is pinned, taped, pressed, glued, or otherwise settled, it remains motion-locked and cannot bounce, detach, drift, re-enter, or repeat its contact animation.
- Secondary responsive motions, camera movement, transition, and timing beats.
- Explicit audit notes for unsupported motion risks.

The governing invariant is **logical on-screen entry**: every object that appears or changes must have a visible or clearly implied source and a physically continuous path into the composition. Paper-native or character-led operation may be used according to the selected treatment. Paper Collage may use stylized illustrated hands and paper tools, while Cutout Character may use complete paper characters and their limbs. Neither treatment may use realistic live-action hands, photographic skin, or unexplained body-part footage; every operator must enter with the same visual medium and have a causal contact with the object. Do not treat a completed keyframe as an opening frame containing all objects when the intended motion is assembly. Do not use arbitrary fades, dissolves, morphs, magic pop-ins, autonomous activation, unsupported floating, or information appearing without a carrier or causal action. Graphic lines must grow from a moving pen tip or paper object; labels must arrive on a card, tape, pin, or other carrier; highlights must occur after the relevant object is placed.

The document must end with a motion-plan approval gate. Present the user with the document and wait for explicit approval before any video generation. If the user requests changes, patch the motion-design document first and repeat approval. A previously confirmed visual style, resolution, duration, or keyframe does not count as approval of this new motion-design document.

## STEP 7: Final Video Parameters and Silent Animation

After motion-plan approval and before generating any video clip, run a mandatory video-parameter confirmation gate:

1. Present a card-style resolution choice using only resolutions supported by the selected video capability. Do not recommend, infer, or silently apply a resolution.
2. Present the final duration and selected resolution together in a second confirmation card, for example: “Final video settings: duration = {confirmed duration}; resolution = {selected resolution}. Confirm?”
3. Start video generation only after the user explicitly confirms both values in the same current decision state.
4. If the user does not confirm, gives an ambiguous reply, or changes either value, do not generate video. Update the plan and repeat the combined duration-and-resolution confirmation until both are explicitly confirmed.
5. Preserve the confirmed duration and resolution in every animation work item and in final assembly. Never reuse an earlier duration confirmation after the user changes the plan or visual direction.

Only after the motion-design document is approved and this video-parameter gate is confirmed, animate the approved keyframes into silent clips.

Default video model policy:

- For Vox-style keyframe-to-animation clips, default to **MiniMax-H3** for video generation unless the user explicitly selects another vendor/model, MiniMax-H3 is unavailable, or a hard capability requirement excludes it.
- Keep animation clips silent by default at this stage; voiceover and BGM are added later during final assembly.

Animation guidance:

- Set animation intensity to **moderate** by default: clearly visible, layered, and rhythmically active, while remaining graphic and editorial rather than cinematic footage or chaotic motion.
- Good motion: visible background paper-layer parallax, drifting fog or paper strips when relevant, route line drawing, evidence cards or icons sliding into place and settling, halftone shimmer, and three to six coordinated living details per frame.
- For the default Paper Collage keyframe animation, prefer a **natural assembly logic**: the background substrate appears first, then paper scraps, maps, newspapers, evidence cards, props, pins, red strings, and finally framed labels slide or are placed into the scene as if a handmade evidence board is being built. Ask how each visible element arrives, gets pinned, connected, and settles into the final keyframe.
- Use **staggered layered reveals** rather than arbitrary activity: background appears first, then decorative geometry, midground landmarks, main subject, and finally framed text labels. Elements may slide in, be lightly pressed down, get pinned, or settle; avoid sudden flipping, lamp-like flashing, magical pop-ins, exaggerated bounce, or unrelated motion that does not come from the visible collage elements.
- For Paper Collage, keep stylized hands and tools as flat paper/illustration layers with simple whole-piece translation or press actions; do not use realistic anatomy or live-action body-part footage.
- For Cutout Character, use moderate, coherent cutout puppetry: characters may walk, turn, point, lift, place, or carry props, but hands, limbs, tools, and carried objects must remain physically connected; avoid detached hands, floating props, sudden vertical jumps, and unmotivated disappearances.
- Add small ambient particles or editorial ornaments when useful: drifting paper flecks, rotating geometric pieces, small map pins, stamp marks, dots, or diagram arrows.
- Use Paper Collage transitions between scenes: paper wipe, torn-edge wipe, card slide, stamp-cover reveal, or parallax zoom into a detail that becomes the next scene. For the optional Cutout Character branch, preserve character-led continuity across the transition.
- Every animation prompt should preserve the approved keyframe's flat paper-collage design and 2.5D layer structure.
- Forbid in both branches: chaotic motion, 3D rotation, morphing faces, text warping, style drift, uncontrolled zooms, realistic footage motion, and new unplanned subjects. In both branches forbid realistic live-action hands, photographic skin, unexplained body-part footage, and operators that do not match the established paper medium. Stylized paper hands are allowed when causally motivated; complete cutout characters are allowed when the selected treatment supports them.

Generate all animation clips before moving to audio. Review for style drift or warped text and report any affected clips to the user; the review itself does not trigger another generation.

## STEP 8: Match Voiceover and BGM

Only after the silent animation exists, generate final audio.

Voiceover:

- Generate one continuous narration track using the approved full transcript whenever possible.
- Use one consistent voice for the whole film. If the user requests replacement narration for a specified segment, preserve the approved voice by using the prior accepted full narration or voice reference as the voice anchor; never mix unrelated timbres across segments.
- Vox register: measured, warm, clear, curious, and lightly documentary; avoid trailer-style delivery.
- Check real duration. If it is far from the target runtime, report the mismatch and ask the user how to proceed before changing the transcript or generating more audio.

BGM:

- Generate one instrumental bed for the whole film.
- Keep it under narration: documentary, restrained, and subject-appropriate.
- Avoid vocals and sudden drops that fight the explanation.

Timing:

- Transcribe or align the final VO to obtain sentence or clause timing.
- Build a beat-to-clip timing map before final assembly: each animation segment must receive the matching narration sentence(s) and subtitle cue(s). Subtitles should appear only during the segment whose visual idea they explain.
- Use VO timing as the master clock, but also respect approved clip boundaries. If a segment's narration is too long for its animation, rewrite that segment's narration first; only then use mild speed changes, trimming, extension, or brief final-frame holds.
- Before delivery, check the last subtitle cue explicitly so the final sentence is visible before the video ends.

## STEP 9: Final Assembly and QC

Assemble the final video:

1. Concatenate conformed animation clips.
2. Add the continuous VO track.
3. Mix BGM under narration.
4. Add approved subtitles if requested.
5. Encode the final video in the approved aspect ratio.

QC checklist before delivery:

- VO and subtitles stay in sync.
- Each subtitle cue and narration sentence correspond to the correct animation segment; shot changes do not cut through important words or phrases.
- BGM does not overpower narration.
- No animation clip has obvious text warping, morphing, or style drift.
- Motion follows the approved reference-style grammar: natural paper-collage assembly, visible background parallax, paper wipes, framed labels, red-line/icon drawing, pinned/placed evidence-card motion, and restrained coherent cutout puppetry.
- The final video matches the approved production plan and keyframes.
- Final duration and resolution exactly match the latest user-confirmed video settings.

Deliver the final video on canvas and reference the exact output filename in the final reply.

## References

- `references/vox-style-guide.md` — writing voice, visual grammar, keyframe prompt structure, motion style, subtitles.
- `references/ffmpeg-assembly.md` — assembly, subtitle burn-in, audio mixing, and encoding recipes.
