---
name: chinese-traditional-animation-shortfilm
description: |
  Create culturally rooted animated shorts in a Shanghai Animation Film Studio-inspired language, from story approval through assets, shots, sound, assembly, and review. Not for live action or posters.
trigger-words: [Chinese traditional animation, Chinese classical animation, Chinese ethnic animation, Chinese-style short film, Shanghai Animation Film Studio, 上影美术, 上美影, 工笔动画, 水墨动画]
---

# Chinese Traditional Animation Short Film

Use this Skill to turn a mythic, folkloric, classical, allegorical, or culturally rooted premise, script, reference image, or rough note into a coherent animated short with a Shanghai Animation Film Studio-inspired visual grammar. The default direction is **Retro Chinese National Animation Digital Revival**: gongbi-heavy figure drawing, opera-like poses, Dunhuang-inspired ribbons, blue-green landscape, flat cel-animation color blocking, decorative cloud/fire/water motifs, and modern digital refinement. This is a staged production workflow, not a one-prompt image or video shortcut.

## STEP 1: Intake and Production Intent

Extract and preserve the user's premise, source script, cultural setting, required characters, target audience, intended duration, aspect ratio, spoken language, on-screen text, audio preference, and final deliverable. If the user supplies only a theme, propose a compact story rather than inventing confirmed production locks. Identify whether the request is a complete short film, a planning package, a storyboard, or selected visual assets. For a complete film, create a production intent covering purpose, runtime, format, tone, content boundaries, and approval gates.

## STEP 2: Expand and Confirm the Story

When the story is not already fixed, propose logline, premise, protagonist and supporting roles, setting, conflict, emotional arc, visual highlights, ending image, and an estimated shot count. Every supporting character must carry a necessary causal or emotional function, have explicit shot boundaries, and remain subordinate to the protagonist; never add characters merely to enrich the frame. Preserve cultural terms and user-authored text. Do not generate expensive assets until the user confirms the story direction, ending, and scope. Adapt the shot count and duration allocation to the confirmed runtime and production complexity: use fewer shots for a simple event, give the longest interval to the core conflict or transformation, and reserve enough time for the ending result. Set the total runtime first, then derive shot durations and action density; never write long shots and compress them later. Add shots only when they introduce a genuinely new story beat, spatial relation, character action, or transformation. As a guideline, a simple 15–30 second piece may use 2–4 shots, a moderate piece 4–7 shots, and a complex piece 7–12 shots; never inflate the count to fill a template.

## STEP 3: Diagnose and Lock Visual Direction

Offer the following branches and explain the recommendation:

- **Retro Chinese National Animation Digital Revival (default):** gongbi-heavy figure drawing, theatrical opera-like gestures, Dunhuang ribbons, blue-green landscape, decorative cloud/fire/water forms, flat cel-animation color blocking, traditional mineral-color logic, and modern digital polish.
- **Gongbi-heavy color:** denser fine linework, elaborate costume and ornament, ritual, myth, battle, and grandeur.
- **Ink wash:** expressive brushwork, spacious landscape, dissolving forms, philosophical restraint, and poetic movement.

Lock the chosen branch, aspect ratio, visual era, narrative tone, audience-facing language, and any user-approved palette or text. If the output drifts, stop and flag the drift; never silently switch branches.

For the default branch, preserve clean closed contour lines, structured flat shadows, traditional costume silhouettes, collars and wide sleeves, layered skirts or armor, crowns, jade and symbolic patterns, theatrical facial construction, ornamental architecture, mountains, bridges, flowers and pavilions. Use diagonal action lines, S-curves, triangles, horizontal scroll-like layouts, and clear foreground/midground/background. Cloud, smoke, fire, and water are designed graphic forms, not random photoreal effects.

## STEP 4: Author and Confirm the Production Plan Document

Before designing or generating any character, scene, prop, or other asset, author the complete production plan as a canvas document and pause for user confirmation. The document must include the overall production approach, project intent, story outline, character design ideas, scene and prop design ideas, visual direction, duration, complexity assessment, adaptive shot count, preliminary storyboard, audio direction, continuity principles, delivery definition, and approval gates. The storyboard should use the smallest number of shots that clearly expresses the story: a simple visual event may use one continuous shot or 2–4 shots, while additional shots are justified only by new story beats, spatial relations, character actions, or transformations. Treat the confirmed document as the source of truth for all later assets and shots. Do not generate asset anchors or video before the user confirms this plan.

## STEP 5: Write the Production Brief and Style Bible

Using the confirmed production plan, create a concise production brief and reusable style bible. The brief operationalizes the approved story beats, shot grammar, runtime, ratio, audio mode, and delivery definition. The style bible states line quality, anatomy and costume rules, expression language, movement principles, color logic, background construction, natural-element motifs, camera behavior, transitions, and forbidden drift. Include continuity rules for recurring characters, locations, props, and voices. For culturally specific material, distinguish verified user facts from creative invention and keep sensitive symbols respectful.

## STEP 6: Build the Character and Identity System

For every recurring character define role, age impression, silhouette, face construction, hair or headwear, costume layers, accessories, signature gesture, emotional states, and action limits. Create front/side/back turnaround references; add expression or pose references only when needed. When a character changes costume, generate only views with each approved outfit worn on the character; do not generate undressed, uncostumed, clothing-removed, or body-exposure comparison views. Map which character appears in which shot and how identity is preserved. For a crowd, define a small set of distinct supporting designs rather than repeating the protagonist.

## STEP 7: Build the Scene and Prop System

Create character-free scene sheets for every important location, preferably with establishing, medium, detail, and depth/atmosphere views. For any architectural transition, establish one coherent plan linking interior, doorway, corridor/veranda, columns, exterior wall, yard, and road; define the camera path and parallax before using a door, screen, or column as an occluder. Hinged doors rotate around a real axis, sliding elements require a plausible track, and backgrounds must change with camera movement rather than freeze or teleport. Define foreground, midground, background, and far-background planes; architecture, terrain, flora, sky, water, cloud, smoke, and graphic motifs; and what can move. Create key prop references for weapons, instruments, ritual objects, vehicles, magical objects, and culturally meaningful items. Each asset receives a stable name, purpose, owning scene or character, and reuse map.

## STEP 8: Plan Layered Staging and Motion Grammar

Treat each shot as an animation stage rather than a flat illustration. For each shot specify plane order, occluders, subject layer, environmental response, parallax, contact points, and readable silhouette. Keep action density executable: one shot should normally carry one principal action or one emotional turn plus no more than one or two subordinate actions. If costume change, equipment handling, mounting, acceleration, braking, and emotional payoff compete inside one short shot, split them across shots rather than compressing them into pose jumps. Design action from the character's identity, body mechanics, role, and confirmed skills: every weapon or ability must have a clear function such as mobility, guard, control, impact, counter, or resolve. For combat, require the causal chain ‘anticipation → attack path → contact point → opponent reaction → counterforce → aftermath/pose’; attacks must act on the opponent, their weapon, or a defined attack path, not only on background effects. State the hit location, visible reaction, spatial consequence, and action remainder. Limit short shots to one clear action chain; a 4–5 second shot usually carries one event, 6–8 seconds one event plus a result, and 9–12 seconds at most two or three causally linked contacts. Build non-combat action as ‘anticipation → force/reaction → completion → follow-through’: eyes may lead the head, the head may lead the torso, the torso drives the limbs, hands and feet establish contact, and hair, sleeves, tassels, straps, or equipment settle later. Human, animal, vehicle, costume, and prop motion must show weight, support, ground contact, resistance, inertia, and recovery. Use animation-friendly motion: reveal, held pose, glance, sleeve or ribbon follow-through, prop action, environmental response, emotional change, and settle. Favor stepped hand-drawn movement, clear key poses, limited secondary motion, and designed cloud/fire/water cycles over smooth CG motion. Do not allow a scene-less or unmotivated camera shot.

## STEP 9: Create an Adaptive Shot Table and Audio Map

Build a shot table with shot ID, time range, scene, characters, reference assets, shot size, camera, action, emotion, transition, dialogue or narration, sound cue, mouth state, and continuity notes. Choose the smallest shot count that can clearly express the approved story at its confirmed duration and complexity. A simple visual event may be one continuous shot or a few connected shots; do not split one action merely to create more rows. Bind one primary speaker per speaking shot whenever possible; use reaction cuts or silent holds for other characters. Map music sections, narration, dialogue, effects, and silence to the same timeline. Separate diegetic environment/action sound from non-diegetic BGM: when the user wants sound effects but has not approved music, retain scene and action sounds while explicitly disabling BGM, then assemble the picture first and ask whether to add one continuous full-film music track. Do not generate independent BGM per shot. The initial production plan document already contains the preliminary storyboard and shot-count decision. After approval, refine this table only when needed for production detail, without changing the approved story scope or topology silently.

## STEP 10: Generate All Asset Anchors After Plan Confirmation

Only after the user confirms the production plan and explicitly confirms output resolution, aspect ratio, and, where supported, quality/compute level, enumerate every involved character, location, prop, creature, vehicle, costume variant, instrument, magical effect, and recurring environmental element. These output locks must be resolved before any image or video generation. For costume changes, list and anchor each worn costume state as an on-character view; never request a removed-clothing or undressed view. Generate or prepare an anchor image for each required asset before any shot video prompt is finalized. Use character turnarounds, character-free scene sheets, prop sheets, and representative composition previews as appropriate; do not omit an asset merely because it appears briefly. Batch like-for-like assets, assign stable names and reuse maps, and keep every anchor tied to the shots that use it.

## STEP 11: Review and Confirm the Complete Anchor Set

Present the complete anchor set for user review. Check identity, silhouette, costume structure, scene geography, prop design, cultural legibility, scale, and style consistency. Repair or regenerate only the affected anchor when needed. Do not proceed until the user confirms the set, or explicitly approves a documented exception for a non-visible/minor element.

## STEP 12: Prepare the Asset Plan and Prompt Contracts

Before any image or video generation, ask the user to choose or confirm the output resolution and, where supported, quality/compute level, together with aspect ratio and any model-specific duration limits. Treat the confirmed values as execution locks and do not generate until they are resolved. Before video generation, create a shot-to-asset matrix and a prompt contract for every shot. Each contract names the required character, scene, prop, action, camera, duration, transition, audio behavior, and continuity invariants. State what each reference contributes and keep the user's story intent first. Batch similar still or reference assets, but do not alternate expensive image and video generation shot by shot. Missing references must be identified and repaired before dependent shots run.



### Execution-level shot contract

Before a video shot is generated, author an execution-level contract rather than a literary summary. Each shot contract must include: shot objective; every reference asset and its specific contribution; first-frame state; intermediate key states; last-frame state; spatial layout; subject positions and facing directions; foreground/midground/background/depth order; occlusion and no-crossing relationships; subject and prop action chains; camera start, path, speed, and end; environmental response; audio and silence; continuity with adjacent shots; shot-specific prohibitions; and observable acceptance criteria. A prompt is not considered production-ready when it only names an action such as “look back,” “enter,” “transform,” or “close the gate.”

Use a consistent spatial protocol: describe left/center/right and upper/center/lower screen regions, foreground/midground/background/far background, relative positions, facing direction, shared depth axes, contact points, occluders, and which elements may or may not cross each other. Bind each moving prop to an initial position, direction, path, speed change, trigger or force, contact relationship, occlusion rule, and final position. For architecture and mechanisms, state the physical axis or track: hinged elements rotate around a real hinge, sliding elements follow a plausible track, and moving vehicles follow a defined route rather than entering from an unspecified edge.

For every meaningful action or transformation, define the state sequence “initial state → trigger → development → result → settle.” Define a first frame, at least one intermediate key state when the action has stages, and a last frame that prepares the next shot. Use a time-coded table or segmented timeline with, at minimum, composition, subject action, prop action, camera, environment, and sound for each interval. Detail must serve spatial, temporal, causal, and acceptance clarity; do not make prompts longer with unrelated decorative adjectives or unsupported story beats.

Action density must remain executable: a short shot normally carries one principal event plus no more than one or two subordinate actions. As a guide, a 4–5 second shot usually carries one event, a 6–8 second shot one event plus its result, and a 9–12 second shot no more than two or three causally linked contacts. For character action, specify the initiating body part, body transfer order, direction, speed, pause, endpoint, and follow-through. For effects, specify the visible source and causal chain. If the required actions compete for time or space, split the shot during planning instead of stacking more instructions into one prompt.

## STEP 13: Generate Reference Images and Validate Them

Generate the approved character, scene, and prop references in batches where practical. Review them for identity, count, costume structure, silhouette, scene geography, cultural legibility, and style consistency. Repair the existing reference with a targeted revision when possible instead of restarting the whole asset set. Do not proceed to dependent shot videos while a key identity or location reference is materially wrong.

## STEP 14: Write and Confirm Detailed Shot Prompts

After the anchor set is confirmed, write a detailed, generation-ready prompt for every shot. This is a hard approval gate: present the complete prompt document to the user and wait for an explicit confirmation that authorizes generation. Answers to earlier story, plan, asset, style, or specification questions never count as prompt approval. Each prompt must preserve the approved shot order and include global continuity, reference roles, shot size, camera start/path/end, character action, emotional change, environmental motion, transition, duration, audio behavior, and explicit silence where applicable. Write all prompts into one canvas document with a shot-to-anchor matrix and a compact continuity checklist. Do not generate video while this prompt document is awaiting confirmation.



### Prompt approval and regeneration gate

The complete execution-level prompt document is a hard user-approval gate. Earlier approval of the story, production plan, style, assets, or output specifications does not authorize video generation. Generate one shot at a time after the corresponding prompt is explicitly confirmed. After generation, inspect the actual result against its contract and report passes, deviations, failures, and any “not observed” items. Do not silently revise, retry, replace, or regenerate a shot after inspection. First submit the specific failed contract dimension and the smallest proposed correction; regenerate only after the user explicitly confirms that correction. Preserve successful shots, distinguish accepted, superseded, preview, and rejected versions, and never rerun a shot merely because another shot failed.

Use shot-level acceptance checks for composition, spatial positions, action order, timing, path, continuity, physical contact, effect origin, audio, and technical output. “Not observed” is not a pass. Classify failures as composition, space, action, timing, path, continuity, physical mechanics, effect behavior, audio, or technical format, and repair only the affected unit.

## STEP 15: Generate Shot Videos After Prompt Confirmation

Use MiniMax H3 as the default video model. If the user explicitly selects another model, verify its support for the confirmed references and output settings before following that choice. Never generate, queue, or retry any shot while its prompt document is awaiting confirmation. Only after the user explicitly confirms the detailed shot-prompt document and the output resolution/quality locks, generate shots in storyboard order, using the approved references assigned by the shot-to-asset matrix. Maintain face construction, costume layers, ornaments, ribbons, props, location geography, graphic natural elements, mouth-state, and speaker binding. Keep camera movement physically compatible with drawn animation: pans, pushes, held tableaux, scroll-like reveals, match-action, and restrained parallax. Check each result against its shot contract before accepting it. After one approved cause-specific correction, use another compatible model if the selected model still fails rather than repeatedly retrying it.

## STEP 16: Design and Generate Sound

Write or confirm the full dialogue/narration text before recording or synthesis. Match voice roles and pronunciation to the cultural setting. Design music around the selected branch only after the user opts into BGM: refined traditional instrumental color for the default direction, solemn and layered for gongbi-heavy color, airy and spacious for ink wash. By default, preserve diegetic environment and action sounds while withholding non-diegetic BGM. If BGM is later approved, create one continuous track for the full assembled runtime rather than separate music per shot, and use audio overlap/crossfades to bridge cuts. Add restrained foley for sleeves, ribbons, footsteps, weapons, water, fire, bells, paper/brush-like transitions, and environmental movement. Keep silence where it improves emphasis. Do not infer subtitles from narration; subtitles are opt-in.

## STEP 17: Check Voice and Audio Continuity

Compare speech timing with the shot table and final runtime. Check pronunciation, speaker identity, volume balance, clipping, clicks, breath residue, abrupt cutoffs, and tail noise. Repair a good take with trimming and a short fade when possible; regenerate only the affected line when necessary. If timing materially exceeds the planned shot, revise the script or shot timing before assembly rather than hiding the mismatch with rushed speech.

## STEP 18: Assemble and Mix

Assemble only approved shot videos and approved audio. Before assembly, record the exact accepted source version for every shot; never mix superseded and accepted variants silently. Preserve an unscored master with diegetic ambience and action sound before optional BGM work. Create optional scored derivatives with new names and never replace, overwrite, or audio-mix back into the unscored master. Use clean hard cuts, match-action, ribbon or cloud wipes, scroll reveals, circular masks, and occasional dissolves according to the locked branch. Keep visual continuity across joins, preserve deliberate holds, and align dialogue, BGM, effects, and silence. Keep a continuous ambience bed across cuts where appropriate, use J-cuts/L-cuts or short audio crossfades to avoid abrupt resets, and duck optional BGM under dialogue or key action impacts. Avoid duplicate music tracks and duplicate audio tracks, and remove temporary or rejected intermediates from the final selection. Apply enhancement only when requested and only after the artistic review.

## STEP 19: Review and Repair

Run a structured review before delivery:

- **Story:** premise, cause-and-effect, emotional arc, ending, cultural respect.
- **Style:** linework, cel layers, traditional design language, palette logic, no generic anime or photoreal drift.
- **Continuity:** character identity, costume, props, scene geography, scale, direction of motion, voice roles.
- **Animation:** readable key poses, stable silhouettes, purposeful camera, identity-driven skills, clear attack paths, visible contact points, opponent reactions, counterforce, no floating, melting, rubbery limbs, or unmotivated motion.
- **Audio:** clean speech, correct speaker, sync, continuous ambience, intentional diegetic effects, optional BGM continuity, no duplicate tracks or independent music resets.
- **Technical:** duration, aspect ratio, resolution, readable text, complete beginning and ending, usable final file.

Record only material issues. Fix the smallest affected unit—prompt, reference, shot, line, or mix—then recheck downstream joins.

## STEP 20: Finalize Delivery

Deliver the final assembled film plus only the requested supporting assets. Keep the production brief, shot table, style bible, and review notes available as project documents when the user requests a reusable package. Clearly distinguish approved final assets from previews and rejected attempts. Confirm that every final media result is usable and registered in the project workspace before reporting completion.

## Lightweight Request Bypass

If the user asks for only a single character sheet, scene sheet, prop reference, storyboard, prompt, or one short shot, do not force the complete film workflow. Run only the relevant intake, direction-lock, adaptive shot-count decision, asset-anchor, prompt-document, generation, and review steps while preserving the style bible and continuity rules. Even a lightweight multi-shot request must confirm anchors before detailed shot prompts and confirm the prompt document before video generation. A request for multiple videos with one shared character, location, or story still requires the full continuity-aware workflow.

## Failure and Correction Rules

If a story, reference, shot, or audio result fails, identify the failed contract dimension first: content, identity, layout, spatial continuity, body mechanics, animal mechanics, timing, sound, or technical format. Diagnose the existing result before rewriting: repair the smallest failed dimension, update the reviewable prompt document when the action or transition contract changes, obtain fresh prompt confirmation, and regenerate only that shot. Preserve successful assets and retry only the failed unit with a substantive correction. Never silently weaken a locked style or delete a required cultural/character trait to make generation easier. If a required input is missing or two user requirements conflict, pause and ask for the shortest decision needed.

## Execution, acceptance, and regeneration rules

- Treat every video shot as an execution-level contract with explicit spatial layout, first/intermediate/last states, time-coded actions, prop paths, camera path, audio, prohibitions, and acceptance checks.
- Use one principal event plus no more than one or two subordinate actions in a short shot; split competing actions during planning.
- Generate one confirmed shot at a time. After inspection, report actual passes, failures, and “not observed” items. Never silently rewrite or regenerate.
- A correction requires a concrete failure dimension, a smallest-unit fix, and explicit user approval before regeneration. Preserve successful outputs and keep version states distinct.
- Prompt detail must improve spatial, temporal, causal, or acceptance clarity; do not add unrelated decorative prose.

## KEY RULES

- Default image/reference workflow uses the platform's image generation. Unless the user selects another available model, default video generation uses MiniMax H3. Before image or video generation, obtain explicit user confirmation of resolution and, where supported, quality/compute level, plus aspect ratio and other tool-critical output locks.
- Default direction is Retro Chinese National Animation Digital Revival; do not replace it with generic guofeng, ordinary anime, or photorealism.
- Confirm the canvas production-plan document—including overall approach, story outline, character/scene design ideas, storyboard, duration, complexity, and shot count—before asset generation; confirm the complete anchor set before detailed shot prompts; then present and explicitly confirm the complete prompt document before any video generation. Earlier confirmations never substitute for this final prompt approval.
- Every important character, scene, prop, shot, speaker, and audio layer must have an explicit owner or binding; every visible asset must be anchored before shot prompts are finalized. Costume variants are represented only by the character wearing the approved outfit, never by undressed or clothing-removed views.
- Batch like-for-like assets, preserve accepted results, and retry only failed units. Keep accepted, superseded, unscored, and scored outputs separately named; optional music derivatives must never overwrite the unscored environment-and-SFX master. If a batch partially fails, never rerun successful units; if the platform marks a submission as non-resubmittable, stop identical retries and surface the blocker.
- Design action from character identity and skills; require contact, reaction, counterforce, and result for combat.
- Keep diegetic SFX and BGM as separate decisions: SFX may remain on while BGM stays off until the user opts in after assembly.
- Subtitles are off unless explicitly requested.
- This Skill does not handle live-action editing, generic poster design, ordinary image-to-video requests, or unrelated video styles.
