---
name: rpg-game-cinematic
description: Create 30-second combat, parkour or open-world story videos from ideas or refs, with full HUD, live-action or realistic 3D, motivated cuts and spatial continuity; not playable games.
---

# RPG Game Cinematic

## Scope and revision

Version 1.0.0. Produce a 30-second landscape game-narrative film. Recommend H3 for shared visual references and native action sound. A user-selected model takes precedence after checking its current availability and equivalent capabilities. Neither live action nor realistic 3D requires tail-frame continuation or a 27-second long take. Design cuts for the content; successive segments must inherit the previous adopted segment's observed final positions, props and spatial state. This file replaces superseded mandatory rules.

The only execution reference is `references/live-action-realism.md`. Both routes read its spatial-handoff and HUD sections before shot design, prompt compilation and QC; live action additionally reads photographic-realism sections. Older reference files are no longer execution authorities; do not reintroduce their mandatory 27-second take or stale model restrictions.

## Mandatory full-HUD contract

The game HUD is required in the final delivery. Never remove it, reduce it to occasional flashes, crop it away or deliver a clean plate as a finished film to improve realism.

- Persistent layer: approved minimap, necessary health/stamina indicators, objective information and fixed function icons remain throughout applicable shots and cuts, preserving screen anchors, scale, type and state.
- Temporary layer: interaction, danger, updates and outcome notices enter, hold, update and exit on authored triggers. Interaction prompts precede available actions; completion follows visible results.
- Default to concise English unless the user chooses another language. Keep an 8% edge-safe margin and avoid faces, contact points, landings and driving paths. Recompose rather than delete approved components.
- HUD is screen-space graphics, not world geometry. It must not rotate with perspective or appear on plates, clothes, walls or props. Do not change values without injury, expenditure or objective progress.
- The realism test is that the underlying imagery looks photographed while the visible HUD supplies interaction cues, not that the user must receive a HUD-free version.

## Stage 0 — Capabilities and sources

Verify current image/video, native sound, composition and inspection capabilities needed by the intended production route. Verify actual-frame extraction only when selecting tail-frame guidance; its absence does not block the default spatial-state handoff. Discover legal models, lengths, framing, resolution and media limits at runtime; do not maintain static provider tables or assume either photographed or 3D characters always pass preprocessing.

Inventory real asset paths. Missing assets can be made after story approval; never generate them before approval or reject a new project merely because assets have not yet been made. Report access failures honestly and do not move, copy or rename generated assets.

## Stage 1 — Type and visual route

Confirm combat, parkour or open world, then live-action cinematic or realistic-3D console-game appearance. Reuse confirmed choices within a project. A new project does not inherit old identities, story or temporary model exceptions; choose according to this Skill’s recommendation and the current user’s preferences.

- Live action: photographed people, places, vehicles, props and physical motion. Game feel comes from HUD, task feedback and input timing, not modeled materials or game-character animation.
- Realistic 3D: preserve console-rendered visuals with content-driven cuts. Do not impose the live-action pilot gate on this route; full HUD and spatial continuity still apply.

## Stage 2 — Specification and production method

Write and confirm a specification: 30 seconds, 16:9, type/style, full HUD inventory/language, sound, shot organization, sources, default video model and pending resolution choice.

- Both visual routes use content-driven shots and motivated cuts. Keep the 30-second total, but allocate shot count, action/closure lengths and generation boundaries to narrative needs, physical action and legal model durations. Do not impose a 27+3 split or stretch actions to fill time. Design a long take only when explicitly requested, explaining its risks.
- Distinguish generation segments from narrative shots: a legal generated segment can contain explicitly planned cuts, and cuts can occur between segments. Specify every cut, before/after blocking and camera relationship. Do not hide missing contact, travel or transfers, or label edited footage a seamless long take.
- Prefer native ambience and action sound. Dialogue follows the confirmed language; do not invent speech. Narration, subtitles and music are opt-in.
- Explain and confirm the HUD route: recommend photographed plates with full HUD composition for live action, or offer in-generation HUD. Verify composition capability before adopting the layered route; disclose added work and costs before execution. Never switch silently.
- Clean internal plates are permitted for layering, but user-review pilots and final films must include every applicable approved HUD component. A clean plate is not a completed deliverable.

## Stage 3 — Original story, route and action budget

Confirm story, opponent/player positions, objective, spatial route, prop ownership and outcome. Combat needs engagement and exit paths; parkour needs run-up, takeoff, landing and recovery; open world needs landmarks, exploration and interaction.

For live action, favor one principal action plus preparation, contact, loading, completion and recovery per shot. Split complex sequences at motivated action boundaries. Do not hide missing mechanics with sliding, clipping or abrupt cuts. Keep movement spatially traceable; difficulty never authorizes a silent switch to 3D.

## Stage 4 — Assets and written state package

Batch-create and inspect character, world, key-prop and HUD assets. Multi-view cards donate identity and wardrobe, not panel layout, studio scenery or duplicate people. For live action, inspect natural skin/hair, clothing under load, material differences, grounding and shared environmental light; do not demand perfectly crisp detail on every surface.

Do not separately generate opening keyframes or storyboard anchors. Establish fixed world directions and two or three stable landmarks. For every shot, record each person's landmark-relative position, front/back and inside/outside relations, facing, gaze, action/contact, distance tier, prop ownership, vehicle direction, camera side of axis, screen position, lighting and HUD lifetime. Mark occluded or unknown states as unknown rather than inventing them. Shared identities require common visual references, not independent text-only re-creation.

Assign every reference a contribution. In layered production the HUD reference drives composition, not the visual style of bodies or scenery. Every supplied asset has an implementation role; obtain a decision before dropping references for model-budget limits.

Wait for explicit approval of assets and state package before video production.

## Stage 5 — Model, resolution and live-action pilot

Recommend H3 for multi-reference continuity and native sound. Respect the user’s explicit model choice. Before production, check current reference modes, sound support, durations, framing, resolution and media limits. If the chosen model cannot meet the confirmed requirements, explain the gap and obtain a decision before changing models or dropping references. Confirm resolution only when still missing; reuse an existing compatible choice. Higher resolution does not repair spatial errors. A failure does not authorize unapproved paid regeneration or model changes.

Before bulk live-action generation, make a representative pilot of approximately 4–6 seconds within legal model lengths. It comes from an approved shot and includes people, environment, a meaningful contact/weight action and the full applicable HUD, not just a stationary face. Disclose cost before execution. Reuse an accepted pilot in the film instead of regenerating it.

Layered pilots receive HUD before user review; embedded pilots include HUD directly. Inspect photographic realism, weight, camera behavior and interface, then wait for acceptance. Reuse an accepted existing pilot covering the same identity/world/technique; reassess major style changes without silently charging for another pilot.

## Stage 6 — Photography and prompt compilation

Lead live-action prompts with current action, world and camera relations, then references and essential continuity. Do not define the photographed world with engine, PBR model, game animation or asset-render language. Ultra-realistic/8K/cinematic adjective piles do not substitute for visible mechanics.

- Camera: specify motivated position and movement; allow restrained tracking lag, reframing and focus changes. Avoid permanently centered, constant-distance tracking and uncontrolled shake. Do not use shallow focus to hide contact.
- Physics: grip before force; support-leg loading; landing before recovery; vehicle load/suspension response; wheel rotation aligned with travel. Describe important visible steps, not unnecessary muscle inventories.
- Light/material: shared illumination, natural skin texture and cloth folds, differentiated reflectance. Depth and motion blur must not conceal anatomy errors.
- HUD: embedded prompts separate the screen interface from world rendering; layered plates preserve safe framing and use the same state ledger to drive the interface.

## Stage 7 — Continuation and motivated cuts

Successive narrative segments depend on the previous adopted out-state. First inspect the preceding segment's final action and ending image, record its spatial state, then compile the next prompt. Do not concurrently generate a successor whose required out-state is not yet known. Truly independent shots may be batched.

Every video prompt must contain these spatial facts, with each supplied reference individually bound to its role:
1. Scene coordinates: stable landmarks, route and world directions. Distinguish world-left/right from screen-left/right.
2. Opening blocking: for every person, specify position relative to landmarks and others, front/back, inside/outside, distance tier, facing, gaze, action and held objects. For vehicles, specify heading and which side/interior each person occupies. Off-screen people retain world positions or last-known destinations.
3. Camera axis: specify which side of the interpersonal/action axis the camera occupies, its viewing direction and current screen positions.
4. Visible changes and cuts: who moves where along which path, who remains still, and when/where the camera cuts. Explain a screen-side reversal through camera geography rather than swapping characters' world positions.
5. Ending blocking: record each person's final position, facing, contact, ownership, vehicle heading, unfinished action and HUD state. Replace this planned ending with verified observations before writing the next opening; 'continue the previous clip' alone is insufficient.

- Default spatial-state handoff: use shared character/world/prop references and explicitly describe the previous segment's observed final blocking and action at the beginning of the next prompt. Extracted tail-frame input and locked opening frames are optional, not mandatory. Inspect the actual ending even without passing it as an image. Never reset characters, exchange their positions, change owners or teleport vehicles at the next opening.
- Preserve the confirmed model, resolution and output framing, matching the chosen operation to live capabilities. Observed output outranks planned state; do not describe riding away if boarding never finished. Revise the successor to a usable observed ending; seek approval if this changes the accepted story or requires regeneration.
- Content-driven cuts apply to both live action and realistic 3D. An ordinary cut changes viewpoint, not world blocking. Movement, crossing the axis or elapsed time needs a readable bridge shot, visible movement or approved spatial/temporal transition. Screen sides may change with justified camera position, but landmark relationships cannot invert without cause.
- Optional tail-frame guidance: use the inspected actual out-frame as an opening image only when the user asks for exact same-view continuation or an approved plan requires it. Use a supported frame-guided operation without mutually exclusive references; never masquerade text-only generation as frame guidance. Neither image anchors nor written blocking guarantees zero drift; compare the successor opening with the actual previous ending.
- Layered HUD state persists on its own timeline. Only when choosing tail-frame guidance extract the underlying plate's out-frame; avoid repeatedly regenerating composited HUD. Embedded HUD state belongs in the observed spatial handoff and must be checked for text, anchors and values.
- If critical final blocking is unclear, inspect a nearby time window. If still unresolved, pause for a decision rather than invent positions. If an optional frame-guided route is unusable, report it and, with permission, use verified spatial state plus shared references; never regenerate the prior segment automatically.
- Spatial QC compares each person's landmark position, facing, distance tier, contact/ownership, vehicle direction and HUD between the prior ending and next opening. Distinguish lawful camera changes from physical contradictions. Swapped positions, unsupported teleportation, reversed travel and vehicle/prop resets block acceptance; preserve outputs, report exact time regions and obtain permission for the smallest repair.

## Stage 8 — Full HUD and audio assembly

Implement interface lifetimes on the adopted edit timeline. A minimap derives from the approved route; never claim exact navigation without verified mapping. Layered UI needs proper transparency, consistent components and genuine state updates rather than one whole static screen pasted throughout.

Do not display completion before the action ends. Every value change needs cause; interaction prompts retire after completion/cancellation/loss of availability. Report embedded HUD misspellings, plate projection, redraws and jumps, then obtain approval for the smallest repair.

Preserve native sound without doubling engines or impacts. When music is requested, listen for both original sound and music; neither inaudible BGM nor masked action cues passes. Shape the ending deliberately; setting a volume value alone is not mix validation.

## Stage 9 — QC, repair and delivery

Select adopted intervals against the approved timeline, retain physical closure and readable outcome, and assemble 30 seconds. Verify actual duration and exact frame ratio rather than filenames or approximate ratio labels.

Evaluate photographed imagery and HUD separately; both must pass. Check faces, hair, materials, foot loading, human/vehicle contacts, camera motion, weather, vehicle structure, seams, interface text/anchors/lifetimes and audio. Never remove HUD to pass realism or use interface stability to excuse modeled-looking imagery.

Preserve failed outputs and report exact time regions and minimal affected scope. Paid regeneration, model changes or production-route changes require explicit approval. Accepted defects mean preview delivery, not a claim of repair. Keep returned names and project paths without moving/copying/renaming. A Skill-edit request generates no media and does not automatically remake the existing film.
