---
name: browser-game-demo-maker
description: |
  Create a Chrome screenshot of a localhost HTML5 game, then a matching video with the same browser frame and character continuity. Uses supplied prompt files; not for posters or generic motion.
trigger-words:
  - browser screenshot
  - localhost demo
  - browser game
  - local html5 game
  - browser game screenshot
  - browser recording
  - local demo
  - action test page
---

# Browser Game Demo Maker Skill

Use this Skill when the user wants a realistic desktop browser window capture that looks like a local localhost HTML5 game demo, then a matching video that keeps the same browser frame and only animates inside the canvas. It is meant for browser-game feel tests, local demo pages, retro arcade UI, and screenshot-to-video continuity. Before generation, read references/image-prompt.txt for the screenshot stage and references/video-prompt.txt for the video stage, and use those files as the only prompt sources. Do not add your own labeled segments, summary bullets, explanations, or paraphrases. Do not use it for poster design, isolated UI mockups, or generic motion graphics.

Use MiniMax-H3 as the default video model. If the user explicitly selects another model, check that model's capabilities first and follow the user's choice. If generation fails, retry once with a targeted correction, then switch to another capable model instead of repeatedly retrying the same model.

## STEP 1: Lock the Screenshot Contract

- Confirm the source character image and preserve the character’s identity, proportions, outfit, and signature accessories. Treat references/image-prompt.txt as the source of truth for the screenshot-stage browser text and control labels, and references/video-prompt.txt as the source of truth for the video-stage browser text, button labels, action beats, and browser-frame copy.
- Keep the browser as a full desktop Chrome window, not a floating frame or stylized mockup.
- Preserve exact browser chrome details when the user supplies them: tab title, address bar URL, navigation buttons, bookmarks, extensions, avatar, and menu.
- Preserve exact on-screen copy for the game UI, control hints, and button labels when the user has already specified them. When composing the generation prompt, copy the full contents of references/image-prompt.txt for the screenshot stage and references/video-prompt.txt for the video stage verbatim rather than extracting or rewriting parts of either file.
- Keep the result looking like a real localhost demo page running in Chrome, not a poster, splash screen, or pure interface comp.

## STEP 2: Generate the Browser Screenshot Anchor

- Create one still image that fills the whole frame with the Chrome window.
- Show the top browser UI clearly and keep the local URL legible.
- Put the game canvas under the toolbar with a dark retro arcade look.
- Center the character on a thin ground line and keep the virtual buttons at the bottom.
- Use the reference character as the identity anchor and keep it consistent. When the runtime prompt is assembled, the only prompt body for each stage must be the exact text from the corresponding reference file.
- Do not add extra readable text, extra buttons, duplicate characters, or decorative poster treatment.

## STEP 3: Review the Anchor Before Video

- Show the screenshot anchor to the user if the browser text, control labels, or character identity still need confirmation.
- If the screenshot needs corrections, revise the anchor before spending video generation.
- Treat this as the only approval point before the higher-cost motion stage.

## STEP 4: Generate the Matching Video

- Reuse the approved screenshot or the same reference set so the browser frame stays stable. The browser text, UI copy, and action sequence must match the corresponding reference file exactly, with no added framing text.
- Keep a fixed camera and make motion happen only inside the HTML5 canvas.
- Animate the exact action sequence requested by the user, with button-triggered feedback that matches the on-screen controls.
- Preserve the Chrome UI, the localhost URL, the retro game canvas, and the same character identity throughout the clip.
- Keep audio minimal and clean: subtle click feedback, button-down cues, and light arcade confirmation sounds only when requested.

## STEP 5: Deliver Separate Assets

- Return the screenshot and the video as separate final assets.
- Keep the browser-window framing visible in both outputs.
- Do not merge them into a poster, cover image, or UI-only design.
