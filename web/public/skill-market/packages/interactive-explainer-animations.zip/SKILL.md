---
name: interactive-explainer-animations
description: Turn machine, product or system principles into interactive diagrams and 3D breakdowns for technical education. Deliver offline pages, editable source and optional demo video; not engineering CAD.
license: MIT
---

# Interactive Explainer Animations

Turn principles into recognizable, working mechanisms. Motion, readouts and explanations must share one state model. Use the bundled Anatomy kit for SVG work and the bundled ISO-GLOW template for advanced object scenes; do not replace technical geometry with generated bitmap art. Original authors, pinned sources and adaptation history are recorded in [provenance](references/provenance.md). A corresponding Chinese entrypoint is available in `SKILL.cn.md`.

## Source-grounded object research

Support the existing invocation, replacing `[object]` with a subject, preferably including its manufacturer, model and revision:

> Use Anatomy to research [object] from real sources: true dimensions, part list, teardown order

For this invocation or a request for documented dimensions, parts or teardown order, read [object research](references/object-research.md). Consult real sources and provide dimensions, a parts list and teardown dependencies with evidence for individual claims. The English invocation alone does not select English output.

For an explicitly research-only request, use the user's stated language or the conversation language. Do not initialize the drawing kit, automatically make HTML/video or show an artwork-language card. When illustrations or video are also requested, research is an input to production: verify evidence before modeling and distinguish schematic geometry from measured structure.

## Advanced orbitable 3D objects

For ISO-GLOW, free object rotation, exploded assemblies, section views or the previously referenced advanced workflow, read [advanced 3D production](references/iso-glow-3d.md). Research first, then create a Three.js scene with source-grounded scale, assembly-by-assembly explosion, service-manual-style labels, section views and functional controls. Compute light paths or other flows from an appropriate model.

Example:

> Use Anatomy to research [object] from real sources: true dimensions, part list, teardown order. Create an ISO-GLOW Three.js explainer with orbit controls, assembly-by-assembly explosion, a labelled section view and functional controls. Deliver the interactive HTML and an MP4 demonstration in English.

This enters the production workflow. A research report and `facts.json` do not replace requested HTML or MP4. Preserve previously confirmed deliverables and language. This branch replaces SVG initialization, drawing and SVG-specific audits, while retaining language selection, source checks, platform delivery and actual acceptance tests. It is distinct from [beta SVG 3D reprojection](references/3d.md); do not mix their implementation or validation claims.

## 1. Establish the brief and initialize

Reuse the user's subject, parameters, interactions and delivery formats. Before producing text-bearing artwork, follow [language selection](references/language-choice.md) to set one output language: **Chinese / English / Other**. Reuse an explicit project language without asking again. Otherwise show a single-choice card and wait for submission before producing text-bearing HTML, SVG or video. Other requires a specific language. Conversation language, a preselected option or elapsed time is not a selection. Editing the skill itself does not trigger an artwork-language card.

Default to a light, standalone offline HTML explainer with a static SVG and editable source for the SVG branch. Add React, WebGL, advanced 3D or video when requested or needed for the chosen outcome. Build a working explanation of the core mechanism before elaborating a complex scene; do not promise a fixed production time mechanically.

Resolve the skill root from its actual loaded location. Create a fresh working directory inside the current project. Do not write into installed examples or assume desktop paths are accessible in a cloud environment.

```sh
node /actual/skill/scripts/design-init.mjs /actual/project/explainer-work
```

The initializer copies the offline kit, build helpers and minimal examples, and creates an environment report and work-state template. Node 20.10+ is required; 22+ is recommended. Ordinary SVG builds do not require npm. Discover the actual filesystem, execution, browser and canvas tools. Follow [preview and delivery](references/design-adapter.md) for preview and delivery. Mark a capability verified only after it actually runs successfully.

## 2. Principles, mechanisms and parts

Read [craft](references/craft.md) and the closest example, starting with `examples/dial-indicator/build.mjs` for a minimal SVG example. Consult the [kit API](references/kit.md) when needed rather than guessing parameters.

1. Write a brief with the principle, quantities and units, inputs, state, boundaries and likely misconceptions. User-provided parameters are design conditions. For a specific physical object, verify model, dimensions and mechanisms through [object research](references/object-research.md); label inferences as schematic.
2. State which physical part moves and which state change it represents. Choose recognizable tools, instruments or machines instead of piles of floating blocks.
3. List foundation, support, mechanism and control parts. Small illustrations commonly need 40-80 purposeful details; scale larger scenes to the actual structure. Do not add meaningless decoration to meet a count. Feet, screws, bevels, bushings, scales, end stops and connectors should serve a purpose.
4. Keep logic in a pure model module and test meaningful boundary conditions. Animation expresses model state: a depleted token bucket cannot admit requests, refill cannot exceed capacity, and reset restores the initial state. Do not infer model state from rendered DOM wording.

## 3. Composition, drawing and interaction

For the SVG branch, write new `build.mjs` and `model.mjs` files in the working directory and build with `kit/iso-kit.mjs` and `scripts/inline-kit.mjs`. Examples are references, not finished deliverables for a new request.

- Use an x/y ground plane and z-up coordinates. Start around 45 degrees azimuth and 30 degrees elevation, then adjust for mechanism readability. Fit the card with `fitProjection`.
- Build static geometry once. Prefer `translateAlong` for moving parts and rebuild only genuinely deforming geometry each frame. Use lo/mid/hi tones for the base, supports and body, with one lit accent; lighter top faces and shaded sides establish volume.
- Draw back to front using actual depth. Split surrounding frames and springs into front/back layers. Record real pipe and curved-part geometry for auditing; substitute bounding shapes must not be used to manufacture a pass.
- Place the figure number, title, hints and live readout around the card edges, with a legend and brief explanation outside. Preserve Anatomy's engraved-label style and avoid floating text or leaders inside SVG figures unless the user's labeling requirements favor them.
- Support pointer, click and keyboard operation. Provide visible focus, accessible control names and ARIA state. Make motion time-based, smooth and restrained. Pause offscreen loops, clamp the resume delta, and keep controls usable with immediate state changes under reduced motion. See [motion](references/motion.md).
- Produce genuinely standalone offline HTML with no dependency on an installation directory, CDN or absolute filesystem path. Embed static SVG styles and retain the complete kit and source required to rebuild.

Optional branches: read [WebGL](references/webgl.md) for fire, water or light effects with a shared isometric camera, rear-SVG/canvas/front-SVG layering and a non-WebGL fallback. Read [3D reprojection](references/3d.md) for beta SVG geometry motion and run its dedicated audits. Use the [ISO-GLOW branch](references/iso-glow-3d.md) for freely orbitable objects and disassembly. Ordinary SVG translation is not orbitable 3D. Read [React](references/react.md) for React output.

## 4. Test and repair

Follow [verification](references/verify.md); inspect script `--help` before using unfamiliar arguments. Respect the host's browser-control rules. If only platform browser tools are allowed, operate through them and save evidence instead of bypassing permissions. Where the bundled scripts are permitted:

```sh
node scripts/capture.mjs index.html --out qa/desktop.png
node scripts/capture.mjs index.html --width 390 --height 844 --reduced --out qa/mobile.png
node scripts/drive.mjs index.html --actions qa/actions.json
node scripts/lines.mjs index.html --out qa/line-ends.png
```

Use the [language checks](references/language-choice.md) to verify one project language across HTML, SVG, video and captions, including actual fonts, wrapping and reading direction. Test initial state, interaction, boundaries and reset. Geometry and numerical readouts must agree at the same moment. Record expected and observed results, with passed, failed or not-tested status for each actual assertion.

Check console errors and horizontal overflow. Personally inspect desktop/mobile screenshots, important motion frames and 4x connection details; generating a screenshot is not the same as reviewing it. Confirm the actual viewport size before claiming mobile coverage.

Use geometry audits for complex pipes or round parts. Claim only audits supported by and run against the current scene. Inspect line-end warnings individually; do not hide defects through bulk `data-free` annotations. Test both themes only when delivering both. For WebGL, additionally check fallback, reduced motion and transition seams. For 3D, check orbit, fidelity, depth order, pops and performance; a quick check does not replace full validation.

Repair observed problems and rerun affected checks. After a tool failure, allow at most two retries with a concrete change. If unresolved, preserve usable outputs and record the precise limitation. Never mark unexecuted checks passed.

## 5. Produce a demonstration video when requested

Read [demonstration video production](references/demo-video.md). Script initial state, operation, state change, boundaries and reset using the validated model and the same mechanism geometry. Synchronize captions with state. Unless specified otherwise, target about 20-40 seconds, 1920x1080, 30 fps, captions in the selected language and no narration. Panning or zooming a static illustration does not count as a mechanism demonstration.

For Three.js, follow the video section of [advanced 3D production](references/iso-glow-3d.md): capture the actual scene and composite labels and captions. SVG-to-Sharp scripts cannot render Three.js. Prefer approved platform/browser recording for a live scene. For SVG, an offline scene adapter can render frames and encode MP4 through `scripts/render-video.mjs`. Disclose which method was used; offline rendering must not be called browser recording.

Video does not replace interactive-page acceptance. Extract and review keyframes for values, occlusion, labels and captions. Check actual duration, frame rate, dimensions, full-file decoding and dynamic change. A rendering callback count is not an encoded frame count. Deliver MP4 through the platform's video-resource workflow; if unsupported, provide the local video and state that limitation.

## 6. Deliver the project

Follow [preview and delivery](references/design-adapter.md) to place real screenshots and the artwork entry point on the canvas, and open the work in a preview that executes HTML. Operate at least one control, verify the readout change and reset. An attachment or screenshot is not an interactive preview.

For researched objects, include `research.md` and `facts.json`. Relevant labels, dimensions and teardown actions in HTML/SVG/video should map to fact IDs. The SVG branch delivers `index.html`, styled SVG and source/kit. The Three.js branch delivers `index.html`, scene and state source, bundled dependencies and licences; do not manufacture a complete vector SVG for it.

Both branches include model/source notes, actual check records, screenshots and LICENSE. Package a ZIP and verify rebuilding from an extracted copy. For video, also deliver MP4, captions/timeline, rerenderable scene source, keyframes and video acceptance evidence. Open the delivered video to verify playback where supported.

Report only tested capabilities; do not generalize a successful SVG example into verified WebGL or 3D support. Distinguish local checks from native platform checks and assisted runs from unattended runs. Do not publish publicly or invoke paid image/video services by default. Continue authorized creation, preview and routine repairs without requesting confirmation at every phase.
