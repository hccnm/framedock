---
name: windows-xp-dialog-story
description: |
  Create Windows XP Luna dialogs or popup-driven action shorts for retro UI, popup storytelling, error escalation, progress interactions, and terminal results; not for full desktop recreations.
trigger-words: [Windows XP dialog, XP popup video, popup animation, system dialog video, retro system UI video, Windows XP 弹窗视频, 弹窗动画, 系统弹窗玩法, 弹窗叙事]
---

# Windows XP Dialog Story

Create standalone Windows XP Luna dialog images and short videos in which dialogs become readable narrative objects. The original static-dialog capability remains available; the video extension turns dialog states, stacking, progress, failure, and completion into timed visual events. A user may provide a short concept, a static dialog asset, a reference image, or a combination.

## STEP 0: SCOPE AND INPUTS

Identify whether the request is for one static dialog, a popup-driven video, or both. For video, use the mandatory staged intake below rather than jumping directly to video generation.

**Conversation pacing is mandatory:** advance only one stage per user turn. Ask only for the current stage's next input, then stop and wait. Do not list all future questions, dump the full production brief, or start a later stage before the user replies to the current one. After each stage completes, briefly state what was completed and ask for only the next required input.

1. **Dialog asset stage:** first design and generate the required dialog family: errors, warnings, progress, interruption, and settlement states as justified by the concept. Keep their chrome and typography consistent. After generating them, stop and ask for the character input.
2. **Character stage:** ask the user to upload the character reference or confirm that no character is needed. Do not invent a character identity when the video depends on a specific person or character. After receiving it, stop and ask for the script or story outline.
3. **Script stage:** ask the user to upload the script, dialogue, or scene outline. Preserve supplied spoken and on-screen copy exactly. After receiving it, stop and summarize only the next unresolved production choice.
4. **Interaction timeline stage:** map character actions and story beats to dialog appearance, stacking, movement, progress change, interruption, fade, or settlement. Ask only for the next missing duration, aspect ratio, scene reference, language, subtitle, or ending choice when needed.
5. **Video stage:** only after the dialog assets, character input, and script or explicit no-script decision are available, generate the popup-driven video.

If a video does not require a character or script, ask the user to explicitly confirm that decision at the relevant stage; do not silently skip the dependency. If duration or ratio is missing and a video must be generated, ask that question only when the workflow reaches the production-choice stage.

Preserve every user-supplied visible word exactly. Do not invent consequential system claims, destructive actions, legal/security notices, or controls without semantic support.

## STEP 1: STATIC DIALOG DESIGN

For a static asset, classify the state as processing, complete, warning, error, confirmation, or input/result preview. Choose the smallest meaningful set of title, body, icon, buttons, hierarchy, and layout. Default to one centered 4:3 horizontal dialog with a cleanly isolated background. Do not promise an alpha channel. Use a blue Luna title bar, classic bevels, readable Chinese or user-supplied typography, and no desktop, taskbar, hardware, or surrounding scenery.

Use the default available image capability. If the user explicitly specifies another image model, check its capabilities before following that choice. If generation fails, correct the likely cause and retry once; if it still fails, switch to another compatible available model. If the user explicitly requires a transparent PNG, explain that generation does not guarantee an alpha channel and use a separate available extraction or post-processing step only when supported.

## STEP 2: POPUP VIDEO PLAYBOOK

The video extension is a **physicalized popup action short**, not a dialogue scene with UI stickers. When a retro look is requested, favor a pronounced early-DV / early-2000s television image rather than a polished modern film look. Static isolated dialogs are only the asset stage; the video should normally place the characters and dialogs in a believable physical space or a deliberately transformed system space.

Apply these visual rules:

- Treat dialogs as flat but physical objects with depth, perspective, front/back occlusion, and collisions with characters or props.
- Bind every major popup to a visible action or story beat: impact, interruption, avoidance, failed reply, object throw, push-away, or reconciliation.
- Build a feedback loop: action → popup response → escalating action → denser popup response.
- Use a clean isolated background only for reusable dialog assets, not as the default final-video staging when the user has supplied a scene reference.
- Include at least one dynamic escalation beat and one clear visual transition of system state when the duration allows.

Build the video around a clear state arc rather than a collection of unrelated interface shots. The following interaction patterns are available when supported by the concept:

1. **Accumulation:** repeated error or warning dialogs appear after visible events, occupy the space, and create escalating clutter.
2. **Layering and relief:** stacked dialogs become a visual pressure field; after the turning point, secondary dialogs fade, move aside, or collapse to reveal one decisive dialog.
3. **Action-linked progress:** a progress bar or status value changes in response to an on-screen action. The change must be visually legible and causally timed; do not show arbitrary numbers without a story reason.
4. **System interruption:** a freeze, crash, restart, or blank-screen beat can interrupt the action when it is part of the user's concept, followed by a clean return or terminal state.
5. **Settlement dialog:** a single completion or result dialog resolves the accumulated state. Its copy must be supplied or grounded in the concept, not presented as an unsupported factual system result.
6. **System carrier shift:** when justified, transform the setting into a crash screen, classic desktop-like system space, loading void, or other system state before returning to reality. This is a scene transformation, not a generic desktop recreation.
7. **After-state and anticlimax:** end with a black screen, final progress completion, or system notification followed by physical consequence or awkward stillness when it serves the joke. A settlement popup should resolve the system while the characters' physical state creates the final contrast.

Use a varied physical-space camera language when the concept calls for action: alternate wide shots that reveal popup density with medium shots, reaction close-ups, insert details, quick pans or push-ins, and brief freezes at system failure. Avoid repeating the same framing or movement for the whole clip. Make depth legible through foreground/background placement and real occlusion. Keep the decisive popup readable; reserve fast movement for transitions or impact moments rather than every shot.

## STEP 3: TIMING AND SOUND

Map popup arrivals, impacts, clicks, state changes, progress changes, freezes, fades, and the final result to a beat timeline. Establish a beginning state, action-driven escalation, turning point, and ending state. Treat system sounds as part of the rhythm: popup clicks, error tones, crash alarms, silence during a freeze, and a final confirmation tone should land with important actions when sound is requested or generated. Unless the user specifies another language or voice direction, perform spoken dialogue in natural Taiwanese Mandarin, not announcer diction or mainland broadcast diction. If music is supplied, align action impacts and popup bursts to its structural accents. Do not imply subtitles unless the user asks for them.

## STEP 4: REFERENCE CONTRIBUTION

Use each supplied image reference according to its role. A generated or user-supplied full-frame still can carry scene, character relationship, camera, and overall look; character sheets can carry identity continuity; dialog images can carry popup chrome and state design. Keep each reference's contribution distinct. If several popup images are supplied, use them as a staged state family: introduce error and warning dialogs first, bring in progress or interruption states only at their story beats, and reserve the completion/result dialog for the resolution. Do not show all popup states simultaneously unless the story explicitly requires that condition. Do not transfer incidental characters, setting, logos, or wording unless the user explicitly requests them.

## STEP 5: PLAN, CONFIRM, AND PRODUCE

For a video, do not generate the final clip before the staged intake is complete. Present the beat plan only after the dialog assets, character input, and script or explicit no-script decision are available. Do not present the entire future workflow or collect all remaining choices in one message. Confirm only the next unresolved choice that materially affects production, then wait for the user before continuing. Generate reusable dialog/keyframe assets first, then generate or assemble the video in chronological order. Keep repeated dialogs consistent in title-bar proportions, typography, icon logic, and button placement while allowing state-specific content.

Use MiniMax-H3 as the default video model. If the user explicitly specifies another model, check its capabilities before following that choice. If generation fails, fix the likely cause and retry once; if it still fails, switch to another compatible available model instead of repeatedly retrying the same model.

If a generated result loses the dialog's readability, fix scale, timing, overlap, or camera movement before adding decorative detail. If the result becomes a generic desktop scene, return to the supplied scene reference or a restrained scene composition; only lock a scene when the user has supplied or approved one. If a progress value does not visibly respond to the action, simplify the action and make the state transition explicit. Preserve successful assets and retry only the failed portion.

## STEP 6: QUALITY CHECK

Check that:

- the popup is a physicalized narrative subject, not a flat sticker;
- the scene has visible depth, occlusion, and a clear action-to-popup feedback loop;
- the state arc is understandable without relying on unsupported exposition;
- every supplied word is exact;
- accumulated dialogs, action-triggered responses, progress changes, interruptions, fades, and settlement states have clear timing;
- repeated dialogs remain visually coherent, appear in story order, and interact consistently with the space;
- the camera does not destroy readability;
- the ending resolves the established state rather than adding an unrelated screen;
- audio effects or music do not imply unrequested subtitles;
- the static output uses the selected available image capability and follows its checked constraints;
- the result is a video or static image as requested, not an interactive prototype.

## BOUNDARIES

This Skill supports standalone Windows XP-style dialog images and physicalized popup-driven action shorts. It does not create functional UI code, interactive prototypes, full desktop recreations, generic modern modal systems, unrelated desktop tours, unsupported system claims, or exact copies of a reference video. A static white or isolated background is for dialog assets, not the default final-video aesthetic when a user-supplied scene exists. For long-form films, multiple independent final videos, complex multi-clip editing, or a workflow requiring extensive script and shot approval, return to a broader production workflow.
