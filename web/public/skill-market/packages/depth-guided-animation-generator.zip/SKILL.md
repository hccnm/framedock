---
name: depth-guided-animation-generator
description: Turn an idea or footage into an animated short using approved performance, depth motion and one style frame. For acting and camera previews, not frame-exact copies or editable 3D scenes.
trigger-words:
- depth-guided animation
- depth-guided animation generator
- animation previz
- 深度引导动画生成
- 深度引导动画
- 动画预演
- 视频转动画
---
# Depth-Guided Animation Generator

Chinese name: 深度引导动画生成. Establish acting and camera work first, then translate the performance into animation. The product name is model-independent.

Previz is AI-generated live-action-style footage, not a real recording. Animation generation means generative visual translation, not layered, rigged, or 3D project delivery. Depth guides visible spatial relationships and motion; it does not recover hidden backgrounds or guarantee exact geometry, joints, skeletons, or materials.

## Use Cases and Entry

Start with duration, aspect ratio, and concrete video content: setting, action, and camera intent. Users need neither professional terminology nor character art, style images, live-action footage, or depth maps.

Prioritize everyday character acting and prop interaction, small emotional scenes, blocking and tracking with occlusion, and dynamic storyboard validation. Recommend one character, a clear setting, and a 5–15 second beat; these are scope recommendations, not silently chosen delivery specifications.

With authorization, reuse approved previz and depth to explore another animation look. Do not automatically generate alternatives. Complex fights, interacting crowds, and long dance routines are advanced high-risk cases; extreme deformation, abstract animation, and exact dance replication are not the core offering.

## STEP 0: Understand Performance and Feasibility

Before previz, ask only for missing duration, framing, and concrete video content. Content may include setting, action, subject count, narrative role, emotion, camera, and ending. Do not use character clarification to ask for final identity, wardrobe, style, or visual references early. Recommend ordinary acting and camera details; do not repeat answered questions.

Store images supplied early and their stated roles for STEP 5 after depth. Do not require early image analysis, style selection, or final design completion. “Use this person” does not automatically mean “use this image's style.” Use reasonable live-action stand-in performers for the approved content; their identity is not the final character. Honor voluntarily supplied previz-casting requirements without asking about final design.

Prefer MiniMax H3 for live-action-style previz and reference-guided animation when its available capabilities support each stage. Previz needs text-to-video with the approved performance and sound plan; the styled film requires a full depth-video reference plus the approved style frame. Verify both input types together before production and honor a user-selected model that satisfies them. If unsupported, explain the gap and ask about a capable alternative; never silently drop the depth input, shorten, or split the film. Price, speed, and reliability are not guarantees.

Do not pass character or style images into text-only previz. Check whether the real depth model loads; request preparation only when needed. See references/execution.md for model and script paths. Setup approval does not authorize generation.

## STEP 1: Approve the Brief

Present a concise previz plan: duration, framing, concrete setting and action, subject count, camera progression, and ending. No final-character source, style options, or style-approval fields. Explain execution and audio without adding a routine questionnaire.

Specify whether previz requests music, ambience, or silence. Do not add unrequested sound. Restore usable previz audio by default; otherwise follow an approved silent or supplied-audio plan.

Explain: duration, framing, and video content → generate/approve previz → explicitly choose whether to process depth → full depth and actual opening frame → choose final character/style and reference roles → one target-style first frame → review identity and look → styled film → audio integration.

Ask whether to generate the previz with this plan. Do not repeat a confirmation already explicitly given. Uploading assets or invoking the Skill alone is not generation approval. This approval covers previz only, not depth processing.

## STEP 2: Generate Live-Action-Style Previz

Describe observable performance: starting state, intent, weight and contact, displacement, environmental response, and ending. Keep simultaneous actions simultaneous. Camera and acting serve the intended expression; do not add unrelated actions, multi-shot stories, or candidates.

Build natural live-action performance and prop contact around the approved content without requiring final character design first. Tell the user this stage validates acting, space, and camera—not final identity or visual style.

## STEP 3: User Reviews Previz

Show the actual previz and explicitly ask whether it is satisfactory and whether the user wants full depth processing. Offer “Approve and create depth”, “Revise previz first”, and “Keep the live-action video only”. Extract depth only after explicit authorization, including a clear “continue” in response to this question; satisfaction alone does not authorize processing. Do not ask again if depth processing was already explicitly requested. Final character and style choices follow only after depth is ready. Read objective duration, size, frame rate, and audio-track facts as needed; do not proactively perform semantic quality inspection of generated work or regenerate based on self-review.

Use user feedback to scope changes. Fix wrong motion or camera in previz, not downstream animation generation. Revised previz needs new approval and new dependent assets; preserve historical versions.

## STEP 4: Prepare Full Depth and Opening Frame

After depth-processing approval, extract the approved previz's actual opening frame and infer real depth across the full timeline, white-near and black-far. A grayscale filter or single depth still is not a video motion reference.

Treat extraction as background production, not a technical lesson for the user. Record model, input version, frame count, duration, and transforms; check decoding and timeline completeness. Do not silently interpolate, retime, or delete action.

Use a shared standard size and aspect ratio for final inputs. Read actual dimensions rather than assuming generation honored the request. Preserve image coverage: never silently stretch or crop. Explain proportional scaling and small padding when ratios differ; seek approval if confirmed composition must change. Prefer matching image/video dimensions. See references/execution.md for recommendations and the observed compatibility case.

Use measured timing. Explain and obtain approval for integer-duration trimming; fractional durations are not inherently invalid. Align depth, opening frame, and audio to one timeline origin. Preserve original and normalized versions.

## STEP 5: Choose Final Character and Style After Depth

Enter final character and style selection only after the full depth video has actually been produced. Present the depth result, then resolve remaining character and style choices. Never ask for the final look before previz or block previz on missing style. Offer two choices:

1. **Choose an animation style**: for example fresh Japanese animation, cel shading, painted watercolor, 3D cartoon, or a custom description. Examples are not defaults; do not impose anime or a director's look.
2. **Upload an image for its style**: extract the chosen medium, linework, palette, lighting, and material treatment. Follow that visual language rather than forcing a preset anime look.

Reuse an explicit style choice or stated reference purpose without asking again. An uploaded image alone does not authorize every possible role. If it contains a person, establish whether it means style only, identity and outfit only, or both. Identity-only images do not automatically define style; style-only images do not define identity. Separate images may supply separate roles. Clarify only unresolved conflicts.

A style image supplies approved visual language, not automatic background, framing, props, text, or character copying. Previz owns movement and space; identity references own approved appearance; style references own rendering. Resolve these in one first frame. If the reference is not anime, do not silently anime-ify it; confirm the requested visual target and feasibility.

Users with finished footage skip new live-action generation, approve their previz, and produce depth before choosing final character and style. If explicitly supplied as approved previz, do not ask for previz approval again; still ask about depth processing if it was not authorized. Choosing style does not authorize extra character design, alternatives, or paid generation.

Check target anatomy, props, and action compatibility here. Resolve necessary unseen design when partial character art is insufficient. If severe incompatibility requires new previz, explain the impact and obtain approval; do not silently rebuild. Multiple sheet views represent one character. Missing character art does not authorize new character-design work.

## STEP 6: Create and Review One Target-Style First Frame

Create one generated first frame per complete video, including multi-shot videos. Do not generate a separate first frame for each shot. Revise the same frame through versions rather than adding independent frames. Necessary extracted source frames may support interpretation; they are not additional generated first frames.

Combine actual previz opening frame with character art. Previz owns composition, pose, count, placement, perspective, scale, occlusion, scene layout, and lighting relationships. Art owns identity, face, hair, anatomy, costume, and accessories.

Resolve the actual opening frame, approved identity references, and approved style references into the single anchor, using only necessary references with explicit roles. Translate character and environment into the user-selected look without changing scene space. Do not import art-sheet backgrounds, crops, multiple-view layouts, or static poses. Resolve props according to the approved action; identity-reference props must not occupy hands needed for performance.

Show the frame and ask whether identity, style, setting, placement, and composition are right before final generation. This approval is separate from previz approval. Review every revised frame again.

## STEP 7: Generate the Target-Style Film

Use exactly two visual inputs: approved target-style first frame and full—or explicitly approved trimmed—depth video from the same previz. Do not include color previz, raw opening frame, raw art sheet, raw style images, or extra backgrounds.

The frame defines identity, animation medium, color world, and opening. Depth guides later space, camera, distance, rotation, occlusion, occupancy, action phases, and rhythm. Do not freeze later composition to the opening or render depth gray values as final color.

Compatible anatomy strongly follows action phases and spatial events. Incompatible anatomy reinterprets performance with the target structure while preserving camera and events, rather than copying a skeleton. Explain severe incompatibility at post-depth character selection; obtain approval before rebuilding previz. Keep causal action and prop contact; add no new story.

Follow live duration and reference contracts. Distinguish reference generation from source-duration-inheriting edits; do not guess conflicting fields. Disable final generated audio and restore approved sound; no unrequested captions.

## STEP 8: Audio and Delivery

Restore only actual usable audio, preserving sequence and timing without overlapping tracks. Do not silently stretch sound or motion to fit; handle discrepancies using an approved ending plan.

For the full workflow, deliver previz, full depth, approved target-style frame, and final short; identify sound source. If the user chooses live-action video only, deliver the existing previz and stop without depth or a style frame. Do not duplicate existing assets. Preserve identity and version history for processing the same content and record real dependencies. Let the user review final quality before proposing or executing changes; no autonomous quality-driven regeneration.

## Failures and Revision Scope

Preserve valid work. Inspect actual request records, published constraints, and objective file facts first. Separate evidence from hypotheses; generic parameter errors do not identify a field. Avoid blind identical resubmissions. Explain changes, cost, and impact and obtain authorization before generation; never auto-retry. After two consecutive failures, stop and provide diagnosis and an escalation path.

Major action, setting, camera, or duration changes invalidate affected previz and downstream assets. Appearance-only changes with unchanged space may reuse previz/depth but require a newly approved target-style frame. Extra styles, candidates, and character design need separate authorization.

Users may enter with an idea or existing previz. Skip new previz generation when approved footage is already supplied; do not force redundant generation. Bundled resource paths are relative to the Skill. Save all production outputs in the current session project directory and reuse actual returned file paths. Keep models and other reusable dependencies separate from project deliverables.

For multiple approved videos, batch the same production stage where dependencies allow, then review that stage before proceeding; never bypass per-video approvals or expand the requested scope.
