---
name: vibe-knowledge-film
description: Turn knowledge topics into code-generated films or short samples using reproducible experiments, charts and music. Deliver MP4 and editable source; not ads, decorative animation or ordinary editing.
trigger-words: [knowledge film, science explainer, black-gold explainer, knowledge visualization, 知识短片, 科普视频]
---

# Vibe Knowledge Film

Use this Skill when a user wants a finished, music-led knowledge explainer built from code. The usual input is one topic plus optional references, source material, or a required music track. Deliver a playable MP4 and an editable project. Do not imply that text alone renders the film; use the available local rendering and encoding environment.

## Fixed references and source discipline

Read `references/reference.md` when the project uses the reference-film language, and `references/motion-camera.md` for shot cards, object hand-offs, camera, and transition review. Borrow the method—concrete experiments, restrained editorial typography, and explanatory motion—not the author credit, title, copy, or historical sequence.

Use a track supplied or approved for the current project, with suitable publication rights, or honor a no-music request. No reference-film soundtrack is distributed with this Skill, and a previous project’s selection is not a default for a new user. Reuse valid analysis of the selected track; do not infer content from filenames. Propose its music window for the confirmed film duration. Never silently replace, time-stretch or loop an excerpt to fill a longer film. Report missing or unsuitable audio before rendering.

## Mandatory sequence and stage gates

The seven steps below are required and ordered, not optional suggestions. Never skip them for speed, because an example exists, or because rendering is available. Reuse still-valid completed steps and evidence without repeating questions or work; known inputs do not constitute approval of an unseen concept.

Maintain a project text record of the current step, confirmed specifications and their user provenance, concept version and approval, preview/acceptance evidence, and unresolved issues. Check each gate before advancing. Stop at the current step when requirements are missing; recommendations are not confirmation, and outputs cannot retroactively supply approval. This record supports this Skill's continuity; do not create a separate multi-stage production plan.

### STEP 1: Topic and core question

Accept a topic, copy, or references and identify one question the film will answer. Invent no dates, people, quotations, or historical relations. Do not start full storyboarding or rendering yet.

**Gate:** The topic and core question are clear; ask only necessary clarifications when ambiguous.

### STEP 2: Collect production choices together

Extract choices from the current request and confirmed context first. Collect missing choices in one round, without asking answered questions again.

- **Duration and delivery mode:** Offer a 20-second test, 30, 60, 90, or 120 seconds, or custom. Recommend 60 seconds if there is no preference, but obtain acceptance. A 20-second duration does not automatically mean test mode; record test versus final separately.
- **Platform:** Douyin/Kuaishou, WeChat Channels, Xiaohongshu, Bilibili/YouTube, or a custom use. For multiple platforms, select a primary version and list only the separately adapted deliverables the user actually requests. Do not silently multiply outputs.
- **Language and explanation:** Confirm audience language and choose narration, explanatory captions, or chart labels only. Track narration and subtitles separately; narration does not enable subtitles, and unrequested subtitles remain off.
- **Music:** Reuse a track already approved for this project. Otherwise confirm a user-provided or appropriately licensed track, or no music, together with the other production choices. Record the selection and rights source; availability alone does not establish publication rights.

**Gate:** Duration, platform/use, delivery mode, language, explanation, and music approach are resolved. An explicit “use your recommendation” accepts concrete recommendations already shown, not unseen future choices.

### STEP 3: Recommend framing and dimensions; confirm specifications

Show a recommendation and rationale based on platform and chart complexity. These are production recommendations, not exclusive platform upload requirements.

| Publishing use | Recommended ratio and final dimensions |
|---|---|
| Douyin/Kuaishou/WeChat Channels portrait feed | 9:16, 1080×1920 |
| Xiaohongshu portrait note | 3:4, 1080×1440 |
| Bilibili/YouTube landscape | 16:9, 1920×1080 |
| YouTube Shorts and similar portrait shorts | 9:16, 1080×1920 |

Explain the landscape advantage for dense multi-curve charts or side-by-side distributions. If portrait is selected, reflow objects, axes, labels, and comparisons instead of cropping landscape or shrinking the whole chart until illegible. Explicit custom specifications take precedence. Explain technical constraints and obtain a decision before changing them. Recommend 30 fps for final delivery and optionally 24 fps for testing; show and record either choice.

Steps 2 and 3 may share one interaction, but the recommendation must follow the platform/content decision logically. Present a compact specification summary: duration, platform, mode, ratio, pixel dimensions, fps, language, narration/subtitles, and music.

**Gate:** The user specified or explicitly accepted concrete specifications. Do not reconfirm already explicit values. Do not author the creative proposal while execution-critical choices remain unresolved.

### STEP 4: Verify knowledge and obtain concept approval

Use reliable primary or authoritative sources, map them to claims, recalculate key results, and distinguish theorem, simulation, approximation, and metaphor. Follow one explanatory thread instead of copying the reference film's historical sequence.

Show a compact proposal: the question, experiment/charts, opening-to-conclusion arc, segments within the confirmed duration, object-continuous transitions (which object id carries each hand-off, or the reason for a hard cut), music landmarks, and selected explanation format. Main scenes must show observable sampling, branching, accumulation, convergence, propagation, or comparison, not particles with paragraphs. Reuse valid music analysis; do not guess BPM or cut mechanically on each beat.

**Gate:** Explicit user approval of the current concept. Stop after presenting it. Duration/framing choices, a generic request to make a video, and approval of an earlier concept do not approve this concept. A complete concept already supplied and explicitly approved by the user can be reused; do not add shot-by-shot approval.

### STEP 5: Implement and check critical sections

Create seeded data, the detailed storyboard, and code from the approved concept. Prefer Canvas/SVG for charts and type, and use 3D only for explanatory spatial form. Drive all scenes by absolute time so each frame is reproducible.

Write one shot card per shot (`references/motion-camera.md` §1): new information, visual focus, framing, camera start → end and purpose, subject action as prepare → contact → response → settle, the hand-off object id, label timing, and any reading pause. Keep world coordinates separate from the camera; record the carried object's position, scale, direction, and speed at each boundary. Prefer semantic relay, path continuation, occlusion reveal, or match cut; motivated hard cuts are fine. Do not ease every segment in from zero and out to a stop, and do not use whole-frame fades as transitions. Morphing or 3D is never mandatory. `scripts/motion-kit/` provides an absolute-time `track`/`relay`/`action`/`camera` helper and checks (`node scripts/motion-kit/check.js`) with two worked migrations (coin → dot → curve; pedal → master cylinder → wheel); schematic pressure or signal travel must not be presented as real propagation speed.

Check the core experiment, chart readability and stable axes at target size, risky hand-offs and camera moves, occlusion, residual imagery, and random-seek consistency first. Reuse valid previews and analysis evidence. Never auto-import intermediate frames or logs to the canvas.

Keep checks proportional but honest about motion. Block on factual errors, unreadable or overlapping key text, broken or missing rendering, a core experiment that fails to read, and these transition defects: an obvious jump in position/scale/direction, a stop-then-restart where continuity was planned, residual shadows or stale 3D, or a promised continuous hand-off that became a slide-style fade. Fix them locally: first watch the risky 2–4 s windows continuously at the target fps, repair only the affected interval, re-check it, then review the full film. Stills and numeric checks never support a claim of visual smoothness. Do not solve motion problems by lengthening the film, adding text, changing fps, or forcing a shot count. Record minor nits (a slightly early label, a soft fade on a secondary element) without iterating. Add sound effects sparingly at contact, release, and reveal moments over the kept BGM; no whoosh on every move.

**Gate:** Critical checks pass with recorded evidence and no unresolved factual or display errors. Do not add a preview-approval stop unless the user requested one; honor it when requested. If checks cannot be completed, disclose the limitation and stop instead of claiming success or starting a full render.

### STEP 6: Render and validate

Render only the confirmed specifications and validate knowledge, charts, sound, complete decoding, duration, dimensions, and fps. Repair affected sections without rerunning valid work.

**Gate:** Actual exported media and validation evidence exist. Test-only authorization permits only a test sample, then stop after delivery. If final production is authorized and the concept approved, proceed after passing preview checks without duplicate start confirmation. Before changing confirmed duration, platform, framing, language, music, output count, or creative direction, explain the impact and obtain the user's decision. Return to the earliest affected step, revalidate, and redo only invalidated work.

### STEP 7: Deliver and stop

Deliver MP4, editable source, rerender instructions, knowledge sources, data, and music timing. Preserve replaceable data, captions when present, and audio mappings. Put only the final sample or film on the canvas; deliver source and reports as project files.

**Deliver the final MP4 in the current project’s media area when available**, and verify that it opens and plays. Import only the final film, keeping corrections grouped as versions of the same work when supported. If the host cannot display it, provide the actual playable file and state that limitation. Source and reports remain project files; intermediate frames are not final deliverables.

**Gate:** The final MP4 is playable through the project or delivered file, and checks and limitations are reported. A test delivery cannot automatically expand into a long film. Additional platform/aspect variants require explicit requests. Skill validation, prompt discussion, and file editing do not authorize video production and do not start this production sequence.

## Visual baseline

Black and gold is the default look, not a limit on the Skill. An explicitly requested visual style takes precedence.

- Near-black background, warm ivory text, champagne gold for emphasis, and dark red only for an explicit counter-branch or warning.
- Use restrained serif editorial typography, negative space, fine rules, and a subtle glow. Avoid generic web cards, oversized decorative type, and unmotivated neon.
- Keep captions short enough to read while watching the experiment. Check chart labels, captions, and sources for collisions at mobile size.
- Add dates, names, and corner sources only when they help the explanation. Never imitate a reference creator's signature or credit.
- Keep the visual language consistent, but redesign the objects for the new topic. A probability film may use coins, samples, and distributions; a neural-network film should show connections and signals instead.

## Required acceptance checks

- Claims agree with the simulation and sources; quotations and historical details are not invented.
- Each key concept has at least one direct visual demonstration; captions are not a full transcript.
- Fonts render correctly; charts have correct labels, scale, bounds, and no overlap.
- Duration, dimensions, frame rate, frame continuity, and audio/video alignment are correct. Check the actual render surface and exported file, not only CLI arguments.
- The exported MP4 contains the intended audio. Verify the output, not merely the presence of an audio file in the project.
- The ending leaves musical room and does not cut through a sentence or phrase.
- For morphing transitions, verify object continuity, full-frame chart visibility, no unintended 3D remnants or transparent-buffer trails, and deterministic random-access frames.

## Development draft and final rules

There is no automatic two-minute or landscape default. Follow the confirmed duration, platform, ratio, dimensions, and delivery mode from steps 2–3. Recommend 60 seconds only when the user has no preference, then obtain acceptance. For a development test, recommend 20 seconds at 24 fps with representative keyframes and one sample. A reduced-resolution draft must preserve the confirmed ratio, show its exact dimensions, and obtain acceptance before rendering: examples are 1280×720 for 16:9, 720×1280 for 9:16, and 720×960 for 3:4. Full production follows the approved final dimensions; draft settings never silently replace final specifications. Test-only delivery stops after the sample. Final authorization does not bypass concept approval or technical preview checks.

A draft must cover the opening, core experiment, and conclusion rather than only the setup. Keep the exact requested music window and document any trim, gain change, or re-encoding. Preserve fixed seeds and reuse validated data, fonts, dependencies, and music analysis.

Validate actual Canvas/WebGL dimensions, draft/final state, time mapping, and exported media. Isolate caches by dimensions, fps, draft/final mode, source/data fingerprint, and scene-map version. If the renderer only checks image dimensions, use a new cache directory after source changes; never treat resized old frames as native output. Resume only missing or damaged frames, and invalidate the affected time range after a scene change. Benchmark the slowest section before increasing concurrency.

For a continuous-morphing chart sequence, preserve the explanatory object as it changes form rather than switching through unrelated cards. A full-width chart must retain its readable axes, labels, baseline, scale, and conclusion long enough to be understood. When a 3D object hands off to a chart, explicitly hide the 3D object and clear relevant buffers during the chart interval; test several timestamps and random seeks.

## Audio and visual analysis reuse

Use existing verified media facts, semantic analyses, and user-approved frame checks as evidence. Do not repeat image analysis merely to reconfirm an already accepted transition, especially when the analysis path can create canvas keyframes. Run a new analysis only for a genuinely new reference, missing dimension/duration fact, or unresolved visual question. If the user says not to analyze again, rely on available evidence and state the resulting validation boundary honestly.

## Canvas and project hygiene

Only put the user-facing final media and, when explicitly requested, a small number of single previews on the canvas. Keep frame sequences, contact sheets, debug screenshots, source code, JSON, intermediate audio, and validation logs in the project directory. A draft normally contributes at most one sample video; a final delivery normally contributes one final video. Do not batch-import debug frames or use analysis paths that automatically create keyframe nodes.

## Reproduction example

Run the following commands from `scripts/sample-project` only for an approved landscape 20-second test. They are not workflow defaults and do not bypass the gates. Adapt both scripts and layout to the approved specifications before using other formats.

Prepare Python 3.9+ and an isolated environment first. `scripts/sample-project/requirements.txt` declares Playwright, Pillow, NumPy, SciPy and imageio-ffmpeg; Chromium is a separate installation. Run the prerequisite check before rendering. It checks imports, the Chromium executable and FFmpeg availability, without generating media. It does not certify browser system libraries or output quality.

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python -m playwright install chromium
python tools/check_dependencies.py
```

Supply the real project-approved audio before the commands below. `music/approved-track.m4a` is an example path, not a bundled file: place the approved track there or replace every occurrence with its actual path. Confirm that the approved window covers at least 20 seconds here; do not silently loop or stretch a short track. Regenerate `music/music_map.json` for that track and review the measured timing; the bundled historical analysis does not establish the chosen track's timing or publication rights. These audio commands do not implement a no-music delivery; adapt the encoder and acceptance checks for an approved silent project. `tools/verify.py` retains the historical sample's 1920×1080/30fps checks and must be adapted before validating the 1280×720/24fps draft below.

```bash
python tools/check_dependencies.py --track music/approved-track.m4a
python tools/analyze_music.py music/approved-track.m4a music/music_map.json
python3 tools/render.py frames --start 0 --end 20 --fps 24 --width 1280 --height 720 --workers 2 --draft --out frames/draft20
python3 tools/encode.py --frames frames/draft20 --start 0 --end 20 --fps 24 --track music/approved-track.m4a --audio-start 0 --out out/draft20.mp4
```

After encoding, make the final file accessible in the project and verify playback before reporting delivery.

The sample-project scripts are reference implementations, not a promise that every future topic uses the same duration, music window, data model, or scene layout. Keep reusable rules general and store one-off measurements in the project report.
