---
name: blender-product-film
description: Build an editable product master in Blender from images, text, drawings, manuals, or 3D files, then create an ad base, keyframes, and final film. Never replace modeling with a concept image.
trigger-words:
- Blender product film
- product 3D modeling
- 3D product commercial
- product feature animation
- Blender 产品广告
---

# Blender Product Modeling and Film Production

Use one complete, editable product master across every shot. The production chain is: source evidence → product evidence analysis → `PRODUCT_MASTER` → product validation → advertising shot plan → shot asset check → required asset enhancement → camera, animation, lighting, and text → preview review → Blender motion render and project delivery → four advertising keyframes → final H3-enhanced film. Execute the production work; do not substitute a proposal, prompt, concept image, or unexecuted script for an editable model and finished media.

## 1. Analyze Product Evidence

Read [product evidence rules](references/product-evidence.md), then use the [product brief](templates/product-brief.md) and [assumptions report](templates/assumptions-report.md).

- Accept product photographs, multi-view images, drawings, dimensions, manuals, written specifications, brand assets, logos, and optional STEP, STP, FBX, OBJ, GLB, or BLEND files.
- Classify every claim as supported, inferred, missing, or conflicting. Record its source, applicable version, confidence range, and affected parts.
- A 3D file is optional. When no model exists, build the editable product in Blender from the available evidence and document non-critical assumptions.
- Ask only when missing information changes a critical visible structure or a factual feature and cannot be completed safely. Continue unaffected work.
- Prefer importing and repairing a supplied model. Preserve the original and verify converters and units for CAD formats rather than assuming native support.

## 2. Build the Complete PRODUCT_MASTER

Confirm the available Blender environment and follow [execution guidance](references/execution.md). Without a model, create and execute repeatable modeling work for consistent coordinates and scale, full exterior form, assembly, major parts, visible ports and controls, materials, and supported branding. With a model, import and repair it instead of rebuilding without reason.

Save `PRODUCT_MASTER.blend` with a semantic `PRODUCT_MASTER` collection and meaningful names for actual parts such as `BODY`, `BUTTON_*`, and `KNOB`. The product must be recognizable from all required exterior views with valid primary assembly relationships. Do not invent invisible engineering internals. Lock supported geometry, quantities, interfaces, and logos; connect assumptions to assumption IDs. A display or exploded pose must never overwrite the assembled master state.

## 3. Validate the Product Before Storyboarding

Render the front, side, top, three-quarter, or other views needed to verify the product. Use `scripts/inspect_scene.py` for scene data and inspect the actual images for proportion, assembly, interface placement, branding, materials, and external dependencies. Compare dimensions in a shared assembly frame, not a rotated world-space bounding box.

Separate geometry problems from lighting, material, or camera problems. Record reviewed views and findings in [review log](templates/review-log.md). Repair critical product errors before final shot planning. Describe the result as visual validation from available evidence, not engineering certification. Wait for explicit user approval only at user-requested gates or when unresolved critical facts require judgment.

## 4. Create the Advertising Shot Plan from the Real Model

Read [product cinematography](references/product-cinematography.md) and [Blender camera guidance](references/blender-camera.md), then complete the [shot plan](templates/shot-plan.md). Reference actual object names, evidence IDs, verified features, and the product master version.

Each shot records its ID, duration and frame range, one core message, shot size, angle, lens, focus and depth of field, composition, camera motion, product action, lighting, transition logic, text or UI, asset dependencies, factual basis, and acceptance criteria. Use varied information rhythm rather than repeating the same framing. Feature sequences state Action → Reaction and distinguish physical controls, software responses, external services, and clearly labeled conceptual graphics. Never present unknown internals as product fact.

## 5. Check and Build Shot Assets

Complete the [shot asset check](templates/shot-asset-check.md) for every shot. Compare camera visibility and animation requirements against the validated master: close-up geometry, inner or rear surfaces, movable parts, hierarchy, pivots, parenting, materials, UVs, seams, and structure views.

Classify each need as reuse, local enhancement, independent asset, evidence required, or unnecessary. Build only what approved shots need, and link every addition to its shot, source object, evidence or assumption ID, reason, and validation view. Store independent high-detail modules under `shot_assets/` with mapping and visibility records so scale and assembly remain consistent between shots.

## 6. Animate Camera, Product, Lighting, and Text

For mixed camera moves, visible motion, dynamic commercials, or slow shots that risk looking static, read [motion direction and acceptance](references/motion-direction.md). Design camera trajectory and product display movement together. Missing feature evidence restricts unsupported functional claims; it does not prohibit clearly artistic whole-product turns, tilts, or floating presentation.

Create `FILM.blend` or controlled per-shot files from the validated master. Use numeric lenses, focus targets, paths, timing, and easing rather than vague directions. `scripts/camera_rig.py` may support the rig, but rendered review determines framing quality. Animate controls around real pivots and travel; preserve and restore assembly transforms. Build required text and UI inside Blender or its compositing and sequence tools, then check fonts, safe areas, readability, and occlusion. Use controlled versioning so reruns do not duplicate objects or keyframes.

## 7. Preview, Review, and Iterate

Render representative keyframes first, then a complete low-resolution motion preview. `scripts/render_frames.py` helps extract frames but cannot replace temporal review. Check product identity, intersections, pivots, reset poses, camera collisions, cuts, focus drift, reflections, text, Action → Reaction clarity, and pacing.

When motion is requested, verify visible screen-space change and continuity at the beginning, middle, and end. A keyed camera or successful render is not proof of visible movement. For floors, soft shadows, and broad gradients, review a continuous clip from the intended render engine to detect temporal flicker. Record the actual frames and clips reviewed, localize feedback to objects and frame ranges, and recheck neighboring transitions after corrections.

## 8. Render and Deliver the Blender Base Film

After preview approval, restore final quality and verify frame rate, resolution, frame range, active cameras, color handling, dependencies, and the final frame. Prefer restartable image sequences, then assemble the video through Blender when possible. Local encoding may package the result but cannot replace Blender production.

Use the [project report](templates/project-report.md). Deliver at least `blender_motion.mp4`, `PRODUCT_MASTER.blend`, the editable film project, required `shot_assets/` and inventory, `renders/`, executed scripts, storyboard and shot list, assumptions report, and project report. Pack supported dependencies, use portable relative paths for the rest, and reopen the delivery project to verify it. Only call files finished after they have been generated and checked.

## 9. Create Four Advertising Keyframes

Read [advertising keyframes and H3 finishing](references/ad-keyframes-h3.md), then complete the [keyframe table](templates/ad-keyframes.md). From the reviewed Blender motion film, use the opening and closing frames plus two different internal frames. Select internal frames for meaningful transitions, difficult camera states, and composition differences rather than simple equal spacing.

Re-render these moments at high quality and apply consistent background design, lighting, typography, color treatment, and compositing while preserving product geometry, parts, proportions, pose, and camera. Save original frames, finished advertising frames, frame numbers or timestamps, selection reasons, and modification records.

## 10. Produce and Validate the Final Video

Use the four advertising keyframes for product identity, visual treatment, and time-specific composition, and use the Blender video for camera movement, product motion, cuts, and pacing. Before generation, verify that the available video system supports the actual number and type of inputs, duration, aspect ratio, and time anchoring. If it cannot accept the intended combination, adapt transparently instead of silently dropping references.

Define the role and timeline of every input. Preserve approved movement, assembly relationships, and brand copy. Review the generated result for product drift, cuts, movement, background flicker, text, and audio, and iterate within reasonable bounds. Deliver the final film together with `blender_motion.mp4`, keyframes, prompt and request records, review report, and Blender projects. If final-generation access is unavailable, deliver the complete Blender work and submission package while clearly stating that the final enhancement was not generated.

## Sources and Maintenance

The inherited source index remains in [article-map](references/article-map.md). Evidence modeling, full shot planning, asset checks, advertising keyframes, and final enhancement are extensions of that basis. Attribution and inspiration boundaries are documented in [sources](references/sources.md). This Skill is self-contained and does not require another Skill package.
