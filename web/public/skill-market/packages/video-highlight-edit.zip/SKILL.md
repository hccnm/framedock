---
name: video-highlight-edit
description: Turn tutorials, interviews, and product demonstrations into coherent highlight videos by selecting key content. Use for source-video recuts, not generated footage or standalone caption cleanup.
trigger-words:
- 视频精华剪辑
- 长视频精剪
- 中文精华视频
- 演示视频精剪
- 视频精华重剪
- video highlights
- highlight edit
- highlight recut
- demo highlights
---

# Video Highlight Edit

Turn existing videos into concise, independently understandable highlights inside Design. Use source footage as evidence, prioritize useful demonstrations and preserve source meaning. This is a deterministic Design media-processing implementation: do not use AI Clip Studio, the Design video editor, HyperFrames, an external coding agent, an HTML renderer, or new dependency installation. Use supported deterministic trimming, concatenation, audio, subtitle and render operations only.

A “no-added-caption” version means this workflow adds no subtitles. Captions already burned into the source remain; removing source captions is outside this workflow.

## STEP 0: Establish inputs and execution scope

1. Resolve the selected source video to an accessible project asset. If several possible sources exist and the user's choice is unclear, ask which one. Never substitute a similarly named file. Preserve the original.
2. Do not ask for target duration yet. First complete the source review and Theme Extraction Card in STEP 0A. After the card is written, ask for the target duration only if it is still absent; never silently assume 90 seconds. Record whether duration is approximate, a strict cap, or exact. For an approximate target, aim within 10 percent when coherent, but never let duration override semantic completeness.
3. Carry forward explicit audience, platform, framing, language, sound and review choices. Do not repeat answered questions. Platform choice alone does not require a crop.
4. Default to original audio, source framing and source-quality delivery. Do not replace English speech with Chinese narration merely because the audience is Chinese. A request for a Chinese highlight version authorizes Simplified Chinese audience-facing editorial text; other output languages follow explicit user intent. Generic highlight requests inherit source language unless specified otherwise. Interaction language follows the current session.
5. Subtitles are a post-export opt-in derivative. First export and validate a no-added-caption version. After that export succeeds, if subtitles have neither been added nor explicitly declined, ask in the language of the user's current input whether to add subtitles in that same language. Create them only after an affirmative answer and retain the no-added-caption version. An earlier explicit subtitle request counts as authorization, but subtitle production still follows the successful no-added-caption export. Do not repeat the question after subtitles have been added or the user has clearly declined. For foreign-language footage requested as an independently understandable Chinese version, Chinese narration remains a separate option requiring explicit authorization.
6. Default to autonomous routine analysis, selection, editing and checks. Honor any requested script or cut review. Before expensive final compositing, obtain approval unless the user already explicitly authorized end-to-end autonomous delivery; such authorization does not cover new paid generation, voice replacement, or irreversible edits.
7. Use only available Design media and editing capabilities. Before committing to a deliverable, verify actual access to analysis, transcription, cuts, text rendering, export and visual inspection. Verify editor abilities rather than inferring them from its name. Never invent operations, timelines or successful exports.
8. Use ordinary edits, source media and existing authorized assets. No generated footage, new music, voice cloning or external upload is a default dependency. If a required capability is missing, identify the precise blocker and request the smallest viable change. Optional decoration may be simplified without blocking the main edit, with the simplification disclosed.

### STEP 0A: Build the Theme Extraction Card before asking duration

After enough full-source review to understand the material, create an internal Theme Extraction Card before asking for a target duration or selecting final clips. The card must state:

- The source's core question or message in one sentence.
- The proposed highlight theme and one-sentence conclusion for a first-time viewer.
- The minimum information chain needed to support that conclusion: hook, necessary context, task or claim, key operation or viewpoint, feedback or evidence, result, and limitation when applicable.
- The evidence-bearing source intervals for each information unit, including whether the unit is speech, screen action or result.
- What can be removed and what cannot be removed without making the topic incomplete.
- Whether the material supports a whole-source highlight, a complete focused topic extract, or only a draft/partial cut.
- A recommended edit direction: evidence-led, publish-ready fast recut, or authorized enhanced visual packaging.
- One or two suitable publishing markets or use contexts, based on the content and requested audience, such as product-demo social post, tutorial knowledge clip, interview highlight or professional-network case study. This is a recommendation, not an assumed platform lock.

First summarize this card for the user in the current interaction language. Then recommend the most suitable highlight edit direction and publishing market, explaining the reason in one or two sentences. Ask for confirmation only when the proposed topic, material narrowing, edit direction or market would materially change the deliverable. If the user has not supplied a target duration, ask for it after this summary and recommendation. Do not select a fixed duration before the theme and information chain are established.

A valid card must describe a complete idea, not merely list attractive source moments. If the requested duration cannot contain the minimum information chain, narrow to a smaller complete subtopic or recommend a duration change; never cut away the result or necessary qualification merely to hit a number.

### Editorial scope lock

Treat a generic request for a highlight of the source as a representative condensation of its core narrative, not permission to choose any isolated topic. Record whether the agreed output is a whole-source highlight, a focused topic extract, or another user-specified form. For a whole-source highlight, preserve the main question and select representative evidence; it need not include every chapter. If the viable proposal materially narrows the subject to one topic, explain that change and obtain approval before editing. Permission to skip an unreviewed source interval does not itself approve a topic change.

Do not impose a minimum shot count or a fixed number of topics. One or two excerpts may support an excellent focused cut, while many rapid cuts may communicate little. Duration reduction, advertising removal and output resolution are not sufficient evidence of editorial completion. Keep the previously confirmed original-audio and post-export opt-in subtitle rules; a request to improve the cut does not authorize new narration, music or captions.

## STEP 1: Check and understand the complete source

1. Obtain deterministic duration, dimensions, frame-rate information when available, and audio/video stream facts. Decode checks and metadata do not prove intelligible speech or valid visual content; inspect those separately.
2. Establish a timestamped transcript of all audible source speech, with detected language, before locking the narrative and speech cuts. A trusted supplied transcript may be the starting point. Visual review may proceed alongside transcription, but semantic summaries are not verbatim transcripts or precise word-boundary evidence. Verify disputed names, claims and numbers against the recording; mark unintelligible spans rather than guessing. Keep source terminology without silently substituting a different product, model or date based on outside expectations. Transcription for internal editorial analysis does not authorize subtitle burn-in or subtitle-file delivery.
3. Review visual content across the entire source, including silent demonstration sections. For sources exceeding analysis limits, split within actual tool limits and maintain global source offsets. Use small overlaps to protect boundaries, then deduplicate overlapping transcript and observations.
4. Maintain a coverage ledger: source interval, transcript coverage, visual-review coverage and unresolved gap. Check for holes, duplicated intervals and truncated tool results. Do not call partial or sparse analysis complete. If full coverage cannot be obtained, disclose that limitation and obtain approval for a partial-source cut before selecting the final material.
5. Identify topic changes, repeated explanations, fillers, demonstrations, comparisons, results, claims, prices, dates and limitations. Locate useful silent operations independently of speech.
6. Inspect every shortlisted evidence-bearing demonstration and claim at sufficient temporal detail to identify the actual action and result. A thumbnail alone does not prove a complete operation.

### Proxy review and recovery

For long sources, use analysis-size proxies or bounded sections when needed, while retaining the original for final rendering. Verify each proxy's duration and local-to-source mapping, including any seek offset or timing drift; a filename or requested trim value alone is not proof of alignment. Choose section sizes and concurrency from actual limits, not a fixed recipe. On capacity or queue failures, reduce concurrency or batch size. On payload failures, shorten sections or reduce preview size. Do not repeat an identical failed submission.

Persist the last successful coverage checkpoint and recover only missing intervals. Keep transcript coverage and visual coverage separate: a full transcript cannot close a visual-review gap. Partial-source approval must name the excluded intervals and stays separate from editorial topic approval.

### Validate returned evidence

Before accepting an analysis result, check that it answers the requested question with source-grounded observations. Provider notices, error text, generic templates, truncated output, impossible timestamps or contradictory identities do not establish successful review, even inside a nominally successful response. Quarantine unsupported claims, reconcile conflicts against the source, and leave unresolved checks incomplete. Do not convert a service's unsupported claim of frame-by-frame review into a user-facing verification claim. Record what was actually inspected and with what temporal granularity.

## STEP 2: Build the evidence and candidate ledger

Keep the ledger internal unless the user asks to inspect it. Use stable local identifiers so subsequent changes do not require redoing accepted work.

For each candidate record:
- Source asset and exact in/out time; local-to-global offset if segmented.
- What is visibly shown and what is audibly stated, recorded separately.
- Narrative role: hook, context, explanation, demonstration, comparison, result or conclusion.
- Information-unit identifier: candidates that prove the same claim share one identifier even when their shots, apps or angles differ.
- Unique value and reason to retain or reject it; state whether it adds new information or only repeats an existing unit.
- Proposed duration and percentage of the target runtime for its information unit.
- Required predecessor context, speech boundary and visible result.
- Possible crop/overlay areas and protected interface regions.
- Uncertainty, contradiction, legibility and privacy concerns.

For each factual claim record:
- Claim wording, source interval, evidence type and confidence.
- Speaker or source attribution.
- Units, currency, plan, billing period, date, comparison baseline and test conditions as applicable.
- Necessary limitations and the final wording that preserves them.

Rules:
- Source claims are not independently verified facts. Attribute subjective judgments and test results where necessary.
- Do not turn one test into a universal capability claim, or drop a pricing condition.
- If audio and screen conflict, investigate; if unresolved, qualify or omit. Ask only when the disputed material is essential to the requested output.
- Never fabricate interface actions, product results, numbers or comparison footage using generative media.
- Remove greetings, redundancy and low-information waiting only when their removal preserves causal and conversational meaning.

### Mandatory source-to-cut comparison

Before final selection, maintain an internal table with: source core question or message; candidate speech and visual evidence; retain/omit decision and reason; required attribution or conditions; effect of omission on meaning; planned output role. Include the opening context, representative findings and relevant conclusion or counterpoint. Do not simply list attractive shots.

Check whether the proposed cut preserves the agreed scope and the speaker's stance. Omitting greetings or sponsorship differs from removing core findings or qualifying evidence. If the remaining material only supports a narrower topic, return to the editorial scope lock. If the duration cannot accommodate the required meaning units, revise selection or ask for the smallest material trade-off rather than hiding the loss of meaning.

Keep this comparison internal unless review is requested. It is required editorial work, not a mandatory long document for the user to approve.


### Information weight, diversity and balance gates

Before authoring the edit map, group every candidate by the claim or conclusion it proves. Shot variety and information variety are different: multiple applications, angles, close-ups or cuts that all prove the same capability remain one information unit. Do not count visual changes as new topics.

Create a duration budget for the proposed cut. For a whole-source highlight, no single non-hook, non-conclusion information unit should normally occupy more than 30 percent of the target runtime unless the user explicitly requests a focused extract or the source only supports that one complete topic. If the limit must be exceeded, disclose the concentration before editing and obtain approval.

Run a balance check before presenting the cut plan:
- Every retained segment introduces new information, supplies necessary evidence, completes an operation–feedback–result chain, or resolves the conclusion.
- Three consecutive segments must not merely repeat the same claim through different visuals.
- The planned weight of each information unit is proportional to its importance to the source thesis, not to how much footage is available.
- A whole-source review highlight uses representative advantages and limitations when the source supports both; one extended demonstration must not crowd out the counterevidence or conclusion.
- Removing the longest segment must not make the thesis clearer. If it does, shorten or replace that segment.

Do not advance when the plan is visually varied but informationally repetitive, or when one topic dominates without an approved focused scope.

## STEP 3: Author the highlight narrative and edit map

1. Choose the strongest supported hook. The first 3–5 seconds should present a specific question, surprising verified-in-source result, or meaningful demonstration, rather than an unsupported superlative.
2. Build an understandable progression: hook, minimum context, core demonstration or point, result, conclusion. Adapt structure to the source instead of forcing all five sections into every short cut.
3. Preserve operation–feedback–result relationships. Screen demonstrations should dominate when the source actually contains them. For interview-only footage, retain useful speaker footage; do not invent demos or filler B-roll.
4. Reorder complete meaning units, not words that would change a speaker's position. Keep names and pronouns understandable after rearrangement. Disclose a repeated teaser excerpt internally so it is not mistaken for unique evidence. Every spoken segment must begin and end as a complete, independently understandable sentence or clause; do not start on an unresolved conjunction or pronoun, or end before a number, unit, negation, condition, comparison or grammatical completion.
5. Preserve real-time playback where speed affects a performance claim. Do not shorten waiting to imply a faster product. Any allowed acceleration of non-evidence waiting must be clearly labelled and retain the outcome.
6. Create an edit map for every segment: stable identifier; output in/out; speech source asset and in/out; picture source asset and in/out; narrative role; actual speech; authorized subtitles or editorial text; framing; overlays; transition; sound treatment; linked evidence identifiers; verified entry/exit boundaries. Mark whether speech and picture are synchronous or the picture is an illustrative source cutaway. When both tracks use the same source interval, record that explicitly.
7. Distinguish source and output clocks throughout. Check that source ranges are valid and output ranges have no unintended gaps. Account for transition overlaps, intentional pauses and supported speed changes in duration calculations; do not merely sum excerpt lengths.
8. Use readable original footage as the base. Prefer adjacent labels or brief overlays to opaque full-screen text cards. Do not add a closing CTA, advertising claim or stock scene unless requested and supported.
9. If a target ratio conflicts with legible UI, offer fitting/padding or a demonstrated safe crop rather than silently cutting away evidence. Do not synthesize interface edges to fill a frame.
10. Before execution, verify evidence coverage, information weights, information diversity, balance, output timing, protected visual areas, authorized text/audio choices and available deterministic editing operations.
11. Before any cutting or assembly, present the proposed highlight plan to the user and stop for approval. For every planned segment, show: final-playback order; planned output in/out and duration; exact source in/out; concrete visible content; narrative purpose and information-unit label; and the verbatim source speech when speech is present. Also show the total planned duration and each information unit's runtime percentage. Do not begin editing until the user explicitly approves this plan.

### Highlight form and pacing control

For a publish-ready or fast-paced highlight, use multiple source shots and purposeful visual changes when the source supports them. Do not impose a fixed shot count, but do not deliver a single arbitrary excerpt merely because it meets the duration. Every cut must advance the theme, clarify context, show evidence or complete the result. Keep the Demo or actual screen/action footage as the visual主体 when the source contains one; avoid turning the result into a long subtitle-card or static talking-head deck.

The first 3–5 seconds must use a source-grounded hook: a question, verified result, meaningful operation or clear tension that the rest of the cut answers. A visually exciting opening that is not explained later is not a valid hook.

Use source cutaways to show the actual object, operation or result named in the retained speech when this strengthens comprehension. Do not imply that an illustrative shot proves a material property, comparative performance or uninterrupted causal sequence that was not demonstrated. Preserve original synchronization for performance evidence and meaningful action sounds. Log every separate picture and speech source range so the edit is traceable.

Make the opening understandable without the discarded long-form context. Phrases such as “coming back to this” and unresolved pronouns need their necessary context retained or a different complete source utterance selected. Do not fabricate a new statement by splicing isolated words.

### Speech-boundary check before assembly

For every proposed entry and exit, compare the timestamped transcript with actual source audio around the boundary and the visible action/result. Inspect audible word endings and the preceding/following utterance; a transcript recognizing a complete word is not proof that the exported sound will contain its complete pronunciation. Use direct listening and, where available, waveform or pause evidence. Do not invent sub-second precision from a coarse semantic summary.

Prefer natural gaps and retain needed breaths and result holds. For approximate durations, use the agreed tolerance rather than cutting a word, negation or condition to hit a round number. For exact durations or strict caps, change the selection instead. Reject a proposed spoken cut when its transcript begins or ends mid-sentence, leaves an unresolved conjunction or pronoun, separates a number from its unit or comparison, or truncates a negation, condition or conclusion. Inspect at least 2–5 seconds before and after the source boundary, then move the boundary or choose a different complete utterance. If a critical boundary cannot be verified, record the limitation and do not mark it passed.

## STEP 4: Prepare captions and light graphics

1. Prepare non-subtitle editorial text and overlay decisions before the no-added-caption assembly. Prepare subtitle text and timing only after subtitle authorization, for the captioned derivative. Use the evidence ledger as the source of wording.
2. If subtitles are authorized, translate and condense naturally while preserving who said what, negation, uncertainty, units and qualifications. Subtitle text remains a faithful rendering of speech; editorial conclusions belong in separately recognizable callouts.
3. Derive subtitle timing from source timed speech plus the actual edit map, or from transcription of the finished rough cut followed by comparison to the source. Never burn original-source timestamps directly onto a reordered output. Recompute timings after trims, transitions or speed changes.
4. Respect the platform's subtitle safe-area and wrapping conventions. Avoid essential buttons, faces, charts and results. Resolve collisions by moving or reducing decoration rather than making captions unreadable.
5. Use restrained titles, factual number callouts, short labels and limited local enlargement. Every enlargement must preserve the demonstrated relation between action and result.
6. Use installed, verifiable fonts. If requested styling is unavailable, propose or disclose a readable substitute. Do not promise unverified animation capabilities.
7. Keep original sound synchronized with its video excerpt. Do not layer the original soundtrack twice or add default BGM. Any requested narration rewrite requires approved wording and explicit voice/audio scope before synthesis.

### Caption version check

Bind timed captions to the actual accepted edit version. Any subsequent trim, reordering, transition or speed change invalidates the previous timing until it is remapped and checked or retranscribed from the revised cut. A later caption-only request should reuse the accepted picture edit and preserve its source audio unless the user requests otherwise.

Check translation against speech for names, numbers, units, negation, uncertainty, attribution and conditions. Do not silently “correct” an unusual source model name using outside assumptions. Verify the rendered glyphs, line breaks, reading time, safe areas and protected operations in the actual captioned video, not only the subtitle text. A subtitle request is not permission to add promotional claims or replace the speaker.

## STEP 5: Assemble with deterministic media operations only

1. Do not use AI Clip Studio or any timeline-editor/plugin workflow for this Skill. Execute the user-approved edit map only with supported deterministic trimming, concatenation, audio, subtitle and render operations. If those operations cannot produce the approved result, report the precise blocker and ask for the smallest change; do not silently switch to an editor.
2. Treat the approved segment order, source ranges, content and speech as the execution contract. A required change to any of them returns to the pre-edit plan and user approval; routine technical repairs that preserve the contract do not.
3. Retain the original and existing accepted versions. Always preserve the successfully exported no-added-caption version when creating a captioned derivative. Do not claim an editable project because this deterministic path produces rendered media, not a reusable editor timeline.
4. Preserve source quality rather than repeatedly re-encoding intermediate files. Do not upscale by default. Select output settings from source metadata and explicit delivery requirements, not guesses.
5. Use cuts or restrained transitions appropriate to the material. Keep speaker audio aligned and protect demonstration legibility.
6. Keep temporary transcripts, analysis frames and intermediate renders out of the final presentation when supported. Never duplicate automatically registered outputs.
7. Preserve successful partial edits and record the last completed checkpoint. On failure, repair only the affected operation instead of restarting the entire workflow.

### Working assets and final versions

Keep proxies, boundary-review clips, transcripts and rough exports clearly distinct from deliverables. Use supported temporary-output handling when available; do not invent unsupported output modes to hide files. If intermediates must appear in the workspace, label them as working material and clearly identify the final version. Do not present every successful intermediate as a final asset or delete user assets to declutter.

Preserve accepted versions and derivation links. For a revision or caption-only derivative, use the available versioning mechanism where supported; otherwise retain both assets and identify their relationship. Avoid unnecessary re-encoding of accepted media and never claim a reusable editor project solely because a video was exported.

## STEP 6: Inspect the actual render and repair

Inspect the exported video, not just the edit map or a successful render status.

Technical checks:
- Actual duration and dimensions satisfy the agreed delivery contract.
- The output opens and contains the intended audio/video streams.
- No unintended black frames, frozen segments, missing media or silent gaps.
- Audio continuity, lip/speech synchronization and absence of duplicate tracks.

Editorial and visual checks:
- Hook appears early and the film answers it.
- A first-time viewer can identify the topic, action and result.
- Every claim retains its necessary attribution and conditions.
- Demonstrations contain enough action, feedback and outcome to be understood.
- The first-time viewer can state the theme, key point, evidence and conclusion after watching without the source or internal ledger.
- The cut is a thematic recut rather than an arbitrary excerpt; the ending does not omit a necessary result or qualification.
- Captions, if authorized, are legible, synchronized, correctly translated into the user-requested language and do not cover essential evidence.
- Crops and local zooms keep important UI, numbers and results visible.
- No accidental filler cards, irrelevant pauses or broken conversational references.

### Conflicting reviews and targeted repair

If two reviews disagree about a word, noise or timing defect, stop modifying that boundary. Compare the same interval in the original source and actual export with independent audio evidence when available. Locate whether the sound belongs to the intended sentence, the preceding/following sentence or a genuine artifact. Do not mute an uncertain region merely because one semantic report labels it residual noise.

Repair in this order: move the source entry/exit to a verified boundary; select a better natural pause or a different complete utterance; use the agreed duration tolerance if needed; only then consider local sound treatment supported by evidence. Do not silence part of an intact word. If evidence remains unavailable or contradictory, preserve the last defensible version, identify the exact unresolved interval and deliver only as a draft. Existing repair limits and stop-on-error instructions still apply.

### Four internal checkpoints

Record pass, pending or approved limitation with evidence at each checkpoint; an unmet requirement blocks normal advancement, not necessarily all useful work. Seek user decisions only for material creative trade-offs, configured reviews or changed scope—not every routine edit.

1. Source checkpoint, before final selection: transcript and visual coverage are separately recorded; failed or missing evidence is reconciled, or exact partial-source exclusions have user approval.
2. Editorial checkpoint, before rendering: the source-to-cut comparison and dual-track map support the agreed topic, self-contained opening, representative evidence and necessary qualifications. Any material topic narrowing is approved.
3. Boundary checkpoint, before rendering: selected speech entries/exits and demonstration results have been inspected; coarse analysis is not presented as word-accurate timing. Unverifiable cuts remain explicit limitations.
4. Render checkpoint, before final delivery: the actual export has been checked for meaning, all joins, picture outcomes, audio, authorized captions and technical integrity. Scope and boundary findings are revisited after repairs; no critical uncertainty is silently converted to a pass.

Output duration and resolution alone cannot pass the editorial or render checkpoint. A file may be playable and still be only an extract or a draft.

Review the hook, all cut boundaries, all claim-bearing moments, all demonstration outcomes and the ending; use continuous review when available. Record inspected intervals and unresolved coverage. Automated anomaly detection is evidence to investigate, not proof that every still frame or silence is wrong.

For each issue record output time, category, severity, evidence and the smallest correction. Apply at most two targeted repair passes after the initial render, then recheck the affected regions and global timing. Respect explicit stop-on-error instructions. If important defects remain or verification is unavailable, label the result as a draft and state the limitation; never claim full inspection or publish-ready quality without evidence.

## STEP 7: Deliver and maintain continuity

### Post-export subtitle decision

After the no-added-caption MP4 has been successfully exported, registered and checked, determine whether the subtitle decision is already resolved. If a captioned version already exists or the user explicitly declined subtitles, do not ask again. If the user previously explicitly requested subtitles, treat that as authorization and create the captioned derivative without another question. Otherwise, ask in the language of the user's current input whether to add subtitles in that same language, then stop and wait for the answer. Only an affirmative answer starts subtitle creation. Keep the no-added-caption MP4 accessible in every case. After creating subtitles, inspect the captioned derivative under the caption checks in STEP 6 and record that subtitles were added so the question is not repeated.

Deliver a usable MP4 on the Design canvas plus a concise report containing:
- Source duration and measured final duration.
- Core retained content and why it matters.
- Every used source interval in final playback order, including repeats and changed speed; distinguish speech and picture ranges when cutaways use different intervals.
- The accurate editorial form (whole-source highlight, approved topic extract, or draft), approved source exclusions and any unresolved boundary checks.
- The actual returned MP4 filename and path.
- Quality-check scope and any unresolved limitations.

Deliver a subtitle file only when requested. When a captioned derivative is authorized, deliver it in addition to—not instead of—the retained no-added-caption version. Link an editable project only when it was actually created and can be reopened. Keep internal ledgers available for revisions without cluttering the canvas with every intermediate.

Report completion only after the final media is registered on the canvas. Reuse returned paths; do not rename or relocate registered files. For later edits, retain the source evidence and accepted clips, update only affected edit-map entries, retime captions and repeat relevant quality checks. A new version of the same work should preserve access to the previous version.
