---
name: 90s-cel-animation-city-pop-short
description: |
  Create 30–90s, 16:9 Japanese 1990s cel-animation City Pop shorts from stories and references, with continuity assets, segment storyboards, video, sound, and editing; not for stills or simple i2v.
trigger-words: [90s cel animation, City Pop animation, retro urban anime short, cel animation short, 90年代赛璐璐动画, 复古都市动画, City Pop动画短片]
---

# 90s Cel Animation City Pop Short

Use this Skill when the user wants one complete 30–90 second, 16:9 horizontal Japanese 1990s-inspired cel-animation City Pop short based on a story, visual references, reference video, or optional audio. It is for connected narrative production, not a still image or simple i2v pass. Preserve approved character identity, city-space continuity, visual language, and timeline. Do not use it for stills, simple i2v, subtitle-only work, full-length music videos, anime game PVs, unrelated motion graphics, or projects over 90 seconds.

## STEP 0: CHECK SCOPE AND RESOURCES

Confirm one complete 30–90 second horizontal short with connected narrative segments. Accept stories, scripts, travel impressions, urban memories, landmark montage concepts, character/scene/prop images, reference videos, and optional music, dialogue, ambience, or SFX. If the main story or subject is unclear, ask for the missing creative material. If duration is missing, propose a duration within 30–90 seconds and confirm it before expensive production.

Use MiniMax-H3 as the default video model. If the user explicitly selects another model, check its capabilities before following that choice. After a failure, retry once for the diagnosed cause, then switch to another compatible available model instead of repeatedly forcing the same model.

## STEP 1: ANALYZE INPUTS

Analyze each source by role: story events, characters, setting, conflict, emotion, ending and timeline; character identity, silhouette, face, hair, costume, age cues and proportions; scene architecture, geography, structure, weather, time and light; reference-video camera, motion, rhythm, transitions and sound cues; audio duration, sections, rhythm, vocals and mood changes. Treat references as contribution sources. Preserve compatible identity, scene structure, spatial relations, action, medium and composition, while ignoring incidental carrier artifacts. Record what must remain recognizable, what may be adapted into cel-animation language, and which asset or shot uses each source.

## STEP 2: CREATE STYLE MASTER AND TIMELINE LOCK

Define a Style Master containing Japanese 1990s cel-animation language, hand-drawn contours, layered cel shadows, flat, graphic, hand-drawn urban backgrounds with poster-like planes, restrained analog texture, the confirmed time period, physical medium, palette direction, lighting logic, atmosphere, narrative language, required text, 16:9 frame, and total duration. Do not stack incompatible animation styles. Lock the timeline before asset production: 30–45 seconds normally uses 3–4 segments; 46–60 uses 4–5; 61–90 uses 5–7; each segment is normally 10–15 seconds. One narrative segment equals one production shot and one video segment. Internal beats may occur inside a shot but must not become extra final shots. Ask the user to confirm the Style Master and timeline.



## REFERENCE STYLE PACK: THREE URBAN CEL-ANIMATION VIDEOS AND 90S CITY POP ANIME

Treat the three supplied reference videos as a reusable style pack, not as storyboards to copy. Their shared visual language is the default reference layer for this Skill:

- **Hong Kong reference**: dense megacity skylines, layered roads and waterfront depth, recognizable towers and transit infrastructure, compact graphic pedestrians, mechanically detailed vehicles and aircraft, dramatic low-angle perspective, strong multi-plane parallax, quick movement accents, horizontal motion blur, reflective vehicle surfaces, rhythmic light flicker, and hard cuts between city scale and transport close-ups.
- **Shanghai reference**: a balance of modern towers, traditional architectural forms, and historic urban interiors; graphic hand-drawn backgrounds with selective architectural detail; stable observation shots, slow pans and tilts, deep perspective through streets or rail lines, restrained character motion, and smooth limited-animation cycles supported by strong spatial staging.
- **Social-platform reference**: polished late-1980s/1990s urban lifestyle imagery, mature character design, elegant interiors, department stores, banquet spaces, rail travel, luxury vehicles and city landmarks; calm tracking shots and composed camera moves, with occasional large-perspective establishing views and clean motion-matched cuts.



### 90s City Pop anime touchstones

Use *Cat's Eye*, *City Hunter*, and *Akira* as user-approved reference works for observable design principles, never as instructions to reproduce a specific frame, character, logo, or story. Translate them into concrete rules: stylish mature urban silhouettes and fashion-led posing; confident clean linework and expressive eyes; graphic night-city staging, vehicles, signage shapes, and street-level energy; dense architectural perspective and industrial scale; controlled cel-shadow blocks; and composed layouts that alternate glamorous city-life details with strong metropolitan establishing views. These references strengthen the retro City Pop identity but do not override the user's approved subjects, setting, or story.

### Shared visual rules

1. **Layered cel construction**: separate foreground characters or vehicles, midground action, and painted background planes. Use clear dark contour lines, controlled line weight, hard-edged two-value cel shadows, selective secondary shadow planes, and narrow graphic highlights on hair, eyes, glass, and metal.
2. **Painted urban world**: backgrounds should feel hand-painted and materially specific, combining recognizable city structure with simplified, graphic animation drawing. Preserve readable architecture, road geometry, rail systems, windows, bridges, mountains, water, interiors, and landmark proportions when relevant.
3. **Analog optical finish**: use restrained film grain, slight image instability, soft bloom around point lights, mild optical diffusion, and a tactile projected-cel impression. The finish must support the drawing and never become a heavy glitch or modern digital filter.
4. **Mechanical credibility**: cars, trains, aircraft, elevators, bridges, and other machines follow perspective and believable weight. Animate wheels, landing gear, doors, reflections, tire smoke, dust, and passing light only when motivated by the action.
5. **Camera grammar**: alternate patient observation with purposeful motion. Use low-angle or wide-perspective views for urban scale, level tracking for moving transport, slow pans/tilts for atmosphere, and foreground/midground/background parallax for depth. Do not use dramatic perspective in every shot; reserve it for emphasis.
6. **Motion grammar**: use restrained limited animation for background people and small gestures; use smoother, more continuous motion for vehicles and camera travel; use hand-drawn frame-by-frame accents for turns, hair movement, impacts, smoke, fireworks, or other story-critical actions.
7. **Editing grammar**: default to clean hard cuts, beat-aware changes, motion-matched direction, and occasional macro-to-micro transitions. Avoid decorative transitions that weaken the continuity of the city space.
8. **Sound grammar**: combine City Pop, retro synth-pop or adjacent electronic music with grounded urban foley. Let engines, rails, tires, station announcements, wind, aircraft, crowds, rain, water, fireworks, and room tone remain spatially legible beneath the music.

### Reference selection rule

Use the three references as a shared baseline, then choose a dominant sub-direction per project: Hong Kong for kinetic megacity and transport energy; Shanghai for contemplative city observation and architectural layering; Social-platform for polished urban lifestyle, interiors, mature characters, and composed tracking. A project may blend them only after defining which rule dominates camera rhythm, background density, and motion treatment. Never paste all reference traits into every shot; select the traits that serve the approved story, subject, and location.

## STEP 3: PLAN STORY, ASSETS, AND SHOTS

Write a short synopsis and timecoded segment list. Each segment specifies duration, narrative purpose, scene, characters, props, action, visible emotion, camera scale/movement, transition handoff, music and sound emphasis. Prefer medium shots, close-ups and detail shots; use wide views only when city scale, landmarks, transportation or geography matters.

If there are no character references, list every appearing or story-relevant character, their role and relationships, emotional or power tension, shared goals, conflicts, and stable cross-segment appearance. Obtain confirmation before creating character assets, then create a consistent multi-view sheet after the base asset is approved. Bind supplied character references directly when available.

Create reusable scene assets for important locations and isolated reusable assets for recurring props or vehicles. Preserve scene geometry, landmark identity, proportions, weather, time, light direction, depth and materials. Every shot names its character, scene and prop assets, states who is present, where they are, what happens, what the camera sees, what is heard, and how it connects forward. Validate that total shot duration equals the locked duration and every participant has a source or approved fallback.

## STEP 4: GENERATE AND CONFIRM ASSETS

Batch by asset category: character bases, character multi-view sheets, scene anchors, scene continuity views, recurring props/vehicles, then one 2×2 storyboard for each narrative segment. Keep the Style Master active, but do not force scene backgrounds into isolated character or prop assets.

Each 2×2 sheet shows four internal beats of one shot: beginning, action development, emotional or visual emphasis, and ending/transition cue. The four cells are planning beats, not four final shots; identity, space, action logic and relations stay consistent. Present the assets and storyboards for confirmation before generating all final video.

## STEP 5: GENERATE VIDEO SEGMENTS

Offer either a first-shot preview or generation of all approved segments. If preview is selected, generate only the first shot and wait for approval. For each segment, use approved assets, preserve its duration and 16:9 framing, describe one coherent shot with internal beats, and keep dialogue only when approved by the story. Use the previous shot as a continuity reference only when the next shot truly depends on its action, composition or camera movement; never use it instead of identity or scene assets. Do not add subtitles, watermarks, logos or unrelated text unless approved. If a master music track will be added later, do not duplicate music inside individual clips.

Check identity/costume, scene geometry, duration, aspect ratio, action readability, style, audio state and neighboring continuity. If a segment fails, retry only that segment with the smallest necessary correction and preserve unaffected assets and prompts.

## STEP 6: MUSIC, SOUND, AND ASSEMBLY

If suitable audio is not supplied, create one master City Pop-oriented bed using retro synth-pop, synthwave, lo-fi electronic textures, elastic bass, regular drums and filtered synthesizers. Support landmark changes on beats, transportation motion on low-frequency accents, denser cuts during fast movement, and sustained musical continuity across locations.

Add world-appropriate sound such as engines, tires, trains, doors, rails, aircraft, elevated traffic, wind, waterfront, rain, fireworks or crowds when relevant. Assemble approved segments in timeline order, defaulting to hard cuts and using only motivated simple transitions. Before final assembly, confirm all segments, audio direction, dialogue/sound treatment, transitions, ending and duration if not already approved.

## STEP 7: QUALITY CHECK AND DELIVERY

Verify one continuous 30–90 second film, 16:9 horizontal framing, correct order, no missing or duplicate segments, character/scene/prop/style continuity, clean audio without unintended overlap or clipping, and no unapproved subtitles, watermarks or text. Deliver the final video with a brief summary of the approved direction, segment count and sound treatment. Keep intermediate assets for segment-level revision. When a user changes style, timeline, identity or location system, revise only affected assets and segments when continuity remains valid.
