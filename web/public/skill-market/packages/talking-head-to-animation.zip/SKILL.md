---
name: talking-head-to-animation
description: Turn speech media or scripts into illustrated explainer videos with object-bound labels, optional presenter insets, responsive framing, and a gated storyboard-to-assembly workflow.
trigger-words:
- talking head
- speech to animation
- illustrated explainer
- stick figure explainer
- educational explainer
- storyboard animation
---

# Talking Head to Animated Explainer

Adapt authorized reference videos, ideas, or existing projects into a target film and explicitly scoped variants in MiniMax Design. Preserve useful narrative relationships while replacing requested people, products, copy, language, or framing. Stop at scripts or prompts when requested.

This Skill owns its flow. Use available platform capabilities directly, not a separate workflow router or planner or a nested Skill. No Hypit engine, Node.js, local model, renderer, external account, or shell-based media pipeline is required or implicitly installed. Read [Production handbook](references/production-handbook.md) before production. It and this document own prompt compilation; no extra vendor knowledge documents are required. Current capabilities remain authoritative for execution limits.

## Script Review Before Production

Before creating a talking-head explainer, determine whether the user supplied the current spoken script. If missing, transcribe and proofread the actual source speech when audio exists; otherwise draft from the topic and target duration. Present the full draft for user review and confirmation before dependent speech, paid image/animation generation or final assembly. Independent measurement and blank layout planning may continue while waiting. An already supplied current script is authoritative and does not trigger this missing-script confirmation again. Correct names, pronouns, punctuation and transcription errors; never silently alter a preserved source voice track. Follow [Script and user review](references/script-review.md) and record source, revision and review status.

## STEP 1: Establish the Goal

Classify reference remix, creation from an idea, existing-project revision, or bounded variant batch. Reuse selected assets and accepted choices. Ask only questions that block the next action. Record purpose, deliverable level, authorized sources, verified product facts, preserve/replace decisions, artifact language, aspect ratio, duration, version count, audio approach, and authorized budget scope.

Resolve duration and framing before video generation. Resolve image ratio explicitly; measured source dimensions may determine framing only when that source intentionally owns the output frame. Subtitles default to off. Narration does not imply captions, lip sync, music, or cloning. Keep interaction and prompt instructions in the current working language; audience-facing speech and copy use the confirmed artifact language. Preserve exact user text.

Inspect current capabilities only for needed operations. Honor explicit model and quality choices; otherwise use current runtime defaults. Check supported references, durations, resolutions, audio, speaker control, formats, concurrency, and aggregate limits. Do not infer prices from upstream examples. Ask before changing an incompatible explicit choice or adding an external paid service.

Use one compact authoritative canvas production record, not a node for every field. Suggested sections: brief/evidence, script, shots/anchors, selected assets, preview, variants/QA. Preserve user grouping. Logical labels are not real node IDs, importable JSON, or an editable timeline.

## STEP 2: Inspect the Reference

Actually inspect accessible video and relevant audio through platform media capabilities. Use metadata for measured facts and semantic inspection for meaning. Titles, thumbnails, prompts, or canvas edges do not prove the film was watched. If inaccessible, ask for an authorized accessible upload; do not bypass authentication or fabricate missing dialogue.

Identify information reveals, causal triggers, character/product roles, pauses, cut rhythm, and ending intent. Record evidence for shots, words, text, action, and sound; label approximate timing as estimated. Silent visual evidence cannot establish audio quality.

Create a complete replacement map. Changing a product can affect props, demonstrations, interfaces, packaging, dialogue, requested captions, and the ending. Verify claims and prices; do not invent customer endorsements. Adapt unsuitable actions or jokes rather than copying every source shot.

Analyze every contributing reference and give each ordered image, video, or audio input a separate role and prompt slot. Name defining compatible identity and structural traits, preserve source count and relationships unless changed by the user, and let images carry colors visually. Ordinary identity/style/world references are not opening frames. Exact keyframes require explicit boundary intent.

## STEP 3: Write the Target Script and Timing Plan

Write the target script first: hook, information progression, proof or reversal, ending. Use stable paragraph, speaker, shot, asset, and variant identifiers. Consult the handbook's record template. The shot table includes narrative purpose, paragraph/event anchor, planned duration, framing/action, dependencies, audio/lip sync, requested text layers, and continuity state.

Bind events to the NEW script, such as the exact product-name occurrence or completion of a conclusion. Re-measure after the selected new performance. Source timestamps are research evidence, not new subtitle timing. Anchor repeated phrases by occurrence and revision; do not force-match absent words.

Track timing as planned, estimated, measured, or verified. Sentence-level evidence supports sentence-level timing only. Do not promise precise word highlighting without reliable alignment and rendering support. Silent animation can use authored intervals.

Show the script, replacement map, shared anchors, version matrix, and pending paid work before costly generation. Existing explicit authorization for unchanged scope is sufficient; do not add per-version approval. Ask again only for material scope, creative, or cost changes not already covered.

## STEP 4: Produce Shared and Variant Assets

For clips or versions sharing a person/product, first use supplied identity assets or create and review a common visual anchor. Complete anchors before dependent clips; batch independent assets within actual limits. Each requested version remains a separate artifact unless a combined deliverable is requested.

Each prompt starts with the current goal, describes one artifact, and names each reference's individual ordered slot and purpose. Preserve concrete identity, product structure, world, layout, and continuity traits. Do not paste the complete shot table into every request.

- Images establish identity, design, composition, and requested text space.
- Videos specify performable actions, camera motion, opening/ending state, needed dialogue, sound, and continuity.
- Speech uses confirmed text, language, real supported voice selection, emotion, and pauses. Never invent voice IDs; cloning requires authorization and consent.
- Music is optional; confirm lyrics before vocal-song generation. Do not add music without a brief or request requiring it.
- Exact words and numbers use deterministic editable layers when supported, not generated pixels represented as editable text.

For in-frame dialogue specify speaker, line, voice, and non-speaker state. If reliable multi-speaker binding is unavailable, propose separate speaking/reaction shots. Narration over B-roll does not make visible subjects speak. Do not duplicate an existing dialogue track with the same voice-over.

Do not feed every preceding last frame into subsequent clips. Use boundary frames only for explicit matching requirements. Record returned node IDs, paths, versions, duration, tracks, and review results. Keep returned filenames and paths unchanged. Generation already creates canvas assets; never upload or register them again.

## STEP 5: Assemble and Preview

Select specific successful takes and update actual durations and resolved events. Replacing speech invalidates dependent timing and lip sync. Keep the selected master sound when covering dialogue with B-roll.

For editable delivery, use the available editor, opening it on the user's behalf when needed. Read documented operations and actual state before edits. Either delegate one complete self-contained editing task or directly apply documented edits, never both. A production document is not an editor project; a render is not a layered timeline.

Use dedicated ordered merging for simple concatenation; resolve size mismatches first. Prefer platform postprocessing for trimming, overlays, supported mixing, and export. For richer illustrated scenes and character motion, use an existing local code-drawing or rendering environment when the current tools actually support it and the task authorization covers it. Verify capabilities; do not guess editor methods, assume an external engine, silently install dependencies, or add paid services. If a critical capability is missing, preserve successful assets and report the quality gap; a basic filter preview is not a reference-quality final film.

Only for requested subtitles, use trusted timed text or measured transcription, safe formatting, then supported rendering or editable captions. Internal timing transcription does not authorize burn-in or subtitle export. Tools may expose intermediate timing documents automatically; do not label these requested final outputs or create extra subtitle nodes manually unless export was requested.

Review opening, longest line, key reveal, and ending before final assembly. Keep dialogue intelligible. A ratio change requires subject/graphic/caption relayout, not blind center cropping. Seek approval before costly final assembly only when existing authorization does not cover the unchanged edit.

### Pure-animation completion follow-up

After a pure-animation master is rendered and passes the first technical and visual checks, do not end the workflow silently. Present a concise next-step recommendation with three optional finishing layers:

- **Subtitles** — use the confirmed transcript, correct names and pronouns, format for the target ratio, and burn or deliver captions only after the user opts in.
- **Presenter inset** — offer a circular head-and-shoulders picture-in-picture from the authorized source video, usually lower-right with safe-area clearance; re-layout or composite it without regenerating animation when the existing animation remains suitable.
- **BGM** — offer an instrumental track only when the user wants music; keep the source speech as the master voice and duck music beneath it.

Ask the user to choose any combination, or to keep the pure-animation version. If the user selects an option, run only the corresponding postproduction step, preserve the approved animation, and perform a focused final QA. If the user declines, deliver the pure-animation master and record that the optional finishing layers were declined. Do not infer subtitles, presenter inset, or BGM from narration alone.

## STEP 6: Make Variants and Recover

Use the handbook's dependency matrix. Execute exactly the requested count and axes, never an unrequested Cartesian product. If shared design is unproven, review a representative preview unless the user explicitly authorized the full batch without that gate.

Reuse only compatible actual input and take versions. Equal names or durations prove nothing. A shared change affects all consumers; a single-version override must not silently alter other versions.

Preserve successes and repair only failed/rejected items. Timeout is unknown state, not failure. Query real returned jobs only when a status capability exists; otherwise reconcile known assets and report uncertainty before a fresh paid submission. Never invent polling or repeat an unchanged failed request. Allow at most two materially corrected retries after the initial attempt, within authorization, then ask for a specific next step. Pause affected batch work when the same fault repeats. Assembly failure does not require new source generation.

## STEP 7: Verify and Deliver

Inspect actual exported media and available audio evidence for identity/product continuity, transitions, text, timing, requested captions, speaker/lip sync, levels, ratio, safe areas, and complete ending. Mark unobserved or unlistened items unverified; structural checks are not audiovisual approval.

Distinguish planned, submitted, succeeded, selected, and verified. Canvas connections indicate user intent, not factual generation lineage. Do not count failed or unexported variants as completed.

Deliver actual final canvas media, a genuine editor project when one exists, requested editable materials, and a compact version/QA summary. State changed/reused elements and gaps. Reference every produced final asset by its exact returned filename. Never duplicate generated nodes; apply current-turn grouping once after all generation when appropriate, honoring explicit user grouping.

See [Source and adaptation notes](references/source-notes.md). Local validation does not prove live reload, marketplace approval, or successful media production.

## Illustrated Explainers and Responsive Framing

For reference-style line-art B-roll, use colourful, moderately dense concept diagrams with prominent simple characters or main graphics, clear supporting symbols and readable flat colour areas. Give the main subject visual weight; do not default to tiny stick figures, isolated colour dots or excessive empty space. Use a coordinated 3–5 colour palette across the film and usually 2–3 colours per shot. Read the illustrated-explainer reference for adjustable scale, hierarchy and colour targets. Explain one concept with actions, staged reveals and useful feedback, without building a complex realistic scene. H3 remains supported when selected; update both overly sparse and crowded composition references before generation. This mode does not override other explicitly requested styles.

Enable this mode when the task calls for it; preserve the defaults for other remix work. Read [Illustrated explainer guidance](references/illustrated-explainer.md) for talking-head animation, and [Aspect-ratio composition](references/aspect-ratios.md) for requested framing or multi-format output. These references contain operational Chinese guidance readable independently of the user-facing artifact language.

- Build an evidence-based style card: line hierarchy, character expression, palette, scene density, bubbles/icons and other visual explanations, motion, and layout. Distinguish viewed video, sampled stills, and creator claims. A still cannot prove full-motion rhythm. Inaccessible video does not block independent skill/layout edits; report the remaining evidence gap.
- Balance subject scale, colour area and negative space. Add useful supporting objects or reactions when the frame is too bare. Drawing-on, fades, arrows and icon replacements are sufficient when they communicate the concept; neither rich scenery nor continuous character acting is required.
- Inspect representative stills and a short motion sample against the reference and target display size before bulk rendering. Record technical and visual acceptance separately. No black frames and unchanged audio do not establish style quality. Simple vector graphics are valid main content in this mode; judge semantic clarity and balanced composition and colour hierarchy rather than rendering complexity.
- In original-audio mode use measured source duration and actually spoken words. Report a shorter-than-planned source; do not loop, slow down, or add unspoken subtitle sentences to fill time. Caption output still follows explicit user intent.
- Support 9:16, 16:9, 1:1, 4:5, 4:3, and custom dimensions. Produce only the requested variants. Share sound, timing, identities, and props; recompose subjects, bubbles, captions, and the circular presenter for each ratio. Input ratio does not automatically dictate output ratio. No stretching, blind center crops, or shrinking a complete portrait movie into a landscape rectangle.
- Where Python execution is available, `scripts/plan_layout.py` computes starting layout boxes; otherwise follow the reference rules. It is not a renderer, a Design project, or an official API. Per-shot composition and actual-output review remain necessary.
- Extend the production record with style evidence, primary action/response, per-ratio width/height/scene/caption/presenter boxes/font sizes/shot overrides, and visual-review findings.

### Presenter-inset remix path

When the source is a presenter-led talking-head video and the target is an illustrated explainer, preserve the presenter as a circular bottom-right picture-in-picture unless the user explicitly requests animation-only output. Lock this choice in the specification before shot generation.

1. Measure the source video and confirm the current spoken script before any dependent paid generation.
2. Show the target specification and sentence-level storyboard for user confirmation.
3. Generate one shared visual anchor and inspect subject scale, colour hierarchy, semantic clarity, and the four-sided safe area before bulk shot generation.
4. Generate silent animation shots independently. On failure, retry only the failed shot; never rerun successful shots.
5. Reserve the presenter zone in every shot layout before generation. For a 16:9 target, use a true circular head-and-shoulders inset in the lower-right, normally about 18–22% of frame height, with at least the declared safe margins from the right and bottom edges. Keep labels, arrows, cards, faces, and their full motion envelopes clear of the inset.
6. Retime shots against the complete source timeline, not only subtitle cue lengths. Include opening and inter-sentence gaps; use a held final frame to fill authored silent intervals when appropriate. Never loop, slow, or add unspoken words to fill duration.
7. Concatenate the silent shots in storyboard order, then add the source audio as the only master speech track. Do not mix a duplicate generated voice or shot audio.
8. Apply the circular presenter mask as a final deterministic composite only after the animation timeline is correct, then inspect the opening, densest shot, key semantic turn, ending, inset edge, safe margins, and audio duration.

The completed asset must be reported as a true presenter-inset version, not as a pure animation version. If the inset is omitted, state that the result is an animation-only intermediate and do not call it the completed talking-head remix.

## Four-Sided Safe Area and Minimal Scene Cues

Animation must not fill the entire frame. Reserve 8% of frame width on each side and 8% of frame height at top and bottom, then exclude captions and presenter areas. Keep every subject, bubble, arrow, scene line and its complete motion extent inside the inner animation safe area. Safety margins take priority over subject-size targets. Use a clean uniform light background; colour belongs inside characters and graphics, not decorative blobs, gradients or border foliage. Represent scene changes with only 1–3 local, lighter, thinner line-art cues such as a doorway, desk or window, without building full environments. Apply these rules to references, prompts, per-format composition and final review.

## Spoken Keywords in the Animation

Use keywords as integrated diagram annotations by default unless the user requests no text. First identify the object, state or relationship being explained, then attach the wording through a tag, card face, speech/thought bubble, sign or callout so the visual reference is unambiguous. In the supplied example, “new terminology” is a tag on a gift box: the tag and box jointly explain repackaging. Do not place changing keywords on a fixed bottom baseline or a detached blank strip; that becomes a second subtitle track. Separate deterministic text layers may ensure spelling, but their visible placement, styling and motion must belong to the illustrated object or diagram. Full-sentence captions remain separate. Follow [Illustrated explainer guidance](references/illustrated-explainer.md) for carriers, spatial anchors and visual review while retaining script review, independent aspect-ratio layouts and safe margins.


## Structured Story Animation Mode

Enable this mode when the user asks for a story-driven educational, narrative, or minimalist stick-figure video, or explicitly requests the staged storyboard-to-assembly pipeline. It supplements the ordinary talking-head remix path; do not use it for a simple one-shot talking-head restyle unless the user asks for this structure.

### Global production contract

Use a strict serial dependency chain. Complete each node, record its outputs in one production record, pause for user confirmation at the required gate, and only then enter the next dependent node:

1. **Global video specification** — author `Final_Video_Spec.md` with topic, target duration, shot-count range, selected style preset, character roles, narration language, aspect ratio, audio approach, caption choice, and approval state.
2. **Requirement clarification** — ask only for missing blocking choices. Default to 16:9, but confirm duration, style preset, narration language, and whether the original voice or newly generated narration is used.
3. **Storyboard design** — create a complete storyboard and audio-layer plan. Use the four-act structure below. Pause for confirmation before costly visual generation.
4. **Visual assets** — generate and review all reusable character key elements first; after confirmation, generate scene backgrounds in a batch. Bind each approved asset to its character or scene role in the production record.
5. **Shot generation** — generate each shot from its bound character and scene references. A failed shot may be retried independently; do not rerun successful shots. Pause for confirmation after all shots are selected.
6. **Audio and assembly** — create or reuse narration and BGM only after the storyboard and audio plan are accepted. Assemble shots in storyboard order, apply declared transitions and pauses, mix audio, and deliver the final video.

Dependencies are strict: storyboard depends on the global specification; visual assets depend on the storyboard; shot generation depends on approved visual assets; audio depends on the storyboard and confirmed narration policy; assembly depends on approved visual, shot, and audio outputs. Never silently skip a confirmation gate or start a downstream paid stage with an unconfirmed upstream creative contract.

### Final video specification

The specification must lock:

- topic and central question;
- target duration and shot-count range: for a one-minute film, 8–12 shots; for a three-minute film, 20–30 shots; for five minutes, scale the count explicitly rather than inventing a fixed number;
- one style preset for the whole project;
- protagonist, supporting characters, distinguishing head shapes and one simple accessory where needed;
- narration language and whether source speech is preserved;
- default 16:9 framing unless the user selects another supported ratio;
- caption and BGM decisions, safe-area policy, and review gates.

If the user changes the style after the specification is approved, treat it as a material replan: pause, revise the specification, and regenerate every dependent visual asset rather than mixing incompatible styles.

### Four-act storyboard contract

For educational or narrative stick-figure films, organize the story around one knowledge gap and one key message per act:

| Act | Approximate share | Function | Required behavior |
|---|---:|---|---|
| Setup | 20% | Establish ordinary life and hint at the question | Minimal background, often one horizon or one local prop |
| Struggle | 35% | Make the problem visible through failure | At least two failure shots; add a visual humor beat every 45–60 seconds in long work |
| Insight | 30% | Reveal the central principle | Mark the insight shot with `pause_after: true`; change messy lines into clean geometric organization |
| Resolve | 15% | Apply the knowledge and close | Hold the final shot for 2–3 seconds and end with a concise key-message text layer |

Each act has one `key_message`. Do not exceed one core idea per 30 seconds. A storyboard row must contain: stable shot ID, act, shot scale (LS/MS/CU/ECU), bound scene ID, bound character IDs, explicit pre-action → main action → follow-through, emotion (`neutral`, `anxious`, `excited`, `thinking`, or `relieved`), camera direction/speed and scale change, one-sentence key message, narration text, transition, and `pause_after`. Use `cut` for most shots, `fade` between acts, `pop_in` for knowledge reveals, and `wipe` only when it clarifies a spatial change.

### Minimal stick-figure visual system

The default character system is deliberately abstract: protagonist = round head plus one cowlick; supporting character = square head without a cowlick; additional characters use round, square, or triangular heads plus at most one simple accessory. Do not use skin tone or body-size differences as identity markers. State the common 2–3px outline, simple expressive face, and baseline emotion in every character description.

Scene descriptions contain no more than five core geometric elements, such as a horizon, desk outline, chair, window frame, or one sign. Keep the lower-middle area open for character staging. Characters must keep at least one-sixth of the frame from every edge. Avoid more than five simultaneous meaningful elements and avoid tilted composition except for a brief imbalance beat of no more than two seconds.

Use flat illustration, hand-drawn minimalist construction, no realistic lighting, no shadows, no shading, no photorealism, no 3D, no gradient, no texture, and no dense decorative background. All shots in one project inherit the same preset and palette.

### Style presets

Choose one preset in the global specification and apply its full lock to every image and video prompt:

- **Classic educational:** pure white background `#FFFFFF`, golden accent `#FFD700`, black 2–3px lines; `clean educational style, friendly and approachable, golden yellow accent, pure white background`.
- **Warm storytelling:** warm cream `#FFF8F0`, orange accent `#FF8C69`, dark-brown 2–3px lines; `warm storytelling style, cozy and inviting, warm orange accent, soft cream background`.
- **Cool analysis:** cool light gray-blue `#F5F7FA`, steel-blue accent `#4A90D9`, dark blue-gray 2–3px lines; `analytical style, cool and precise, steel blue accent, light gray-blue background`.
- **Tense suspense:** dark navy `#1A1A2E`, warning red `#FF4444`, white 2–3px lines; `tense suspenseful style, dramatic contrast, warning red accent, dark navy background, white lines on dark`.

Append the selected preset lock together with `no realistic lighting, no shadows, no shading, flat illustration, hand-drawn minimalist style`. For suspense, switch all line descriptions to white and the background to dark navy. Do not switch presets mid-project.

### Audio-layer contract

When narration is generated, use a warm neutral conversational profile, not a broadcast announcer voice. Keep the pace around 150–170 words per minute; make the struggle act slightly tense and the insight act brighter; place an approximately 0.8-second breath before a knowledge reveal and a 1.5-second act-end pause when the script supports it. Preserve an authorized source voice without re-recording or changing its speed.

BGM is optional unless the user requests it or the approved specification includes it. For the default hand-drawn style, prefer light acoustic guitar, ukulele, or simple piano around 90–110 BPM. A struggle variation may use a minor-color passage; return to a brighter tonal center for insight. Keep BGM at no more than 40% of the narration level by mix intent, duck it under speech, and use fades rather than abrupt changes. For work longer than three minutes or with major emotional turns, plan separate BGM sections and bind each to its audio layer.

### Shot and assembly review

Before shot generation, verify every shot has both its character and scene dependency. Do not put narration text into a video-generation prompt when an independent narration track will be used. Video prompts must describe the three movement phases (anticipation, main action, follow-through), camera direction/speed and scale change, emotion, the bound references, the selected style lock, and negative constraints such as no subtitles, no music, no realistic lighting, no shadows, and no shading.

Assemble strictly in storyboard order. Apply declared transitions only: `cut` = hard cut, `pop_in` = short scale-and-bounce reveal, `fade` = short crossfade between acts, and `wipe` = short directional wipe. Do not use complex 3D flips, more than three consecutive non-cuts, or crossfades over action unless the storyboard explicitly justifies it. For every `pause_after: true`, hold a clean final frame for about two seconds. Check that each act stays within roughly half a second of its planned narration timing, that the final insight and resolve beats breathe, and that BGM never competes with speech.
