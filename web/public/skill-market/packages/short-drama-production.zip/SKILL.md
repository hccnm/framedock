---
name: short-drama-production
description: |
  Make a short drama based on the user's request.
---


## Stage 1: Script

1. Use `references/short-drama-genres.md` to combine the user's premise with suitable references. For international dramas, also read its international adaptation section (出海改编).
2. Propose a creative outline directly, including but not limited to: title, one-sentence story, main turns, and ending direction, plus an episode outline for multi-episode work;
3. Based on the outline, write the script with `references/short-drama-script.md`.


## Stage 2: Character, scene, and prop references

- Build look references for the main on-screen characters per `references/character-reference.md`, with a separate state reference for each lasting appearance change (such as different injury levels or a costume change), and spatial references for recurring locations per `references/scene-reference.md`
- Build prop references per `references/prop-reference.md` for plot-critical props that recur across shots, appear in close-up, or change state

## Stage 3: Storyboard and segment prompts

Create the storyboard per `references/storyboard-planning.md`. Use its segment prompt template (片段提示词) to write a prompt for each generation unit with the character, scene, and prop references, keeping dialogue verbatim from the script. Use the prompts directly for video generation without saving them as a document.


## Stage 4: Video generation and assembly

- Assemble the generated video segments into the episode cut in shot-table order.
- Segments keep only dialogue, ambient sound, action sound, and Foley. When the user wants music or subtitles, generate them at the final-cut stage to match the script's emotion and timing, then combine them with the existing cut.



## Boundaries

For any request outside this skill's scope, the agent chooses another skill on its own.
