---
name: brand-ad
description: |
  Use when the user wants an official brand ad or product showcase film, such as a brand film, launch short or product hero video. Not for creator reviews, talking-head selling, unboxing or POV.
trigger-words: [homepage brand ad, product showcase, brand reveal, 首页品牌广告, 产品主角展示, 品牌视觉]
---

# Brand Ad

Make one official brand or product showcase with a clear visual idea and rich audiovisual execution. Preserve the showcase treatments in the visual-routes reference and equivalent user-requested styles. Narrative TVCs, campaign strategy and multi-film production are outside this Skill's scope: explain the boundary, then stop this Skill without specifying another Skill or workflow.

## Content ownership boundary

Brand-led showcase content is defined by brand control of the message while the product or brand remains the visual subject. People, hands, scripted demonstrations, and product use can appear as official direction, scale, or evidence; they do not become creator content by themselves. The defining goal is brand recognition, product memory, or an official visual claim without a creator's personal review or an audience-action goal.

Creator-native content commonly includes reviews, recommendations, comparisons, unboxing, personal-experience narration, first-person POV, tutorials, and platform hooks aimed at engagement, follows, inquiries, or conversion. Talking-head selling and experience-based demos remain creator-content cases even when the product is still the visual subject.

An official product demonstration belongs to the brand-led showcase category when it is authored by the brand, uses approved facts and copy, and presents product behavior or visual identity without a creator persona, personal verdict, or social-commerce call to action.

When the core deliverable is creator-native content, explain that it is outside this Skill's scope, then stop this Skill without specifying another Skill or workflow.

## 1. Continue from the supplied work

Read the brief and actual available assets before planning new work. Preserve verified identity, supplied script/storyboard, exact copy, duration intent, format and accepted art direction. Distinguish user requirements from creative choices you can develop. Ask only about a gap that materially changes identity, claims or delivery; reuse existing decisions and authorization.

If the idea is missing, develop one visible relationship or event that makes the product/brand memorable. Use a compact creative card for the takeaway, visual idea, important events and rhythm, ending and remaining preparation. If a supplied script or storyboard already communicates these decisions, continue from it and state only missing choices. Do not rebuild the card or story to satisfy a workflow template.

Select the relevant treatment in [homepage-visual-routes.md](references/homepage-visual-routes.md). Use [showcase-prompt-core.md](references/showcase-prompt-core.md) for detailed audiovisual writing; a compact plan is not a short generation prompt.

## 2. Prepare consistency anchors and scene anchors as needed

### Separate accuracy from creative freedom

Before image generation, summarize only two categories in the existing plan:

- **Must be accurate:** the real subject's form, person identity, brand marks, specified text, confirmed states and other approved requirements. Identify the source for each relevant fact; unsupported details remain unknown.
- **Open to creation:** environment, lighting, composition, palette, visual metaphor, spatial scale and emotion, within the accepted direction. Ordinary backgrounds and lighting in source photos do not become creative constraints unless the brief requires them.

Do not fill gaps in real identity with plausible inventions. Seek the missing source or clarification, or compose around an unknown detail while continuing independent creative work. Expressive changes of spatial scale do not establish real dimensions or product claims.

### Prepare two anchor roles for creative gaps

Use the accepted idea and upcoming shots to distinguish two image roles: **consistency anchors** preserve the identity and appearance of recurring people, products and other subjects; **scene anchors** establish scene design, spatial relationships, lighting, composition and creative states. Scene anchors do not carry product-appearance, logo or text consistency requirements. There is no separate KV preparation stage.

Judge existing material by the actual views, states and readable details needed. First check whether the supplied product sources make the silhouette, proportions, components, markings and required states reliably legible. If they are too unclear for reliable recognition, generate a product identity reference card before creative image generation or video production, using only supported source views and keeping unresolved details unknown. Do not let a scene anchor stand in for this identity check. Reuse sufficient originals directly. Organize scattered but legible sources into a clear identity card only when that makes them easier to use; supplement only a necessary missing view or state with supported evidence. For precise recognition, retain a clear original or local crop instead of shrinking details into a dense grid. The goal is less ambiguity, not a comprehensive card. See [product-anchor-card.md](references/product-anchor-card.md) when a product anchor needs preparation.

When a person must remain consistent across shots, check whether face recognition, body proportions, hair, clothing and carried items are covered for the planned views. Reuse sufficient character references. Supplement only a needed, missing side view, back view, facial close-up or specific state, preserving the same person and accepted styling; do not assume one full-body photograph covers every viewpoint. Establish an original character from the accepted design; use reliable sources for a real person without inventing identity. Choose view count, layout and format for recognition rather than a fixed grid.

One existing image may cover several roles. A missing file called an “anchor” is not a gap by itself. When existing work clearly covers identity and the accepted scene design, proceed with **no new image generation**. If identity remains unclear, the product card is the necessary preparation even when the creative direction is already approved. Preserve supplied scripts, boards and approved images; neither a new layout nor a generic aesthetic upgrade justifies repeating them. Respect explicit requests for text-only work or reduced preparation, except where an unclear real product would otherwise be invented or misrepresented.

### Develop complete scene designs with scene anchors

Prepare a scene anchor when an environment, important changing state or art-direction relationship required by the idea lacks usable coverage. With substantial creative freedom or a requested redesign, use it to explore a complete scene proposal. Show environment, spatial scale, materials, lighting, composition, emotion and potential change; a person or product need not appear. Include a provisional subject only when useful for scale or action relationships, without establishing person/product identity or requiring exact brand lettering. Separate consistency anchors carry subject identity into video production. A product, logo or Chinese copy in the final film does not impose those accuracy requirements on a scene image.

Choose models by image role. For consistency anchors, prioritize faithful person/product appearance, source details and needed views. For scene anchors, first evaluate a currently available image model whose strengths are decorative or editorial aesthetics, art-print or painterly direction, abstract experimentation and mood exploration. This is a soft preference: the user-selected model wins; if the feature-matched route cannot carry the scene's own required references or output constraints, use a capable alternative and explain the specific reason. Different roles in the same project or reference set may use different models; subject anchoring and scene design need not share one model.

Do not merely list those scene-design strengths as an optional alternative after defaulting to a general identity or photoreal model. When a new scene anchor is needed and no scene-specific hard requirement rules that route out, record it as the recommended first candidate, evaluate it first and use it when it satisfies the brief. Prefer text-only scene design and add only essential references when needed; do not automatically condition every scene image on the product card or character reference. Preserve accurate products, people, brand marks and specified text in their respective consistency sources and final-film requirements.

Each image needs a specific visual proposition before choosing lenses or lighting: a small subject against vast space can express isolation or power; close contact can convey touch; foreground occlusion and a distant bright area can create discovery; related shapes can connect two ideas. Decide why the image is photographed this way, then choose its means. “Premium,” “cinematic” and “high tension” do not replace this design. Apply [tvc-moodboard-creative-guide.md](references/tvc-moodboard-creative-guide.md) to the current visual gap.

### Design the set for visual rhythm

For a first scene exploration, usually start from **3–4 complementary visual states**, adjusted to the brief, existing coverage and agreed scope; this is neither a generation quota nor a required number of consistency anchors. Every added image should contribute a new discovery or useful contrast.

| Variation | Design question |
| --- | --- |
| Shot scale and subject proportion | Are we always seeing the subject from the same distance or at the same size? |
| Information and action state | Does each image reveal something new rather than repeat a display? |
| Energy and emotion | Does the set develop tension and release rather than stay uniformly intense or quiet? |

Wide, medium and close views are not a rotation schedule; change distance when it brings new information. A repeated viewpoint is useful for a deliberate state comparison, but continuity does not require every image to share it. Standalone proposals need not become a grid, a fixed shot list or equally long video segments. Use a supplied storyboard directly; a workable written shot plan may already be sufficient.

Select relevant, complementary inputs for each video within current model capacity: consistency anchors supply accurate people/product identity, scene anchors supply space, art direction and state, and the prompt explains their combination. A provisional subject in a scene image cannot override verified identity. Grids, labels, incidental backgrounds and unrelated identities do not transfer into the film; ordinary references do not implicitly bind first/last frames. Do not generate an extra complete advertising still merely to combine both roles. Reuse a suitable closing image. A logo alone supplies identity, not an ending composition: prepare only a missing close, with the mark in the upper safe area over a brand-related background capable of motion. An identity-bearing closing image serves the required brand exposure, not a requirement for every scene anchor. No pure-white static logo screen unless requested, and no later brand-name/logo overlay.

## 3. Direct and produce the film

Once the needed inputs are usable, write a self-contained prompt for the full local progression: composition and depth; material-specific light; subject action and consequence; camera start, path, speed changes, reveal and landing; cuts and outgoing-to-incoming cues; exact copy and reading time; native music, narration, Foley and ambience; brand resolution. Preserve the finished detail when submitting it.

For each generation unit, record one self-contained final prompt before generation. The prompt string actually sent must be character-for-character identical to the recorded final version, so the confirmed creative detail survives submission. No later step may shorten, summarize, rewrite, translate, reorder or silently polish it. If a revision is needed, first update and record the final version within the existing decisions and authorization, then submit that same string. If the strings differ, stop submission and resolve the mismatch; never send a summary instead.

Choose rhythm from attention, action, emotion, speech and reading. Dense inserts may open into a broad reveal; a long passage earns time through internal discoveries. No fixed shot count, equal-duration blocks or transition quota. For selected effects use [product-visual-techniques.md](references/product-visual-techniques.md); for copy, spatial type, Logo packaging, product-showcase motion or narration use [voice-keyword-typography.md](references/voice-keyword-typography.md). It carries the title-sequence rules for type roles, spatial binding, exact text, Logo protection, readable holds and inherited transitions. Do not preload unrelated methods.

Read [production-and-delivery.md](references/production-and-delivery.md) for capability, scope and continuity. Keep one integrated generation when it can carry the film; split at useful action boundaries only when needed; each segment keeps its own relevant references, sound continuity and the full detailed ad prompt. Here creative copy is generated with the picture and brand exposure uses its prepared image; generic postproduction-text defaults must not silently change that agreed treatment. Use a shared music bed only when planned, without duplicate music or narration.

Deliver the actual film, complete prompt and relevant existing/new assets with actual duration, dimensions and known limitations. Reused assets count as preparation; do not generate duplicates for delivery. Preserve completed work, report duration differences, and do not automatically regenerate, trim, pad, loop or retime to force a nominal duration.
