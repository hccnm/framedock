---
name: handdrawn-explainer-video
description: Turn a topic, article or script into a narrated, stroke-by-stroke hand-drawn video with captions, cover and chosen style and hand preset. Supports revisions; not for single illustrations.
trigger-words:
- handdrawn-explainer-video
- my-sweety-handdraw-video
- hand-drawn explainer
- whiteboard explainer
- 手绘讲解视频
- 白板讲解
- 文章转手绘视频
- 手绘视频
- 代码渲染手绘
---

# Hand-drawn Explainer Video

Deliver a playable video, cover, captions, and narration script. The bundled Python + FFmpeg scripts draw and compose every frame deterministically, stroke by stroke; image generation, speech, and transcription use the capabilities of the current execution environment. Read the [Rendering workflow](references/rendering-workflow.md) before production for environment setup, input hand-off, and file delivery.

## Show style and hand choices before production

Extract the topic, body text, and settings the user already stated. Read [Required style and hand selection](references/visual-selection.md) first and show the bundled real style previews and all six realistic-look hand presets (imported for review in the project). Never list names only or skip the choice. Ask for a topic only when none exists; never re-ask settled items.

Before generating voice or images, collect every unresolved item in one round, with no preselection and no timeout default:

| Item | How to show it |
|---|---|
| Video language | Chinese, English, or a user-specified language |
| Duration | e.g. ~30 s or ~60 s, user-specified, or explicitly "decide from content" |
| Frame and resolution | 16:9, 9:16, or 1:1 with an explicit resolution the current environment can render |
| Style | One of the 13 catalog styles numbered 1–13 with real previews; also accept a user description or explicit delegation. Every style carries a style anchor image that is passed as the style reference for every illustration |
| Drawing implement | Pen only or a specific hand preset; show the real assets as needed |
| Background music | None, add music, or user-supplied; when adding, confirm the source and style |

One table or one question is fine, and the user may answer everything in one sentence. Unanswered items stay pending; silence is not permission and old defaults are not reused. While waiting you may organize content and check capabilities, but do not generate assets that depend on pending choices. When the user says "you decide", decide only the delegated items and record why, without re-confirming; a plain "continue" is not blanket delegation.

After the settings are complete, briefly restate the actual plan and produce it; do not add an approval round. Keep captions single-layer and clearly typeset for the chosen frame. This version offers no pen-barrel ads, floating watermarks, voice cloning, or custom hand generation. Record settings per [Production options](references/production-options.md).

## Production flow

1. **Prepare the runtime, check capabilities, write the script.** First run `scripts/install_runtime.sh --check` for Python and FFmpeg (using the available verified executable); if either is missing, tell the user what will be installed and, after they agree, run `scripts/install_runtime.sh`, per the [runtime bridge](references/rendering-workflow.md). Then run the environment script from the runtime bridge (verified FFmpeg + isolated virtual environment), then confirm image generation, full narration, timestamps, and composition per [Runtime](references/local-runtime.md); report only real gaps. Create the job directory inside the current project. Write the complete narration and storyboard, e.g. 2–3 complete pictures for 30 s; let measured speech pace decide rather than padding page counts. Adaptations keep source conditions and citations. Write `design.json` per [Story and storyboard](references/story-design.md).
2. **Lock the narration first.** Generate the complete narration in one pass with available speech synthesis (a real catalog voice), or reuse an approved full recording, and convert it to a WAV master. Keep natural breaths and sentence endings. Get measured timestamps from timed transcription, check them against the script, and write the alignment file; never pass estimates off as measured. Format: [Continuous narration](references/continuous-narration.md). Without speech capability, state the gap once and ask for a recording; never deliver a silent film as complete.
3. **Representative image first, then expand.** Read the [art direction guide](dependencies/sweety-image-art-direction/GUIDE.md) before the first image and keep using it for the job; per image add only its brief and full prompt. Prepare and preflight the plan per [Style and drawing](references/style-and-drawing.md), run `art_direction.py bind-evidence`, then generate with the available image-generation capability. Check one representative image for subject, contact, and part separability before batch-generating the rest. Clean images with `clean_image.py` (on copies inside the job directory). The cover reuses the approved key visual with editable text; usually no extra image is needed.
4. **Choreograph to the voice.** Mark real parts and occlusion from the actual image; outline the whole picture before filling, in the same part order, with pen lifts between strokes and color appearing under the brush. Calm strokes are the default: trace only the main contours as a bold pencil sketch with connected strokes and a smoothed hand, and let texture arrive with the color brush; use `detailed` only when the user asks for dense line-by-line tracing. Never reveal a person as a block scan or fade. Body text shows keywords only; captions carry the full narration. Plan the whole frame before placing anything: reserve the bottom caption band (caption height plus at least 24px clearance) and keep every board word, marker and illustration above it, with visible gaps between board elements; `build` rejects any element whose ink meets the caption band while a caption is on screen. Reduce detail when it exceeds the voice window. Exact fields and commands: [Runtime contract](references/runtime-contract.md).
5. **Check a short segment, then export once.** Render a representative segment with text, outlines, fills, and captions; check the pen tip, arm, occlusion, and legibility. Then render the full film once. Run `verify`, actually view completed frames and each page's motion, record evidence per [Quality gates](references/quality-gates.md), then `finalize`. On failure fix only the affected layer; do not regenerate unaffected audio or images.

## Delivery and revision

Place the film and cover for review in the project and show the film first, with editable captions and the script; keep detailed prompts and review records in the job directory and keep the delivery message short. Captions stay in `outputs/editing/` so players cannot auto-load a second layer. State whether background music was added according to the actual choice. If no real listening was done, say "subjective listening not reviewed"; engineering checks do not replace it.

A style change redoes only affected illustrations, cover, and drawing paths; a caption change rebuilds only that layer; an unchanged master reuses its alignment. Review results must match current files and are never auto-filled as passed. Write all job material to a separate job directory in the current project; never modify the installed package or publish automatically.
