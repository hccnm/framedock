# Product-input routing and walkthrough checks / 产品输入路由走查

These are expected routing results and a desk walkthrough, not claims of live-site execution. / 以下为预期路由和文档走查，不代表已联网实测。

## Should trigger / 应触发
1. 「根据这几张记账 APP 截图和我补充的操作步骤，做一条 15 秒极简界面宣传片。」Screenshot input; visible facts are evidence, hidden interactions require steps or confirmation; output MP4 and source. / 截图可见内容为事实，隐藏交互需补证或确认。
2. “Use this official SaaS URL to research its real workflow and create a minimalist looping UI motion promo.” Verify browsing availability, record official evidence, confirm visual direction and beats before coding. / 先确认浏览能力，记录官方依据，确认方向和时间表。
3. 「找这款音乐 APP 的官方演示，用我的参考视频的变形节奏做功能展示，不要编功能。」Resolve product identity and keep product evidence separate from style references. / 核对产品身份，分离功能依据与风格参考。

## Should not trigger / 不应触发
4. 「给我的网站写一个能真实登录、支付的完整后台。」Ordinary application development, not a UI motion film. / 普通应用开发，不是宣传动效。
5. “Make a live-action influencer testimonial for this app.” Presenter-led ad, not code-drawn UI motion. / 真人口播广告，不是代码界面动效。
6. 「把这个教程录屏压成小文件，不要改画面。」Compression only, not UI flow redesign. / 纯压缩，不是界面流程重绘。

## Desk walkthrough / 文档走查
Scenario: an appointment-booking website URL, two screenshots and a motion-only reference video. / 场景：预约网站网址、两张截图及纯风格参考视频。
- Check product name, platform and public access; screenshots prove the visible date picker, not the submission result. / 核对产品及访问条件；截图不能证明提交结果。
- Build source-located verification table from official help and safe observation; if login blocks results, request a recording or user confirmation. / 建表，受限时补录屏或用户确认。
- Do not actually submit a booking without action-specific authorization. / 未授权不提交真实预约。
- Select a causal verified flow and confirm brand-faithful or minimalist redraw, format and beat table together. / 选择有因果的已核验流程，统一确认方向、规格与时间表。
- Code, sound and render only the approved scope; retain source evidence and deliver MP4/source. / 仅制作已确认范围，保留依据并交付。
- Product research capability is conditional; no live browser or third-party site was tested by these checks. / 真实调研依赖运行时能力，本次未实测第三方网站。


## Detail regressions for 0.1.2 / 0.1.2 细节回归走查

Scope: document-level expected behavior, not generated-media acceptance or live-site execution. The six routing prompts above remain unchanged because the name, descriptions and intended task boundary did not change.
范围：文档级预期行为，不是生成媒体验收或网站实测。名称、描述与适用任务不变，沿用上方六条中英文触发/不触发用例。

| Scenario / 场景 | Expected behavior / 预期行为 |
|---|---|
| A calendar app’s logo plus official feature copy, but no UI screenshot / 日历APP只有Logo和官网功能文字，没有界面截图 | Treat branding, capabilities and native interaction as distinct evidence. Continue an agreed conceptual redraw only after the material direction is confirmed, not because the logo arrived. / 分离品牌、能力、原生交互证据；概念化方向需确认，不能以收到Logo代替同意。 |
| A playback slider changes 9→100 and rubber-bands / 播放滑杆从9变100并越界拉伸 | Reserve maximum digits and adjacent controls before the flexible track. One geometry drives rail, thumb, cursor and limits; do not adopt a case-specific universal gap. / 先留最大位数和操作区，轨道滑钮光标限位同源，不固化案例间距。 |
| A switch label shifts right and then adds a status badge / 开关文字右移后新增状态徽标 | Reflow the icon-label-badge-button row together; a text-only fix must not transfer the collision to the badge. / 联动重排图标、文字、徽标和按钮，不能把遮挡转移给徽标。 |
| seek(late)→seek(early)→seek(late), including a hidden label and a later font weight / 早晚状态往返，涉及隐藏文字与后续字重 | Reset all measured visibility/layout state and preload all scripts/weights before capture. / 完整重设测量状态，提前加载全部字重与文字脚本。 |
| The user asks to fix one label near a transition without changing music / 用户只修转场附近一处文字，不改音乐 | Identify the selected work/version and dependency window; preserve unaffected content and audio. Reuse segments only with safe joins and deliver the whole work. / 锁定作品版本及关联窗口，保留无关画面音轨，安全时分段复用并交完整作品。 |
| A montage looks clear but the user reports icon occlusion / 拼图看似正常但用户指出图标遮字 | Use the reported original-resolution frame/crop and geometry within scope; do not assert a negative text-box test proves no collision or expand to a whole-film quality audit. / 按范围使用原分辨率问题帧与几何，不以文字框检测代替图标核查，不扩展全片排查。 |
| Existing monochrome reference and no glass/duration change requested / 仍用原黑白参考，未要求玻璃或改时长 | Preserve the existing style/defaults and stage order. Do not introduce purple, glass, 20 seconds or extra routine confirmation gates. / 保留原风格默认值及阶段顺序，不加入紫色、玻璃、20秒或额外常规确认。 |
| User requests analysis only / 用户只要求分析 | Deliver analysis; do not render, purchase assets or generate extra paid candidates. / 仅交分析，不渲染、不购买素材、不追加付费候选。 |
