---
name: wes-anderson-style-short-film-generator
description: |
  Create an original symmetry-led narrative, brand, or social short from a confirmed brief and references. Use for retro storybook visuals; not generic editing or copied films.
trigger-words: [Wes Anderson, Wes Anderson-style, symmetric composition, storybook short film, retro palette, 对称构图, 复古童话感, 韦斯安德森, 韦斯安德森风格短片, 短片生成]
---

# Wes Anderson–Like Short Film Generator

Use this Skill for one coherent short film, brand short, ad, or social clip whose visual language depends on centered composition, deliberate symmetry, storybook framing, exact blocking, restrained retro production design, and dry whimsy. The named director is a routing hint only: translate it into original, high-level visual attributes rather than copying a specific film, shot, character, dialogue, or living artist’s exact signature.

This is a workflow Skill, not a single prompt. Preserve the ordered stages below. Planner-owned documents and media Stages should be visible on the canvas; pause at the approval gates before expensive video or final assembly work.

## STEP 1: Confirm the brief

Collect the story idea, script or source pointers; title; target duration; aspect ratio; spoken and on-screen language; narration choice; chapter preference; and any explicit model or delivery requirement. Default to 16:9 unless the user clearly requests vertical social delivery. Do not invent missing duration, ratio, title, language, or narration requirements. If several essential values are missing, ask one compact question covering them together.

## STEP 2: Analyze source material

Use metadata for dimensions and duration, and semantic media analysis for story completeness, characters, setting, period, motifs, action, composition, broad medium, and portable design signals. Treat uploaded source material as authoritative for retained subjects and layout. Identify opportunities for symmetry, visual center, recurring framing, chapter beats, and whether the story needs expansion. Record a concise analysis document on the canvas.

## STEP 3: Lock the production spec

Create a planner-owned `Final_Video_Spec.md` or equivalent text node containing title, duration, ratio, language, narration, chapter count, audio approach, and the original visual grammar: centered balance or intentional symmetrical tension, controlled camera movement, storybook staging, precise blocking, measured retro production design, and restrained whimsical tone. If a named film is requested, ask the user to choose a broad direction or use an original direction; never treat the film title as permission to reproduce protected scenes or exact frames. Pause for confirmation before visual design.

## STEP 4: Design visual direction

After approval, define the palette in words only when supplied by the user or references; otherwise describe material and tonal relationships without inventing exact colors. Establish framing rules, center balance, foreground/background layering, production design, props, costumes, title treatment, and chapter-level tonal shifts. Preserve a common visual grammar across chapters. Record the visual direction and chapter plan on the canvas, then pause if a material choice would materially change the result.

## STEP 5: Build script, elements, and keyframe previews

Convert the approved direction into scene beats, motion beats, dialogue or narration beats, recurring elements, props, and continuity anchors. Generate a small keyframe preview set as a single composed design artifact when a sheet is requested, or as separate scene references when the final topology requires it. Keep every preview consistent with the confirmed subject count, layout, symmetry, staging, and language. If the story is too thin, mark it as needing story expansion and resolve that before full storyboard work.

## STEP 6: Generate the storyboard set

Generate all approved chapter storyboard images as one organized batch when they share a ratio and purpose. Use a suitable image capability selected from the live manifest; do not hardcode a vendor or model unless the user has chosen one. Each panel must state its scene beat, composition, camera intent, action, audio cue, and matching video-segment duration in the planner document. Symmetry is a visual anchor, not a restriction: deliberately diversify the storyboard with a broad range of shot language and composition styles, such as centered tableaux, balanced two-shots, frontal portrait frames, profile or side-on compositions, overhead or high-angle views, low-angle views, wide establishing frames, medium observational shots, close-ups, detail inserts, depth-layered staging, lateral compositions, negative-space frames, and controlled off-center tension. Use variation to serve story rhythm, character relationships, scale, reveal, and emotional contrast while preserving the overall production-design grammar and continuity. Keep chapter count at four or fewer unless the user explicitly requests more. Pause for storyboard approval.

## STEP 7: Generate video segments

Only after storyboard and visual-direction approval, generate one video segment per approved panel. Keep panel-to-segment mapping explicit and preserve continuity of identity, setting, props, blocking, and camera grammar. Use the current video capability manifest to validate mode, ratio, resolution, duration, and reference limits. Do not combine independent panels into one generation call. For a longer film, route the ordered segment work and final assembly through the Stage Execution Plan rather than pretending it is a direct one-shot task.

## STEP 8: Generate narration

If narration is enabled, generate it as a separate speech layer in the confirmed language. Use a catalog voice unless the user supplied an exact voice ID or explicitly requested cloning/design. Align narration to the approved story rhythm and chapter plan. Keep narration optional; a request for spoken audio does not imply subtitles.

## STEP 9: Generate sound effects

If sound effects are requested, define restrained diegetic and transition layers that support the storybook world without overpowering dialogue or music. Keep effect timing tied to approved scene beats. If the selected audio capability cannot create the requested sound design directly, route it to the appropriate audio or post-production Stage instead of inventing a tool call.

## STEP 10: Generate background music

Create instrumental background music as a separate layer unless the user requests a vocal song and has confirmed lyrics. Describe the emotional arc, instrumentation, pacing, and chapter transitions without copying a named composer or existing track. Keep the music plan on the canvas before assembly.

## STEP 11: Assemble and deliver

Assemble confirmed video segments, narration, sound effects, music, and title cards using the smallest suitable post-production workflow. Validate language consistency, chapter count, target duration, ratio, audio layering, readable text, and continuity of symmetry, palette, framing, and production design. If a defect is found, revise the earliest approved asset that controls it and continue from that point. Deliver the final canvas-backed media asset and a concise summary of the confirmed title, duration, ratio, language, and direction.

### Reliability rules

- Never skip an approval gate before full video generation or final assembly.
- Never use a reference to override an explicit user instruction; assign each reference a role such as source/edit, layout, style/design, character, scene, pose, or mood.
- Keep generated media on the canvas through the generation tools; do not duplicate-register their outputs.
- Preserve successful Stage outputs and retry only failed work items.
- Subtitles are off unless explicitly requested.
- If a capability or source constraint is incompatible, explain the conflict and ask before changing the user’s choice.
