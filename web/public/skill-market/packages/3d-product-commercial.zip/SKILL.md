---
name: 3d-product-commercial
description: Turn clear product images into one approved 3D-look commercial with material-led motion and native sound. Do not invent claims or editable projects.
trigger-words:
- C4D商品广告
- C4D渲染风格
- 三维质感产品广告
- 产品图生成广告
- C4D product ad
---

# 3D Product Commercial

Create one product-led commercial from user-provided product images. C4D describes the visual finish, not verified software use or an editable project. The workflow first identifies the product and its reliable visual facts, then writes and presents one timecoded script for approval, and generates one complete video with native sound for the user to review.

## Priority order

When requirements conflict, use this order:

1. **Product identity and packaging text accuracy** — preserve the product, logo, label layout, count, visible symbols and known specifications.
2. **Product clarity** — keep the hero product readable at the planned reveal points; not every shot must show the product. Material-only shots are allowed when they add a concrete sensory or structural idea and clearly hand back to the product.
3. **Credible material and motion** — use physics and visible causes appropriate to the selected product mode.
4. **Advertising communication** — make the product, value, category and visual thesis understandable.
5. **Camera variety and effects** — add richness only after the first four are safe.

If a conflict remains, simplify the conflicting layer rather than flattening the whole film. Preserve the product, the core material event and the camera energy; reduce only the effect, copy or simultaneous action that causes the conflict.

## Scope

Best for short product-led commercials from clear product images, especially beverages, cosmetics, soft goods, transparent packaging and selected products with strong visible structure. It delivers one approved timecoded script and one complete video with native music and effects for user review. It does not deliver editable C4D projects, fabricate claims or silently split one generation into multiple clips.

## STEP 1: Collect only missing requirements

Require a clear product image. Do not ask for an existing upload again. Ask together for any missing duration, framing and sound choices. Do not infer output framing from a source image.

Sound may be music plus effects, music only, narration-inclusive or silent. For a product commercial, advertising copy is not silently omitted by default: use user-provided or explicitly approved copy, or ask for the minimum copy decision before scripting. Verified packaging copy may be used as a fallback when the user has not supplied a campaign line. Subtitles remain opt-in; advertising typography and product communication are separate from subtitles.

Before recommending a duration, check that one generation can support the requested length, framing, references and native audio. Never silently change a user choice, split the work or add a post-production stage.

## STEP 2: Establish the identity record

Inspect the image and separate:

- **Product anchors:** hero object, package count, silhouette, bottle or box shape, cap, controls, label layout, logo and visible text;
- **Supporting materials:** liquid, cream, foam, condensation, glass, metal, paper, textile or other material cues;
- **Auxiliary props / ingredients:** fruit, grain, flowers, tools or set dressing that may support the story but must not replace the product;
- **Unknowns:** hidden backs, unreadable copy, internal construction, unseen mechanisms and unproven claims.

Build an identity checklist before scripting: brand spelling, logo, product name, package geometry, label layout, visible capacity / alcohol / model information, and each visible package surface. Unknown text remains unknown; never complete it from context.

Only user product images are generation references. External examples may inform general principles but must not be attached as visual, audio or intermediate references.

## STEP 3: Select one product-material mode

Choose the smallest mode that explains the product. Do not put every mode's rules into one prompt.

### Beverage / liquid / cosmetic mode

- Distinguish **exterior condensation**, **liquid inside the container**, **bubbles inside liquid** and **surface foam**. Describe them separately.
- Condensation is a thin wet film or small local beads that may gather and slide down a credible surface. Avoid giant syrup-like droplets or elastic strings.
- Liquid follows gravity, container tilt, inertia, adhesion and surface tension. Explain a direction change with a visible cause. Do not make water flow uphill or reverse into its source without cause.
- Bubbles mainly rise inside the liquid. In realistic beverage shots, do not let complete large bubbles float continuously above the rim.
- Foam is fine, irregular, airy and slowly changing. Avoid sponge holes, whipped-cream blocks or rubber slabs.
- Product-native liquid may become a connected foreground, background or transition space when its link to the package is clear. Keep the bottle, cup or package readable.
- A commercial background must not be a dead static gradient or frozen studio plate by default. Every shot needs at least one purposeful evolving background signal: liquid flow, foam expansion, bubbles, moving refraction, condensation travel, ingredient motion, light sweep or camera-space parallax. The background should support the product and remain subordinate to the hero label.
- For beverage or liquid ads, background motion may be rich and continuous: connected beer ribbons, impact waves, foam clouds, droplets, bubbles and moving highlights are valid when their source, direction and material relationship remain legible. Do not remove all background motion merely to protect text; separate the motion plane from the label-safe plane instead.
- Ingredients may fall, roll, scatter, bounce once or settle when that adds product meaning. They should exit the brand-recognition area after their action.

### Soft / textile / flexible mode

Use folds, seams, fibers, compression, stretch, drape, wrapping and recovery only when the source supports them. Do not force fluid behavior onto fabric or add a rebound event to every shot.

### Rigid / electronic / industrial mode

Prioritize edges, seams, perforations, screens, controls, assembly, reflection, thickness and camera-space parallax. Do not add water, gel or soft-body behavior by default. A graphic layout, inset or split-screen may still be used when it clarifies structure or comparison.

### Transparent / reflective packaging

Use refraction, reflection, thickness, condensation, internal layering and controlled light movement. Do not invent hidden interiors or use reflections to conceal identity defects.

## STEP 4: Write a compact script and wait for approval

Recommend one direction. Vary information density according to the concept. A 15-second beverage or similar product may use 6–8 purposeful shots when short rhythm beats, material peaks and transitions need them; it may use fewer when a longer fluid action or product reveal needs room. Do not distribute time evenly. If execution is difficult, simplify the simultaneous actions inside the affected shot before removing a shot.

For every shot, state:

- time and viewing purpose;
- subject, scale and product visibility;
- one dominant camera path and its information endpoint;
- product, material and prop action with its physical cause;
- what new information this shot adds;
- transition or hand-off;
- optional inset / split-screen roles, placement, timing and independent motion;
- exact approved copy, language, layout and safe placement;
- music and sound event.

### Camera and prop discipline

- Use macro, medium and wide views according to the product story; do not accumulate close-ups by default.
- Props and ingredients may cross the frame only when the crossing has a purpose. Do not repeatedly wipe over the product, label or brand area.
- If a shot only changes crop, speed or background while showing the same product relationship, merge it with the previous shot.
- For a 15-second commercial, normally include at least one purposeful moving inset or split-screen. It must reveal information not previously shown, not duplicate a crop of the main frame; the main frame continues its motion and the secondary view has independent movement. Omit it only when the user explicitly requests a clean single-frame film or when it would materially damage product readability.
- Do not let adjacent shots repeat the same angle and path. Across a short film, deliberately vary at least three camera behaviors when the source supports them: structural macro pass, lateral or diagonal track, short arc/parallax reveal, forward approach or pass-through, and controlled retreat/settling. State the angle change and the new information endpoint for each shot.
- A product reveal may naturally slow into the final hero frame. Do not force an extra cut merely to prove that the ending is different. If a separate hero shot is useful, make its change motivated and legible.

### Product visibility and material-only shots

- Product presence is a rhythm decision, not a per-shot quota. Alternate clear product reveals with short material-only shots when the material is a defining part of the product story.
- A material-only shot must have a concrete anchor: it observes an evidenced product material, continues a force or shape from the product, or creates a transition that resolves back to a known product feature. Do not use unrelated abstract filler.
- Keep the hero product visible at identity, spatial-reveal and ending beats. During a pure macro or material beat, it may be fully out of frame for a short interval, but the scale, material, motion direction or sound must preserve continuity.
- Do not write every shot as “product centered, slow push.” Give each shot a distinct start angle, camera path, depth relationship, speed shape and information endpoint. Alternate low/high viewpoint, front/three-quarter/profile where evidenced, macro/medium/wide, lateral/diagonal movement and approach/retreat.

### Text and packaging copy

- Treat designed text as advertising information, not as a default material label.
- Use user-provided or explicitly approved copy that helps communicate the product. A product commercial should include at least one intentional text beat unless the user explicitly requests a text-free film; if no campaign copy exists, ask whether verified packaging copy may be animated or used as the communication line rather than silently removing all text.
- Dynamic typography is part of the advertising design, not an optional production label. Text may enter with a liquid impact, emerge from foam, track with a moving reflection, be briefly occluded by a controlled splash, or settle into the final hero frame. Keep the approved words exact and protect the package label.
- Do not automatically add phrases such as `COLD GLASS`, `FOAM / BUBBLE` or other production descriptions.
- Typography follows the brand and composition. Single-line horizontal text is not mandatory; reasonable line breaks are allowed when they improve hierarchy.
- Avoid competing with text already printed on the package. Never place added copy over a label unless the script explicitly requires and protects it.
- Keep added text inside a safe margin, normally at least 7% from each frame edge unless the user requests edge-to-edge design. Check first-shot placement especially; never put copy against a corner by default.
- Specify exact copy, language, layout, size, interval, placement, animation and relation to the product. Do not promise that a prompt alone guarantees tiny packaging text.

### Required motion and communication check

Before approval, explicitly verify two independent requirements:

1. **Communication:** the script contains at least one approved product or campaign text beat, with exact wording, timing and placement, unless the user explicitly chose a text-free commercial.
2. **World motion:** every shot has a purposeful changing background or environmental motion. A static backdrop may be used only as a brief contrast or final hold, not as the default state of the film.

If either requirement is missing, repair the script and present it again; do not rely on the generation model to invent or restore it.

### Mandatory approval gate

Present the complete script and ask for explicit approval such as “确认脚本”. Duration or parameter choices do not approve the script. If the user requests changes, rewrite the affected script and present it again before generation.

## STEP 5: Complexity check before one generation

Before compiling the generation brief, count the interacting demands: number of shots, macro views, fluid events, props, inset or split-screen, exact copy, package text and complex camera paths.

If the combination is unlikely to be reliable in one generation, simplify the affected shot first: reduce simultaneous camera, material, prop and typography actions; clarify the main action; then merge only genuinely repeated content. Do not remove purposeful rhythm, material peaks or product reveals merely to make the prompt shorter.

Do not simplify away product identity, approved copy, a necessary product action or a critical material distinction without telling the user. Still generate one complete video with native music and effects; do not silently split, assemble or add post-production.

## STEP 6: Generate one complete video

Compile only the approved, relevant product constraints, shot actions, copy and risks. Do not paste the entire Skill into the generation brief. Attach only user product images and identify their roles.

Submit one generation for one complete video. Music and synchronized effects belong in that generation. If the capability cannot support the approved duration, framing, references or audio, pause and explain the exact incompatibility.

## STEP 7: Deliver for user review

Deliver the generated video directly after the generation call. Do not impose a mandatory Agent-side acceptance or evidence-review workflow unless the user explicitly asks for critique, verification or a repair report.

The user owns final acceptance. If the user reports a visible problem, preserve the output and apply only the requested repair or script revision; do not silently regenerate or call the result final on the user's behalf.

Before delivery, report only the actual output filename and any tool-level failure. Do not claim that packaging text, audio, fluid physics or camera behavior passed unless the user asks for an inspection and a media analysis was successfully completed.

## Default delivery

Deliver the approved script and one complete video for user review. Reference the actual output filename. Preserve earlier versions and do not create duplicate registrations.
