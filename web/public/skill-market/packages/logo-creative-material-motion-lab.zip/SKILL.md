---
name: logo-creative-material-motion-lab
description: |
  Create a logo motion package from a logo, brand tone, and references, covering a 3D base, material directions, and horizontal or vertical video variants. Use for brand reveals and TVC openers.
trigger-words: [logo animation, logo reveal, 3D logo, logo motion, 片头, 片尾, LOGO动效, 立体logo, 创意材质动效]
---

# Logo Creative Material Motion Lab

Follow the user's three-step workflow and keep the process visible on the canvas.

## STEP 1: GENERATE THE 3D LOGO BASES

Create a canvas brief node from the uploaded logo, brand name, brand tone, and reference images.
Then use NanoBanana Pro to generate the 3D logo bases.

**Reference pairing rule:** when generating 3D material logos, keep a strict one-logo-plus-one-reference-image pairing. Each 3D logo output must be created from the original logo and exactly one reference image, and that output should only reflect the material direction of that one reference image.

Rules:
- 1 logo + 1 reference image = 1 3D logo output
- do not mix multiple reference images into the same 3D logo base
- do not reuse one reference image as if it belongs to every 3D logo
- preserve the logo's readable structure and proportions
- let the selected reference image donate texture, material behavior, surface quality, and taste/mood cues

If the user wants multiple material directions, create one separate 3D logo base per reference image.
After the 3D logo bases are created, ask the user whether the 3D texture or material should keep following the uploaded reference images.
- If yes, continue using the reference images as the material truth.
- If no, ask the user to upload new 3D texture reference images or describe three desired material directions in words.

The goal of this step is to lock usable 3D logo foundations before any motion writing starts.

## STEP 2: WRITE THREE MOTION PROMPTS FROM THE 3D LOGO SET

Create a canvas analysis node and summarize the brand tone, logo structure, and the three 3D material directions.
From the generated 3D logo set, write three separate motion prompt directions that can be produced as final videos.
Each direction should include one horizontal prompt and one vertical prompt:
- one prompt for a wide screen / TVC frame
- one prompt for a portrait / social frame

The three directions should correspond to the three logo material directions and stay visually distinct.
Keep the prompts focused on:
- what the logo does
- how the material moves or reveals
- what the final lockup should feel like
- what stays fixed from the logo identity

Do not collapse the three directions into one generic motion style.

## STEP 3: GENERATE THE 6 H3 VIDEOS

After the prompts are ready, generate the six videos with the default video model; if the user explicitly selects another model, capability-check it and follow that choice.
Create exactly six outputs:
- 3 horizontal videos
- 3 vertical videos

Use 5 seconds for each video unless the user explicitly requests a different duration.
Each video should match one of the three material directions from Step 2.

**Video reference rule:** when generating final videos, include both the generated 3D logo base and the uploaded reference image used for that material direction as reference resources whenever available. The 3D logo base anchors the logo shape; the uploaded reference image anchors texture, surface behavior, taste cues, and brand mood.

Keep the logo identity stable across all six videos.
If the user wants different durations, ask before generation.

## STEP 4: PRESENT THE RESULT

Create a canvas summary node that lists:
- the 3D logo bases
- which uploaded reference image each 3D logo used
- whether texture followed reference images or user-described materials
- the three motion directions
- the six generated videos
- which videos are horizontal and which are vertical

If the user asks for revision, update only the specific material direction or video set that needs correction.
