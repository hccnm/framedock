---
name: trendy-3d-ins-card
description: |
  Turn a portrait, pet, mascot, or character photo into a minimalist social-frame 3D card, then optionally create a fixed-camera interaction video. Use for short social visuals, not complex stories.
trigger-words: [social app 3D character card, photo-to-3D social UI]
---

# Trendy 3D social app Card

Use this Skill to transform a user-uploaded photo into a social-media interface composition: an social-app-like post frame containing a cool 3D character avatar inspired by the photo. The Skill first produces a still card, then, if the user wants motion, guides a follow-up video with finger interaction such as swipe, tap-like, heart particles, and character idle motion.

The core value is a reusable visual format: uploaded photo → low-poly collectible figurine identity → minimalist social-frame card → optional interactive animation short video.

## STEP 1: Intake and Required Question

Confirm that the user has provided at least one portrait, selfie, character photo, outfit photo, or other image suitable for character transformation.

If no usable photo is available, ask the user to upload one photo before continuing.

Always ask the desired output size/aspect ratio before generation. Recommend **3:4** as the default because it gives enough space for the interface frame, the character, and later video interaction.

Suggested question:

- “What size do you want? I recommend 3:4 for the social-frame 3D card. You can also choose 1:1, 3:4, 4:5, 9:16, or 16:9.”

Do not ask about subtitles. This Skill is visual-first; subtitles are off unless the user explicitly requests them.

## STEP 2: Analyze the Uploaded Photo

Before generating the card, inspect the uploaded image as the character source. Extract only reusable character evidence:

- subject count and which person should become the main 3D character;
- hairstyle shape, facial expression, glasses, hat, jewelry, or other identity-signaling accessories;
- clothing silhouette and major outfit structure;
- pose or attitude if the user wants to preserve it;
- whether the source is a portrait, full body, pet, object mascot, or multi-person photo.

Let the image carry color information directly. Do not invent color descriptions unless the user stated them in text.

If several people appear and the user did not specify the target subject, ask which person should be transformed.

## STEP 3: Still Card Generation

Before generation, lock the reference-video priorities:

- the face should balance cute and cool: big head, rounded face, slightly long narrow eyes, upward outer eye corners, and a calm self-possessed expression;
- the outfit should feel like a cool hand-finished toy: headwear or hair volume with strong silhouette, chunky accessories, thick layered collar structure, and hard-edged outerwear forms;
- the composition should stay close to the reference-video logic: front-facing, centered, chest-up close-up dominant, with a square media area inside a portrait social frame;
- the media area background should remain minimal and clean, not decorative, so the figure reads like a premium 3D figurine display;
- the card should default to an already-liked state, so the social shell feels alive before any interaction video.


Generate one final still image unless the user explicitly requests multiple variants.

The still card should include:

1. **social-app-like interface shell**
   - post card layout with top profile row, username/location placeholders, media window, like/comment/share icons, caption area, and carousel indicator when useful;
   - interface elements should feel like a social app mockup, not an polished fictional social-card interface;
   - use neutral placeholders for profile, location, caption, and reaction details.

2. **Cool 3D character avatar**
   - transform the uploaded subject into a cartoon-cool premium 3D figurine / designer-toy / collectible character avatar, with stronger hand-painted toy energy and a slightly rebellious cool attitude;
   - preserve the subject’s main identity and outfit cues from the photo;
   - emphasize solid modeled forms, oversized expressive eyes, playful head-to-body proportion, and fashion-accessory details;
   - include subtle idle-ready posture: slight head tilt, relaxed arms, expressive face.

3. **Reference-video coolness rules**
   - push the avatar beyond a plain cute portrait: use a sharper stylized face silhouette, oversized expressive eyes, confident brows, toy-like head volume, and a more fashion-forward attitude;
   - add a few plausible trend accessories when the source photo has none, such as headphones, glasses, cap, stickers, patches, pins, or small wearable tech, unless the user asks for exact simplicity;
   - the media-window background should stay minimal and clean like a studio product-shot backdrop; coolness should come from the 3D figurine face, accessories, material, and attitude, not from a busy background;
   - the like icon should already be in the liked state by default, with subtle heart/reaction hints around the character, because the reference card reads as already engaged.

4. **Card composition**
   - the character should sit inside the media area as the hero subject;
   - leave enough visual room around the character for possible later finger interaction and floating heart particles;
   - keep the UI readable and balanced at the chosen aspect ratio;
   - if the user did not specify a size, default to a 3:4 vertical card presentation where the social post fills the frame like the reference video.

Recommended still-image prompt structure:

```text
Transform the uploaded photo subject into a trendy 3D collectible chibi character inside an social-app-like social post card. Preserve the subject identity, main facial/accessory cues, and outfit silhouette from the uploaded photo. Build a clean social media interface frame with profile row, media window, reaction icons, caption area, and carousel-like details. The character is the hero inside the media window, posed like a premium designer toy with expressive oversized eyes, solid 3D modeling, fashion details, and enough surrounding space for future tap / swipe interaction. Chosen aspect ratio: <confirmed ratio; default 3:4 when unspecified>.
```

Adapt the prompt with evidence from the uploaded photo and the user’s desired size. Keep the prompt positive. Do not over-constrain negative cleanup text unless the user reports a specific failure.

## Low-poly Figurine Default Rules

When the user references low-poly 3D models, toy figurines, or says the generated card is not close enough, apply these rules by default:

- Face proportion: push away from realistic oval portrait proportions. Use a two-head chibi / low-poly figurine proportion with a large head, short rounded face, wide forehead, low facial feature placement, full cheeks, and a short rounded chin.
- Eyes: avoid realistic human eyes. Use large toy eyes shaped as flattened half-ovals or soft fan shapes, with a slightly lowered upper eyelid, upward outer corners, hard-edged eyeliner, large pupils, visible toy-eye highlights, and optional dotted lower lashes. The expression should feel cool, lazy, or self-possessed rather than merely cute.
- Accessories: accessories must read as physical toy parts with thickness, contact shadows, and modeled edges. Headphones, cap, earrings, patches, bandage stickers, pins, or wearable-tech elements should look like attached 3D components, not printed decorations. Do not add glasses unless the user explicitly asks for them or the source photo already includes them.
- Outfit modeling: reduce realistic cloth folds. Use simplified low-poly / soft-vinyl clothing forms with thickened hems, chunky collars, beveled sleeves, layered neck openings, hard outerwear panels, and clear ambient occlusion at seams.
- Material: prioritize soft-vinyl / matte-plastic / semi-gloss collectible figurine material, rounded low-poly edges, broad soft highlights, and gentle contact shadows. Avoid flat 2D avatar filtering.
- Background: keep the background extremely minimal, but do not default to gray-white. Use a clean non-gray pure-color or soft-gradient studio backdrop, with light contact shadow under the figurine. The background should support toy-display feeling without becoming decorative clutter.
- Social frame: keep the social-app-like card already-liked by default unless the user asks otherwise.

- Card margins: keep visible left and right breathing space around the social post frame. The frame should not touch or nearly touch the canvas edges; preserve a clean border so the UI feels premium and intentional.
- Eye makeup balance: the eyes may be more stylized than the source photo, with stronger eyeliner, eyelid shadow, toy-eye highlights, and small graphic lower-lash marks, but they must still preserve the source person's calm gaze, brow impression, and recognizable facial character. Do not replace the identity with a generic doll face.


## Video Direction Menu

After the still card is accepted, offer a short menu of interaction directions before generating video. Keep the camera fixed and preserve the outer card frame throughout the motion. Do not let the border disappear. The background can remain minimal, but it may gain simple expressive overlays such as emoji-like faces, floating shapes, reaction symbols, or graphic bursts when they support the chosen interaction.

Recommended options:

1. **Face poke reaction** — a hand/finger pokes or taps the character’s face and the character reacts with a blink, tilt, pout, blush, or surprised expression.
2. **社交框ide-frame dance** — the character dances or bounces inside the frame while the card stays fixed and the outer border remains visible.
3. **Hand grab / reach-out** — the user’s hand reaches in, the character reaches back, and the scene creates a feeling of breaking through the frame while still keeping the card border present.
4. **Swipe / interactive response** — a finger swipes or taps, and the character or UI reacts with playful feedback.
5. **Custom interaction** — the user describes any other interaction they want.

When asking the user, keep the question concise and present the options clearly. If the user chooses custom, ask for a short description only.

## STEP 4: Review and Optional Video Branch

After the still card is generated, tell the user they can continue into an interaction video.

Ask only if they show interest, or if they already requested video:

- “Do you want me to turn this into an interactive video like the reference, with a finger swiping the card, tapping like, floating hearts, the 3D character reacting, or any user-chosen interaction from the menu?”

If the user says no, stop after the still card.

If the user says yes, confirm duration and platform ratio if not already locked. Recommend a short 5–8 second clip for a single interaction, or 10–15 seconds for swipe + like + character reaction.

## STEP 5: Interaction Video Generation

Use the accepted still card as the primary visual anchor. Preserve its character identity and interface layout.

The video should follow the reference interaction pattern:

1. **Opening hold**
   - front-facing fixed camera on the social post card;
   - character performs very subtle idle movement: tiny head bob, blink, breathing-like micro motion.

2. **Finger gesture**
   - a realistic foreground finger enters the frame;
   - finger performs either a horizontal swipe across the media area or a tap on the like icon;
   - the UI responds to the gesture.

3. **Interface feedback**
   - swipe: the inner media window slides horizontally with elastic easing;
   - tap-like: the like icon pops with a small bounce;
   - hearts or reaction particles float upward around the character and fade away.

4. **Character reaction**
   - the 3D character blinks, tilts, waves, smiles, or reacts in a cute playful way;
   - keep the movement small enough that the card layout remains stable.

5. **Ending hold**
   - the card settles in a clean hero frame suitable for looping or posting.

Recommended video prompt structure:

```text
Animate the accepted social-frame 3D character card into a short interactive social UI video. Keep the same character identity, same card layout, and same front-facing composition. A realistic finger enters in the foreground, interacts with the card by <swipe or tap>, and the interface responds with elastic motion. The 3D chibi character performs subtle idle animation, blink, head bob, and a cute reaction. Add floating heart particles after the like tap when requested. Keep the motion beat-synced, playful, fixed-camera, frame-safe, and loop-friendly. The outer social card border should remain visible unless the user explicitly asks for a border-break effect.
```

## STEP 6: Failure Handling

If the generated still needs stronger subject preservation:

- strengthen identity cues from the photo: face shape impression, hairstyle silhouette, accessories, outfit structure, and pose;
- keep the source image as the active character reference;
- do not solve identity failure by adding unrelated style words.

If the interface becomes messy:

- simplify the UI shell to profile row, media window, reaction icons, caption line, and carousel dots;
- reduce decorative text and avoid tiny unreadable labels.

If the video finger interaction contaminates the character or hides the face:

- specify that the finger stays in the foreground edge area and never covers the character’s face; preserve the card border and keep the frame readable even during interaction;
- use one clear interaction per clip instead of too many gestures.

If the user wants multiple characters:

- ask whether they want one combined group card or separate cards for each person;
- for separate cards, generate one still per subject and keep filenames distinct.

## STEP 7: Delivery

For still-only requests, deliver the generated card asset and mention that video continuation is available.

For video requests, deliver the final video asset. If both still and video were generated in the same turn, group them together on the canvas with a concise label such as “潮流3D卡片”.
