---
name: oriental-diffusion-aesthetic
description: |
  Transform an uploaded image into an Eastern diffusion still, then optionally extend it into a restrained short video. Use for poster-like image transformations, not full ads or story films.
trigger-words: [Eastern diffusion aesthetic, diffusion aesthetic, 东方弥散美学, 东方雾化风格, image first video later, still then video]
---

# Eastern Diffusion Aesthetic

Use this Skill when the user wants to turn an uploaded product, person, object, animal, or character image into an Eastern diffusion still image first, and then optionally extend that accepted still into a short video. The default flow is still image first, user confirmation second, video last. If the user only wants the still image, stop after the still image.

## STEP 1: Intake and Aspect Ratio

1. If the user did not provide a source image, ask for the image to transform.
2. If multiple images are provided, identify which one is the main source and which ones are optional references; this Skill is source-first.
3. Ask for the aspect ratio before generating the still image. Default recommendation: `3:4`.
4. If the user does not specify a size, ask; if the user says “default”, use `3:4`.

## STEP 2: Analyze the Source Subject

Identify the most important anchors in the source image before writing the prompt.

Preserve first:

- subject category and count;
- silhouette and composition;
- face impression, pose, clothing, accessories, vessel structure, logo, or pattern;
- clearly visible internal color zones already present in the source;
- which background information must stay and which should be simplified.

Common rules:

- For products / vessels: preserve proportions, functional structure, decoration, and identifying marks;
- For people / characters / animals: preserve face impression, outline, and signature clothing or accessories;
- If the source already has strong internal color blocks or patterns, treat those as the basis for later layering and looping.

## STEP 3: Still Image Prompt Kernel

The still image should not look like a realistic photo or a normal illustration. It should become a more flat, poetic, centered, symbolic Eastern diffusion poster.

### Core still-image rules

- Keep the subject centered, with a clean, continuous, smooth outer contour, like a vessel-like graphic mark;
- Keep soft internal structure, but do not turn it into real lighting or photography, and do not make it too heavy; make the diffusion body a little brighter, more legible, flatter, and more abstract; reduce local detail;
- Do not put loop, wave, relay, outward, flicker, or music language into the still-image prompt;
- Use only colors already visible in the source image's gamut; do not introduce foreign hues;
- If the source only has a few clear colors, stay inside those colors and their light/dark variations;
- Keep the background dark, clean, restrained, and paper-textured with breathing negative space, but do not add background diffusion, mist, or dirty gradients;
- Use edge glow as a clear but restrained contour separator between the subject and the background; it should be visible and supportive, but do not rely on tiny specular details to create a realistic glass look; keep both edge and interior more summarized and less material-specific;
- Keep the prompt focused on effect and structure, not on any specific artifact name, previous image name, or historical reference object; if the user wants stronger glowing haze, layered outward spread, clearer edge light, abstraction, or seal-like character, describe that visual structure only; avoid adding decorative detail or product-photography realism;
- The overall feeling should combine a modern Eastern vessel poster, an old book rubbing, and gentle atmospheric graphics, with emphasis on quietness, airiness, and negative space.

### Still-image compilation template

Build the still prompt like this:

```text
Transform the uploaded image of [subject] into a contemporary Eastern diffusion paper poster, aspect ratio [ratio].
Preserve the [3-6 most important recognition anchors], while removing realism, photographic lighting, and ordinary illustration shading.
Reconstruct the subject as a centered, flat, symbolic, vessel-like silhouette with clean, continuous, smooth outer contours.
The inside should become a large, center-out layered diffusion body: first a brighter core area, then a simplified transition band, then a more visible outer halo, like glowing haze forming a wave-like push inside the form; keep the body flatter and more abstract.
Keep soft internal structure, but only use the source image's existing color gamut; do not introduce new colors. If the source only has green and yellow, stay within deep green, light green, deep yellow, and light yellow, and compress any complexity into a few large color regions. Use fewer local details and larger color blocks.
Keep the background dark, clean, and paper-textured with breathing negative space; the background itself should stay non-diffused, but the subject halo should feel more distinct against it.
Add a restrained round Eastern emblem, seal-like symbol, or museum-card layout; use only user-provided text if any, and do not invent ad copy. Keep symbols and typography minimal.
The final image should feel like a modern Eastern vessel poster combined with gentle atmospheric graphics, not a realistic photo, a normal cartoon, an ink painting, or cyber neon; prefer abstraction over detail.
```

## STEP 4: Generate the Still Image

Use the default image generation route to create the first still.

- Keep the subject intact first;
- Then flatten it into the Eastern diffusion style;
- Do not lose the source identity just for style;
- Do not invent colors that were not in the source.

After the still is generated, show it to the user and ask whether to continue into video.

## STEP 5: Confirm Whether to Continue to Video

If the user only wants the still image, stop here.

If the user wants video, continue.

Before generating video, confirm duration. Default recommendation: 4 seconds. If the user did not say the duration, ask for 4, 5, 6 seconds, or custom.

## STEP 6: Video Extension

Build the video only from the accepted still image, and do not copy the still-image template wholesale into the video prompt; keep the video prompt limited to motion, looping, and music.

### Video motion rules

- Fixed camera, completely still;
- The subject outline stays unchanged, with no displacement or deformation;
- The background stays still, clean, and restrained;
- Only the internal color moves;
- The color must stay inside the source image's own visible gamut; do not add new colors;
- If the source only has two clear colors, stay inside those colors and their light/dark variations;
- The motion should be a relay-style outward wave: when one color wave reaches the edge, the next wave starts immediately inside, so the motion never stops after a single pass;
- The image should feel like color continuously surges outward from the inside, repeats, and hands off to the next cycle.

### Music rules

- Do not call a separate music model;
- Write the music prompt directly inside the video prompt;
- Use the video model's native audio capability;
- Default to light music / ambience unless the user explicitly asks for silence.

### Music prompt template

```text
Minimal, moderately paced, delicate electronic ambience with a clear pulse, soft synth bed, a few grainy percussion ticks or crisp accents, no vocals, no big drums, no strong melody, quiet, restrained, loopable, synchronized with the subject's relay-style outward color waves; each wave reaching the edge should slightly lift the music, and the next wave should begin immediately.
```

### Video prompt compilation template

The video prompt should describe motion, looping, and music only, not restate the still-image composition language; the vessel-like silhouette and paper-textured still are already established in the accepted image.

```text
Fixed camera. The frame stays completely still, with no zoom, dolly, pan, orbit, or rotation. The subject outline stays unchanged, with no displacement or deformation. Only the internal color changes. The color must stay inside the source image's existing gamut, with no new hues added. The motion should feel like relay-style waves continuously expanding outward: when one wave reaches the edge, the next wave starts immediately inside and pushes outward again, creating a continuous repeating outward flow, not flicker, not return, and not a single pass. The background stays dark, still, and clean, without background diffusion. Write the music prompt directly into the video prompt, using minimal, moderately paced, delicate electronic ambience with a clear pulse, synchronized to the outward color waves.
```

## STEP 7: Failure Recovery

If the result is wrong, fix it in this order:

- **New colors appeared**: lock the palette back to the source image's existing gamut and only allow light/dark variations;
- **It flickers instead of flowing outward**: switch to relay-style outward waves, emphasizing that the next wave starts immediately after the edge is reached;
- **It is too slow**: increase the density of the internal wave handoff;
- **The background looks dirty or moves**: remove background diffusion and keep a clean dark base;
- **The subject lost clarity**: reduce decoration and return to a vessel-like symbolic silhouette.

## Boundaries

Use this Skill only for a single Eastern diffusion still image and its optional short video extension.

Do not use it for:

- full brand ads;
- KOC / talking-head / unboxing videos;
- multi-shot story films;
- ordinary retouching, background replacement, or cutout work;
- unrelated video editing.
