---
name: h3-visual-design
description: |
  Use for a video built on a visible motion technique: kinetic type, logo or caption packaging, subject-tracking graphics, or live action with hand-drawn animation. Not for static design.
trigger-words: [H3 motion design, kinetic typography, motion typography, tracking graphics, TouchDesigner look, hand-drawn live action, motion packaging]
---

# H3 Visual Design

The main file only decides the visual technique and carries no concrete style recipes; once a route is chosen, read the corresponding reference on demand — that reference owns setup, prompt, generation, and delivery rules.

## 1. Trigger conditions

Enter this Skill when the requested result is one focused motion-design treatment:

| In-scope intent |
| --- |
| Directly generate a kinetic-typography or packaging piece, or add kinetic type, titles, cards, graphics, captions, logo treatments, material textures, or AE-style layouts to a person, product, logo, scene, spoken video, or original footage. The result may include exact user copy, curated copy, talking-head captions, tracked text, and designed transitions between the subject and the surrounding space. |
| Produce TD / TouchDesigner / CV tracking visuals that make a subject's perceived data visible, including tracking frames, corner brackets, topology lines, point clouds, digital IDs, scan grids, partial negatives, color inversions, debug overlays, or an AI-perception view. The result should visibly follow a person, object, or scene rather than behave as a generic abstract effect. |
| Fuse a real living space or live-action performance with 2D hand-drawn, doodle, crayon, or chalk animation through visible contact and interaction, such as drawn objects entering the room, wrapping around a person, responding to movement, or morphing between physical and drawn states. |

Judge by the core result the user wants delivered. If the request is centered on another kind of final deliverable, explain that it is outside this Skill's boundary and stop this Skill; do not specify another Skill or workflow. Never widen this Skill's scope based on a single keyword.

## 2. Route selection

| Dominant intent | Route | Required reference |
| --- | --- | --- |
| Add kinetic type, titles, cards, graphics, captions, or AE-style packaging to a person, product, logo, scene, spoken video, or original footage | `typography-packaging` | [typography-packaging.md](references/typography-packaging.md) |
| Produce TD / TouchDesigner / CV debug visuals, tracking frames, topology lines, digital IDs, partial negatives, or "the world as AI sees it" | `td-cv-tracking` | [td-cv-tracking.md](references/td-cv-tracking.md) |
| Produce videos that fuse real living spaces with 2D hand-drawn, doodle, crayon, or chalk animation | `handdrawn-live-action` | [handdrawn-live-action.md](references/handdrawn-live-action.md) |

When TD/CV or hand-drawn fusion intent appears explicitly, enter that route first; all other kinetic type, logo, spoken-word, and material packaging goes to `typography-packaging`. Never guess a route from weak signals like "cool", "effects", or "visual vibe"; when decisive information is missing, ask the user once which technique they want.

One task reads one route by default. When the user explicitly asks to combine two techniques, decide the primary route first, then read only the one additional relevant reference; never preload all routes or merge three rule sets into a single prompt.

For `typography-packaging`, ask only for missing output aspect ratio and duration. Use explicit user choices for style and text; otherwise compose them from the available facts and present them directly, without an extra confirmation round. Follow the route reference for internal defaults.

## 3. Shared execution constraints

1. Complete the work as one continuous flow within this Skill; no later step may redesign the confirmed direction.
2. Read only the references the chosen route explicitly requires; the route reference is the source of truth for concrete questions, prompt structure, generation method, and completion criteria.
3. Use only attachments, existing materials, and user facts that actually exist; never fabricate asset paths, brands, text, personal identities, or reference relationships.
4. Preserve the user's explicit model, duration, aspect ratio, subject, copy, and audio requirements; ask only for missing information that blocks the chosen route.
5. After the route produces the final prompt, the prompt shown to the user and the prompt actually used for H3 generation must be character-identical; no later step may summarize, translate, or rewrite it.
6. The route's hard rules take precedence over the generic rules of this main file; do not deliver until the route passes its own completion checks.
