---
name: half-narrated-3d-short-drama
description: |
  Create a guided 3D manhua half-narrated short drama from a story or script. Plan narration and dialogue, generate anchored shots, and deliver a dialogue video with separate narration audio.
trigger-words: [3D manhua drama, half-narrated 3D drama, 3D short drama, manhua short film, narrated 3D drama, fantasy manhua drama]
---

# 3D Half-Narrated Manhua Short Drama (Guided Pipeline)

Use this Skill when the user wants a finished **3D-rendered manhua half-drama** episode driven by first-person narration plus dialogue turns. Narration carries background, time shifts, internal thought, and what cannot be said directly; dialogue carries conflict, reveal, reversal, and emotional spikes.

**Visual style is locked** to 3D-rendered characters/scenes and manhua webtoon composition, with the three Q4 sub-modes retained. Use one approved sub-mode per episode. Cartoon or painterly drift is a defect in the default guoman mode, not a reason to reject legitimate traits of an explicitly selected rounded or painterly mode. Pure 2D, cartoons without manhua composition, photoreal CG, and live action remain outside this workflow.

**Top-2 narrator voices**: pick between male short-drama narrator and female short-drama narrator based on the genre track chosen in STEP 0 Q2. One voice for the full episode.

**Workflow is fully guided**: every irreversible decision is presented as an `question` option card with a sensible default, so the user only confirms or picks — they do not need to write a creative brief from scratch.

**Default video generation**: use **MiniMax-H3**, planning around 10s while preserving each approved, supported shot duration. Reconcile job state and existing results before retrying. A diagnosed terminal execution failure permits one cause-corrected retry only within precise existing or new authorization. Content defects use the local-repair contract. Stop and report continued failure; model switching needs approval, never automatic fallback.

**Lean anchor set**: per main character — 1 main character card + 1 three-view sheet (front / side / back) [3D characters need rotation-friendly references, not optional]; per main scene — 1 main scene card + 1 auxiliary scene card (different camera angle) [also not optional, since 3D scenes have real depth]; plus at most 1 prop card.

**User-language following**: all user-facing prompts, options, progress updates, summaries, and final replies follow the user's current language; user-provided text is preserved verbatim.

**Three delivery hard gates** (failure prevents a qualified-final claim, but permits clearly labeled review/partial handoff without automatic extra generation):
1. **Story preservation** [HARD GATE]: no original plot point is deleted, compressed, or rewritten to fit timing
2. **Canvas gate** [HARD GATE]: final spec + core assets + pre-video-generation outputs all on canvas
3. **User-language following** [HARD GATE]: all user-facing output in the user's current language

Do not use this Skill for live-action filming, pure clip editing, 2D cel-only, or long-form series planning.

## Delivery QC and Local Repair (v1.0.1)

The main files and all references follow the “Delivery and Local Repair Contract (v1.0.1)” in `references/qc-checklist.md`. Old thresholds, repair tips, examples, and completion templates do not grant extra attempts. A QC verdict is not generation authorization.

- Record shot/file version, evidence timestamps, checked coverage, pass/warning/fail/unverified, and justified not-applicable results. Sampling is not full-film verification; a correct prompt does not prove a correct render. Deliver video without narration plus separate narration audio/text/timing and QC records, not an automatically mixed narration master.
- Verified unapproved speaking-mouth action in a narration window, a character reciting narration, or simultaneous visible speakers is a hard failure. Repair only the evidenced shot. “Must redo” means repair is needed before qualified delivery, not immediate or unlimited generation. Do not infer speech from one breathing/surprise frame; inspect the interval or mark unverified.
- Timing is unified: around 10s by default, normal shots 6–10s, combat/fast cuts 4–6s, using approved supported per-shot values with a 10s ceiling. 7/8/9s examples are not instructions to upgrade to 10s. When content is complete, intelligible, contained, and free of critical overlap, accept drift ≤1.5s OR ≤20% of its reserved window; either threshold suffices. Retain larger but usable drift with a note. Old 1s/2.5s thresholds, different defaults, and historical success rates never mandate regeneration.
- Before repair, list affected shots/assets, evidence, retained outputs, proposed changes, actual invalidated dependencies, output count, attempts, and cost exposure. Money remaining is not permission. Reuse only precise unspent authorization covering this operation; otherwise ask. Default approval covers one attempt per listed artifact. Initial batch approval, failed review, or an unscoped “continue” does not cover further generation.
- Same issue: initial plus at most two substantively changed attempts, three total; stricter authorization/platform limits prevail. Model/spec changes or splitting do not reset counts; every new output counts and costs. Preserve qualified neighboring shots, narration, and old versions; inspect real dependencies rather than restarting the episode. Stop at limits, no improvement, scope expansion, unknown job state, blockers, or user pause and hand off existing results.
- Diagnose style against the approved sub-mode, anchors, and actual defect: reference binding, angle, or style block. Text edits do not repair existing media; new versions remain review candidates. Changes to sub-mode, duration, camera, story, or extra cards require approval. Never trim story or delete lines to fix timing.

---

## STEP 0: Interactive Setup — Option Cards to Start

**Goal**: lock the 5 most expensive-to-change decisions in one round so the rest of the pipeline runs without re-interviewing the user.

⚠️ **Mandatory instruction**: you MUST call `question` once (multi-step version) and ask **all 5 questions** below. Each one must include a recommended default. **Do not skip Question 5 (narration voice)** — it is an episode-level hard lock, equal in importance to the visual style lock.

Run a single multi-question `question` call (the in-app tool supports multi-step in one call) with these five questions. All questions, options, and descriptions are written in the user's current language. Each one must include a recommended default. The user can always pick "Other" or describe a custom direction in free text.

### Question 1 (mandatory) — Starting path
- **From scratch** (recommended): I have only a story idea or one-line premise
- **Partial materials**: I have a script fragment, character sketch, or reference image
- **Complete materials**: I have finished character sheets, scenes, and a full script

### Question 2 (mandatory) — Genre track

| Option | label | platform fit | auto-recommended voice (-> Q5) |
|---|---|---|---|
| ★ 1 | urban suspense (urban suspense) | Douyin / short-drama platforms | male short-drama narrator |
| 2 | ancient fantasy (ancient / xianxia) | short-drama platforms / serialized-fiction platforms | male short-drama narrator (can switch to female) |
| 3 | urban romance (urban romance) | Douyin / short-drama platforms | **female short-drama narrator** |
| 4 | campus youth (campus youth) | Douyin | **female short-drama narrator** |
| 5 | comeback growth (comeback) | Douyin / short-drama platforms | male short-drama narrator |
| 6 | apocalypse survival (apocalypse) | short-drama platforms | male short-drama narrator |
| 7 | other-world adventure (isekai) | serialized-fiction platforms / ReelShort | male short-drama narrator |
| 8 | custom (custom) | — | male short-drama narrator (default) |

> **Rule of thumb**: **male-frequency genres** (suspense / power / battle / thriller / apocalypse) -> male voice; **female-frequency genres** (romance / campus / healing) -> female voice; ancient / generic -> default male, user can switch to female.

### Question 3 (mandatory) — Format lock
- **Aspect ratio**: 9:16 portrait (recommended for Douyin/short-drama platforms/ReelShort) / 16:9 landscape / 1:1
- **Duration**: 30s hook clip / 60s short / 90s standard (3D manhua shot is longer, so fewer shots than 2D) / 3min full episode
- **Subtitle mode**: burnt-in subtitles / soft subs / no subs
- **Delivery target**: short-video platforms / short-drama platforms / ReelShort / YouTube Shorts / TikTok / other

### Question 4 (mandatory) — Visual style confirmation
This is **NOT a free choice** — visual style is locked to 3D manhua. The question only confirms the user has read the visual lock, and offers 3 sub-mode flavors within the same 3D-manhua family:

- **Chinese-animation 3D render (default)**: 3D-rendered characters and scenes, manhua panel composition, clean dark outlines over 3D shading, and strong cinematic light and shadow.
- **Rounded family-animation 3D**: rounded shapes, expressive eyes, soft cinematic lighting, stylized non-photoreal materials, and dynamic manhua framing.
- **Painterly semi-realistic 3D**: semi-realistic proportions, PBR materials with painterly surface texture, dramatic cinematic light, and manhua framing.

> If the user requests pure 2D cel animation, pure photoreal CG, live-action filming, oil painting, ink wash, or line-only art, direct them to a more suitable Skill.

### Question 5 (mandatory, ⚠️ cannot skip) — Narration voice (Top-2 Douyin-style)

**The first two options are always "male short-drama narrator" and "female short-drama narrator"**, with the ★ default auto-recommended by the genre track chosen in Q2.

| # | User-facing label | voice_id | style |
|---|---|---|---|
| ★ 1 | **male short-drama narrator** | locked catalog narrator voice | steady, clear, and explanatory |
| ★ 2 | **female short-drama narrator** | selected catalog narrator voice | clear and steady, with a broadcast-style delivery |
| 3 | warm male narrator | selected catalog voice | warm and restrained; suited to ancient romance or tragic romance |
| 4 | mature authoritative narrator | selected catalog voice | mature and authoritative; suited to political intrigue, business, or suspense |
| 5 | youthful narrator | selected catalog voice | sincere and conversational |
| 6 | young student narrator | selected catalog voice | young and campus-oriented |
| 7 | custom / audition | leave blank or add a note | let the user audition the full catalog |

**Auto-recommend ★ by Q2 genre**:

| Q2 genre | Q5 ★ default | voice_id |
|---|---|---|
| urban suspense | male short-drama narrator | the locked catalog narrator voice |
| ancient fantasy | male short-drama narrator | the locked catalog narrator voice |
| urban romance | **female short-drama narrator** | the selected catalog narrator voice |
| campus youth | **female short-drama narrator** | the selected catalog narrator voice |
| comeback growth | male short-drama narrator | the locked catalog narrator voice |
| apocalypse survival | male short-drama narrator | the locked catalog narrator voice |
| other-world adventure | male short-drama narrator | the locked catalog narrator voice |
| custom | male short-drama narrator | the locked catalog narrator voice |

> ⚠️ **Anti-pattern (gender mismatch)**: do not force a male voice onto a female-frequency / female-protagonist story (e.g. female-led romance with male voice sounds jarring). The Q5 ★ default is designed to prevent this. See `references/voice-presets.md` for the full logic.

### Output of STEP 0
A pinned `Project Lock Card` containing:
- **user_language** [NEW for v2.0.3]: detected from user's first message, locked for the session; drives all ULF rules
- **output_language** [NEW for v2.0.3]: default = user_language; can be overridden if user wants to publish to a different-language platform
- start_path
- track
- aspect_ratio, duration, subtitle_mode, delivery_target
- visual_style_lock: `3D-manhua-cel` + sub_mode (default: Chinese-animation 3D render)
- **narrator_voice_id** (default the locked catalog narrator voice) + narrator_voice_preset_label (use platform's localized display name, e.g. `male short-drama narrator`)
- **`narrator_volume`** (default `1.8`, range 1.2-2.0) [NEW for v2.0.1] — narration must be louder than the default 1.0, otherwise the half-narrated function dies in noisy viewing environments
- video_generation: MiniMax-H3 image-to-video by default; user-selected alternatives require a capability check; default shot planning around 10s

> **[v2.2.0]** This Skill delivers a dialogue-only video and a separate narration audio package for user-led editing. It stops before narration-to-video compositing.

Do not proceed to STEP 1 until the Project Lock Card is filled and shown back to the user.

### Voice re-ask rule (rare, but documented)

If the user later asks to change the voice mid-project, you may re-run Question 5's list, but you MUST warn the user:
- An explicit whole-episode voice change requires a scoped count/cost approval for all affected narration; an audition is not episode-wide rerecording permission. Local audio defects repair only their segments. Retain source files and qualified video; rebind the voice after the new version is reviewed.
- The voice lock re-binds from that moment; the next episode in the series uses the new voice

If the user is on episode 2+ of a series, **default to reusing the previous episode's `narrator_voice_id`** without re-asking.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 1: Analyze the Source and Read the Story

If the user is from-scratch: ask 2–3 light questions to extract premise (use a single `question` with free-text "Other" option, plus a few structured choices for genre sub-flavors). If the user already gave a script or reference, skip directly to analysis.

Analyze the source to extract:
- story premise and hook
- conflict spine and turning points
- narration vs dialogue split
- **visual DNA within the 3D manhua family**: 3D character proportions, material logic (skin / fabric / metal / glass), color logic, lighting direction, manhua panel composition
- **motion logic**: 3D character action capability, camera move freedom (orbit / follow / push-pull / pan), environmental motion
- continuity risks: identity drift, material drift, lighting drift, pacing dead spots, over-static shots

### Narration / Dialogue Classification Hard Rule [HARD GATE]

> **Why this guardrail exists**: narration-first's premise is that the story is complete and every line is clearly attributed. If a line in the original script is not classified as narration or dialogue, STEP 5.5 reconciliation and STEP 5.6 narration-first cannot align.

**Hard rule for classifying a line as narration or dialogue** (STEP 1 must follow this):

| Sentence pattern | Category | Example |
|---|---|---|
| First-person ("I" / "we") + inner thought / mental monologue | **narration** | "I thought: she must be deceiving me." |
| First-person + time skip / background | **narration** | "That year, I was eighteen." |
| Third-person narration / environment description | **narration** | "Three days later, heavy snow fell over the capital." |
| Quoted + clear speaker + action / emotion | **dialogue** | He sneered:"You should bow." |
| Same-shot multi-character conversation (with or without quotes) | **dialogue** | Example: the speaker asks a question while another character reacts. |
| Ambiguous (no quotes, no speaker) | **pending** | mark `needs_user_confirm: true` and ask user |

**Output format** (`narrative_split.md` from STEP 1):

```yaml
narration_lines:
  - text: "I thought: she must be deceiving me."
    needs_user_confirm: false
  - text: "Three days later, heavy snow fell over the capital."
    needs_user_confirm: false
dialogue_lines:
  - speaker: "the speaker"
    line: "You should bow."
    tone: "cold"
    needs_user_confirm: false
pending:
  - text: "He turned and walked away."
    reason: "no quotation marks or speaker, cannot determine"
```

`needs_user_confirm: true` lines MUST be resolved with a single `question` ("is this line narration or dialogue?") — never default.

**Hard constraint** (story preservation [HARD GATE]): every line in the original script must be classified into one of the three categories above; **none may be dropped**. If a line is both narration and dialogue (e.g. first-person inner monologue + mouth moving), handle via "split shot or split window" (see STEP 2 conflict resolution), not by merging at classification time.

For each major beat, write a concise internal director's read:
- dramatic function, turn, POV, power shift
- hidden objective, obstacle/tactic
- subtext or contradiction
- visible suppressed behavior
- non-transferable detail
- stock solution refused

**End of STEP 1 — show the story read in 5 bullets plus `narrative_split.md` and ask**: "Continue to the beat chain? (Continue / Adjust hook / Adjust genre / Resolve pending narration-dialogue labels)"

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 2: Build the Story Spine and Episode Beat Chain

Lock one main track from STEP 0, then define the episode as a 5-beat chain:

1. **Setup** (setup)
2. **Pressure** (pressure)
3. **Response** (response)
4. **Turn** (turn)
5. **Cliffhanger or payoff** (cliffhanger / payoff)

For the narration channel:
- narration may explain background, time shifts, inner thought, and things a character cannot say directly
- narration must never replace role dialogue when conflict, reveal, reversal, or emotional explosion belongs to the character
- use narration to support the story, not to flatten it into summary

For the dialogue channel:
- dialogue carries the key clash, reveal, refusal, counterattack, and emotional turn
- keep lines short, sharp, and colloquial
- give each main speaking role a stable phrasing style or catchphrase

Default balance:
- narration around 60%, dialogue around 40%
- no more than 2 consecutive narration blocks without an action or dialogue beat
- if narration and dialogue share the same shot, assign them to different time windows and keep them non-overlapping
- **if the same plot point needs both narration and dialogue, prefer split-shot / extended-shot / time-offset solutions — never hard-stack them in the same time window**
- **never delete a plot point from the original script; only move it to an adjacent shot, split into the next shot, or keep it intact**
- narration clips are generated per shot first, then paired with the shot video
- dialogue uses the video's original spoken audio by default

### Narration Completeness Self-Check (End of STEP 2, narration-first Guardrail 1/3) **[HARD GATE]**

> **Why this guardrail exists**: narration-first's premise is story completeness. If the narration is written thin and we rely on STEP 5.6 "rewriting for timing alignment" to fill it in, the 5-beat chain will run its course with the story already flattened.

**5 completeness self-check items** (each must ✅, otherwise fix STEP 2, not later):

1. ✅ Can each narration block independently carry a story beat (background / time skip / inner thought / unsayable)?
2. ✅ Does each beat have enough information density?
3. ✅ Is anything inside the "red-line circle" missing (relationships, hidden motives, time pressure, foreshadowing)?
4. ✅ Is there any "re-narration" of what the visual already says?
5. ✅ Does the final beat actually leave a cliffhanger or payoff (not an anti-climax)?

**If self-check fails**:
- Fail -> fix STEP 2 (beat chain / narration channel duties / balance), do not fix narration text via STEP 5, do not delete narration words via STEP 5.6.

**End of STEP 2 — show the user the 5-beat chain AND the narration completeness self-check table and ask**: "beat chainiswhetherpass?(pass / adjust a beat / change ending direction / redo narration self-check)"

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 3: Write the Final Video Spec

Create a production spec that locks the episode before asset generation. Include (see `references/final-video-spec.md` for the full template):

- drama title
- aspect ratio, episode duration, output language
- **visual_style_lock: `3D-manhua-cel`** + sub_mode (from STEP 0)
- protagonist narrator profile
- narration-to-dialogue balance
- world, era, faction, or conflict system
- subtitle mode
- delivery target
- continuity rules
- shot count target
- global constraints: no unwanted text overlays, no watermark, no baked-in background music in shot renders
- **video capability lock**: use a currently available image-to-video capability selected by the platform; preserve the confirmed aspect ratio and shot durations
- **audio lock**: narrator_voice_id (from STEP 0, default the locked catalog narrator voice), one voice for the full episode; dialogue voices bound to characters; no narration/dialogue overlap unless explicitly approved
- **canvas rule [HARD GATE]**: place the final spec and every core asset card on canvas so the user can review the project before final generation; any core assets produced before video generation must also be placed on canvas immediately for user inspection and adjustment.
- **story preservation rule [HARD GATE]**: every original plot point must be preserved; no compression / rewriting to fit timing
- **3D manhua additional locks**:
  - per main character: 1 main card + 1 three-view sheet (front / side / back)
  - per main scene: 1 main card + 1 auxiliary card
  - per shot duration: 6–10s (combat / fast-cut 4–6s)
  - per shot first_frame: must match the camera angle (side view -> side view card; back view -> back view card)

**Mandatory**: confirm the spec with the user via `question` before any expensive asset generation. Use a single question with options: pass / adjust aspect ratio or duration / adjust genre track / adjust visual sub-mode / adjust narrator voice.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 4: Plan Key Elements and the Visual State Ledger

Classify assets into three tiers:
1. **Core assets**: protagonist, primary recurring scene, and first reusable key prop
2. **Conditional assets**: supporting roles, major scene variants, or props that clearly affect blocking or story understanding
3. **Skip assets**: incidental background details, unnamed extras, or one-off objects without continuity value

Plan and record:
- main characters (each main character needs: 1 main card + 1 three-view sheet)
- recurring scenes (each main scene needs: 1 main card + 1 auxiliary card)
- key props (at most 1 prop card)
- audio keys: narration voice, dialogue voices, SFX, BGM mood
- **locked narrator voice id** (from STEP 0) — used for every narration clip
- a dialogue voice map that binds each speaking role to one fixed voice

For each shot, build a visual state ledger (see `references/visual-state-ledger.md`) with:
- character pose and position
- prop state and orientation
- environment and time of day
- light direction and color behavior
- **3D material block** (skin / fabric / metal / glass) — new vs 2D skill
- emotional state and physical tension
- what the next shot must inherit
- shot-level audio windows for narration and dialogue when speaking is present

**Style enforcement reminder**: each visual state follows the approved 3D-manhua sub-mode. Legitimate rounded/painterly traits are not drift. Reject pure 2D, cartoons without manhua composition, photoreal CG, or live-action replacement, not isolated keywords.

**3D manhua multi-angle asset mandate (the core difference from 2D)**:
- Every main character needs a **three-view sheet** (front / side / back).
- Every main scene needs an **auxiliary card** (different camera angle).
- These two extras are NOT optional for 3D manhua.

Ask for confirmation before generating the key element images. **[Canvas gate HARD GATE]**: once generated, place them on canvas immediately so the user can inspect and adjust them before any video generation begins.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 5: Draft the Storyboard and Prompt Package

Write the storyboard so each shot can be generated without re-interviewing the user. If key element images or core assets already exist, make sure they are on canvas first so the user can review them before continuing into video generation. Each shot should include (see `references/storyboard-design.md`):
- shot title and beat role
- approximate duration (**6–10s** for 3D manhua, 4–6s for combat / fast-cut)
- scene and characters
- blocking and spatial anchors
- **`narration_lines`** — uniform format `[{text, start, end}]`; start and end MUST be assigned during storyboard design, then checked against measured narration duration
- **`dialogue_lines`** — uniform format `[{speaker, line, tone, start, end}]`; start and end MUST be assigned during storyboard design, then checked against dialogue timing
- performance notes
- shot start state
- action progression
- shot end state for the next beat
- audio timeline with pre-allocated narration and dialogue windows, safety gaps, and tail buffer
- **3D manhua style block**: 3D-rendered / manhua cel-look / non-photoreal / material keywords
- **first_frame source** (with `first_frame_angle_match` 3D field)

Rules for shot design:
- every shot must change story state or camera grammar
- adjacent shots must not repeat the same action, same first frame, or same camera logic
- one shot should only carry one major emotional or factual job
- keep the handoff from one shot to the next explicit
- if narration and dialogue both exist in one shot, assign them to separate windows and keep them from overlapping
- narration audio is produced per shot first, then handed off separately for user-led editing
- **3D manhua camera freedom**: orbit / tracking / push-pull / pan shots all allowed; pacing slower (6–10s per shot) because 3D camera moves have weight
- **first_frame must match camera angle**

### Shot audio-space reservation [HARD GATE]

Audio placement is designed at storyboard time, before shot video generation. Every shot row MUST reserve explicit space for narration and dialogue instead of filling the shot with dialogue first. Include:

- `narration_window: [start, end]`
- `dialogue_window: [start, end]` or an explicit empty window
- `narration_reserve_sec`, `dialogue_reserve_sec`, `gap_sec`, and `tail_buffer_sec`
- `audio_priority`: narration / dialogue / none

When both channels are present, the windows MUST be non-overlapping and separated by a visible safety gap. As a default planning budget, reserve up to 35% of the shot for narration, up to 55% for dialogue, at least 0.3 seconds between speaking windows, and at least 0.3 seconds of tail buffer. Never write a full-dialogue shot and try to squeeze narration into leftover time. If both channels cannot fit, extend the shot within the allowed range or split the beat during storyboard design.

The exact windows, not just the text, are part of the shot contract and MUST be copied into the shot-generation prompt. The generated video should leave the narration window free of character speech and should place dialogue only in its assigned window.

### Narration Word-Count Pre-Check (End of STEP 5, narration-first Guardrail 2/3) **[HARD GATE]**

> **Why this guardrail exists**: STEP 5.6 rewriting narration flattens the story, so narration word count must be capped at STEP 5.

**Estimation formula** (using the locked voice_id and speed from STEP 0):

```
predicted_narration_duration = chinese_word_count × 0.25s + 0.3s start-buffer
(based on the male-qn-* / Chinese (Mandarin)_* family at speed=1.0, average ~4 chars/s)
```

**Per-shot narration word-count hard cap** (3D manhua, H3 10s mode):

| Shot type | Max Chinese characters | Max duration |
|---|---|---|
| Normal shot (6–10s) | 28 chars | ~7.6s (fits an 8s shot) |
| Key emotion shot (8–10s) | 32 chars | ~8.6s (fits a 9s shot) |
| Long inner / background (10s) | 36 chars | ~9.6s (fits a 10s shot) |

**Decision rules**:
- word count <= cap ✅ — narration will fit the shot
- word count > cap ⚠️ — **split at STEP 5**
- word count > cap × 1.3 🔴 — **go back to STEP 2 and re-balance beats**

Every shot's `narration_text` is annotated with `narration_word_count` and `narration_predicted_duration` as a human-readable checklist.

If the user only wants a storyboard package, stop here and deliver it. Otherwise present the storyboard to the user with an `question`: pass / adjust a shot / adjust dialogue / adjust pacing / **split an overlong narration shot**.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 5.5: Script Reconciliation Check **[MANDATORY, HARD GATE]**

> **Why this step exists**: prevent the case where STEP 5 misses a plot point, STEP 8 finishes the video, and the user says "wait, where's that dialogue line?" — reconcile up front.

This step MUST be passed before STEP 5.6.

### Step 5.5.1 — List all original plot points

From STEP 1's `narrative_split.md`:
- `original_plot_points[]`: every `narration_lines.text` + every `dialogue_lines.line`
- Numbered: P001, P002, P003 ...

### Step 5.5.2 — List plot points covered by the storyboard

From STEP 5's storyboard:
- `covered_plot_points[shot_id] = [P001, P003, ...]`
- Each shot's narration_lines / dialogue_lines mapped back to plot points

### Step 5.5.3 — Reconciliation table

Output `script_reconciliation_table`:

| plot_point | text | covered_by_shot | status |
|---|---|---|---|
| P001 | "I thought: she must be deceiving me." | shot_03 | ✅ |
| P002 | "He sneered:You should bow." | shot_05 | ✅ |
| P003 | "Three days later, heavy snow fell over the capital." | — | ❌ missing |
| P004 | "I ran out of the manor." | shot_08 | ✅ |
| ... | ... | ... | ... |

`status` three values:
- ✅ `covered`: a shot's narration_lines / dialogue_lines contains this
- ❌ `missing`: not in the storyboard
- ⚠️ `partial`: text was changed (simplified, merged)

### Step 5.5.4 — Handle missing / partial

For each ❌/⚠️, use a single `question`:

| Option | label | when to pick |
|---|---|---|
| ★ 1 | Add a new storyboard shot | the missing plot point must be kept |
| 2 | Merge into an adjacent storyboard shot | content fits an existing shot |
| 3 | User explicitly deletes | user says this segment is out |
| 4 | Move to the next episode | this episode can't fit it |

**Anti-patterns**:
- ❌ Default ❌ -> ✅ (pretend the reconciliation passed)
- ❌ Hide the table from the user
- ❌ Push forward to STEP 5.6 with >20% plot points missing

### Output of STEP 5.5

- `script_reconciliation_table`
- User's decision per ❌/⚠️
- **Updated storyboard** (if any add / merge / delete / move happened)

Do not enter STEP 5.6 until `script_reconciliation_table` passes and the storyboard is updated.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 5.6: Schedule-First (TTS Preview for Both Narration and Dialogue) **[MANDATORY, v2.0.2 REWRITE]**

> **v2.2.0 scheduling rule**: STEP 5 designs the audio windows first. STEP 5.6 measures narration and dialogue previews against those pre-allocated windows, then locks `shot_audio_schedule` and passes it to STEP 6 as the `audio_schedule` block in the prompt. Dialogue preview remains timing-only and is not used as final dialogue.

**Premise: the story spine is complete (STEP 5.5 passed).** Schedule-first is not a tool for filling in an unfinished story — it is a timing lock for a complete episode.

**🚨 STEP 5.6 Guardrail 3/3 (story completeness first)**: every decision in this step must put "story completeness" before "duration alignment". Now applies to **both** narration and dialogue:
- ✅ First priority: design enough narration and dialogue space in STEP 5
- ✅ Second priority: extend within the allowed shot range or split the beat only when the planned windows cannot fit
- 🟡 Small measured deviations are acceptable; keep the planned windows as the edit guide
- 🔴 Always forbidden: speed up speech, force-delete story content, or hard-stack speaking windows

> **After STEP 5 locks all text, this step is not allowed to delete any story word.** Text edits can only be made with explicit user approval, and only for trimming filler / transition sentences.

### Step 5.6.1 — Batch TTS preview for BOTH narration and dialogue

Call `batch speech synthesis` once to generate **two streams**:

```python
    requests=[
        # Stream A: narration (LOCKED, used in final cut)
        {
            "text": "<shot 01 narration line>",
            "output_file_path": "audio/shot_01_narration.mp3",  # LOCKED file
            "voice_id": "Chinese (Mandarin)_Male_Announcer",  # from STEP 0
            "speed": 1.0,
            "emotion": "neutral",
            "volume": 1.8,  # [v2.0.1] 80% above default
        },
        # Stream B: dialogue TTS PREVIEW (TIMING ONLY, will be discarded)
        {
            "text": "<shot 01 dialogue line 1, speaker the speaker>",
            "output_file_path": "audio/_preview/shot_01_dialogue_the speaker_preview.mp3",  # disposable
            "voice_id": "<speaker the speaker's voice_id from dialogue_voice_map>",
            "speed": 1.0,
            "emotion": "neutral",
            "volume": 1.0,  # dialogue volume reference
        },
        # ...
    ]
)
```

Output:
- `audio/shot_NN_narration.mp3` × N (locked, used in final cut)
- `audio/_preview/shot_NN_dialogue_<speaker>_preview.mp3` × N × speakers (TTS preview for timing, disposable after STEP 6.5)

### Step 5.6.2 — Measure real duration and lock shot_audio_schedule

Use platform media-duration measurement on **both** streams. Build the locked `shot_audio_schedule`:

| shot_id | duration | narration_window | dialogue_window | buffer | total | fits |
|---|---|---|---|---|---|---|
| 01 | 8.0s | [0.0, 3.6] | — | 0.0 | 3.6 | ✅ |
| 02 | 8.0s | [0.0, 3.4] | — | 0.0 | 3.4 | ✅ |
| 03 | 7.0s | [0.0, 2.8] | [3.3, 5.1] | 0.5 | 5.6 | ✅ |
| 04 | 8.0s | [0.0, 4.1] | — | 0.0 | 4.1 | ✅ |
| 05 | 9.0s | [0.0, 4.0] | [4.5, 6.4] | 0.5 | 6.9 | ✅ |

**Decision rules**:

| condition | flag | default action |
|---|---|---|
| All within tolerance, fits_in_shot | ✅ | lock schedule, proceed to STEP 6 |
| Drift ≤1.5s or ≤20% of its reserved window, with complete intelligible contained content and no critical overlap | ✅ | accept and record actual timing; either numeric condition suffices but never excuses mouth/style hard failures |
| Larger drift that still leaves the shot usable | ⚠️ | keep the shot and mark the offset for user editing; do not loop regeneration |
| Window overlap, missing speech, or unusable timing | 🔴 | only then revise the storyboard or regenerate the affected shot |
| Dialogue TTS > shot_duration × 0.6 | ⚠️ | **★ Extend shot or split dialogue** |
| `fits_in_shot: false` | 🔴 | Extend shot or split (return to STEP 5) |

### Step 5.6.3 — Schedule confirmation

For each shot, show the locked schedule. Ask the user once via `question`:

| Option | label | when to pick |
|---|---|---|
| ★ 1 | pass — continue STEP 6 | all ✅ |
| 2 | adjust a shotduration | need to change shot duration |
| 3 | split dialogue into the next shot | dialogue too long |
| 4 | rewrite dialogue only when it contains filler | dialogue has filler |

**Anti-patterns**:
- ❌ Speeding up speech to fit
- ❌ Cutting narration or dialogue text
- ❌ Hard-stacking narration and dialogue windows
- ❌ Using dialogue TTS preview in the final cut
- ❌ Discarding `shot_audio_schedule` before STEP 6

### Output of STEP 5.6

- `audio/shot_NN_narration.mp3` × N (locked narration)
- `audio/_preview/shot_NN_dialogue_*_preview.mp3` × N × speakers (disposable TTS preview)
- **`shot_audio_schedule` (locked)** — passed to STEP 6 as `audio_schedule` in the prompt, to STEP 6.5 as the drift baseline
- Updated `shot_timing_table`

Do not enter STEP 6 until `shot_audio_schedule` is locked.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 6: Generate Anchor Assets and Shot Clips

**STEP 6 has only two steps.** Everything else is wasteful for a 3D manhua short drama.

### Step A — Anchor assets (1 batch, 1 round of generation) **[Canvas gate HARD GATE]**

> **[Canvas gate HARD GATE]**: every asset produced in this batch **must be placed on canvas immediately after generation**, so the user can review and adjust them before Step B. Skipping this is a hard fail.

Generate only what shot-clip generation actually needs as first_frame anchors:

- **Character main card** — one clean image per main character (face + wardrobe + signature props), **front 3/4 view**
- **Character three-view sheet** — one image per main character with **front view / side view / back view** side-by-side
- **Scene main card** — one clean image per main scene (architecture + key in-frame furniture + lighting/color palette), **the main camera angle**
- **Scene auxiliary card** — one image per main scene at a **different camera angle**
- **Prop card** — at most ONE, only if a single prop is the visual focus of multiple close-up shots

**3D manhua vs 2D core difference**:
- **Three-view sheet is mandatory for 3D**. Without real multi-angle references, H3 re-imagines the face on every angle change.
- **Auxiliary scene card is mandatory for 3D**. 3D scenes have real perspective and occlusion.
- These two extras are used once each (no need for full 360° or every-lighting-condition).

**Embed approach**: wardrobe, props, jewelry, signature furniture, decorations, and color palette all go INTO the main cards.

**Do not generate**:
- ❌ Multiple expression sheets per character
- ❌ Multiple pose sheets per character
- ❌ Multiple lighting variants per scene
- ❌ Costume-change sheets
- ❌ Background details as separate assets
- ❌ **Full 360° turntable character sheet** (3-view is enough)
- ❌ **Multiple scene lighting variants** (main + auxiliary is enough)

Before this batch, ask the user once via `question`:
> Generate <N> character main cards, <N> character three-view sheets, <M> scene main cards, <M> scene auxiliary cards, and at most one prop card if needed. This may use substantial credits. Continue?
> ★ Generate / review current outputs first / pause and adjust / adjust the asset list

After this batch, ask once more:
> Does this asset batch pass? (Generated assets are on the canvas)
> ★ Pass / redo one image / adjust line treatment overall / adjust color treatment overall / redo one three-view angle

> ⚠️ **Canvas gate**: Step B (shot generation) **must wait for the user's on-canvas confirmation of these assets**. Do not start Step B before user confirms.

### Step B.0 — Lock shot duration (based on STEP 5.6)

**Before entering Step B, confirm each shot's final duration.** This duration comes from STEP 5.6's `shot_timing_table`.

Example:

| shot_id | final_shot_duration | source | first_frame |
|---|---|---|---|
| 01 | 8.0s | narration 7.8s + 0.2s buffer | character_main_card |
| 02 | 9.0s | narration 8.2s + 0.8s buffer (user chose to extend) | shot_01_last |
| 03 | **10.0s** | narration rewritten down to 9.4s + 0.6s buffer | character_three_view_side |
| 04 | 7.0s | narration 6.1s + 0.9s buffer (user chose to compress) | shot_03_last |
| ... | ... | ... | ... |

**Shot-duration hard constraints** (3D manhua vs 2D):
- per-shot duration >= 6s for normal shots
- per-shot duration <= 10s
- combat / fast-cut shots may go 4–6s
- buffer >= 0.2s, <= 1.5s

If a shot cannot fit its pre-allocated windows within the allowed range, split the beat during storyboard design; do not force speech into leftover time.

### Step B — Shot clips (1 batch, with first_frame anchors)

Generate every shot clip in one batch (or a few sub-batches) using the **first_frame anchor strategy**.

**Every shot MUST be generated in image-to-video mode** with `opening_frame_image` set to a real anchor image.

**Anchor sources** (in priority order):
- **Character main card** (front 3/4) — first appearance / reset cadence
- **Character three-view (side)** — side-tracking / parallel moves
- **Character three-view (back)** — back-view / chase shots
- **Scene main card** — scene first appearance
- **Scene auxiliary card** — different camera angle in same scene
- **Last_frame of previous shot** — same character / scene continuation

### Per-shot first_frame decision table (3D manhua — angle match is key)

| shot_role / shot_camera_angle | first_frame | frame_role | use |
|---|---|---|---|
| Character first appearance (front 3/4) | **character main card** | `"first_frame"` | most authoritative face start |
| Side-tracking / parallel | **character three-view (side)** | `"first_frame"` | lock side face / pose |
| Back-view / chase | **character three-view (back)** | `"first_frame"` | lock back / silhouette |
| Same character, later shot (regular) | **last_frame of previous shot** | `"first_frame"` | lock pose / light / material |
| Reset anchor | **character main card** | `"first_frame"` | every 4 / 6 shots reset |
| Scene establishing | **scene main card** | `"first_frame"` | lock layout / palette |
| Same scene, different angle | **scene auxiliary card** | `"first_frame"` | keep scene continuity at another angle |
| Same scene, later shot | **last_frame of previous shot** | `"first_frame"` | scene continuity |
| Wide shot without specific character | **scene main / auxiliary / last_frame** | `"first_frame"` | lock palette / composition |
| Reverse angle / cut to other character | **character main card** of newly-introduced character | `"first_frame"` | reset on cut |
| Prop close-up | **prop card** (only if it exists) | `"first_frame"` | lock prop detail |

### Last-frame archive step **[MANDATORY]**

After each shot is generated, **extract the last frame** of the shot and save it as `clips/shot_NN_last.png`.

```bash
    platform last-frame extraction for each generated shot
```

### Reset-anchor cadence (3D manhua vs 2D key difference)

- For the **protagonist**: every **4 shots** (2D is 3)
- For **supporting characters**: every **6 shots** (2D is 5)
- For **scenes**: every **5 shots** in the same scene (2D is 4)
- If a shot already resets (reverse angle, scene cut, time jump), the next shot's anchor is by definition reset.

**Why 3D cadence is longer than 2D**: 3D rendering gives more stable geometry continuity than 2D cel outlines.

### STEP 6.5 — Dialogue duration micro-adjustment [v2.0.2: from primary to fallback]

> STEP 6.5 verifies actual output; it is not a zero-drift regeneration loop. A schedule guides timing but guarantees no hit rate.

**H3-generated dialogue duration may still differ from the STEP 5.6 pre-plan.** After STEP 6 generates all shots, measure each shot's actual dialogue duration (VAD or human listening) and compare to `shot_audio_schedule.dialogue_window`:

- Complete, intelligible, contained content with no critical overlap and drift ≤1.5s OR ≤20% of its reserved window: accept and record actual timing.
- Larger but usable drift: retain shots and narration with an offset note; do not automatically extend, split, or regenerate.
- Missing dialogue, critical overlap, or unusable audio: identify the affected shot and propose the minimum repair; new generation follows scoped authorization, never story trimming.
- Narration-triggered speaking or actual style violations remain separate hard failures, not timing-tolerance exceptions.

Historical percentages are not current evidence or delivery thresholds. Report this batch's actual coverage/results; never create new versions to meet a target rework rate.

### Partial-materials path

If the user chose "Partial materials" in STEP 0 and provided character / scene cards:
- **character main card** = `user_uploaded/<name>.png`
- **character three-view** = `user_uploaded/<name>_3view.png` (optional; if missing, rotation shots will drift)
- **scene main card** = `user_uploaded/<scene>.png`
- **scene auxiliary card** = `user_uploaded/<scene>_aux.png` (optional)
- Use them as anchors, **skip Step A entirely**, go to Step B
- **[Canvas gate HARD GATE] still applies**: user-provided assets also go to canvas immediately

### Style block (paste into every prompt)

**Chinese-animation 3D render (default)**:
> `3D rendered, Chinese-animation manhua-cel look, clean dark outlines on top of 3D shading, soft PBR materials with non-photoreal finish, dynamic manhua panel composition, dramatic cinematic light, webtoon-friendly vertical framing, no live-action, no Pixar-style CG, no 2D flat illustration, no watermark, no baked-in text`

**rounded family-animation 3D**:
> `3D rendered Pixar/Disney-style, rounded soft shapes, large expressive eyes, soft cinematic lighting, stylized non-photoreal materials, manhua panel composition with dynamic angles, no live-action, no 2D flat illustration, no watermark, no baked-in text`

**painterly semi-realistic 3D**:
> `3D rendered with painterly thick-coating, semi-realistic proportions, PBR materials with brushstroke texture, dramatic cinematic light, manhua panel composition, webtoon-friendly framing, no live-action, no 2D flat illustration, no Pixar/Disney cartoon, no watermark, no baked-in text`

### Failure repair priority

The following are diagnostic candidates for evidenced face, wardrobe, scene, prop, material, or lighting defects, not an automatic generation ladder. Apply scoped authorization to the affected shot/asset, choose only the diagnosed change, and preserve other locks:

1. **Strengthen the first_frame** — switch to a sharper / cleaner card or a more recent last_frame.
2. **Check first_frame angle match** — if the shot is a side-tracking but the first_frame is the front card, the 3D model will re-imagine the side. **3D-specific repair entry.**
3. **Add explicit identity keywords** (e.g. "same face as previous shot, no face change, exact same dark robe with gold trim")
4. **Shorten the shot duration** — long shots drift more than short ones.
5. **Reduce camera motion** — heavy camera move (especially rotation) masks identity.
6. **Check the approved sub-mode block** — cartoon/painterly drift fails the guoman mode, while legitimate rounded/painterly traits in the selected mode do not. Compare actual output, anchors, and prompt; propose a targeted repair, not an automatic sub-mode change or rerun.

Do **not** keep re-running the same text-only prompt.

Before the shot batch, confirm the user still wants to spend the budget.

Default: the platform's current image-to-video capability, with the confirmed shot duration preserved.

For the full anchor strategy, see `references/shot-anchor-strategy.md`.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 7: User-Led Audio Handoff and Dialogue-Only Video

### Complete-shot direct-join rule [HARD GATE]

Every generated shot clip is a complete story unit. The final cut MUST preserve each clip from its first frame to its last frame and join the clips directly in the confirmed order. Do not trim, shorten, speed-ramp, crop away, or replace any portion of a shot to solve pacing, audio, or total-duration issues. If timing needs correction, revise the storyboard/audio schedule or regenerate the affected shot; never repair it by cutting story content. The ending shot must remain complete, and any end card is appended only after that full shot.


After the visual shots are ready, prepare the dialogue-only video and hand off the separately generated narration audio to the user:

- Narration audio was already batch-generated in STEP 5.6 using the locked catalog narrator voice (locked in STEP 0) — only in `narration` / `mixed` modes
- The full episode uses one consistent narrator voice
- Dialogue defaults to the video render's original spoken audio (**all three modes**; `dialogue` mode NEVER generates extra TTS)
- Direct-join the complete shot clips in the confirmed order, preserving original dialogue and production sound.
- Deliver narration clips separately with the planned windows and actual measured durations.
- Do not composite narration into the video; the user performs the final narration edit.
- Add or format subtitles only when explicitly confirmed.
- **Do not delete any original plot point for assembly convenience** [Story preservation HARD GATE]
- **If a shot must carry both narration and dialogue, keep their windows non-overlapping; if impossible, go back to STEP 5.6 to adjust duration or split** [Story preservation HARD GATE]
- Preserve the ending turn or cliffhanger exactly as planned

**Do not regenerate narration here** (this would overwrite STEP 5.6's output).

### Mouth-state constraint [HARD GATE, v2.0.4]

> **Single-speaker rule**: in every shot, **at most ONE character is allowed to move their mouth to speak**; other visible characters must keep their mouth closed or perform reaction actions (nod, frown, eye movement). Narration does NOT trigger any character's mouth movement.

**Hard constraints**:
- In any mode, **only one character is allowed to perform mouth-speaking actions** per shot; others must stay closed
- Narration text MUST NOT enter the video prompt's "mouth" or "lip" fields
- Verified unapproved speaking-mouth action or recited narration in the reserved narration window is a **hard failure**. Repair only that shot under precise existing authorization or new approval. “Must redo” is not immediate execution permission; do not call it qualified or conceal picture defects by muting sound.
- Narration-only windows have no character speech. Inspect the interval to distinguish ordinary expression from speaking. Insufficient evidence is unverified; confirmed violations are hard failures, not a generic warning that passes QC.

### BGM handling [HARD GATE, v2.0.4]

> **BGM is an optional layer, always post-positioned**: the no-BGM cut (narration-only or dialogue-only) MUST be completed and user-reviewed first. **The no-BGM version is a required independent deliverable; the BGM version must be a NEW independent asset, never overwriting the no-BGM version.**

**Hard constraints**:
1. **Complete the no-BGM main cut -> user review -> only then add BGM**
2. BGM-to-cut alignment:
   - BGM too long -> trim to cut duration, do natural decay
   - BGM too short -> loop as needed, trim loop result to cut duration
   - **No forced stretching of BGM**
3. BGM mixing: audible but **ducks (auto-ducks or volume-down) when narration plays**; not so ducked as to be inaudible
4. **BGM version is an independent asset**; do not overwrite the no-BGM version
5. Across all audio modes: BGM ducking is for ambience / SFX, **not a substitute for separating the two speaking voices** (narration and dialogue must be separated by time window, not by ducking)

### Ducking (audio sidechain) hard constraint [HARD GATE, v2.0.4]

> **Ducking is for ambience / SFX, NOT a substitute for separating speaking voices.**

**Hard constraints**:
- ✅ Allowed: ambience ducks narration/BGM (street noise ducks when narration speaks)
- ✅ Allowed: SFX ducks narration/BGM (effect sounds yield to narration)
- ❌ Forbidden: using ducking to make narration and dialogue "both play but distinguishable" — must use **time-window separation** (narration first, then dialogue with a gap)
- ❌ Forbidden: ducking that makes narration or dialogue inaudible

**End of STEP 7 — preview the dialogue-only video and narration audio package to the user and ask**: approve / adjust narration timing / replace dialogue / change shot order / adjust BGM / adjust volume or ducking.

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## STEP 8: QC and Deliver

Before delivery, verify actual shots and output QC records under `references/qc-checklist.md`. Distinguish qualified delivery, usable warnings, review/partial handoff, and blocked work. Missing evidence is not a pass. Apply only relevant checks; an unproduced narrated master is not verified:

Hard failures prevent qualified-final claims but permit labeled asset/issue handoff and a pause. QC never automatically restarts a batch or episode.

### Hard Gate 1: Story preservation
- Every original plot point preserved (STEP 5.5 reconciliation table all ✅ or user-approved-deleted/moved)
- No narration secretly deleted to align timing
- No dialogue secretly merged/deleted for assembly convenience

### Hard Gate 2: Canvas gate
- Final spec on canvas
- Core assets (character cards / three-view sheets / scene cards / auxiliary cards / prop card) placed on canvas immediately after generation
- User confirmed assets on canvas before video generation

### Hard Gate 3: User-language following
- All `question` options in user's current language
- All progress updates, summaries, final replies in user's current language
- User-provided text (character names, scene names, user-written dialogue) preserved verbatim

### Hard Gate 4: 3D manhua style & anchors
- `visual_style_lock == 3D-manhua-cel` honored in every shot
- Every shot's first_frame angle matches the camera angle
- Reset-anchor cadence honored (protagonist 4 / supporting 6 / scene 5)
- Every main character has a 3-view sheet; every main scene has an auxiliary card

Other routine checks:
- narration / dialogue balance
- character / prop / scene layout continuity
- pacing and timing (6–10s, combat / fast-cut 4–6s)
- subtitle readability
- emotional arc from hook to ending
- every shot is preserved from first frame to last frame and directly joined in confirmed order
- whether the episode actually resolves or teases as planned
- MiniMax-H3 by default (or a user-selected compatible model) and confirmed shot durations maintained
- narration voice consistency across the episode
- narration-first 3-layer guardrail all passed

Return:
- dialogue-only video and separate narration audio package, or assembly guidance
- reusable character / scene / prop cards (with three-view sheets and auxiliary scene cards)
- storyboard or shot prompt package
- continuity warnings and repair notes
- voice preset used (so the user can re-use it on the next episode)

**Final user message template** (**must be in user's current language**):

> 🎬 Episode X: <qualified / usable warnings / review or partial handoff / blocked>; <N> delivered shots, measured <M>; checked coverage <scope>, failed/unverified <list>
> - Visual: 3D manhua rendering (<sub_mode>)
> - Narrator: <voice_name> (<voice_id>)
> - Video generation: MiniMax-H3 by default, or a user-selected compatible model after capability check
> - Anchors: protagonist reset every 4 shots, supporting-character reset every 6 shots, scene reset every 5 shots; three-view sheets and auxiliary scene cards support camera movement
> - Pipeline: narration-first; generate narration before filming and preserve measured shot timing
> - Story: <verified covered/total, user-approved changes, unverified items>; video has no narration, with a separate narration package and measured timing. No claim of narrated-master mix acceptance.
> - Narration and dialogue: non-overlapping windows by default
> - Next-step suggestions: <create the next episode / adjust BGM / create three platform cuts / adapt for international aspect ratios>

[ULF] Output this STEP in `<user_language>`. Reference: `references/user-language-rules.md`.


---

## Quick Reference

- `references/final-video-spec.md` — full spec template with `visual_style_lock` / `narrator_voice_id` / **story preservation** / **canvas gate** / **user-language following** fields
- `references/storyboard-design.md` — per-shot storyboard template (`narration_lines` / `dialogue_lines` uniform `[{text/speaker, start, end}]` format + 3D `first_frame_angle_match`)
- `references/visual-state-ledger.md` — per-shot continuity ledger (3D material block)
- `references/audio-timeline.md` — per-shot audio timeline (STEP 5.6 narration-first / Dialogue duration estimation / **3-layer guardrail**)
- `references/qc-checklist.md` — delivery checklist (3D manhua style / voice consistency / **first-frame anchor angle** / **3D multi-angle assets** / **story preservation** / **canvas gate** / **user-language following** / **narration-first timing** — 8 hard gates total)
- `references/voice-presets.md` — Top-2 Douyin-style narrator voice preset list + genre auto-recommend + **gender mismatch anti-pattern**
- `references/style-presets.md` — 3D manhua style prompt blocks per sub-mode
- `references/shot-anchor-strategy.md` — first_frame anchor strategy with **3D angle-match rules** + STEP 5.5/5.6 references
- `references/interactive-checkpoints.md` — standardized `question` question templates per step (Top-2 voice / narration-dialogue classification / script reconciliation / delivery template)
