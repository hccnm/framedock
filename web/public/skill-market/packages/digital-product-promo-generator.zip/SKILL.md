---
name: digital-product-promo-generator
description: Turn a real product webpage, frontend project, screenshots, or recordings into a cinematic promo with accurate UI, purposeful motion, rhythm, and sound. Use for launches and demos.
trigger-words: [digital product promo, product promo, product video, launch film, feature demo, webpage video, frontend promo, 数字产品宣传片, 产品宣传片, 产品发布短片, 网页产品视频, 功能演示视频]
---

# Digital Product Promo Generator

Use this Skill for a complete promotional film or a clearly scoped motion shot built around a real digital product, webpage, frontend project, or supplied product reference. The product source is the authority for interface facts, copy, layout, typography, visual language, and interaction logic.

## STEP 1: Capture the production brief

Collect only missing decisions that change the deliverable:

- Product URL, screenshots, screen recordings, frontend assets, or an explicitly supplied visual reference.
- Brand assets and exact copy that must remain unchanged.
- Duration, aspect ratio, platform, and delivery context.
- Audience, launch message, feature priority, and any required call to action.
- Whether the request is a complete promo or one motion shot.
- Music, sound effects, narration, or voice-cloning requirements. Voice cloning requires an authorized reference recording and explicit consent.

Do not ask for a universal brief when the user has already supplied an executable request. Do not assume an Ink Press template, shot-card library, code project, or audio pack is bundled. If one is named but not provided, ask for the asset or describe the desired visible effect.

## STEP 2: Inspect and establish product truth

Inspect the supplied page and media before creative planning. Prefer real screenshots or recordings for interface-led films. Record a compact product fact sheet covering:

- Verified product positioning, features, terminology, and exact on-screen copy.
- Interface hierarchy, typography, spacing, colors, components, and interaction states that are visibly supported.
- Brand marks, legal text, metrics, prices, claims, and calls to action that may appear.
- Source media dimensions, duration, orientation, and any continuity limits.

Treat public webpage content as evidence, not permission to invent claims. If a page is inaccessible or a fact is ambiguous, surface the gap and use only approved source material.

## STEP 3: Build a reviewable creative plan

Before costly generation or final assembly, propose a concise plan that includes:

1. One-sentence narrative and the product promise.
2. Ordered shots with approximate timing and the interface or product fact each shot proves.
3. Camera movement: crops, zooms, pans, perspective, depth separation, or parallax only when they clarify the story.
4. Transition logic, on-screen text, text-safe areas, rhythm, and ending frame.
5. Music, sound effects, narration, or silence strategy.
6. Required sources, unresolved risks, and what will remain conceptual if real media is unavailable.
7. Missing screenshots, recordings, exact copy, logo files, brand assets, or style references that must be supplied before generation.

Stop for user approval at this creative decision point. A short confirmation is enough when the plan is already concrete. Explicitly surface any missing screenshots, recordings, exact copy, logo files, brand assets, or style references before costly generation or final assembly.

## STEP 4: Generate approved visual and audio assets

After user approval, generate video shots with MiniMax-H3 by default when it is available and compatible. If the user explicitly chooses another model, first verify that it supports the required reference inputs, duration, resolution, aspect ratio, and audio needs before following that choice. Keep one intended outcome unit per final artifact. Use source media in its assigned role and preserve ordered reference identity when multiple inputs are supplied.

For interface-led content:

- Keep product names, UI labels, figures, prices, legal text, and calls to action exact.
- Prefer real screenshots or recordings as visual anchors; use generated motion to enhance presentation, not to redesign unsupported screens.
- Make every added claim, object, scene, action, or story beat traceable to user intent or approved product evidence.
- Generate only the approved music, effects, and narration. Spoken audio does not imply subtitles; add subtitles only when requested.

If a user-selected model fails, make only one targeted retry after correcting the likely parameter, prompt, or reference issue. If it still fails, switch to MiniMax-H3 or another available capable model instead of repeatedly retrying the same model. For other generation failures, make targeted corrections that change the failing constraint or prompt structure and never repeat an identical request. Report the incompatibility and ask before changing a user-selected reference or deliverable constraint.

## STEP 5: Assemble and review

Assemble the approved shots in the planned order, then check:

- Product identity, UI structure, text accuracy, and claim fidelity.
- Subject and interface continuity between shots.
- Camera movement, pacing, transitions, beat alignment, and clean opening and end frames.
- Audio balance, duplicate tracks, abrupt cuts, and requested subtitle state.
- Duration, aspect ratio, resolution, export format, and playable final output.

Use deterministic post-processing only for operations such as trim, crop, transcode, audio mix, subtitle formatting, or ordered assembly. Do not use post-processing to repair a semantic visual generation error without telling the user.

## STEP 6: Deliver

Save the final artifact and report its exact filename, format, duration, aspect ratio, reference sources used, and any approved substitutions. If multiple final artifacts were requested, list each separately. Keep intermediate anchors and source files distinguishable from the final deliverable.

## Boundaries

This Skill covers product launch films, feature demos, website or desktop product storytelling, and focused product motion shots. It does not cover generic video editing, talking-head cleanup, unrelated motion art, unsupported product claims, or unauthorized voice imitation. If the user asks for a broader multi-scene production with scripts, reusable character or scene anchors, dependent assets, or a reviewable timeline, preserve the requested workflow rather than collapsing it into a single improvised shot.
