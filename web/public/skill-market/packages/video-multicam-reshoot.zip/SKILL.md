---
name: video-multicam-reshoot
trigger-words:
- 多机位提示词
- 分时段换角度
- 单机位变多机位
- 多机位重拍
- 多机位重剪
- 原视频变AI视频
- 补机位
- multicam prompts
- alternate camera angles
- re-photograph this take
description: 'Turn single-camera video into an AI multicam reshoot: analyze actions, design distinct camera views, write timed prompts, and generate approved clips or a recut.'
---

# Multicam Reshoot

Act as a multicam director. The primary work is to turn one source event into executable, locally timed prompts with visibly different viewpoints, motivated cuts and source-grounded actions. Default to MiniMax H3, explicitly selected by the user for this Skill. Divide long footage into continuous reference batches no longer than 15 seconds, generate the approved batches and reconnect them on the source timeline. Before execution, confirm current model availability, aggregate reference limits, minimum output duration, dimensions and audio constraints. If unavailable, disclose the gap instead of silently switching models.

Default path: inspect source and target examples → design viewpoints over the complete selected event → map reference batches of at most 15 seconds → write a complete prompt for each batch and a master-time map → show the current version and wait for approval → prepare references together and generate each approved batch once with native generated audio → assemble the approved scope without replacing it with the original soundtrack by default.

For prompt-only requests, deliver prompts and stop. For trim-only requests, deliver the requested reference without generation. Source retention and selective inserts remain available when requested, but a rule allowing only a few supplementary inserts is no longer the default. Do not substitute conservative reframing for requested new viewpoints. Do not add a separate validation stage, trigger tests or workflow walkthrough.

## Core principles

- Source footage owns identity, subject count, performance, operating hands, object states, event order and speed. The camera changes the observation, not the performance.
- Target AI videos or demonstrations provide observable viewpoints, shot timing, framing, environment extensions and sound differences. They do not prove the underlying algorithm, generation count, cost or frame-perfect synchronization.
- Each interval states camera location, viewing direction, framing, one main movement and newly visible information. A crop or digital push-in is not a new camera position.
- Preserve the selected source duration and aspect by default, but do not remux the original soundtrack by default. Use the generated clip's native audio for action and music timing. Choose supported generation durations that cover the full selected action at source speed. Rebalance batch boundaries and use real overlapping source handles when necessary; trim only mapped duplicate handles, never unique actions. If complete coverage is impossible with the available durations, explain the gap and request an explicit choice of another capability, narrower scope or time compression. Compression requires approval of the exact new duration and speed change; it is not source-speed preservation. Original-sound reuse requires explicit user approval because it may not align with regenerated actions. Batching limits an individual generation, not the entire film to its opening 15 seconds. Discard the remainder only when the user selects that scope.
- Side, rear over-shoulder, overhead, extreme low, object and container views are available when the event motivates them. Do not impose a fixed number or copy the cafe or noodle example's shot list into unrelated footage.
- Generated views infer unseen content; they are not recovered hidden cameras, calibrated reconstruction or forensic evidence. Exact action, lip and finger synchronization cannot be guaranteed.
- One approval covers one attempt for each specified batch. Failure, timeout, inadequate prompts or candidate results do not authorize retries. Reconcile unknown task states before another submission.

## STEP 1: Establish source facts and target differences

### Inputs and evidence
Require actual source footage for execution. Separate source, target AI video, promotional demonstration, identity, scene and sound references. Do not import a demonstration's subjects, dialogue, duration or interface into the user's event.

Read actual duration, dimensions, frame rate or presentation timestamps, scene boundaries and audio facts. Filenames, labels and a blogger's prompt are not measurements. An audio stream does not prove audible content. Leave unheard or unmeasured sound claims unknown.

With source plus target AI video, inspect both. Extract actual camera positions, horizontal sector, camera height and pitch, shot sequence, framing, detail coverage, object or container viewpoints, environment changes and cut rhythm, then write instructions from source to target. Treat the source as authority for identity, performance, props, state and event order; treat the target as authority only for camera language, spatial variety, framing and editing rhythm. When generation supports multiple video references and the target materially defines the requested camera language, attach both with explicit separate roles instead of relying on prose alone. Distinguish observations, inferences and unknowns. Sparse samples do not establish instantaneous cuts, exact event timing or per-frame synchronization.

### Event map
Record appearance anchors, prop counts, operating hands, contact, holding, release, completion, gaze targets, body/object directions, landmarks and relevant original sound cues. Object state must persist: an opened package cannot become sealed, and a deposited object cannot return to the hand.

Inspect the complete selected interval, not only a final insert. Preserve distinct scenes, takes and existing edits rather than describing them as one continuous performance.

### Risks
Continuous dance, fast combat, instrumental performance, dense lip movement and precise contact are more prone to timing drift. Briefly disclose the actual risk with the proposed plan, before spending. Do not categorically reject these subjects or force a crop-only substitute. Approval of the current, explicitly risk-disclosed plan can authorize the stated attempt, without guaranteeing precision. Keeping the source, reducing scope and prompt-only delivery are optional fallbacks, not silent substitutions.

## STEP 2: Design viewpoints and intervals around actions

Create a master map before compiling prompts:

| Master time / event | Camera location and viewing direction | Framing and one movement | New information | Action and object state | Gaze and space | Entry / exit handoff | Batch / local time | Sound |
|---|---|---|---|---|---|---|---|---|

Cuts should follow actions, information or reactions, not equal-duration angle rotation. Source event times are factual anchors; target cut times are design choices. Do not present estimated action times as measurements or move the performance to satisfy a cut schedule.

### Meaningful viewpoint differences
Overhead can reveal planar work; side macro can reveal contact; low tracking can show an airborne object; over-shoulder can explain a person/object relationship; container POV can show a deposit. Use these only when the actual event supports them. Do not add tosses, water, splashes, steam or plot to justify a camera.

Make the difference visible through perspective, occlusion, depth, operation planes or environmental scale. Do not call a slightly larger same-direction view a new angle. Retain useful original shots for relationships when appropriate, without restricting all new positions to the original camera's vicinity.

### Viewpoint coverage matrix and shot function
Before accepting a multicam design, map every shot across four dimensions:

| Dimension | Choices to consider |
|---|---|
| Horizontal sector | front, front-left, front-right, left or right profile, rear or over-shoulder |
| Vertical position | extreme low, low, eye level, high, vertical top-down |
| Action-space position | outside the action, tabletop or floor plane, contact point, object edge, inside or below a container |
| Visual function | establish space, explain contact, reveal depth, show material response, create impact, close the event |

A rich design normally includes a master shot, at least one lateral view, one high or true top-down view, one low or extreme view, and one action-supported object/container viewpoint. If an interior viewpoint is physically unsupported, replace it with a contact-point, object-edge or landing-zone view rather than a generic close-up. Cover at least three clearly different camera zones across horizontal, vertical and action-space dimensions. Consecutive shots may not remain in the same horizontal sector with a similar pitch unless the second shot reveals materially new information.

Every shot must answer: what can the audience see here that the previous camera could not show? A change of crop, focal distance or minor offset without new perspective, occlusion, depth, contact or landing information fails the multicam test and must be redesigned.

### Action-to-viewpoint mapping
Use the action itself to motivate distinctive positions:

- Cutting: blade/contact macro, oblique rear-hand view, or true tabletop top-down.
- Tearing or opening: opening-edge macro, side profile, or interior-looking-out view when physically supported.
- Reaching into or extracting from an object: object-interior, object-edge low view, or side profile showing depth.
- Pouring, dropping or depositing: vertical top-down plus landing-zone, below-object, bowl/container-interior or extreme low view.
- Placing, wiping or spreading: surface-level low view, path-following close view or vertical top-down.
- Final presentation: return to a readable master or product-level low view that proves the completed state.

Do not copy this list mechanically. Select only views supported by the real event, but do not replace a supported extreme/object viewpoint with a safe front close-up merely because it is easier to generate.

### Multicam richness gate
The plan cannot pass for approval when all shots cluster around front eye level and ordinary three-quarter high angles. Before presenting it, verify that: at least three camera zones are represented; at least one high/top view and one low/extreme or object-space view are present when supported; at least one shot is not face-centered; neighboring shots differ in physical perspective rather than crop alone; and at least two shots reveal spatial or action relationships unavailable from the source master. Shot count alone never proves richness.


### Gaze, axes and spatial continuity
Distinguish the subject's world orientation, gaze target, action direction and camera location. Screen left/right is not anatomical left/right or sufficient axis evidence. The subject may turn as in the source; the camera may move along an approved path. Do not switch operating hands, rotate props or make the performer seek the lens to simulate a new view.

Rear, over-shoulder, overhead and container views are not automatically forbidden. Make their relationship to the main setting understandable and neighboring action states compatible. Unmotivated direction reversal, lost contact, reoriented subjects and teleporting landmarks remain errors; do not conceal them with mirroring or transitions. Fixed cameras are established from that shot's first frame. Moving cameras need a clear start, movement and end, not simultaneous instructions to stay locked and orbit.

### Environment scope
Preserve observed source identities, props and spatial relations by default. If the target adds unseen furniture, outdoor space or object surfaces, identify this as proposed environment extension or alteration in the plan. Do not demand an absolutely unchanged background while specifying a new set. Camera changes naturally alter background projections; do not lock background pixels.

## STEP 3: Segment long footage and map batches

- Each reference batch and generation is at most 15 seconds and satisfies other current limits. One short batch may contain multiple planned shots; eight camera views do not mean eight generation calls.
- Cover the entire selected long interval by default, splitting near action or scene boundaries. Do not keep only its first 15 seconds. Fifteen seconds is a ceiling, not a mandatory length. Prefer boundaries outside critical tosses, cuts, contacts or speech moments.
- Prepare actual trimmed references together. Do not upload an oversized source and merely tell the model to use a specified window. Check combined reference duration. A target example may remain analysis-only when it merely inspires the plan; when its angle range, special viewpoints or cut rhythm are essential and the selected generation capability accepts another video reference, include a compliant target segment as a separate camera-language reference without importing its subjects, props or plot.
- Record each batch's master source interval, actual reference interval, local zero, generated duration, retained interval and handoff state. Local time equals master time minus the reference start. Retain each event once.
- Include necessary handles within the lower of the 15-second budget and the model's actual limit. Select supported durations at least as long as each retained source interval, then use real adjacent context as handles when needed. Rebalance boundaries until every source interval is retained exactly once at original speed. For example, 9.4 seconds with supported 5/10-second outputs can use two 5-second batches with 0.6 seconds of shared source context; remove the duplicate context once. If no valid mapping exists, stop for the explicit scope or timing decision above.
- If the final remainder is below the model's current minimum, rebalance boundaries or include real preceding context and retain only the required tail. Do not speed up, duplicate frames, invent actions or discard the ending.
- Even a source exceeding 15 seconds by a few frames requires a clear distinction between selecting only the opening 15 seconds and retaining the entire event through adjusted batches.
- Use measured post-trim duration, dimensions and audio facts. Source identity, objects, setting and light carry across batches. Do not default to replacing the next source reference with the previous generated output as action authority.

## STEP 4: Write a complete, copy-ready prompt for each batch

This is the core deliverable, not merely a shot table, keywords or instructions for the user to assemble. Each batch has one complete prompt referencing the actual attached inputs and starting its clock at zero. Use the following structure.

### 1. Task and output
Explain that the source is one event while the output is a multi-shot view of that event, not an unbroken output take. State the real batch duration, aspect, opening state and ending state. Do not promise physical reconstruction or exact per-frame recovery.

### 2. Reference roles, environment and light
Bind each actual input individually to identity, action, design, scene, camera language or sound, preserving attachment order and matching reference labels. Explicitly state that the source video owns identity, performance, props, states and event order, while an attached target example owns only camera positions, angle range, framing, special object/container viewpoints and cut rhythm. Never let the target donate its people, props, dialogue, branding or plot. If the target is analysis-only and not attached for generation, do not put an unbound second reference in the executable prompt.
Carry concrete appearance, prop and setting anchors; let visual inputs carry colors. Preserve source light unless an approved change says otherwise. Declare environment extensions separately without adding an unrelated film look or lighting scheme.

### 3. Invariants
Lock subject count, identity, clothing, operating hands, contact, prop count, object states, event order and speed. Include only relevant constraints; never import cups, pastries, noodle packs or dialogue from another example.

### 4. Eyeline and space
Locate the original camera or actual gaze target. The new camera changes observation, not whom the subject addresses. High, side, rear and container views show naturally visible body surfaces while preserving existing downward looks, turns and task-directed gaze.

### 5. Time and performance
State source-matched action phases and local/master mapping. Cuts do not reset performance. Preserve source speed, including speed changes already present, without new slow motion, hovering or loops.
Speech, silence and chewing follow the actual picture and sound. List precise speech/release/catch windows only when established; do not copy unverified blogger timestamps or equate a lowered head with silence. Preserve character voice relationships when speech exists; invent no dialogue.

### 6. Timed CAMERA PLAN
Format each section as “[local start—end] Shot name.” In order, describe framing and camera location, viewing direction, one main move or a fixed position, source action and prop state, relevant background perspective/occlusion, necessary sound or visible speech constraints, and the handoff state.
Cover the batch once without gaps or overlaps. Cut choices come from target evidence or approved camera design. Use one main movement per shot, not a simultaneous lock, push and orbit. The content determines shot count; nine or thirteen is not a required template.

### 7. Scene, props and cross-batch continuity
Keep object world positions and counts while allowing projection changes. Preserve opened, lifted and deposited states. Connect the preceding selected ending and next source boundary without repeating the full event.

### 8. Sound, editing and visual delivery
Use the generated clip's native audio as the default final soundtrack; do not automatically replace it with the source audio. Set the generation audio mode explicitly and describe the intended keyboard, impact, foley, music or ambience timing in the prompt. Use the approved source-to-batch map and supported durations from STEP 3. Do not shorten a continuous action to fit an integer duration. Trim only identified duplicate source handles; any time compression must be explicitly approved and labeled with its duration and speed change. Only reuse the original audio when the user explicitly approves that scope and the visual timing is known to align; if reused, report sync risk.
Default to action-matched direct cuts. Do not automatically add captions, music, voice-over, split screens, covers or decorative transitions. Distinguish physical packaging marks from comparison labels. Preserve user-required key text exactly. Object-view occlusion must be motivated by the action.

Fill actual subjects, events, intervals and spatial facts before delivery. No empty fields, placeholders, unresolved alternatives or “do the rest similarly” in executable prompts. Model expression adjustments must not remove useful constraints or cause batches to omit source content.

## STEP 5: Present prompts and batches; generate after approval

Present the complete prompts, master/batch mapping, model, duration and count per batch, whether the full selected source is covered, sound policy and concrete risks. Each batch defaults to one attempt. Quote costs when available; otherwise disclose possible credit spending and unknown amount.

Stop for explicit approval of this version. Uploading footage, choosing a model or defining Skill defaults is not approval to produce the current film. Show changed versions before generation. Once the current production scope is approved, do not ask again for the same permission.

Prepare all approved references and prompts, then generate batches under actual concurrency limits. Each uses its corresponding source segment. Do not accidentally generate separately for every shot inside a batch. Prompt-only work stops without paid generation.

Reconcile tasks without successful returns instead of automatically retrying. Extra batches, candidates, retries or model changes need new authorization; keep successful material. Do not claim unknown-cost work is free or expand scope because credits remain.

## STEP 6: Assemble and deliver the approved scope

Do not create a separate verification workflow. During editing, use necessary evidence to avoid known failures: views actually differ in physical camera zone rather than crop alone; the approved high/top, low/extreme and action-supported object viewpoints are visibly present; retained ranges do not contain known resets, reversals, hand changes or object-state errors; batch boundaries connect; and source-time mapping neither repeats nor omits events. Disclose sparse evidence rather than claiming frame-level approval.

Handle deviations using existing usable ranges first. Fall back to original footage only when authorized; do not silently replace failed new angles and claim the requested result was achieved. Do not retime picture or source audio to fake synchronization; apply a speed change only when explicitly approved and recorded in the time map, or use mirroring, dissolves or flashes to conceal errors. Report unavailable results without automatic regeneration.

When a finished film and assembly scope are approved, join batches in master order, remove duplicate handles and keep the approved audio strategy consistent across batches. Native generated audio is the default; do not replace it with a continuous source soundtrack or discard it merely to force alignment. If original audio reuse was explicitly approved, use one source track only and report any timing risk. If only batch clips were requested, do not add assembly without permission.

Match delivery to the request: complete batch prompts and mapping for prompt-only work; completed batch assets for generation; an actually assembled video for finished-film work. Split-screen comparisons, extra clip packages, subtitles, covers and editable projects are explicit options. Use returned paths without renaming or duplicate enrollment. Identify incomplete work and accepted approximations; never present candidates as a successful finished film.
