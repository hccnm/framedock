---
name: bullet-time-slow-motion-video
description: Create bullet-time shorts from scripts, ideas, or references. Lock style and continuity, generate orbital freeze shots, build separate audio layers, and assemble a reviewed final cut.
trigger-words:
- bullet time
- bullet-time
- time freeze
- ultra slow motion
- 子弹时间
- 子弹时间短片
- 慢速视频
- 时间冻结
- 环绕冻结
---

# Bullet-Time Slow-Motion Video

Use this Skill when the user wants a coherent narrative short centered on bullet-time: time slowing or freezing at a precise action beat while the camera orbits the subject. It supports script-led and inspiration-led projects, reference assets, character and scene continuity, dialogue, voice-over, BGM, and final assembly. Choose image generation that preserves reference identity across multi-view sheets. Prefer MiniMax H3 for video when its available reference and native-dialogue capabilities meet the confirmed shot requirements. The user's selected model takes priority when it meets those requirements; neither images nor video are restricted to a fixed model list. Long-form creative documents are canvas deliverables: write or update them as canvas text documents rather than pasting their full contents into chat.

## STEP 1: Intake and creative direction

1. Determine whether the user supplied a complete script, storyboard, both, or only an idea. Preserve supplied story content as the source of truth.
2. If only an idea is supplied, offer 2–3 story directions, each explaining how the bullet-time effect functions dramatically. Ask the user to choose before writing the script.
3. Expand the chosen idea into a scene-by-scene script, then a shot-list draft with shot size, camera movement, transitions, duration, action beats, and audio ownership. Create or update a separate canvas text document for the script and another for the storyboard draft; do not paste the full documents into chat. Pause for confirmation after each major creative document, using the canvas documents as the review surface.
4. If a script or storyboard exists, extract its setting, characters, events, dialogue, and any stated visual style. Never add, remove, skip, or rewrite story beats without approval.
5. If no visual style is specified, offer 2–3 style directions with reasons tied to the story, characters, setting, and bullet-time impact. Allow a custom style direction. Confirm the selected style before locking production.

## STEP 2: Lock the production spec

Create a final production spec as a canvas text document containing:

- title and project type: bullet-time style short;
- 16:9, 720p final target;
- confirmed visual style and output language;
- intended duration and scene order;
- continuity rules for characters, locations, props, lighting, and sound;
- which spoken content is in-shot dialogue or inner monologue, and which is independent VO.

The production spec is the authority for downstream storyboard, asset, video, and audio work. Keep the full spec on the canvas; in chat, report only its title, a concise summary, and the confirmation request. Ask for confirmation before proceeding.

## STEP 3: Build the storyboard and continuity map

1. For a supplied script/storyboard, parse it scene by scene and shot by shot. Produce a traceable script-to-storyboard checklist: source beat, shot ID, restored elements, and any proposed non-source additions. Write the complete checklist into a canvas text document; do not reproduce it in chat.
2. Design a storyboard document on the canvas with key elements, shot list, and cross-shot audio layers. Keep the complete shot records in that document; chat should contain only a short status summary and review request. Required key elements include principal characters, important environments, and bullet-time props such as bullets, glass, fragments, liquid, dust, or sparks.
3. Each bullet-time shot must specify:
   - the trigger beat for slow motion or freeze;
   - the exact frozen pose or object state;
   - orbit direction and start/end angle;
   - the slow-motion-to-freeze-to-recovery timing;
   - the preceding and following rhythm-contrast shots.
4. Prefer longer shots with internal speed changes when suitable. Keep each shot between 4 and 15 seconds; use 10–15 seconds for a complex bullet-time shot when the action benefits from an internal cut or speed transition.
5. Each shot record must include Scene, Story beats, and Cinematography. Scene must identify the scene asset and a specific quadrant or region. Story beats must preserve exact dialogue and the action timeline. Cinematography must state framing, camera angle, orbit direction, and motion.
6. For emotional acting, specify in order: cause, visible facial detail, body language, and speaking manner. Do not use only abstract emotion labels.
7. Separate audio ownership in the storyboard:
   - in-shot dialogue and inner monologue belong to the shot and are spoken by the video generation;
   - VO belongs to an independent narration layer and must never be written into the video prompt;
   - BGM and effects belong to cross-shot audio layers.
8. Check that dialogue and VO do not repeat or closely paraphrase one another. Resolve overlap before generation. Update the canvas storyboard and any script-to-storyboard checklist with the result, then pause for user confirmation.

## STEP 4: Create continuity assets

Generate or register all assets in batches before generating final videos.

### Character assets

For every recurring character, use a full-body three-view sheet: front, side, and back in one horizontal 16:9 image, with a small head-and-shoulders detail if useful. Lock face, hair, makeup, clothing silhouette, colors/materials, footwear, and distinctive props. Target 2K detail with the selected, reference-capable image model. Before generating continuity assets, the runtime must verify availability, reference editing, framing and resolution support. If a confirmed requirement is unsupported, explain the gap and obtain approval for an equivalent capability or revised spec. If a user character reference is not already a compliant three-view sheet, regenerate a compliant sheet from that reference before binding it.

### Scene assets

For every recurring scene, create a no-character four-panel multi-angle reference sheet in 4:3 at the confirmed image resolution, targeting 2K detail. The four panels must depict the same location from clearly different angles or regions. Every scene description must identify the exact region used by each shot. For a space that supports or encloses a character, explicitly record the floor/deck/platform, boundaries, railings, walls, or other physical contact anchors.

### Prop assets

Create important bullet-time props in 16:9 with the selected image model. Emphasize material, texture, impact state, motion blur, and readable spatial scale. Minor props may remain text-described when the video reference limit requires it.

### User-provided assets

Analyze every supplied image, video, audio, or document for role and style compatibility. Bind it to the correct element or shot when compatible. If it conflicts with the confirmed style or format, use it as the source for a compliant regenerated asset rather than silently using the mismatch. Pause for review of all continuity assets.

## STEP 5: Create and bind character voice profiles

This step is mandatory before any shot with dialogue or inner monologue.

- If the user provides an authorized voice file, register and bind it to the corresponding character.
- Otherwise, offer a choice between a lower-cost text-to-speech sample path and a video/audio extraction path when available. Explain the tradeoff between speed/cost and voice-character fit.
- Generate a short sample from an appropriate line, define age, personality, timbre, speaking pace, and emotional range, then bind one stable voice profile per character.
- Reuse the same profile for that character in every shot. Do not create a new voice per shot.

Pause for voice review, then perform a complete asset-binding audit: every referenced character, scene, prop, and required voice profile must exist and be correctly attached.

## STEP 6: Select the video model and generate final shots

Before generating shots, the runtime checks current availability, reference types and count, supported duration, framing, resolution, native dialogue and voice-reference support against the approved spec. Prefer MiniMax H3 for reference continuity and native dialogue only when those capabilities are available. Respect an already recorded user choice; do not ask again merely to select a default. Present the viable model and limitations with the generation plan for approval.

If the selected model is unavailable or cannot meet a hard requirement, explain the specific gap and propose an available equivalent model or an explicit spec revision. Obtain approval for changes to the selected model or output; never silently weaken voice identity, continuity or shot timing. Keep the approved model consistent across shots and revisions for visual continuity. A user-supplied usable shot can be bound without regeneration.

Generate the selected model's shots in 16:9 at the confirmed project resolution, defaulting to 720p when no other resolution is locked.

Before each shot, verify all six conditions:

1. the scene four-panel reference is attached and its exact region is named;
2. every involved character three-view reference is attached;
3. every speaking or inner-monologue character has its bound voice profile;
4. all shot dialogue is complete and exact;
5. VO is assigned to the independent narration layer and is absent from the video prompt;
6. action, posture, timing, camera path, and bullet-time beat are all represented.

Use only the reference count and input combinations supported by the selected model at execution time. Prioritize character sheets, then the scene sheet, then essential props. Describe secondary props in text when necessary. Add the previous shot as a video reference only for unusually strong visual continuity; do not add it by default.

Write the prompt as one natural-language paragraph in the user's working language. Keep the following order:

1. Camera: framing, angle, orbit direction, start/end angle, and speed;
2. Subject: exact body positions, slow-motion interval, frozen pose, and recovery action;
3. Space: the chosen scene region, physical contact/support, and trajectories of bullets, fragments, liquid, or sparks;
4. Audio: in-shot sound effects and exact dialogue only.

For physical spaces, state where the character stands, sits, or makes contact, plus the surrounding boundaries. Treat the four-panel image as reference only and request one unified scene, never a grid-like video. Inject compact visual anchors from the previous shot: clothing/material, key light direction, and one background landmark.

Always state no music and no subtitles in the video prompt because those are handled separately. Keep the prompt under 2,300 characters including reference placeholders. Compress repeated style and background wording first; preserve action, dialogue, timing, and emotional performance details. Do not put VO text in the video prompt.

For an emotional shot, explicitly state cause, micro-expression, body movement, and speaking manner. Do not replace these four components with a generic word such as “sad” or “angry.”

After all shots are generated, pause for user review. If generation fails without an asset, retry automatically with a materially corrected prompt. If an asset exists but fails quality review, stop and show the problem; never regenerate without the user's approval.

## STEP 7: Generate audio layers

After shot review, create the cross-shot audio assets:

- at least one BGM track with the requested mood, pulse, and a time-freeze impact; never name a famous musician in the prompt;
- independent VO audio when requested, with complete script and emotional pauses;
- sound effects or ambience when needed.

Keep in-shot dialogue/inner monologue inside the video generation and keep VO independent. Recheck for repeated or near-duplicate wording before assembly. Pause for audio review.

## STEP 8: Assemble and mix

Before final assembly, ask whether to apply optional super-resolution to the video assets. Do not assume either choice.

Assemble shots in storyboard order. Use a normal or slightly fast setup before the bullet-time peak, a gradual entry and exit around the freeze, and a controlled return to normal speed. Do not add decorative transitions inside a bullet-time shot; let the speed change carry the effect. Use simple cuts or brief fades between ordinary shots.

Mix with the priority dialogue > VO > BGM. As a starting point, keep BGM around -18 to -20 dB, lower it further at the freeze or under speech; keep VO around -6 to -9 dB; keep in-shot dialogue around -6 to -3 dB. Duck lower-priority layers rather than allowing all three to play at full level.

VO should not be truncated to fit a single shot. It may continue into the next shot at a semantic boundary. Do not extend a shot solely to fit VO. If VO is more than 30% too long or short for its intended region, pause and propose a script or timing adjustment for approval.

Export the final 16:9, 720p video, or the confirmed super-resolved target. Review continuity, bullet-time readability, audio duplication, dialogue clarity, subtitle absence/presence, and final shot order before delivery.

## Failure and revision rules

- A missing or failed generation with no asset may be retried automatically, once, with corrected constraints. If it fails again, explain the cause and propose an available equivalent model or revised plan for approval rather than repeatedly retrying the same model.
- A generated but unacceptable asset requires user-visible quality feedback and explicit approval before re-generation.
- Local revisions should target the affected style option, storyboard shot, key element, voice profile, audio layer, or video shot; do not restart the entire project unless the user requests a full reset.
- Never skip a confirmation milestone: locked spec, storyboard, continuity assets, voice profiles, shot videos, audio layers, super-resolution choice, and final assembly. The locked spec, script, storyboard, and script-to-storyboard checklist are canvas documents; do not output their full bodies in chat. When revising them, update the existing canvas document instead of creating duplicate documents unless the user explicitly requests a new version.
