---
name: narrative-script
description: Write stories and narrative scripts
---

## Story outline

Use the available information to propose a brief creative outline, including the title, one-sentence story, main turns, and ending direction. After user confirmation, write the script within the agreed scope.

## Script format

- Structure the script as `# Script — <project/scope>`, `## Basic information`, `## Synopsis`, `## Characters (identity/goals/relationships)`, and `## Scene-by-scene script`. Include only confirmed specifications such as episode count and duration.
- Use `### Scene <number> | <time> | <location> | <characters>` for each scene. Describe visible actions and surroundings; give character names and verbatim dialogue. Add emotion and timing annotations as needed.

## Script writing

Develop the detailed script from the confirmed outline using the methods below.

- Plot: use four phases. Opening breaks the status quo, introduces the protagonist's goal and central question, and plants clues or hooks. Rising action turns choices into new obstacles and plants relevant questions and clues at key choices or information changes. The storm brings earlier clues and costs together into crisis or reversal. The final confrontation pays off the setup through character action and reaches the ending.
- Character arc: establish the protagonist's goal and inner conflict. Let them hesitate, choose, and bear consequences at key events. Contrast the ending with the opening through action to show change and growth.
- Scenes and dialogue: each scene has a goal, resistance, action, and result that changes information, relationships, or risk and drives the next scene. Dialogue expresses character intention and relationships without repeating known background, and matches the speaker's personality.
