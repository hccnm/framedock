---
name: pet-keynote-video
description: Create a 28-second pet keynote from photos with five outfits, a jacket pocket, pair interaction and symmetric curious head tilts, silent 15+13s clips and chosen BGM. Not official Apple ads or slides.
trigger-words:
- 宠物发布会
- 猫咪发布会
- 狗狗发布会
- 苹果风宠物广告
- 宠物换装发布
- pet keynote
- cat launch film
- dog launch film
---

# Pet Keynote Video

Create an original photoreal pet concept film in minimalist technology-launch imagery. Deliver one five-outfit sheet, one audio-free 15-second clip, one audio-free 13-second clip, and one 28-second film. Both clip production and the silent master have no sound; only after full-film visual acceptance is the user's supplied or designated BGM composited. Preserve the optional-music branch, but an explicit BGM instruction is an established choice and must not trigger another music-choice question. Do not imply Apple affiliation or add Apple logos or endorsements. Use a suspended utility-jacket patch pocket and specified cuts, not a canvas travel tote or fabric-penetration extension.

## STEP 0: Confirm inputs, resolutions, and constraints

Require photos of the same pet, a name, and a user-confirmed breed. Resolve identity conflicts first; never assert a breed from appearance. Cats, dogs, and other pets retain source-grounded face, muzzle, ears, fur, tail, and natural proportions. Adapt actions to their anatomy; ask only about true incompatibilities.

- Sheet and film are 16:9 landscape. Target 28 seconds as a 15-second first clip and a 13-second second clip.
- Use MiniMax H3 as explicitly selected by the user. Check current capabilities; historical resolution, duration, or mode support is not a permanent guarantee. Explain and confirm alternatives when required.
- Before generating ANY image, obtain explicit user confirmation of image resolution; before generating ANY video, obtain explicit confirmation of video resolution. Offer only options supported by the currently selected model. Collect the two choices together or before the first generation of each medium. No unconfirmed medium may be generated, including outfit sheets, previews, and test clips. Never silently use 2K or a model default.
- Resolution, aspect ratio, and quality tier are separate decisions. An explicitly requested and currently supported resolution counts as confirmation. Reuse confirmed values within the same project and scope while unchanged. Confirm again for a new resolution, new project, or a model change that makes the approved specification unsupported. Never silently upgrade or downgrade. Outfit, copy, framing approval, or generic continuation does not confirm resolution.
- Preserve existing assets; do not regenerate them just to retroactively obtain resolution approval. Inspect actual pixel dimensions and exact aspect ratio. Report mismatches before any authorized resizing, cropping, or regeneration. Resolution approval does not replace result review or retry authorization.
- Original photos own identity; the outfit sheet owns clothes. Explain every reference contribution individually. A video of another pet cannot replace the identity source. Let photos carry existing fur colors and markings.
- Keep the Chinese screen copy below verbatim, substituting only 【宠物名称】 and 【宠物品种】. Do not translate it. This is advertising typography, not dialogue subtitles.

### Audio-free clips: separate generation, delivery, and final music

- Explicitly request silence for both the first 15 seconds and the second 13 seconds, and disable generated audio whenever the current capability supports it. Do not generate or retain music, narration, dialogue, animal calls, ambience, transition sounds, or other effects.
- A silence request, muted player, or zero volume does not prove an audio-free file. Inspect actual streams after every return. If audio exists, remove only the audio while preserving video pictures, dimensions, frame rate, and duration; then verify there is no audio stream. This purely audio-removal delivery step is pre-authorized by this Skill and precedes visual approval. It does not authorize trimming, retiming, or regeneration.
- Present the playable audio-free review version by default. Retain the original return for traceability, not as a second final deliverable. If audio removal fails, report the blocker rather than calling the audible file compliant.
- After individual visual approvals, assemble an audio-free master. Add the user's supplied or designated BGM once to the complete film only after full-film visual acceptance, never during generation or separately to each clip.

### Mandatory result approval and regeneration authorization

- After every video generation, including retries, retain the result, perform only the audio-removal delivery step above, and show the audio-free review version. Inspect specifications and visuals read-only as needed, report deviations, then end the turn for explicit approval. Passing self-inspection never permits automatic progression.
- Only after approval of clip one, including reported deviations, and permission to continue may you trim it, extract its actual endpoint, and generate clip two. Only after approval of clip two and permission to continue may you trim and assemble. Show the assembly and pause for visual acceptance before designated BGM compositing. A prior BGM choice does not approve the film.
- Never automatically regenerate, replace, or overwrite visuals because of copy, background, action, quality, or seam problems. Failure or no usable video requires reporting and explicit retry authorization. Resolve unknown task status before resubmitting; never blindly duplicate a submission.
- Continue or approval authorizes only the single stated next step, not regeneration. An explicit request to modify and redo the current clip authorizes one corresponding regeneration; dissatisfaction alone requires clarification. Show every regenerated result and pause again.
- Approval never transfers across clips. Initial plan approval, music choices, and self-inspection cannot bypass current-result review. Preserve successful assets and limit repairs to authorized parts. Editing this Skill does not authorize regenerating historical assets.

## STEP 1: Five-outfit reference sheet

User-specified core prompt:
> 根据上传的图片宠物形象,生成一张图片,自左向右横向整齐排列(白T款、灰卫衣款、原版裸毛款、小恐龙外套款、透明外套款)

Confirm image resolution first. Analyze source-grounded face, markings, ears and ear tufts, ruff, fur length, proportions, and tail. Produce one 16:9 sheet of exactly five front-facing, full-body seated versions of the same pet, equally scaled, clearly separated, paws aligned, without text. Do not split into five deliverables. Use the smooth white-to-light-gray seamless environment below, not curtains or an interior that later clips might inherit.

Left to right is always white T-shirt, gray hoodie, natural fur without clothes, dinosaur jacket, transparent jacket. Original is centered; transparent is far right. T-shirt is short-sleeved and round-necked; hoodie has a hood. Dinosaur clothing has recognizable dorsal details without hiding the face. Transparent clothing has legible edges and reveals fur. Natural fur means no clothing, never shaving. Change only clothes, not face, fur, or animal anatomy. Report old-order or incorrect sheets and obtain correction authorization instead of silently reusing or automatically regenerating them.

Before video production, present the sheet, substituted copy, and 15+13-second timing plan for approval. Reuse unchanged approvals; resolution and post-generation result gates still apply.

## STEP 2: Full 28-second video prompt

### Background and typography: include completely in each clip

Throughout, use a white-to-light-gray seamless background flowing into the floor without a visible horizon, resembling the light minimalist visual language of an Apple keynote without implying affiliation. Large soft light from front-above, side-rear rim light, and light-gray contact shadows. Use medium-to-long focal-length perspective throughout, shallow depth of field in macro shots, explicit camera starts and stops, and gentle deceleration.

Advertising text uses a PingFang-like sans-serif form with a medium-to-fine visual weight, neat compact spacing, and a low-saturation horizontal blue-to-cyan-green gradient. Prefer one line, character height approximately 3%-4% of frame height, generous negative space, and no subject obstruction. Fade whole sentences in and out. No outlines, shadows, glows, or per-character animation. Show copy only in its specified interval.

### Execution and review requirements

- Include the COMPLETE shared background and typography constraints in both the first 15-second and second 13-second generation descriptions. Do not leave them only in the overall plan, shorten them to white studio or gradient type, or assume the second clip infers them.
- White-to-light-gray means smooth lighting over a seamless continuous space. No curtains, pleated drapes, hanging backdrop fabric, stripes, panel seams, room corners, baseboards, stage edges, or visible horizon. The utility jacket may have realistic local clothing folds; those must not expand into a pleated background.
- The gradient runs horizontally across each entire line from blue at screen-left to cyan-green at screen-right, not vertically, diagonally, or as per-character color jumps. Character height refers to actual video height, not reference-image height. Reserve enough horizontal space for the complete sentence and prioritize one line. Do not enlarge it into a two-line headline, alter words, or shorten copy to fit.
- Inspect the real opening frame for clip two. If the first clip ends with curtains or another incorrect backdrop, report it and wait for the user to authorize a first-clip repair or explicitly accept the deviation. Do not silently treat the incorrect background as compliant or jump to a different background in clip two.
- Wrong backgrounds, wrong gradient direction, extra line breaks, and obstructed subjects are reportable deviations even when actions are correct. This does not authorize automatic regeneration or background repainting.

### 0-4.5s: Macro pullback

Begin in extreme macro on the pet's iris and ear-tip fur. Pull back smoothly at constant speed, revealing full cheeks and the entire seated body. The pet looks directly at camera amid clean negative space. Fade in above:
「【宠物名称】,大有可爱。」
Fade out before 4.5s.

### 4.5-9.5s: Medium close-up, petting, and utility-jacket pocket

The pet makes an endearing backward lean, inclining slightly backward and extending its front paws forward. A clean slender hand enters from above, stroking gently from forehead backward. Fur settles beneath the hand and naturally rebounds; the pet is adorable with wide-open eyes. Fade in at right:
「萌，也能有质感」
Transition through the white seamless space to the large patch pocket of a loose, light-colored utility jacket hanging in the air. The pet curiously emerges from deep inside the pocket with its entire round furry head and wide-open eyes. Both paws rest on the edge and gently sway; its expression is adorably alert. Fade in center-left:
「随身带,好心情。」
Fade out before 9.5s, then cut to the next scene. Do not substitute a travel tote or fabric-penetration extension.

### 9.5-15s: Step and fan-like duplication

Remain in the continuous white-to-light-gray seamless space: the pure-white studio floor flows into the backdrop without curtains, pleats, or a horizon. The original pet elegantly steps forward; at that exact instant, four differently dressed versions slide smoothly outward to both sides like an unfolding fan, using the supplied clothing reference. Five pets form a neat technology-product lineup. Left to right remains T-shirt, hoodie, original, dinosaur jacket, transparent jacket. Each is a complete independent individual of the same identity, with no torn or fused limbs. Fade in above:
「【宠物品种】Pro Max」
Fade out before 15s. Complete the lineup before the 15-second seam: all five full bodies clear, stable, and grounded, camera gently decelerated to a stop. No outro, white ending, or premature tracking.

### 15-19s: Left-to-right tracking close-ups

Move the camera steadily from left to right along the lineup, presenting close views of all five pets. This is lateral translation, not an orbit; the pets stay in their positions. Keep the same seamless environment. Fade in below:
「多款模样，各有主张。」
Fade out before 19s.

### 19-22s: Two-pet side interaction

After a brief empty-space beat, cut to a locked side close-up in the same white-to-light-gray seamless environment containing only two pets: hoodie on the left and dinosaur jacket on the right. They enter toward each other from opposite sides, slowly approach with noses nearly touching, and exchange affectionate looks and sniffing. The empty beat is included within these three seconds. No third pet, forced kiss, extra duration, or text.

### 22-25s: Five seated looks

Directly cut back to a wide view of all five pets seated in a row on the floor of the same seamless space, with no airborne, jumping, or floating transition. Left to right remains T-shirt, hoodie, original, dinosaur jacket, transparent jacket. All face camera and sit upright. Identity, clothes, proportions, and order match the earlier lineup. Bodies rest naturally on the ground with soft contact shadows. Lock the camera and pause movement to prepare symmetric curious head tilts around the centered original pet. No text or premature head tilting.

### 25-28s: Symmetric curious head tilts around the center pet and closing copy

Lock a frontal full-body wide shot. Pet 3, the centered original, is the stable axis of symmetry: its head stays upright and centered, bright eyes looking at camera, without following either side's tilt. Left and right always mean the viewer's screen directions, not the pets' anatomical left and right. Pet 1 in the T-shirt and pet 2 in the hoodie gently tilt only their heads at the neck toward screen-left. Pet 4 in the dinosaur jacket and pet 5 in the transparent jacket gently tilt only their heads toward screen-right. Use small, natural tilts of approximately 10-15 degrees, mirrored outward, with curious eyes still looking at camera. No profile turns, head flicking, or exaggerated neck twisting.

All five torsos, chests, and front legs remain vertically seated and grounded. Positions, spacing, scale, and outfit order stay fixed. Tilt heads only, not bodies; do not tip the whole group in one direction, slide, or lose ground contact. Start at film time 25s, complete by approximately 26s, and hold the left-pair-left / center-upright / right-pair-right curious portrait through 28s. Fade in one bottom-centered Chinese line as a whole sentence:
「每一款，都有偏爱。」
Show this copy only during 25-28s and hold it with the group to the last frame. Do not pull back to one-tenth scale or fade to white.

### Notes and explicit-cut exceptions

Never alter the pet's face or fur quality. Specified physical transitions must be smooth, with no dropped frames, intersections, or unrequested hard cuts. The cut into the studio at 9.5s, the side-close-up cut after the empty beat within 19-22s, and the direct wide cut at 22s are explicit exceptions to the generic hard-cut prohibition. Do not restore the old fabric-penetration extension or omit required cuts. The utility jacket is suspended; pets after 22s must stay seated on the floor. Both generated clips and review versions must be silent and audio-free. Composite BGM only after full-film visual acceptance under STEP 5.

## STEP 3: First 15-second clip and actual continuity frame

Confirm video resolution before generation. Use original photos for identity and the approved sheet for outfits. Local time equals film time: 0-4.5s macro pullback; 4.5-9.5s petting and utility-jacket pocket; 9.5-15s specified cut, step, and fan duplication. Use the complete corresponding STEP 2 actions, its full background and typography constraints, and STEP 0 silence requirements, not just an abbreviated timing table.

Before 15s, duplication is complete, all five full bodies are grounded in canonical order, the title has disappeared, and the camera is stationary. Rightward tracking has not started. Retain natural subtle breathing, not an outro.

After return, inspect and remove only unexpected audio, verifying an audio-free file with unchanged pictures, duration, dimensions, and frame rate. Inspect background, typography, actual specifications, and the 14-15s lineup/title exit. Show the audio-free review version and deviations, then pause. After approval and permission to continue, trim to 15s only if required actions remain intact. If duplication or title exit is incomplete, report it and obtain repair authorization; never arbitrarily retime.

Extract the final valid frame from the retained 15 seconds based on measured frame rate, never an old hardcoded 14-second index. Inspect identity, coordinates, scale, clothes, absence of title, seamless background, lighting, and stationary camera. This actual frame is the next opening, not a redrawn approximation. Do not propagate an incorrect curtain backdrop into clip two without explicit acceptance.

## STEP 4: Second 13-second clip and local timing

Generate clip two only after approval of clip one and permission to continue. Reuse the confirmed video resolution; confirm changes first. Begin directly from the actual endpoint using a currently supported single-opening-frame method, not one requiring a closing frame as well. Respect compatibility between keyframes and other references.

- Local 0-4s = film 15-19s: begin left-to-right lateral camera movement from the real frame and showcase close views. No orbit, pet relocation instead of camera movement, repeated duplication, or breed title. Fade in 「多款模样，各有主张。」 below and out before local 4s.
- Local 4-7s = film 19-22s: brief empty beat, then locked side close-up of only hoodie left and dinosaur right approaching and sniffing. No text.
- Local 7-10s = film 22-25s: direct cut to five grounded seated full bodies in canonical order, locked camera, no text, no floating or jumping. Heads stay upright; do not start tilting early.
- Local 10-13s = film 25-28s: original pet 3 keeps its head centered and upright. Pets 1 and 2 tilt only their heads screen-left; pets 4 and 5 tilt only their heads screen-right, approximately 10-15 degrees, with all bodies vertically seated on the ground. Start at local 10s, complete by approximately 11s, and hold through 13s with curious eyes toward camera. Fade in the bottom-centered single line 「每一款，都有偏爱。」 from the start of this shot and hold to the last frame, without premature text.

Use complete corresponding STEP 2 actions and explicitly repeat its FULL background and typography constraints plus silence requirements; do not rely only on the opening frame or earlier descriptions. Bind the center pet and both side groups to their specific head directions and distinguish head motion from body posture. Do not compress the ending into ambiguous group leaning or uniform head tilting. After generation, remove only unexpected audio and verify unchanged video pictures and specifications, then show the audio-free review version and findings. End the turn for approval. Do not automatically trim, assemble, or retry.

## STEP 5: Silent assembly, verification, and final BGM

After approval of clip two and permission to assemble, inspect its 13-second cutoff and trim without damaging required actions. Reconfirm both clips contain no audio streams and have compatible dimensions, aspect ratio, and frame rate. Concatenate 15s then 13s into a 28-second silent master with no added seam duration, crossfade, or retiming to hide jumps.

Acceptance checklist:
- 28s, 16:9, first clip 15s and second 13s, actual resolution and exact aspect ratio match approval. Both review clips and the silent master have no audio stream, not merely zero volume.
- Every shot uses the white-to-light-gray continuous background and floor with no visible horizon, curtains, pleated drapes, or panel seams. Local jacket folds never become backdrop folds.
- Large front-above soft light, side-rear rim light, light-gray contact shadows, medium-long perspective, macro shallow focus, and gentle deceleration remain consistent.
- Check each exact sentence, PingFang-like sans-serif, medium-to-fine weight, neat compact spacing, left-to-right blue-to-cyan-green gradient, approximately 3%-4% character height, prioritized single line, and no subject obstruction. Whole-sentence fades only; no outlines, shadows, glow, or per-character animation. Copy appears only in specified intervals.
- Suspended utility-jacket patch pocket, not a travel tote. Specified cut at 9.5s, not fabric extension.
- Inspect film 14-16s for identity, coordinates, scale, clothing, and lighting continuity. Title leaves before 15s, tracking begins at 15s, and duplication never repeats.
- Every lineup is T-shirt, hoodie, original, dinosaur, transparent. Tracking during 15-19s is lateral, not an orbit; pets do not relocate.
- Exactly hoodie left and dinosaur right sniff in side view at 19-22s. At 22-25s, all five are seated on the floor with upright heads and no early tilting. No copy during 19-25s.
- Check each pet at 25-28s: original pet 3 has an upright head; pets 1 and 2 tilt toward viewer screen-left, pets 4 and 5 toward screen-right, gently and curiously. All torsos, chests, and front legs remain vertically seated and order stays unchanged. Mirrored outward head tilts around the center must not become all-in-one-direction tilts or body leaning. If direction cannot be seen reliably, report uncertainty rather than inferring compliance from the prompt.
- Head tilts start only at film 25s (clip-two 10s), finish by approximately film 26s (clip-two 11s), and hold to the end. Bottom line 「每一款，都有偏爱。」 appears only during 25-28s and remains to the final frame. Premature action or copy remains a deviation; do not write an individual generation's early timing back into the standard timeline. No endless pullback, one-tenth scale, or white ending.

Show the assembly and pause for acceptance. Correct actions do not excuse incorrect backgrounds or typography. Report deviations, preserve successful assets, and repair only explicitly authorized parts. Changing clip one requires a new actual endpoint and reassessment of clip two, not automatic regeneration of clip two. Show and pause after every retry. Timing and seamlessness are targets, not guarantees. Keep historical 14+14 clips as older assets; do not arbitrarily retime them and call them compliant with this revision.

### Composite designated BGM after visual acceptance; retain optional choice

No sound applies to both clip generations, their review versions, and the silent master, not to a final soundtrack the user requests. If the user already says to add their BGM at the end, record that choice and use the designated track after visual acceptance without asking again whether music is wanted. Future tasks without a choice retain one question: “使用《宠物发布会bgm.mp3》” or “保持静音”. Do not add music by default; its selection never replaces visual acceptance.

- The optional recording is [宠物发布会bgm.mp3](https://cdn.hailuoai.com/hailuo-video-web/public_assets/80d3afa0-2f45-4077-bac4-36c431d156f2.mp3), hosted externally to keep the install package free of audio binaries. If the user explicitly designates a new uploaded track, use that track instead. Clarify only the file identity if several are ambiguous. Never search for or generate replacement music. If the designated file is missing or unreadable, request it rather than silently substituting. Materialize through an available asset mechanism when project-local media is required.
- Apply music once to the complete accepted film, from time zero continuously across the 15-second seam, never restarting per clip. Keep both source clips audio-free. Reuse accepted visuals for audio-only requests rather than regenerating them.
- Inspect actual music and film durations. Trim excess music; if shorter, ask whether to loop or pad with silence. Never stretch video or change shot, copy, or transition timing to fit music. Do not assume historical track durations remain valid.
- Preserve speed, pitch, and original level. No unapproved fades, normalization, narration, or effects. Prefer retaining the video stream unchanged; remove all old audio and keep only the designated BGM as the sole soundtrack.
- Verify unchanged duration, dimensions, frame rate, visuals, and copy; exactly one designated soundtrack continuous across the seam, without duplicates. Report clipping or abrupt endings and obtain treatment approval. Show the music composite without further automatic processing.
- If silence is chosen, final output has no audio stream. Deliver only the chosen final version unless both are requested; retain the silent master for repairs. Music cannot conceal unaccepted background, typography, or visual deviations.

## STEP 6: Deliver and reuse

Deliver the outfit sheet, audio-free 15-second and 13-second clips, and the 28-second final film: use the designated recording when BGM is selected, or no audio stream when silence is explicitly selected. Retain the actual continuity frame as an intermediate. Reuse returned paths without moving or duplicating registered assets and organize the canvas under platform rules. Report measured specifications, verified findings, and deviations.

Future runs substitute the new pet, name, and confirmed breed instead of historical identity or old-order sheets. Confirm image and video resolutions for each new task. Later explicit user story, copy, or audio changes take precedence.
