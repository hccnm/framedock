---
name: design-photoshop
description: |
  Create or edit in Photoshop (PS) from briefs, photos or references; deliver layered PSD/PSB files for layout, retouching and compositing. Not for style mentions alone or image-only generation.
---

# Editable Photoshop Design

Help designers produce work they can continue editing in Photoshop: new layouts, photo retouching, product composites, reference reconstruction, existing PSD revisions and canvas asset handoff. Deliver a real layered document and a visual preview returned to the canvas by default. Use the references selectively for the actual task.

## 1. Establish the intended deliverable

- Use when the user asks to create or edit in Photoshop/PS, requests an editable PSD/PSB, or continues the current Photoshop document. “PS-like,” “cinematic” or “poster style” alone does not select Photoshop; neither do layer masks or editable text without an application or document context. A style reference, source attribution, negation or knowledge question is not a request to operate PS.
- Reuse the brief, selected canvas assets and existing decisions. Establish source version, intended changes, dimensions, screen/print destination and editable elements. Preserve source dimensions unless a resize is requested. For a new screen design with no size specified, choose and state an appropriate size; print production requires physical size and supplier specifications.
- Ask only when the answer changes the execution: which source/version to edit, PSD versus a flat image when ambiguous, exact replacement text, or an unresolved print requirement. Continue asset inspection while waiting. Do not repeat confirmed questions or require approval for ordinary reversible edits within scope.
- Establish naming language from the user's explicit preference, then existing project conventions, then the conversation language. Application UI language alone does not determine layer names. Keep visible artwork text verbatim unless asked to change it. Do not translate existing names indiscriminately.

Read `references/document-design.md` for layer structure and reference reconstruction, and `references/handoff.md` for canvas inputs or existing projects.

### Ask questions the user can answer directly

- Ask about the desired result, use and tradeoffs; decide construction methods yourself. Prefer the user's own vocabulary. When they use technical terms, follow their lead and briefly explain the effect on the result when needed.
- Prefer one question that most affects the next step; combine at most three short questions when genuinely related. Do not turn the internal checklist into an opening questionnaire. Inspect the image, document and context first for answers already available.
- When choices help, offer two or three plain-language options, explain the recommendation and practical difference, and allow a free-form answer. Do not ask users to choose mask types, bit depth or Smart Objects as implementation details; ask about intended use or editing needs when these matter.
- State a reasonable default and continue for reversible, low-impact details. Do not treat silence as approval for a consequential decision that requires an answer. If a layered PSD is already requested, do not ask again whether the file should be editable.
- Ground questions in the current assets. When the editing scope actually needs clarification, ask “What will you mainly want to change later: the text, the background, or the person's position?” instead of “Confirm layer decomposition granularity.” When use is unclear, ask “Is this for sharing online or for printing?” instead of asking the user to select a color space.
- For a missing font, explain the practical effect: “The original font isn't installed. I found a similar one, but the letters are slightly wider. Shall I use it?” Verify that the substitute exists before making that claim; examples are not facts to copy unconditionally.
- Describe connection problems through observed facts and the next step. If the application is open but documents cannot be read, say “Photoshop is open, but I can't read its files yet. I'll keep checking the connection.” Only request a user action when necessary, naming an actual visible control and the reason. Do not present raw error codes, script output or internal terminology as a user question, or promise a repair that has not been performed.

## 2. Establish a working application connection

Use `references/readiness.md` for interpreting readiness and failure evidence. If the desktop application is missing or its location is unresolved, follow its installation guidance before retrying connector setup: provide the official entry and the user's OS-specific steps, then recheck readiness and resume the retained task after installation.

1. Inspect the current session's available application capabilities. With local execution available, run `node scripts/ps-host.mjs --status` from this skill directory to discover the operating system, candidate installations and matching processes. This is inspection, not document access.
2. If the Photoshop connector is absent or disconnected, run `node scripts/prepare-connector.mjs --help`, then `--status`. When supported by the current desktop, use `--install` to prepare the registered connector for the requested Photoshop task. Allow the command to finish; after an interrupted result check status before another attempt. Keep system password entry inside the system dialog.
3. If the application is closed, use `node scripts/ps-host.mjs --launch`. With multiple candidates, select the version matching the existing project or known connection and pass its discovered path with `--app`; ask only if the choice remains consequential and unresolved. The helper supports macOS and Windows. It does not install Photoshop, open documents, load plugins or prove application control.
4. Inspect the installed connector's actual instructions and available capabilities. Reuse its supported connection/startup mechanism; do not copy the After Effects bridge, invent a Photoshop panel, or assume all versions use the same plugin. If a plugin must be opened, automate the documented action only through available application control; otherwise state that exact missing step.
5. Before document changes, obtain a fresh application response that lists documents or explicitly reports none. For an existing document, read its dimensions and layer structure and match it to the intended source. A process, successful launch or installed connector is insufficient. If discovery is stale after installation, refresh through the host's available connection mechanism and repeat the read.
6. If preparation is unavailable, use available connector UI automation; otherwise guide the user to the Photoshop connector with a concrete reason. Do not guess ports, read credentials, or edit private client configuration. If document access fails, retain the task plan and explain the verified blocker without claiming a PSD was made.

On Windows, the application helper also verifies a custom path supplied by the user or host, and includes the path of a running installation. It reuses the unique running version even when several versions are installed. An unreadable process path or failed process query remains unknown; multiple running instances or a different selected version block a new launch. Resolve that specific ambiguity, then continue with a fresh document read. Do not install Blender's Python dependencies for this connector.

### Bounded preparation recovery

Keep the original brief, asset paths, target project and last verified step in the conversation throughout preparation. The preparation helper already rechecks status and retries a confirmed package failure once through the managed installer; it does not retry unknown outcomes or authorization failures. Allow the full time budget documented in its help. Do not wrap it in another retry loop, delete cooldown markers, edit private settings or download a replacement from an unregistered source.

If installation is still running, check status up to three times over at most 30 seconds without starting another installation. If still busy, retain the task and report that preparation is pending; do not call it a failed installation. For an unknown result, inspect status before any further action. Repeated package failure requires diagnosing the client/network/extraction stage, not blindly sending the user to repeat the same installation in Settings. If no supported recovery is available, explain the specific blocker and the smallest required action.

After successful preparation, follow this skill's application connection steps to start the application and read the real project/document/scene, then resume the original task automatically. Do not ask for the brief again or for an “opened” acknowledgement. Never restart an application with unverified unsaved work or replay a creative write whose result is unknown.

## 3. Plan from the layer structure

- Inspect source pixels, transparency, fonts, color profile, bit depth, linked assets and the existing document's editable structures. Record what is observed versus inferred. Choose pixel dimensions and color handling before retouching.
- For a flattened reference, map visible elements into editable text, vector shapes, masks, photographic assets, adjustment layers and effects. Rebuild geometric elements natively. Keep photographic content as raster assets or Smart Objects; placing a whole screenshot in one Smart Object does not reconstruct its layers.
- Plan occlusion and hidden regions before cutting out subjects. Rebuilding missing pixels is a reconstruction, not recovery of the original. Resolve identity-sensitive or layout-critical missing sources before substituting them. Use generated material only within the user's requested scope and label its role.
- Preserve originals. Work in a versioned copy or new document, track the intended document and layer identifiers, and avoid edits based only on whichever tab happens to be active. Save an initial working document before substantial edits.

## 4. Build with editable decisions

### Photoshop built-in generative tools are disabled in this workflow

Do not use any Photoshop built-in generative tools, including Generative Fill, Generative Expand and image generation, even when the connector reports support. Do not invoke them directly, through custom scripts or UI automation, or through another operation that falls back to built-in generation; do not test or retry these routes. Ordinary fills, gradients, masks, healing, cloning and non-generative content-aware fill remain available when they do not use a generative fallback. If an operation's behavior is unclear, verify it before use or choose a clearly non-generative alternative.

For small defects, use source-based retouching. For large missing regions, follow the reconstruction guidance in `references/masks-and-retouching.md`: obtain a suitable source or, when authorized, use Design image editing for the affected region and return to Photoshop for the layered document. Preserve prior authorization; do not silently substitute generation for faithful product detail or for the whole PSD task.

For the work at hand, read:

| Task | Reference |
|---|---|
| Posters, typography, native shapes, layout reconstruction | `references/document-design.md` |
| People, hair, transparent edges, product cutouts | `references/masks-and-retouching.md` |
| Product placement, lighting, color matching, finishing effects | `references/compositing-and-effects.md` |
| Profiles, resolution, PSD/PSB and delivery checks | `references/color-and-delivery.md` |

Build a representative difficult region first: a hair edge on the intended background, a product contact shadow or the headline layout. Inspect it at native pixels and delivery size before repeating the technique. Simple edits do not need a separate approval round.

Use masks instead of deleting source pixels, adjustment layers for reversible correction, editable text and vector shape layers for design elements, and Smart Objects/Smart Filters when supported and useful. Keep texture detail where it belongs; do not smooth away skin, flatten text to evade a font issue or apply one edge treatment to the entire subject.

Check available operations before selecting a construction method. If a needed operation is unavailable, use a supported method that preserves the requested editability; if no equivalent exists, explain the affected element and ask before a materially different result. Do not silently replace the whole task with image generation.

## 5. Verify, save and hand back

- Inspect the actual composite at 100% and final viewing size: contours, hair, transparent areas, texture, text, alignment, shadows, gradients and crop. Compare reference and result at the same dimensions. Review structural editability separately from appearance.
- Re-read the layer tree to verify text, masks, adjustment layers, Smart Objects and groups exist as claimed. Check that linked assets resolve and that the correct document received the edits. After each substantial phase, save a checkpoint; inspect after a partial failure instead of replaying all mutations blindly.
- Save a versioned PSD, or PSB where document size/features require it. Verify the saved document can be opened without discarding an unsaved source; inspect its layers when reopening is available. If this check is unavailable, report that limit. Export previews from the same saved version.
- For completed creation or revision, default to exporting one final PNG/JPEG image from the saved document and returning it to the current Design canvas without another preview request. Preserve required transparency and color appearance using `references/color-and-delivery.md`. Honor explicit requests to skip export or canvas display, or to deliver multiple artboards/variants. For explicitly requested animation, follow `references/handoff.md` for a finished playable video; a still does not satisfy a dynamic deliverable.
- Deliver the PSD/PSB path, required linked assets and concise editing notes alongside the preview. Report approximated regions, substituted fonts or unsupported features specifically. Follow `references/handoff.md` to isolate intermediate files, verify exported media and confirm its canvas node, retaining source-to-output correspondence for revisions. Reuse an existing node for that output instead of duplicating it.
- Do not equate a preview placed on the canvas with native editable canvas layers, a layered PSD with vector-only artwork, or a file write with a completed visual review.

Completion requires a verified layered source and its matching final image displayed, or requested finished video available for playback, on the canvas unless explicitly waived. If export or canvas return fails, retain the source and verified files and report the unfinished step; a path or chat attachment alone is not canvas delivery.
