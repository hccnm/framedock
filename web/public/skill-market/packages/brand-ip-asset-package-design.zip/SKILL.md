---
name: brand-ip-asset-package-design
description: |
  Build a reusable IP character asset system from a sketch, reference, or brief, covering characters, expressions, outfits, posters, and merchandise. Use for staged IP development.
trigger-words: [IP物料, IP角色, 表情包, 换装, 海报, 文创周边, 潮玩, 手办]
---

# IP Asset Production

When the user wants to turn one IP character into a reusable asset system, follow this workflow. The goal is not just to make one image, but to lock the character identity first, then extend it into a controllable set of deliverables: IP 3D形象图、IP九宫格表情包、IP多种服装主体形象、IP海报场景延伸、IP文创周边等。The user may provide a sketch, a finished reference, or only a text idea. At every module boundary, present the results and ask whether to continue; the user may stop after any partial deliverable.

## STEP 0: 收集输入与范围

1. **Accept either sketch or text-first input**.
   - If the user already has a sketch / reference image, use it as the IP anchor.
   - If the user only has a text idea, first ask whether they want to先设计草稿图，or直接进入成品化角色图。
2. **Clarify the target scope**.
   - If the user provided a sketch or reference image, do not ask them to pick a module list first; use the fixed default sequence: 3D形象图 → 九宫格表情包 → 多种服装主体形象 → 海报场景延伸 → 文创周边。
   - If the user only has a text idea, ask whether they want first a草稿图 or directly a成品化角色图, then start from the chosen entry point.
   - If they are unsure about later modules, still recommend the same default sequence.
3. **Lock the fixed identity**.
   - Record the character’s face, head shape, hairstyle, silhouette, body proportion, core emblem, core color family, and any must-keep accessories.
   - Record what can change: posture, expression, clothing, props, scene, and product packaging.
4. **Confirm the production style**.
   - Use the user’s already confirmed phrases as anchors, such as“保持角色外观完全一致”“不改变造型/服装/颜色/发型和任何细节设定”“明亮干净的色调”“柔和光影过渡”“简洁现代的视觉氛围”“泡泡玛特风格”“3D卡通角色”。
   - If the user wants a new direction, update the lock before generating.

## STEP 1: 如果没有草稿，先生成草稿方向

If the user does not provide a usable sketch or reference image, do not jump straight to merch or posters.

1. Propose 3-4 sketch directions for the same IP.
2. Generate a small set of draft options.
3. Show the options and ask which one becomes the identity anchor.
4. Only after the user chooses, continue to the next step.

This step is optional when the user already provides a clear sketch or finished IP reference.

## STEP 2: 建立IP基础形象

Create the core IP 3D形象图 as the identity anchor for later assets.

- Keep the fixed identity unchanged.
- If the user wants polish, refine the sketch into a complete 3D卡通潮玩手办成品。
- If the user wants consistency testing, make a small set of core views or color variants, but keep the same character.
- After presenting the result, ask whether to continue to the next module and whether they want additional colorways.

## STEP 2.5: Colorway priority rules

When the user asks for IP colorways or palette options, prefer this order:

1. Start from a warm, low-attack base such as cream, milk tea, peach, oat, mint, or misty blue.
2. Use one dominant hero color, one supporting contrast color, and one small accent color.
3. Keep the full set within the same brightness and saturation band so the series feels unified.
4. For blind-box or collectible series, vary hue across variants while keeping the same soft overall color language.
5. For physical merch or figure sheets, prefer low-saturation, high-brightness colors with a clear dark or metallic accent for outline and finish.

## STEP 2.6: Optional motion extension board

After the core 3D character is finished, the workflow may optionally ask whether the user wants a motion extension board, or generate one when needed.

1. Keep the character appearance fully consistent and only vary motion, angle, expression, and light interaction.
2. Default to 8 distinct motion schemes with natural movement, varied viewpoints, and no stiff repetition.
3. Keep props simple; if needed, let the character hold or touch the prop directly instead of placing it beside the character.
4. Best used as a white-background reference board, motion proposal page, or motion study page.
5. After generation, ask whether to continue with the next asset module.

### Motion extension prompt template

"Based on the provided IP setup, keep the style unified and generate 8 ordinary motion extension schemes on a pure white background. The result should feel natural, differentiated, rich in angles, and interactive, while fully avoiding repetitive stiff poses, repeated viewpoints, and repeated facial expressions. Keep the character appearance completely consistent and only vary motion, angle, expression, and light interaction. Keep props simple, and if they appear, let the character hold or directly touch them."

## STEP 2.7: Expression pack module (optional)

When the user asks for IP九宫格表情包 or expression stickers:

1. Keep the same character model, clothing, color system, and main accessories.
2. Only vary expression, small action, and pose.
3. Default to a 3×3 grid with nine different emotions unless the user requests a different count.
4. Use a clean white seamless background by default so every expression-pack output stays easy to read and consistent; only change it when the user asks for a different background.
5. Keep the style unified so the set feels like one character family.
6. Present the sheet and ask whether to continue or revise.

## STEP 4: Outfit identity module (optional)

When the user wants multiple outfit identities for the same IP, first ask whether they want a common theme or a custom theme.

### A. Common theme

1. Generate standard occupational or themed outfits such as baker, astronaut, racer, doctor, chef, police, painter, or singer.
2. Preserve the character’s face, silhouette, proportion, and key emblem.
3. Change only outfit logic, role props, and identity cues.
4. Make each outfit read clearly as a different role or theme while still feeling like the same IP.
5. Default to 8 different character variants on one white-background sheet unless the user asks for a different count.
6. After completion, ask whether to continue to the next module.

### B. Custom theme

1. Analyze the IP’s style, recognition points, and overall vibe to find suitable character directions.
2. Turn that analysis into a custom character design recommendation, then turn it into a prompt ready for image generation.
3. Generate the image only after the direction is confirmed.
4. Preserve the character’s face, silhouette, proportion, and key emblem.
5. The new outfit should still feel like the same IP, with only identity, clothing, and props shifted in a custom direction.
6. If the user wants several identities, generate them as a series, then pause and ask what to do next.

## STEP 5: 海报场景延伸模块（可选）

When the user wants theme posters or scene extensions:

Any poster title, label, or supporting text defaults to English unless the user explicitly asks for Chinese.

1. Keep the same IP character unchanged.
2. Place the character into an energetic, playful, story-rich scene.
3. Let the scene support the character instead of replacing it.
4. Common directions include海上冲浪、森林探险、拳击比赛、潮玩展示、节日活动等.
5. Keep the result readable as a poster and ask whether to continue.

## STEP 6: 文创周边模块（可选）

When the user wants stationery, school items, sticker sheets, or kid-friendly merch:

1. Keep the IP role identity recognizable.
2. Extend the character into products such as笔袋、书包、铅笔、橡皮擦、儿童水杯、午餐盒、毛绒玩具等.
3. Keep the design bright, playful, simple, and suitable for children.
4. Prefer clean white or simple backgrounds unless the user asks otherwise.
5. After one merch board or one product set, ask whether to continue or split into individual products.

## STEP 7: 细节修改与重做

At any point, if the user says an asset is too plain, the color balance is wrong, the pose is weak, or a detail is missing:

- Update only the affected module.
- Keep the identity lock intact unless the user explicitly changes it.
- If the user asks to change the base sketch, revise the sketch first before generating downstream assets again.
- If the user asks to stop after a partial result, end the workflow and summarize what is already complete.

## STEP 8: 交付与继续选择

After every module:

1. Show the generated assets.
2. Summarize what was preserved and what changed.
3. Ask one short question: whether to continue to the next module, revise the current module, or stop.

The user may choose to generate only part of the full IP set. When the user starts from a draft image, always follow the fixed order above and ask after each completed module whether to continue to the next one. Never force the full sequence if the user wants only a sketch, only a 3D image, only an expression pack, or only merch.
