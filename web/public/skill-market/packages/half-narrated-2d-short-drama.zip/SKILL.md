---
name: half-narrated-2d-short-drama
description: |
  Create a 2D cel/webtoon half-narrated drama: lock speech windows, preserve original dialogue, hand off narration, and let the user edit. MiniMax-H3 is default; check explicit alternatives first.
trigger-words: [2D half-narrated short drama, cel animation drama, webtoon short drama, animated narrated drama, 2D动画半解说短剧, 2D半解说短剧, 国漫webtoon]
---

# 2D Half-Narrated Short Drama v1.0.1

This workflow is for a single 2D cel-shaded Chinese-animation webtoon episode. Narration carries context, time jumps, and unspoken thoughts. Dialogue carries conflict, reveals, refusals, and reversals. The default narration delivery is fast, clear, hook-forward short-drama commentary, and the user-selected narrator voice remains consistent across the entire episode.

### What is a first-frame anchor?

A first-frame anchor is an optional continuity reference image supplied to a shot generation request. It can fix the starting face, hair, wardrobe, props, scene layout, and lighting, but it is not required. Character, scene, prop, and wardrobe identity is enforced through the per-shot asset manifest and spatial blocking fields. It controls visual continuity only, not audio.

## Delivery Boundary, QC, and Rework Authorization (v1.0.1)

This Skill ends at STEP 7 narration handoff. STEP 8 only packages existing outputs; it is not another generation or post-production stage. Deliver the authorized shot assets, separate narration, preserved original dialogue, text/timing metadata, and checks, not final cutting, video assembly, subtitle burn-in, BGM/SFX mixing, or exported-file QC. Subtitle style and final-film specifications record later user editing intent, not permission to execute it here. Every reference, template, and example is subordinate to this boundary; “complete film,” “check after export,” or “all checks pass” cannot override it. An earlier user-requested stop takes precedence.

Record QC separately from execution permission: pass / fail / unverified / not applicable, with line IDs, shot IDs, versions, time ranges, and evidence. A hypothesis or ASR uncertainty is not proof of whole-batch failure. Never call failed media qualified, but report available usable outputs. Unresolved findings may be handed off as clearly labeled review-only/partial materials, not as fully validated or as a finished film. Do not generate again merely to achieve all-pass status.

Additional generation, pickup narration, model switching, whole-batch replacement, or new post-production requires explicit scoped authorization. State affected lines/shots/files, evidence, retained assets, proposal and contract changes, output count, attempts, and cost exposure first; disclose unknown cost. Voice selection, text approval, first-pass batch approval, and a generic “continue” do not automatically authorize rework. Reuse precise unspent preauthorization without asking twice. Default: one additional attempt per named artifact; cap the same issue at initial generation plus two additional attempts. Model changes, splits, new sessions, or renamed defects do not reset the count; stricter user/platform limits prevail.

Repair only evidence-backed affected lines, intervals, shots, and actually invalidated dependencies. Check neighboring handoffs rather than regenerating neighbors by default. Retain qualified narration, original dialogue, clips, and last approved versions; new outputs are review candidates until approved. Document/timing edits do not prove media has been repaired. A narration-only issue does not regenerate visuals or dialogue. A video rerender changes its native dialogue: disclose this in the authorization and recapture timing rather than reusing old evidence.

First-pass narration remains one locked master/batch. Diagnose local defects under `references/voice-presets.md`; explicitly authorized repairs may use a documented pickup batch for affected script lines with the same voice and full parameter lock. Never pretend it is the original session. Propose a whole narration replacement only when evidence shows a shared parameter failure or inseparable defective master and local repair cannot preserve consistency, or when the user explicitly requests an episode-wide narrator change. Obtain separate authorization for the full scope and cost. Do not invalidate or regenerate the entire batch without it.

Stop extra work when the acceptance target, authorization/budget/time limit, or cumulative attempt cap is reached, on user pause/cancel, external blockers, no material improvement, or an unapproved next step. Do not mechanically restart a capped issue. End at narration handoff; references cannot trigger later editing. Script/contract changes require a proposed revision and approval before changing the record; approval to edit documents alone is not authorization to regenerate media.

## Hard locks

1. visual_style_lock=2D-cel-webtoon, default guoman-webtoon.
2. backend=MiniMax-H3 and generation_mode=platform-supported reference mode by default. Capability-check an explicitly chosen alternative and follow it when compatible. On failure, record the cause and affected shots; retry or switch only within the scoped authorization rules above, never automatically.
3. narrator_delivery_lock=fast_short_drama_commentary: default narrator speed is 1.15 with clear diction, compressed nonessential pauses, strong sentence openings, and crisp emphasis on hooks, conflict, reversals, and payoffs. Lock voice id, profile, speed, pitch, emotion baseline, pause policy, volume, sample rate, codec, loudness, and delivery style episode-wide.
4. dialogue_source_policy=video_original_only: use the input video's original track or the original track returned with an H3 clip. Never create or replace dialogue with TTS.
5. narration_dialogue_overlap_allowed=false; narration and dialogue must never overlap on the same mixed audio track. Leave at least 0.20s between any two speech windows, and reject the mix if measured intervals violate this rule.
6. narration_generation_policy=single_batch_or_single_master: generate first-pass episode narration in one TTS batch/session or unified master with the user-approved voice and complete parameter lock. Do not choose voices per shot. Explicitly authorized local repairs are the only documented supplemental-batch exception, under `references/voice-presets.md`; never use the exception to fragment initial production into per-shot sessions.
7. audio_track_separation_required: keep narration and original video dialogue on separate stems until verified assembly; never place overlapping narration and dialogue into one audio track, never hide overlap with ducking, muting, truncation, crossfades, or volume reduction.
8. dialogue_consistency_scope: lock and verify narrator consistency; matching parameters or a shared batch alone does not prove matching sound. Character dialogue remains original per-clip audio and is not assumed to be globally voice-consistent.
9. Every shot must bind the required character, scene, prop, wardrobe, and other assets through `asset_manifest`, with stable IDs and hashes. First-frame or last-frame images may be used as optional continuity references.
10. narration_window_first_design=true: narration duration and placement must be budgeted and locked during storyboard design, before video generation. A shot without a feasible narration window is not generatable.

## STEP 0: Project lock

Lock starting path, genre, aspect ratio, duration, subtitle intent, delivery target, user-selected resolution (`768P` or `2K`), 2D sub-mode, narrator voice, speed, and backend. Subtitle preferences are later user-editing intent only, not burn-in authorization. The voice step remains mandatory: classify genre, viewpoint, emotion, and platform, then offer a recommended voice plus male/female alternatives for confirmation or audition. Existing defaults remain 9:16, 90 seconds, Douyin, guoman-webtoon, fast clear hook-forward delivery, speed 1.15, and MiniMax-H3 reference mode. Capability-check explicit model alternatives. On failure, propose a bounded retry or model change and obtain authorization before acting.

~~~yaml
project_lock:
  delivery_scope: "narration_handoff"
  stop_after: "narration_handoff"
  final_assembly_authorized: false
  narration_repair_policy: "authorized_affected_lines_only"
  narration_repair_manifest: []
  rework_authorizations: []
  aspect_ratio: "9:16"
  target_duration_s: 90
  subtitle_mode: hard-burn
  visual_style_lock: 2D-cel-webtoon
  visual_sub_mode: guoman-webtoon
  narrator_voice_id: selected catalog narrator voice ID
  narrator_speed: 1.15
  narrator_pitch: 0
  narrator_emotion: "fast_short_drama_commentary"
  narrator_pause_policy: "compressed_punctuation_pauses"
  narrator_delivery_style: "brisk_clear_hook_forwarding"
  narrator_volume: 1.0
  narrator_sample_rate: 48000
  narrator_codec: "wav_pcm_s16le"
  narrator_loudness_target_lufs: -16
  narrator_voice_profile_id: ""
  narrator_delivery_style: "brisk_clear_hook_forwarding"
  narrator_reference_audio_sha256: ""
  narrator_tts_batch_id: ""
  narration_render_mode: "single_batch_then_timed_slices"
  narration_batch_required: true
  narration_per_shot_generation_allowed: false
  narration_voice_lock_scope: "entire_episode_single_voice_id_profile_speed_volume"
  script_source_of_truth: "approved_script_manifest"
  prompt_generation_mode: "mechanical_from_shot_manifest"
  prompt_script_match_required: true
  h3_audio_policy: "dialogue_only; narration_forbidden_in_shot_audio"
  h3_audio_validation_required: true
  audio_render_mode: "separate_stems_handoff_no_final_mix"
  narration_dialogue_same_track_overlap: forbidden
  narration_dialogue_mix_gate: "measured_intervals_and_0.20s_gap_required"
  h3_must_preserve_submitted_audio: true
  backend: the platform’s currently available video capability
  generation_mode: platform-supported reference mode
  video_input_mode: "h3_reference_mode"
  resolution: "user_selected_768P_or_2K"
  asset_binding_required: true
audio_policy:
  dialogue_source_mode: rendered_video_original # or input_video_original
  dialogue_replacement_allowed: false
  narration_dialogue_overlap_allowed: false
  minimum_speech_gap_s: 0.20
~~~

Changing the narrator after locking requires a proposed new version and impact list. An episode-wide voice change needs explicit whole-narration generation scope, cost, and stop conditions; choosing a voice alone is not that authorization. Preserve prior narration and original dialogue, and do not automatically rerender video.

## STEP 1: Source, plot, and asset audit

Create a source_manifest with input files, duration, audio tracks, sampling details, dialogue availability, source path, and SHA-256. For an input video, extract and preserve its original track. For H3, archive the audio returned with every clip immediately after generation. If no usable original dialogue exists, stop and request an audio source; do not synthesize dialogue as a fallback.

When a script or image assets are uploaded, ask whether to use each image directly, use it only as a reference for regeneration, or use a mixture. Do not redraw or replace an uploaded image before that answer. Analyze the script without changing its event order, relationships, or ending; any alteration is only a proposal awaiting approval. Build an asset gap table (characters, scenes, props, wardrobe, actions, audio sources), generate missing assets, obtain confirmation, and only then continue to storyboarding.

## STEP 2: Story and two-channel script

Build five beats: Setup, Pressure, Response, Turn, Cliffhanger/Payoff. Write separate narration and dialogue columns. Narration must not repeat a fact already carried by dialogue. Dialogue should be short and spoken. The 60/40 narration/dialogue ratio is a target, not a reason to weaken a beat.

Assign every original script line an immutable `script_line_id` and `source_text`. `narration_text` must exactly match the approved source line; do not silently paraphrase punctuation, numbers, names, or particles. Compression or splitting requires an approved proposal and a new version ID. Do not hand-write a second story inside prompts: build each prompt mechanically from `shot_manifest` and retain `script_manifest_sha256` and `shot_manifest_sha256`.

## STEP 3: Shot-level narration and dialogue budget

Budget both speech channels during storyboard design, before submitting any video generation request. For every Shot, first place the approved narration text and estimate its duration using the locked narrator voice, speed, language, pause policy, and delivery style. Then place the dialogue line and reserve a protected gap. The shot must explicitly declare the audio order, narration window, dialogue window, and any silent action / reaction window. Do not assume that narration can be added after the video is generated.

Each Shot must pass a pre-generation feasibility check:

- `shot_duration_s` is fixed within the allowed range (4–10s).
- `narration_text`, `narration_start_s`, `narration_end_s`, and estimated narration duration are present, or narration is explicitly null.
- `dialogue_line_text`, `dialogue_start_s`, `dialogue_end_s`, and the expected speaker are present, or dialogue is explicitly null.
- The narration and dialogue intervals plus the 0.20s guard gap fit inside the shot bounds.
- The visual action plan contains a readable non-speaking action / reaction during every narration window; speaking mouth movement is reserved for dialogue windows.
- If the budget fails, block that shot's generation and propose the smallest change: shorten/split narration, move its window, split the shot, or extend it up to 10s. Obtain approval before changing locked text, windows, or shot contracts. Never submit an overfull shot hoping generation creates room.

Required constraints:

~~~text
if narration comes first: narration_end + 0.20s <= dialogue_start
if dialogue comes first: dialogue_end + 0.20s <= narration_start
cross-shot: next_speech_start_global - current_speech_end_global >= 0.20s
shot_start <= every interval <= shot_end
~~~

Every Shot row records `shot_id`, `shot_duration_s`, global shot bounds, `audio_order`, `narration_text`, `narration_start/end`, `narration_duration_estimate`, `dialogue_line_text`, `dialogue_start/end`, `dialogue_duration_budget`, `silent_action_window`, `dialogue_source_file`, `speaker`, narrator voice id, speed, pause policy, delivery style, and `pre_generation_window_check`. These narrator fields must match the episode lock exactly. Validate both within-shot and cross-shot windows before video generation.

## STEP 4: Storyboard and anchors

Each shot has one main information/emotion job, blocking, spatial positions, camera axis, eyelines, depth layers, start state, action progression, end-state handoff, `script_line_ids`, `referenced_asset_ids`, `asset_bindings`, and the complete audio timeline. Every visible character, including secondary characters and extras, must map to a specific character-card asset ID. Keep speaking faces and mouth movement readable. Add the 2D cel/webtoon style block to every prompt.

The storyboard is also an audio blocking document. For each Shot, explicitly stage what the viewer sees during narration, what the speaking character does during dialogue, and where the camera holds a silent reaction or action. Put the narration and dialogue text, their exact planned positions, estimated durations, order, and 0.20s guard gap directly in the Shot row. A narration line may not be left as a later post-production wish. The Shot is rejected for generation if its planned speech windows do not fit.

For spatial continuity, define a screen-space layout for every shot (left/center/right, foreground/midground/background), each character's facing direction and eyeline target, the 180-degree axis, and entry/exit direction. Reuse the previous shot's layout ledger unless a deliberate cut or axis reset is declared. Do not let H3 infer an unbound secondary character from text alone.

Before video generation, ask the user to choose `768P` or `2K`; lock the selected resolution for the episode. Video generation defaults to MiniMax-H3 with `generation_mode=platform-supported reference mode`; an explicitly selected alternative must pass capability checking first. Every shot must bind its actual character, scene, prop, wardrobe, and other required assets through `asset_manifest`, including stable IDs, paths, and SHA-256 hashes; do not submit a shot when any character/scene/prop binding is missing. First-frame or last-frame images may be used as optional continuity references, but first-frame image-to-video is not required.

Run the `script-prompt-contract` before submission: show each shot's script line IDs, exact narration/dialogue text, asset bindings, spatial layout, planned audio order, narration window, dialogue window, silent action window, estimated narration duration, and final prompt for user confirmation. The submitted prompt must carry the script line IDs and manifest version hashes. Compare the request log back against the manifests; any missing, added, rewritten, reordered, overfull audio budget, or narrator-as-dialogue text fails the shot.

## STEP 5: Generate and capture original dialogue

For input-video workflows, extract original audio without overwriting the source. For H3 workflows, retain the dialogue line, speaker, dialogue window, silent narration windows, and `dialogue-only; no narrator, voiceover, commentary, or descriptive speech` constraint. Stage silent visual action during narration windows. Archive complete returned audio, run ASR/speaker segmentation, and compare each speech segment with the approved dialogue. Use a separately returned original dialogue stem when available, preserving full-track evidence. If unsolicited narration contaminates the only track, mark that shot's source unqualified, report evidence, and propose an authorized retry of that shot or user-supplied clean original audio. Do not rerender automatically or discard qualified neighbors. Any new video requires fresh dialogue/timing evidence. Never hide contamination by overlaying narration, muting arbitrary regions, vocal separation, or dialogue TTS.

## STEP 5A: Audio separation gate

The default and required path is separate audio: H3 shot audio may contain only video-original dialogue and natural ambience / SFX. It must not contain narration, voice-over, commentary, or descriptive speech. Do not send a narration master or narration slice into ordinary shot generation. This separation is required because H3 cannot reliably reproduce one locked narrator voice across independently generated shot audio tracks.

If a shot contains unsolicited narration, an extra speaker, or speech untraceable to approved dialogue, record the failed shot and evidence without automatic regeneration. Only after scoped retry authorization, correct the contamination-causing instruction and recapture evidence. Never conceal it through muting, vocal separation, volume reduction, or masking overlays. Preserve other approved shots and stop under the common limits.

A prelocked audio bed is an exception only after capability confirmation of unchanged preservation and explicit user approval of the contract exception. It is not the default, does not authorize generating narration inside H3 or final mixing, and cannot bypass the narration-handoff stop point.

## STEP 6: Generate the separate episode narration master

After storyboard feasibility and real dialogue windows are locked, generate approved narration in script order within the authorized first-pass scope as one TTS batch/session or unified master. Preserve the locked voice ID, profile/reference hash, speed, pitch, baseline emotion, pauses, volume, sample rate, codec, loudness, and delivery style. Record each slice's line ID, source text, real batch provenance, master interval, and actual file hash. Use alignment/ASR plus listening to verify wording; uncertainty stays unverified, not proof that the whole batch failed.

Local omissions, additions, wrong words/order, or audible drift first identify affected lines/intervals. Distinguish annotation errors, slice-boundary errors, and actual synthesis defects. Prefer correcting metadata or lossless reslicing when sufficient, without new synthesis. For actual defects, apply the authorized local-repair exception in `references/voice-presets.md`: preserve the full lock and context, generate only approved affected lines in an honestly recorded repair batch, compare against retained audio, and approve before replacement. On failure, stop or propose another scoped plan rather than expanding to the full batch.

Normal slicing remains lossless and never changes a shot's speed or emotion. Measure real durations and update timing; recheck changed lines and affected global speech boundaries while retaining compatible media. If a full replacement is truly needed, show evidence and why a local repair cannot meet the lock, then obtain separate whole-batch authorization. Archive the prior master and approved version.

Timing alternatives are rewrite/split text, move a window, split a shot, or extend it up to 10s; they are proposals, not an automatic ladder. Approve script/shot-contract revisions before changing locked records, and regenerate media only if needed and authorized. Never conceal overlap by speeding up, truncating, crossfading voices, ducking, muting words, or reducing a voice. This stage validates separate stems and the intended timeline with at least 0.20s gaps; it does not perform final mixdown. Report unresolved conflicts at the handoff/decision point without entering final export.

## STEP 7: Narration handoff and workflow completion

Hand off and end after the authorized narration has been generated, measured, and checked against approved text, including the unified first pass and approved local repairs with honest segment provenance. If a stop condition leaves failed, missing, or unverified items, provide a labeled partial/review handoff under the governing rules rather than continuing generation. Do not automatically enter final video assembly, subtitle burn-in, BGM/SFX mixing, or exported-file QC.

Provide the user with the narration master or narration slices, their timing metadata, the preserved original dialogue tracks, the shot-level audio timeline, and the relevant subtitle timing sources so the user can assemble and edit the episode in their preferred editor. The user may choose cuts, transitions, BGM, ambience, SFX, subtitle styling, ducking, and final export independently.

A later explicit editing/assembly request is a new task with its own scope and authorization; use an appropriate workflow or editor, never automatically continue this Skill. Keep stems separate until measured speech gaps are at least 0.20s. If the new task requires narration/dialogue repair, return only the authorized lines/shots to STEP 6/STEP 5 and recapture evidence, not the whole episode.

## STEP 8: Handoff package

Package the in-scope narration master/batch files, approved local pickups and replacement map, honest per-segment batch/hash provenance, source text and timing, preserved original dialogue, `shot_audio_timeline.yaml`, dialogue/narration subtitle timing sources, existing clips/cards/storyboards, checks, and unresolved findings. STEP 8 only organizes existing materials; disclose missing items rather than generating them automatically. Never claim final video assembly or exported-file QC is complete.

End the handoff when the authorized narration outputs, text/timing findings, and handoff materials are available on canvas. Label failed, unverified, and missing items; partial handoff is not full qualification. Do not cross the stop point to manufacture a final film or finished subtitles. Final editing and assembly remain the user's decision.

See SKILL.cn.md for the Chinese workflow and the references/ templates for the data contracts.
