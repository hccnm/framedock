---
name: interior-modeling-render
description: Create editable Blender interiors from plans, photos, briefs, or references, then deliver an approved model and a photoreal one-take walkthrough. Not for construction safety advice.
trigger-words: [interior modeling, Blender interior, architectural visualization, room render, floor plan to 3D, walkthrough video, 室内建模, 室内渲染, Blender建模, 户型图建模, 一镜到底漫游, 实景漫游]
---

# Interior Modeling and Rendering

Use this Skill for interior planning, spatial visualization, editable Blender modeling, model review, one-take walkthrough capture, photoreal rendering, and optional final delivery. Follow the default model policy below for spatial reasoning, design-decision synthesis, and continuity checks; do not silently switch models. The workflow has two input branches and replaces the white-model checkpoint with a detailed colored axonometric concept checkpoint.

### Default model policy

- Prefer the user-specified `GPT-6-Astra` for spatial reasoning, design decisions, and continuity assessment. This is an execution preference, not a claim that the Skill can switch the active conversation model; actual availability belongs to the runtime.
- Default image generation and editing to **GPT Image 2.5 Sunburst** for plan concepts, axonometric concepts, photoreal appearance anchors, and image corrections. Actual Blender scene rendering remains a Blender operation; never substitute a generated image for a claimed model render.
- Default both STEP 4 walkthrough generation and STEP 5 photoreal video treatment to **MiniMax H3**, after checking current support for the actual references, duration, and framing.
- Honor an explicit model choice after checking its support for the confirmed inputs and settings. If it fails, make one cause-specific correction; if it still cannot complete the task, report the change and use another compatible model instead of repeatedly retrying the same model.
- Model names do not guarantee quality. Preserve confirmed dimensions, framing, duration, and audio. A request for realism does not automatically authorize a more expensive quality tier.

### Minimal canvas delivery (mandatory throughout)

- The canvas is for necessary deliverables and unresolved review decisions, not a process log. Before producing an artifact, classify it as a necessary deliverable for this request, a necessary pending review, or internal processing/QA. Only the first two may be shown. Expand the scope only when the user explicitly requests extra views or comparisons.
- Keep extracted frames, opening/middle/ending screenshots, detail checks, contact sheets or grids, collision/cut diagnostics, low-sample route previews, test clips, failed retries, and intermediate audio files in an internal project process directory by default. Do not publish them as separate canvas assets or create media cards or lengthy explanation cards merely to prove that checks occurred. Still inspect the complete video; a tidy canvas is not permission to skip QA.
- Reuse approved models, routes, and suitable appearance anchors. Show only one current necessary reference when a creative decision actually remains unresolved; do not default to separate endpoint, continuity, or multi-angle screenshot cards. When proceeding from an approved model, do not regenerate or republish plans, axonometrics, or the model package.
- Keep one current delivery entry per deliverable for this request. Never import an automatically placed output again. Where supported and safe for user content, update the corresponding agent-created artifact from this round in place rather than accumulating old drafts, new drafts, and duplicate cards. Display versions side by side only on an explicit comparison request.
- Check automatic canvas-publication behavior before execution. Prefer local-only processing, direct analysis, or checks that produce no asset. If a capability necessarily adds a visible node and cannot safely replace it or avoid displaying it, explain the limitation and obtain agreement for the necessary display or an alternative workflow first. Do not assume hiding/deletion capabilities exist or claim an artifact was hidden when it was not. Grouping unwanted assets does not satisfy a no-display requirement.
- Preserve the approved uncut shot and duration. Do not insert diagnostic screenshots, still-image sequences, cut-test clips, extra transitions, or prolonged holds, and do not pad the runtime. Failed clips are internal diagnostics, not final deliverables or extra showcase outputs.
- This policy does not authorize retroactive canvas cleanup. Do not delete, move, or hide historical nodes, user uploads, or other tasks' outputs without an explicit request. Updating the Skill itself must not generate example screenshots or media.

## STEP 1: Classify the spatial input

Classify the user's main input before designing:

- **Colored 2D floor plan:** treat walls, openings, room adjacency, circulation, and fixed elements as authoritative.
- **Real-space photograph:** infer only visible spatial relationships, room depth, openings, furniture placement, and likely circulation; mark uncertain geometry and do not claim exact dimensions.
- **Text-only brief or mixed references:** establish a provisional spatial brief, identify missing dimensions or adjacency decisions, and ask only the questions that block a coherent plan.

An uploaded Blender scene or measured CAD plan is authoritative when provided. A style image contributes materials, lighting, furniture language, and atmosphere, not geometry unless the user explicitly assigns it structural authority.

## STEP 2: Build or reconstruct the colored 2D plan

For a colored 2D plan, cleanly interpret and preserve its structure. Do not regularize an irregular outline, move walls, invent openings, merge rooms, or silently correct the user's plan.

For a real-space photograph or text brief, first infer a proposed spatial relationship map and produce a colored 2D floor-plan layout. Clearly label estimated dimensions, inferred openings, and unresolved assumptions. Never present photo-based inference as a measured construction drawing.

The plan should show walls, doors and swing directions, windows, fixed kitchen and bathroom elements, furniture footprints, circulation, functional zones, and dimensions when supported. If exact dimensions are unavailable, use an explicit estimate label and request confirmation before modeling.

Pause after delivering the 2D plan. If the user requests structural changes, revise the plan before continuing. Proceed only after the user confirms the plan or gives equivalent approval.

## STEP 3: Generate the detailed concept, model in Blender, and deliver the model package

After the approved 2D plan is available, generate a detailed 3D axonometric or cutaway concept image before calling Blender. This is not a white model. It must show spatial structure plus proposed materials, furniture, lighting direction, soft furnishings, storage logic, and the intended design language.

Strictly preserve the approved plan's walls, openings, adjacency, scale relationships, fixed facilities, furniture logic, and circulation. Apply style references only to materials, colors, furniture forms, lighting, and decor. For an inferred photo/text plan, keep uncertain geometry provisional and identify it in the review note.

Pause and obtain approval of the 2D plan plus the detailed axonometric concept. Structural changes require revising the 2D plan first; material or decor changes may revise only the concept.

Only after this approval, create or refine the editable Blender scene. Build the approved walls, openings, fixed facilities, furniture, materials, lighting, cameras, and approved soft furnishings. Keep estimated dimensions clearly marked in project metadata when no measured source exists.

When this request creates or modifies a model and model approval is needed, deliver only the following package under the minimal-canvas policy. Do not republish it when proceeding from an already approved model:

1. **Editable Blender project file** containing the modeled scene;
2. **One necessary Blender modeling axonometric render** showing the actual modeled scene, structure, furniture, and spatial relationships; do not add detail or multi-view screenshots by default.

If the canvas does not support the model file type, provide its actual file link in the reply rather than creating substitute screenshots or explanation cards.

The modeling axonometric render is a review artifact, not the final photoreal video look. Pause again and wait for the user to confirm the delivered model package or request modifications. If the user requests changes, modify Blender and update the current project and necessary render under the minimal-canvas policy without accumulating historical versions.

## STEP 4: Record the continuous one-take interior walkthrough

Only after the user confirms the Blender model package, use the Blender scene's **main camera** to create one continuous, uncut interior walkthrough. The default movement language is a smooth, cinematic **drone-style indoor camera move**: fluid gliding, gentle elevation and heading changes, and a stable sense of spatial flow rather than handheld walking.

Default capture requirements:

- **Camera:** call and animate the existing scene main camera; do not silently replace it with an unrelated camera. If no main camera is assigned, assign the approved walkthrough camera and record that choice in the review note;
- **Duration:** 8–15 seconds, selected to fit the requested spatial scope;
- **Video model:** MiniMax H3;

- **Camera height:** keep the viewpoint physically plausible for an indoor drone-style move, normally between 1.5 m and 2.2 m above the floor unless the user explicitly requests another height;
- **Camera motion:** smooth, continuous, and connected, with a controlled forward glide, slow orbiting or panning to reveal the room, and gentle turns only where the approved circulation requires them;
- **Lighting and atmosphere:** begin in bright daytime natural light and preserve a coherent, inviting, atmosphere-rich interior throughout the shot, with stable exposure and no abrupt lighting changes;
- **Coverage:** completely show every space explicitly requested by the user, following real adjacency and the approved circulation path;
- **Layout fidelity:** strictly preserve the modeled walls, doors, windows, furniture placement, furniture silhouettes and forms, fixed facilities, proportions, materials, and spatial relationships;
- **Format default:** 16:9 horizontal unless the user specifies another ratio.

### STEP 4 prompt template

When generating the one-take walkthrough from the modeled Blender scene, use the following prompt as the core video-generation instruction, adapting only confirmed scene facts, route, viewpoint height, duration, and format:

> Generate a continuous 10-second, 16:9 horizontal one-take spatial walkthrough video. Use the provided spatial image or approved scene setup as the visual basis; for this workflow, use the modeled Blender scene as the authoritative visual reference. If an explicit opening frame is specified, begin naturally from that frame. Preserve the existing spatial structure, scale relationships, connections between areas, and the position, form, and materials of fixed objects. Continue the original scene's time, weather, and lighting conditions. Do not add or remove objects, change the layout, or create nonexistent passages.
>
> Camera movement: start from the approved camera position and choose a short, coherent exploration route through actually traversable areas. Move smoothly and slowly at a natural eye-level viewpoint, with slight horizontal turns, continuously revealing the main spatial layers, characteristic structures, and nearby details. Let framing change through real camera movement, preserving plausible perspective, parallax, and foreground/background occlusion. Match route length to the requested duration; do not force the camera through multiple areas. In confined spaces, use short advances, small lateral shifts, and gentle turns; in open spaces, progressively follow a clear feasible route. Decelerate naturally at the end and stop on a composition that clearly explains the spatial relationship.
>
> Continuity: use one uninterrupted shot with a stable focal length, coherent camera height, and level horizon. Use smooth acceleration and deceleration. Respect all spatial boundaries: do not pass through walls, terrain, closed doors or windows, or other solid objects. Do not teleport, jump-cut, use transitions, suddenly zoom, or introduce implausible vertical drifting. Keep fixed structures and static objects stable: no deformation, flicker, or sliding with the camera. Existing dynamic elements such as water or vegetation may move only naturally under the scene conditions. Camera movement is the primary visual change; do not add people, subtitles, or overlaid text.
>
> Image and sound: present realistic spatial-photography quality with continuous exposure and lighting, view-dependent natural reflections, physically plausible shadows, detailed dark areas, and controlled highlights. Keep only subtle realistic ambient sound appropriate to the current space, with reverberation matching whether the space is open or enclosed. No dialogue, music, footsteps, or additional sound effects.

The shot must begin at the approved starting point and end at the approved destination after the requested spaces have been visibly covered. The motion must feel like one uninterrupted camera flight. Do not use cuts, transitions, teleportation, wall penetration, floating through solid objects, sudden zooms, invented rooms, changing furniture designs, layout substitutions, or unapproved camera paths. Keep speed readable and allow the room to breathe; never cover more space through impossible acceleration.

Show one complete walkthrough only when it is a requested standalone deliverable or a genuinely unapproved route requires user review; pause as needed. When the route is approved and photoreal treatment is requested, inspect route references and process previews internally without additional canvas publication or separate cut-check clips. If the user requests a route or motion change, revise STEP 4 while keeping the approved Blender model, main-camera assignment, home layout, and furniture forms fixed.

## STEP 5: Apply physical-world photoreal rendering to the walkthrough

### Required supplement: photographic standards and acceptance

Whenever STEP 5 runs, first read `references/step5-photoreal-addendum.md` and integrate its reference roles, appearance-anchor preflight, lighting branches, core prompt, full-video acceptance, and at-most-two-retries rule into the existing workflow below. Retain this section and its original prompt. Explicit user requirements and approved project conditions take precedence; examples such as 3500K and 24mm are not hard defaults. Never promise that every generative run will succeed; strict frame-by-frame geometry requires actual Blender animation rendering or disclosure of generative limitations.


After the walkthrough route is accepted, render the recorded walkthrough as a coherent real-physical-world interior video. The final result should feel like a real camera recording inside the modeled space, not a game-engine preview or a sequence of unrelated generated frames.

Preserve the walkthrough's exact spatial path, timing, viewpoint height, speed, room order, geometry, furniture, and framing. Apply one consistent physical lighting and material system across the entire shot: realistic daylight direction, plausible indoor illumination, physically coherent reflections and refractions, natural diffuse response, contact shadows, exposure continuity, realistic depth and atmospheric falloff, and stable white balance. Materials must retain visible wood, stone, metal, glass, textile, ceramic, and painted-surface behavior without plastic or artificial CGI appearance.

The final video must maintain temporal consistency: no furniture morphing, wall movement, material flicker, changing room dimensions, duplicated objects, disappearing props, or lighting jumps. Keep the original room tone or approved natural ambience unless the user requests another audio treatment. Do not add subtitles, logos, or text unless explicitly requested.

### STEP 5 photoreal rendering prompt and intelligent invocation

For STEP 5, use the following rendering instruction as the default prompt core. Adapt only confirmed scene facts, the approved walkthrough route, user-requested time/weather/light/material changes, duration, and aspect ratio; never weaken the geometry or continuity locks:

> Render the approved walkthrough as an ultra-photorealistic real-world interior video, as if captured by a professional full-frame camera or high-end phone inside the actual space. Preserve the exact architectural structure, wall relationships, floors, ceilings, doors, windows, cabinetry, furniture layout, object count, proportions, geometry, functional zoning, camera path, timing, viewpoint height, speed, room order, and framing. Do not redesign the space or move, remove, duplicate, or add major objects.
>
> Reconstruct physically plausible materials for every visible surface: painted walls, wood flooring and cabinetry, stone, metal, glass, ceramic, textiles, upholstery, curtains, and decor must show natural micro-texture, believable roughness, view-dependent reflections and refractions, soft diffuse response, contact shadows, and distinct material layering. Eliminate plastic, toy-like, waxy, over-smoothed, game-engine, and obvious CG appearance. Preserve the source colour relationships unless the user explicitly requests a change.
>
> Use physically coherent daylight entering from real openings, with believable falloff, bounce light, shadow direction, ambient occlusion, and atmospheric depth. Preserve existing fixture states; when fixtures are on, blend a restrained warm interior light around 3500K with daylight rather than flattening the scene. Keep highlights controlled, retain detail in dark areas, lock white balance, and avoid HDR halos, crushed blacks, blown highlights, false reflections, and inconsistent exposure.
>
> Present natural architectural-photography perspective with a wide but non-distorted interior field of view, approximately 24 mm equivalent when compatible with the approved camera, moderate depth of field, accurate perspective, restrained sharpening, and no artificial beauty retouching. The result must look lived-in but clean, realistic and buildable, with visible real-world spatial depth rather than a render preview.
>
> Across the entire moving shot, keep walls, openings, furniture, people, reflections, shadows, textures, perspective, lighting, and materials temporally stable. No morphing, flicker, sliding, duplication, disappearance, texture stretching, broken seams, floating objects, geometry offsets, camera shake, wall penetration, jump cuts, teleportation, sudden zooms, or layout substitutions. Keep only subtle space-appropriate ambience; no dialogue, music, footsteps, subtitles, logos, watermarks, or unrelated decoration.

Invocation rules:

- Use this full prompt core by default whenever the user asks to enter STEP 5, create the final physical-world render, make the walkthrough ultra-realistic, or remove CGI/render-engine appearance.
- If the user supplies explicit lighting, material, weather, time, camera, or audio requirements, preserve those requirements and modify only the corresponding clauses; never replace them with defaults.
- If the user asks only for route or motion changes, stay in STEP 4 and do not invoke this rendering pass. If the route is approved and the user asks for both motion and realism, complete or reuse STEP 4 first, then invoke STEP 5.
- Use the approved walkthrough as the motion and continuity authority, and the approved Blender scene/opening frame as the geometry and material authority. Do not treat the photoreal pass as permission to invent a new room, redesign furniture, or change the camera path.
- Before generation, check that the input walkthrough, opening frame or scene reference, duration, ratio, and requested audio treatment are available. If a required route or source is missing, ask for the smallest blocking decision instead of improvising.
- After delivery, inspect for the specific failure risks above. If geometry and motion are correct but realism is weak, rerun STEP 5 only with stronger physical-material, exposure, reflection, and temporal-consistency emphasis; do not alter the approved route or model.

## STEP 6: Final renders and delivery

Deliver only the validated outputs actually needed for this request, preserving spatial identity, material system, time of day, and lighting logic. An end-to-end video request defaults to one final photoreal walkthrough; provide the actual model-file link when needed without duplicate canvas publication. Show stage outputs or additional views only when explicitly requested or required for a pending review. The STEP 1–5 output list is not a mandatory attachment bundle to republish every round. Do not append process screenshots, failed versions, test clips, or unrelated cutaway footage.

Use returned asset paths and names; do not claim exact dimensions when the source was estimated.

## Recovery rules

- If the plan is rejected, repair STEP 2 first.
- If the concept is rejected, revise the concept from the approved plan.
- If the Blender model package is rejected, modify Blender and re-deliver the project and modeling axonometric render.
- If walkthrough motion is wrong but geometry is approved, regenerate STEP 4 without changing the model.
- If photoreal rendering is wrong but motion and geometry are approved, regenerate STEP 5 without changing route or model.
- If media constraints fail, apply the smallest deterministic trim, crop, or format correction and preserve the creative intent.
